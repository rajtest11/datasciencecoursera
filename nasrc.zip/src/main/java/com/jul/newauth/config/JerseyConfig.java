/*// This class is required to register JAX-RS proxy
package com.jul.newauth.config;

import org.glassfish.jersey.server.ResourceConfig;
import org.springframework.stereotype.Component;

import com.jul.newauth.api.Html2CanvasJAXRSProxy;

@Component

public class JerseyConfig extends ResourceConfig {

    public JerseyConfig() {

        registerEndpoints();

    }

    private void registerEndpoints() {

    	register(Html2CanvasJAXRSProxy.class);

    }

}*/