package com.jul.newauth.config;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.EnumSet;
import java.util.Properties;

import javax.servlet.DispatcherType;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.config.YamlPropertiesFactoryBean;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.boot.yaml.SpringProfileDocumentMatcher;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
import org.springframework.core.io.ClassPathResource;
import org.springframework.util.StringUtils;
import org.springframework.web.filter.CharacterEncodingFilter;

import com.jul.newauth.model.LocalHostVO;

@Configuration
public class NewAuthApplicationConfig {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(NewAuthApplicationConfig.class);
	
	@Bean
	public static PropertySourcesPlaceholderConfigurer properties() {
		String activeProfile = System.getenv("spring.profiles.active");
		
		LOGGER.info("Active Profile: " + activeProfile);
		
		if (StringUtils.isEmpty(activeProfile)) {
			activeProfile = "default";
			LOGGER.info("Setting Active Profile: " + activeProfile);
		}
		
		PropertySourcesPlaceholderConfigurer placeholderconfigurer = new PropertySourcesPlaceholderConfigurer();
		
		YamlPropertiesFactoryBean yamlbean = new YamlPropertiesFactoryBean();
		yamlbean.setDocumentMatchers(new SpringProfileDocumentMatcher(activeProfile));
		yamlbean.setResources(new ClassPathResource("newAuthConfig.yml"));
		
		Properties properties = yamlbean.getObject();
		placeholderconfigurer.setProperties(properties);
		
		LOGGER.info("Loaded properties: " + properties);
		return placeholderconfigurer;
		
	}
	
	@Bean
    public LocalHostVO hostip() {
		LocalHostVO out = new LocalHostVO();
        try {
			out.setHostip( InetAddress.getByName(InetAddress.getLocalHost().getHostAddress()));
		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        return out;
    }
	
	
	/* @Bean
	    public FilterRegistrationBean charEncodingFilter() {
	        FilterRegistrationBean registration = new FilterRegistrationBean();
	        
	        CharacterEncodingFilter encodingFilter =  new CharacterEncodingFilter();
	        encodingFilter.setForceEncoding(true);
	    	   encodingFilter.setEncoding("UTF-8");
	    	   registration.setFilter(encodingFilter);
	        registration.setDispatcherTypes(EnumSet.allOf(DispatcherType.class));
	        registration.addUrlPatterns("/authenticate");
	        return registration;
	    }
	*/

}
