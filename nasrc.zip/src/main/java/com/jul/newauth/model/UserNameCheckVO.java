package com.jul.newauth.model;

public class UserNameCheckVO {
	
	private String userName;
	private String usernameclear;
	private String response;
	private String clientip;
	private String clientsession;

	
	
	
	

	public UserNameCheckVO(String userName, String usernameclear, String response, String clientip,
			String clientsession) {
		super();
		this.userName = userName;
		this.usernameclear = usernameclear;
		this.response = response;
		this.clientip = clientip;
		this.clientsession = clientsession;
	}



	public UserNameCheckVO() {
		
	}



	public String getResponse() {
		return response;
	}

	public void setResponse(String response) {
		this.response = response;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}



	public String getUsernameclear() {
		return usernameclear;
	}



	public void setUsernameclear(String usernameclear) {
		this.usernameclear = usernameclear;
	}



	public String getClientip() {
		return clientip;
	}



	public void setClientip(String clientip) {
		this.clientip = clientip;
	}



	public String getClientsession() {
		return clientsession;
	}



	public void setClientsession(String clientsession) {
		this.clientsession = clientsession;
	}
	
	

}
