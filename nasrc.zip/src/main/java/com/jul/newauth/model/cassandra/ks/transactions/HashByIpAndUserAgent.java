package com.jul.newauth.model.cassandra.ks.transactions;

import java.net.InetAddress;
import java.util.Date;
import java.util.UUID;

import com.datastax.driver.core.PreparedStatement;
import com.datastax.driver.core.ResultSet;
import com.datastax.driver.core.Session;
import com.datastax.driver.mapping.Mapper;
import com.datastax.driver.mapping.MappingManager;
import com.datastax.driver.mapping.Result;
import com.datastax.driver.mapping.annotations.ClusteringColumn;
import com.datastax.driver.mapping.annotations.Column;
import com.datastax.driver.mapping.annotations.PartitionKey;
import com.datastax.driver.mapping.annotations.Table;
import com.jul.newauth.model.cassandra.ks.users.UsersByUserid;

@Table(keyspace = "newauthtransactions", name = "hashbyipua")
public class HashByIpAndUserAgent {

	private UUID userid;
	@PartitionKey(0)
	@Column(name = "ip")
	private InetAddress ipaddress;
	private String useridhash;
	@ClusteringColumn(0)
	private String username;
	private String fullname;
	@Column(name = "init")
	private boolean initdevice; // This is the device the user was created from
	@Column(name = "remote")
	private boolean remotedetection; // The user was detected by this device remotely

	@Column(name = "height")
    private int devicedisplayheight ;
   	@Column(name = "width")
    private int devicedisplaywidth ;
	@PartitionKey(1)
	private String useragent;
	
	@Column(name = "indcnf")
    private Date individualconfirmdate;
    @Column(name = "grpcnf")
	private Date groupconfirmdate;
    @Column(name = "pubcnf")
	private Date publicconfirmdate;
	
    private static MappingManager manager;
    
    private static PreparedStatement readentityps = null;
    
	 
	public HashByIpAndUserAgent() {
		
		
	}

	public HashByIpAndUserAgent(UUID userid, InetAddress ipaddress, String useridhash, String username, String fullname,
			boolean initdevice, boolean remotedetection, int devicedisplayheight, int devicedisplaywidth,
			String useragent, Date individualconfirmdate, Date groupconfirmdate, Date publicconfirmdate) {
		super();
		this.userid = userid;
		this.ipaddress = ipaddress;
		this.useridhash = useridhash;
		this.username = username;
		this.fullname = fullname;
		this.initdevice = initdevice;
		this.remotedetection = remotedetection;
		this.devicedisplayheight = devicedisplayheight;
		this.devicedisplaywidth = devicedisplaywidth;
		this.useragent = useragent;
		this.individualconfirmdate = individualconfirmdate;
		this.groupconfirmdate = groupconfirmdate;
		this.publicconfirmdate = publicconfirmdate;
	}


	public UUID getUserid() {
		return userid;
	}
	public void setUserid(UUID userid) {
		this.userid = userid;
	}
	public InetAddress getIpaddress() {
		return ipaddress;
	}
	public void setIpaddress(InetAddress ipaddress) {
		this.ipaddress = ipaddress;
	}
	public String getUseridhash() {
		return useridhash;
	}
	
	public void setUseridhash(String useridhash) {
		this.useridhash = useridhash;
	}
	public String getUsername() {
		return username;
	}


	public void setUsername(String username) {
		this.username = username;
	}


	public String getFullname() {
		return fullname;
	}


	public void setFullname(String fullname) {
		this.fullname = fullname;
	}


	public boolean isInitdevice() {
		return initdevice;
	}
	public void setInitdevice(boolean initdevice) {
		this.initdevice = initdevice;
	}
	public boolean isRemotedetection() {
		return remotedetection;
	}

	public void setRemotedetection(boolean remotedetection) {
		this.remotedetection = remotedetection;
	}

	public int getDevicedisplayheight() {
		return devicedisplayheight;
	}
	public void setDevicedisplayheight(int devicedisplayheight) {
		this.devicedisplayheight = devicedisplayheight;
	}
	public int getDevicedisplaywidth() {
		return devicedisplaywidth;
	}
	public void setDevicedisplaywidth(int devicedisplayimagewidth) {
		this.devicedisplaywidth = devicedisplayimagewidth;
	}
	 
	
	public String getUseragent() {
		return useragent;
	}


	public void setUseragent(String useragent) {
		this.useragent = useragent;
	}


	public Date getIndividualconfirmdate() {
		return individualconfirmdate;
	}


	public void setIndividualconfirmdate(Date individualconfirmdate) {
		this.individualconfirmdate = individualconfirmdate;
	}


	public Date getGroupconfirmdate() {
		return groupconfirmdate;
	}


	public void setGroupconfirmdate(Date groupconfirmdate) {
		this.groupconfirmdate = groupconfirmdate;
	}


	public Date getPublicconfirmdate() {
		return publicconfirmdate;
	}


	public void setPublicconfirmdate(Date publicconfirmdate) {
		this.publicconfirmdate = publicconfirmdate;
	}


	public void createViaMapper(Session sess) {
		
		if (manager == null)
			manager = new MappingManager(sess);

		Mapper<HashByIpAndUserAgent> mapper = manager.mapper(HashByIpAndUserAgent.class);
		
		long starttime = System.currentTimeMillis();
		mapper.saveAsync(this);
		System.out.println("Added HashByIpAndUserAgent entry - Asynch : "  + " IP : "  + this.getIpaddress().toString() + " in " + (System.currentTimeMillis() - starttime) + "ms");
		
	}
	
	
	public HashByIpAndUserAgent readViaCQLAndMapper(Session sess) {
		long starttime = System.currentTimeMillis();
		if (manager == null)
			manager = new MappingManager(sess);
		
		Mapper<HashByIpAndUserAgent> mapper = manager.mapper(HashByIpAndUserAgent.class);
		
		if (readentityps == null)
			readentityps = sess.prepare( " select userid, ip, useridhash, username, fullname, init, remote, useragent, height, width, indcnf, grpcnf, pubcnf  from newauthtransactions.hashbyipua where ip = ? and useragent = ? and username = ?");
		
		ResultSet rs = sess.execute(readentityps.bind(this.getIpaddress(), this.getUseragent(), this.getUsername()));
		
		Result<HashByIpAndUserAgent> out = mapper.map(rs);
		
		System.out.println("Read HashByIpAndUserAgent back via cql in: " + (System.currentTimeMillis() - starttime) + "ms" );
		
		return out.one();
	}
	
	public Result<HashByIpAndUserAgent> readViaIPAndUserName(Session sess, InetAddress ip, String username) {
		// This WILL NOT WORK because user agent is part of partition key
		if (manager == null)
			manager = new MappingManager(sess);
		
		Mapper<HashByIpAndUserAgent> mapper = manager.mapper(HashByIpAndUserAgent.class);
		long starttime = System.currentTimeMillis();

		ResultSet results = sess.execute("SELECT * FROM newauthtransactions.hashbyipua where ip = '" + ip.getHostAddress() + "' and username = '" + username + "'");
		Result<HashByIpAndUserAgent> out = mapper.map(results);
		
		for (HashByIpAndUserAgent u : out) {
		    System.out.println("Users from IP : " + ip.toString() + " - "+ u.getUsername());
		}
		
		System.out.println("Read HashByIpAndUserAgent by query in: " + (System.currentTimeMillis() - starttime) + "ms" );
		
		return out;
	}
	
	public Result<HashByIpAndUserAgent> readViaIP(Session sess, InetAddress ip) {
		if (manager == null)
			manager = new MappingManager(sess);
		
		Mapper<HashByIpAndUserAgent> mapper = manager.mapper(HashByIpAndUserAgent.class);
		long starttime = System.currentTimeMillis();

		ResultSet results = sess.execute("SELECT * FROM hashbyipua where ip = " + ip);
		Result<HashByIpAndUserAgent> out = mapper.map(results);
		
		for (HashByIpAndUserAgent u : out) {
		    System.out.println("Users from IP : " + ip.toString() + " - "+ u.getUsername());
		}
		
		System.out.println("Read HashByIpAndUserAgent by query in: " + (System.currentTimeMillis() - starttime) + "ms" );
		
		return out;
	}
}
