package com.jul.newauth.model;

import java.net.InetAddress;

public class LocalHostVO  extends BaseVO {
	
	InetAddress hostip;

	public InetAddress getHostip() {
		return hostip;
	}

	public void setHostip(InetAddress hostip) {
		this.hostip = hostip;
	}

}
