package com.jul.newauth.model.cassandra.ks.transactions;

import java.net.InetAddress;
import java.util.Date;
import java.util.UUID;

import com.datastax.driver.core.Session;
import com.datastax.driver.mapping.Mapper;
import com.datastax.driver.mapping.MappingManager;
import com.datastax.driver.mapping.annotations.ClusteringColumn;
import com.datastax.driver.mapping.annotations.Column;
import com.datastax.driver.mapping.annotations.PartitionKey;
import com.datastax.driver.mapping.annotations.Table;

@Table(keyspace = "newauthtransactions", name = "accessbyuidandsession")
public class AccessByUserIDAndSession {

	@PartitionKey(0)
	private UUID userid;
   	private InetAddress ip;
   	
   	@Column(name = "ua")
   	private String useragent;
   	
   	
   	@Column(name = "lstsc")
   	private short lastauthscore;
   	
   	@PartitionKey(1)
   	@Column(name = "sid")
   	private String sessionId;
   	
   	@Column(name = "acc")
   	private Date accesstime;
   	
   	public AccessByUserIDAndSession() {
   		
   	}
   	
   	public static String getInsertQueryStringWithQMarks() {
		
		return " INSERT INTO newauthtransactions.accessbyuidandsession ( userid,ip,ua, acc, lstsc, sid ) values (?, ?, ?, ?,? ,?); " ;
	}
   	
	


	public AccessByUserIDAndSession(UUID userid, InetAddress ip, String useragent, short lastauthscore, String sessionId,
			Date accesstime) {
		super();
		this.userid = userid;
		this.ip = ip;
		this.useragent = useragent;
		this.lastauthscore = lastauthscore;
		this.sessionId = sessionId;
		this.accesstime = accesstime;
	}

	public UUID getUserid() {
		return userid;
	}
	public void setUserid(UUID userid) {
		this.userid = userid;
	}
	
	public InetAddress getIp() {
		return ip;
	}
	public void setIp(InetAddress ip) {
		this.ip = ip;
	}
	public String getUseragent() {
		return useragent;
	}
	public void setUseragent(String useragent) {
		this.useragent = useragent;
	}
	public Date getAccesstime() {
		return accesstime;
	}
	public void setAccesstime(Date accesstime) {
		this.accesstime = accesstime;
	}
   	
	public String getSessionId() {
		return sessionId;
	}

	public void setSessionId(String sessionId) {
		this.sessionId = sessionId;
	}

	public int getLastauthscore() {
		return lastauthscore;
	}

	public void setLastauthscore(short lastauthscore) {
		this.lastauthscore = lastauthscore;
	}

	public void createViaMapper(Session sess) {
	
		MappingManager manager = new MappingManager(sess);

		Mapper<AccessByUserIDAndSession> mapper = manager.mapper(AccessByUserIDAndSession.class);
		
		long starttime = System.currentTimeMillis();
		mapper.saveAsync(this);
		System.out.println("Added AccessByUserID entry - Asynch : "  + " IP : "  + this.getUserid() + " in " + (System.currentTimeMillis() - starttime) + "ms");
		
	}
   	
}
