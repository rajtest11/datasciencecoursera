package com.jul.newauth.model.cassandra.ks.transactions;

import java.net.InetAddress;
import java.util.Date;
import java.util.UUID;

import com.datastax.driver.core.PreparedStatement;
import com.datastax.driver.core.ResultSet;
import com.datastax.driver.core.Session;
import com.datastax.driver.mapping.Mapper;
import com.datastax.driver.mapping.MappingManager;
import com.datastax.driver.mapping.Result;
import com.datastax.driver.mapping.annotations.ClusteringColumn;
import com.datastax.driver.mapping.annotations.Column;
import com.datastax.driver.mapping.annotations.PartitionKey;
import com.datastax.driver.mapping.annotations.Table;

@Table(keyspace = "newauthtransactions", name = "uidbyip")
public class UserIdsByIP {
	
	@PartitionKey
	@Column(name = "ip")
	private InetAddress ipaddress;
	@ClusteringColumn
   	private UUID userid ;
   	@Column(name = "height")
    private int devicedisplayheight ;
   	@Column(name = "width")
    private int devicedisplaywidth ;
    
    @Column(name = "indcnf")
    private Date individualconfirmdate;
    @Column(name = "grpcnf")
	private Date groupconfirmdate;
    @Column(name = "pubcnf")
	private Date publicconfirmdate;
    
    private static MappingManager manager;
    
    public UserIdsByIP() {
    	
    }
    
	
	public UserIdsByIP(InetAddress ipaddress, UUID userid, int devicedisplayheight, int devicedisplaywidth,
			Date individualconfirmdate, Date groupconfirmdate, Date publicconfirmdate) {
		super();
		this.ipaddress = ipaddress;
		this.userid = userid;
		this.devicedisplayheight = devicedisplayheight;
		this.devicedisplaywidth = devicedisplaywidth;
		this.individualconfirmdate = individualconfirmdate;
		this.groupconfirmdate = groupconfirmdate;
		this.publicconfirmdate = publicconfirmdate;
	}





	public InetAddress getIpaddress() {
		return ipaddress;
	}
	public void setIpaddress(InetAddress ipaddress) {
		this.ipaddress = ipaddress;
	}
	public UUID getUserid() {
		return userid;
	}
	public void setUserid(UUID userid) {
		this.userid = userid;
	}
	public int getDevicedisplayheight() {
		return devicedisplayheight;
	}
	public void setDevicedisplayheight(int devicedisplayheight) {
		this.devicedisplayheight = devicedisplayheight;
	}
	public int getDevicedisplaywidth() {
		return devicedisplaywidth;
	}
	public void setDevicedisplaywidth(int devicedisplaywidth) {
		this.devicedisplaywidth = devicedisplaywidth;
	}
	public Date getIndividualconfirmdate() {
		return individualconfirmdate;
	}
	public void setIndividualconfirmdate(Date individualconfirmdate) {
		this.individualconfirmdate = individualconfirmdate;
	}
	public Date getGroupconfirmdate() {
		return groupconfirmdate;
	}
	public void setGroupconfirmdate(Date groupconfirmdate) {
		this.groupconfirmdate = groupconfirmdate;
	}
	public Date getPublicconfirmdate() {
		return publicconfirmdate;
	}
	public void setPublicconfirmdate(Date publicconfirmdate) {
		this.publicconfirmdate = publicconfirmdate;
	}
	
	public static String getInsertQueryStringWithQMarks() {
		
		return " INSERT INTO newauthtransactions.uidbyip (ip, userid, height, width, indcnf, grpcnf, pubcnf ) values (?, ?, ?, ?, ?, ?, ?); " ;
	}
	
	public void createViaMapper(Session session) {
		
		if (manager == null)
			manager = new MappingManager(session);

		Mapper<UserIdsByIP> mapper = manager.mapper(UserIdsByIP.class);
		
		long starttime = System.currentTimeMillis();
		mapper.saveAsync(this);
		
		
		
		System.out.println("Added UserIdsByIP entry - Asynch : " + 
								((this.getUserid() ==null)?"":this.getUserid().toString()) + 
								" IP : "  + this.getIpaddress().toString() + 
								" in " + (System.currentTimeMillis() - starttime) + "ms");
		
		
	}
	
	public void createViaDirectCQL(Session session) {
		long starttime = System.currentTimeMillis();
		PreparedStatement ps = session.prepare(
				   getInsertQueryStringWithQMarks()
				);
		
		session.executeAsync(ps.bind(getIpaddress(), 
										getUserid(), 
										getDevicedisplayheight(), 
										getDevicedisplaywidth(), 
										getIndividualconfirmdate(), 
										getGroupconfirmdate(), 
										getPublicconfirmdate()));
		System.out.println("Added UserIdsByIP entry - Direct CQL : " + 
				((this.getUserid() ==null)?"":this.getUserid().toString()) + 
				" IP : "  + this.getIpaddress().toString() + 
				" in " + (System.currentTimeMillis() - starttime) + "ms");

	}
	
	
	public Result<UserIdsByIP> readViaIPAndUserId(Session sess, InetAddress ip, UUID userid) {
		if (manager == null)
			manager = new MappingManager(sess);
		
		Mapper<UserIdsByIP> mapper = manager.mapper(UserIdsByIP.class);
		long starttime = System.currentTimeMillis();

		ResultSet results = sess.execute("SELECT * FROM newauthtransactions.uidbyip where ip = '" + ip.getHostAddress() + "' and userid = " + userid );
		Result<UserIdsByIP> out = mapper.map(results);
		
		/*for (UserIdsByIP u : out) {
		   // System.out.println("Users from IP : " + ip.toString() + " - "+ u.getUserid());
		}*/
		
		System.out.println("Read UserIdsByIP by query in: " + (System.currentTimeMillis() - starttime) + "ms" );
		
		return out;
	}
}
