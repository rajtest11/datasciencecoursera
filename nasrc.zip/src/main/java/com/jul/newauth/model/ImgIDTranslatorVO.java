package com.jul.newauth.model;

public class ImgIDTranslatorVO {
	
	private String tinyID;
	private String normalID;
	
	private int normalwidth;
	private int normalheight;
	
	private int normalclickx;
	private int normalclicky;
	
	private int matchingClickCount;
	
	
	public String getTinyID() {
		return tinyID;
	}
	public void setTinyID(String tinyID) {
		this.tinyID = tinyID;
	}
	public String getNormalID() {
		return normalID;
	}
	public void setNormalID(String normalID) {
		this.normalID = normalID;
	}
	public int getNormalwidth() {
		return normalwidth;
	}
	public void setNormalwidth(int normalwidth) {
		this.normalwidth = normalwidth;
	}
	public int getNormalheight() {
		return normalheight;
	}
	public void setNormalheight(int normalheight) {
		this.normalheight = normalheight;
	}
	public int getNormalclickx() {
		return normalclickx;
	}
	public void setNormalclickx(int normalclickx) {
		this.normalclickx = normalclickx;
	}
	public int getNormalclicky() {
		return normalclicky;
	}
	public void setNormalclicky(int normalclicky) {
		this.normalclicky = normalclicky;
	}
	public int getMatchingClickCount() {
		return matchingClickCount;
	}
	public void setMatchingClickCount(int matchingClickCount) {
		this.matchingClickCount = matchingClickCount;
	}
	
	

}
