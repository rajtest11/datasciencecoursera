package com.jul.newauth.model;

import java.util.Date;
import java.util.List;
import java.util.UUID;

public class ImageVO {

	private UUID imageid;
	private UUID userid;
	private short imageseq;
	private int imageheight; // e.g. '1024X768
	private int imagewidth;
	private String imagetype;
	private Date createdate;
    private Date lastaccessdate;
    private List<String> tags;
    
    private long imagesize;
    private long checksum;
    private byte[] imagebytes;
    
    
	public UUID getImageid() {
		return imageid;
	}
	public void setImageid(UUID imageid) {
		this.imageid = imageid;
	}
	public UUID getUserid() {
		return userid;
	}
	public void setUserid(UUID userid) {
		this.userid = userid;
	}
	public short getImageseq() {
		return imageseq;
	}
	public void setImageseq(short imageseq) {
		this.imageseq = imageseq;
	}
	public int getImageheight() {
		return imageheight;
	}
	public void setImageheight(int imageheight) {
		this.imageheight = imageheight;
	}
	public int getImagewidth() {
		return imagewidth;
	}
	public void setImagewidth(int imagewidth) {
		this.imagewidth = imagewidth;
	}
	public String getImagetype() {
		return imagetype;
	}
	public void setImagetype(String imagetype) {
		this.imagetype = imagetype;
	}
	public Date getCreatedate() {
		return createdate;
	}
	public void setCreatedate(Date createdate) {
		this.createdate = createdate;
	}
	public Date getLastaccessdate() {
		return lastaccessdate;
	}
	public void setLastaccessdate(Date lastaccessdate) {
		this.lastaccessdate = lastaccessdate;
	}
	public List<String> getTags() {
		return tags;
	}
	public void setTags(List<String> tags) {
		this.tags = tags;
	}
	public long getImagesize() {
		return imagesize;
	}
	public void setImagesize(long imagesize) {
		this.imagesize = imagesize;
	}
	public long getChecksum() {
		return checksum;
	}
	public void setChecksum(long checksum) {
		this.checksum = checksum;
	}
	public byte[] getImagebytes() {
		return imagebytes;
	}
	public void setImagebytes(byte[] imagebytes) {
		this.imagebytes = imagebytes;
	}
	
    
}
