package com.jul.newauth.model;

import java.net.InetAddress;
import java.util.ArrayList;
import java.util.Date;
import java.util.Hashtable;
import java.util.List;
import java.util.UUID;

import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Component;

@Component
@Scope(value="session", proxyMode = ScopedProxyMode.TARGET_CLASS)

public class SessionDataVO {
	
	private DeviceVO deviceinfo;
	private UserVO userinfo;
	private String cookiedata;
	private Date sessioncreatetime;
	private String sessionid;
	private boolean isMobileDevice;
	private int risk;
	private UUID userid;
	private String userauthenticated; // userid of authenticateduser
	private String accessidtype; // How was the user authenticated - username 'U', email 'E', phone 'P', specialID 'S'
	private int lastImageSeq;
	private int authscore;
	private Hashtable<String, String> imgidtotempimgid;
	private Hashtable<String, String> tempimgidtoimgid;
	private List<Integer> authAttempts;
	private List<Integer> userimageseqnumbers;
	private List<Integer> systemimageseqnumbers;
	private List<Integer> systemimageseqnumbersforcollage;
	private Hashtable<String, List<ImgIDTranslatorVO>> currentimagesforuser;
	
	

	public DeviceVO getDeviceinfo() {
		return deviceinfo;
	}

	public void setDeviceinfo(DeviceVO deviceinfo) {
		this.deviceinfo = deviceinfo;
	}

	public UserVO getUserinfo() {
		return userinfo;
	}

	public void setUserinfo(UserVO userinfo) {
		this.userinfo = userinfo;
	}

	
	public UUID getUserid() {
		return userid;
	}

	public void setUserid(UUID userid) {
		this.userid = userid;
	}



	public String getUserauthenticated() {
		return userauthenticated;
	}

	public void setUserauthenticated(String userauthenticated) {
		this.userauthenticated = userauthenticated;
	}

	

	public String getAccessidtype() {
		return accessidtype;
	}

	public void setAccessidtype(String accessidtype) {
		this.accessidtype = accessidtype;
	}

	public int getLastImageSeq() {
		return lastImageSeq;
	}

	public void setLastImageSeq(int lastImageSeq) {
		this.lastImageSeq = lastImageSeq;
	}

	public String getCookiedata() {
		return cookiedata;
	}

	public void setCookiedata(String cookiedata) {
		this.cookiedata = cookiedata;
	}

	public Date getSessioncreatetime() {
		return sessioncreatetime;
	}

	public void setSessioncreatetime(Date sessioncreatetime) {
		this.sessioncreatetime = sessioncreatetime;
	}

	public int getAuthscore() {
		return authscore;
	}

	public void setAuthscore(int authscore) {
		this.authscore = authscore;
	}

	public Hashtable<String, String> getImgidtotempimgid() {
		if (imgidtotempimgid == null) {
			imgidtotempimgid = new Hashtable<String, String>();
		}
		return imgidtotempimgid;
	}


	public Hashtable<String, String> getTempimgidtoimgid() {
		if (tempimgidtoimgid == null) {
			tempimgidtoimgid = new Hashtable<String, String>();
		}
		return tempimgidtoimgid;
	}

	public List<Integer> getAuthAttempts() {
		if (authAttempts == null) {
			authAttempts = new ArrayList<Integer>();
		}
		return authAttempts;
	}

	public String getSessionid() {
		return sessionid;
	}

	public void setSessionid(String sessionid) {
		this.sessionid = sessionid;
	}

	public boolean isMobileDevice() {
		return isMobileDevice;
	}

	public void setMobileDevice(boolean isMobileDevice) {
		this.isMobileDevice = isMobileDevice;
	}

	public int getRisk() {
		return risk;
	}

	public void setRisk(int risk) {
		this.risk = risk;
	}

	public List<Integer> getUserimageseqnumbers() {
		if (userimageseqnumbers == null)
			userimageseqnumbers = new ArrayList<Integer>();
		return userimageseqnumbers;
	}

	public List<Integer>  getSystemimageseqnumbers() {
		if (systemimageseqnumbers == null)
			systemimageseqnumbers = new ArrayList<Integer>();
		return systemimageseqnumbers;
		
	}
	
	public List<Integer>  getSystemimageseqnumbersforcollage() {
		if (systemimageseqnumbersforcollage == null)
			systemimageseqnumbersforcollage = new ArrayList<Integer>();
		return systemimageseqnumbersforcollage;
		
	}

	public Hashtable<String, List<ImgIDTranslatorVO>> getCurrentimagesforuser() {
		
		if (currentimagesforuser == null)
			currentimagesforuser = new Hashtable<String, List<ImgIDTranslatorVO>>();
		return currentimagesforuser;
	}

}
