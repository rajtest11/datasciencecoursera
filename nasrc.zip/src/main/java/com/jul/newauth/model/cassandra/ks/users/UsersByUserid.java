package com.jul.newauth.model.cassandra.ks.users;

import java.net.InetAddress;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import com.datastax.driver.core.Session;
import com.datastax.driver.mapping.Mapper;
import com.datastax.driver.mapping.MappingManager;
import com.datastax.driver.mapping.annotations.Column;
import com.datastax.driver.mapping.annotations.Frozen;
import com.datastax.driver.mapping.annotations.FrozenValue;
import com.datastax.driver.mapping.annotations.PartitionKey;
import com.datastax.driver.mapping.annotations.Table;
import com.jul.newauth.model.ImageVO;

@Table(keyspace = "newauthusers", name = "usersbyuserid")
public class UsersByUserid {

	@PartitionKey
	private UUID userid;	
	
 	@Column(name = "uname")
	private String username;
 	@Column(name = "fname")
	private String firstname;
 	@Column(name = "mi")
	private String middleinitial;
 	@Column(name = "lname")
	private String lastname;
	private short validations;
	@Column(name = "crdt")
	private Date createdate;
	@Column(name = "upddt")
	private Date lastupdatedate;
	@Column(name = "accdt")
	private Date lastaccessdate;
    
	@FrozenValue
	private Map<String, Address> addresses ;
	@Frozen
	private Set<Phone> phones;
	@Frozen
	private Set<String> emails;
	@Frozen
	private Set<InetAddress> ips;
	
	public UUID getUserid() {
		return userid;
	}
	
	public UsersByUserid () {
		
	}
	
	public UsersByUserid(UUID userid, String username, String firstname, String middleinitial, String lastname, short validations,
			Date creationdate, Date lastupdatedate, Date lastaccessdate, Map<String, Address> addresses,
			Set<Phone> phones, Set<String> emails, Set<InetAddress> ipaddresses) {
		super();
		this.userid = userid;
		this.username = username;
		this.firstname = firstname;
		this.middleinitial = middleinitial;
		this.lastname = lastname;
		this.validations = validations;
		this.createdate = creationdate;
		this.lastupdatedate = lastupdatedate;
		this.lastaccessdate = lastaccessdate;
		this.addresses = addresses;
		this.phones = phones;
		this.emails = emails;
		this.ips = ipaddresses;
	}
	
	public void setUserid(UUID userid) {
		this.userid = userid;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public String getMiddleinitial() {
		return middleinitial;
	}
	public void setMiddleinitial(String middleinitial) {
		this.middleinitial = middleinitial;
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	public short getValidations() {
		return validations;
	}
	public void setValidations(short validations) {
		this.validations = validations;
	}
	public Date getCreatedate() {
		return createdate;
	}
	public void setCreatedate(Date creationdate) {
		this.createdate = creationdate;
	}
	public Date getLastupdatedate() {
		return lastupdatedate;
	}
	public void setLastupdatedate(Date lastupdatedate) {
		this.lastupdatedate = lastupdatedate;
	}
	public Date getLastaccessdate() {
		return lastaccessdate;
	}
	public void setLastaccessdate(Date lastaccessdate) {
		this.lastaccessdate = lastaccessdate;
	}
	public Map<String, Address> getAddresses() {
		return addresses;
	}
	public void setAddresses(Map<String, Address> addresses) {
		this.addresses = addresses;
	}
	public Set<Phone> getPhones() {
		return phones;
	}
	public void setPhones(Set<Phone> phones) {
		this.phones = phones;
	}
	public Set<String> getEmails() {
		return emails;
	}
	public void setEmails(Set<String> emails) {
		this.emails = emails;
	}
	
	public Set<InetAddress> getIps() {
		return ips;
	}

	public void setIps(Set<InetAddress> ips) {
		this.ips = ips;
	}

	public String getInsertCQL() {
		// TODO Auto-generated method stub
		
		/*insert into users 
		(userid, username, firstname, middleinitial, lastname, creationdate, lastupdatedate, lastaccessdate, addresses, phones, emails)
		values
		(uuid(), 
				)
		*/
		return null;
	}
	
	public String getUpdateCQL() {
		// TODO Auto-generated method stub
		return null;
	}
	
	
	
	public void createViaMapper(Session sess) {
		
		MappingManager manager = new MappingManager(sess);

		Mapper<UsersByUserid> mapper = manager.mapper(UsersByUserid.class);
		
		long starttime = System.currentTimeMillis();
		mapper.saveAsync(this);
		System.out.println("Added UsersByUserid user async: " + this.getUsername() + " UUID: "  + this.getUserid().toString() + " in " + (System.currentTimeMillis() - starttime) + "ms");
		
	}
	
	public UsersByUserid readViaMapper(Session sess) {
		MappingManager manager = new MappingManager(sess);
		Mapper<UsersByUserid> mapper = manager.mapper(UsersByUserid.class);
		long starttime = System.currentTimeMillis();

		UsersByUserid out = mapper.get(this.getUserid());
		
		System.out.println("Read userbyuserid back in: " + (System.currentTimeMillis() - starttime) + "ms" );
		
		return out;
	}
		
	
}
