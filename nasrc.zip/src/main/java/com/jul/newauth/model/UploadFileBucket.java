package com.jul.newauth.model;

import org.springframework.web.multipart.MultipartFile;

public class UploadFileBucket {
 
    MultipartFile file;
    String url;
    
     
    public MultipartFile getFile() {
    	
    	return file;
    }
 
    public void setFile(MultipartFile file) {
        this.file = file;
    }

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}
}
