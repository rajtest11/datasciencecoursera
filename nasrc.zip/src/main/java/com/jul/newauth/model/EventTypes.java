package com.jul.newauth.model;

public class EventTypes {
	
	public static final String USER_CREATED = "UC";
	public static final String USER_FISHING = "UF";
	public static final String IMAGE_CLICK = "ICL";
	public static final String USER_EXISTS = "UE";
	public static final String INVALID_COOKIE = "ICO";
	
	public static final String AUTH_CHALLENGE_SENT = "AC";
	public static final String AUTH_CHALLENGE_SUCCESS = "ACS";
	public static final String AUTH_CHALLENGE_FAIL = "ACF";
	

}
