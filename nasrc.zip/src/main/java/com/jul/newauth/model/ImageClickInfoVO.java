package com.jul.newauth.model;

public class ImageClickInfoVO extends BaseVO {
	
	private String imgID;
	private String userID;
	private String clickX;
	private String clickY;
	private String imgWidth;
	private String imgHeight;
	private String delay;
	
	public String getImgID() {
		return imgID;
	}
	public void setImgID(String imgID) {
		this.imgID = imgID;
	}
	public String getUserID() {
		return userID;
	}
	public void setUserID(String userID) {
		this.userID = userID;
	}
	public String getClickX() {
		return clickX;
	}
	public void setClickX(String clickX) {
		this.clickX = clickX;
	}
	public String getClickY() {
		return clickY;
	}
	public void setClickY(String clickY) {
		this.clickY = clickY;
	}
	public String getImgWidth() {
		return imgWidth;
	}
	public void setImgWidth(String imgWidth) {
		this.imgWidth = imgWidth;
	}
	public String getImgHeight() {
		return imgHeight;
	}
	public void setImgHeight(String imgHeight) {
		this.imgHeight = imgHeight;
	}
	public String getDelay() {
		return delay;
	}
	public void setDelay(String delay) {
		this.delay = delay;
	}
	

}
