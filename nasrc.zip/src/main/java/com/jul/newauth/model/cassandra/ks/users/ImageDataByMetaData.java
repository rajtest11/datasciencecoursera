package com.jul.newauth.model.cassandra.ks.users;

import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.Date;
import java.util.List;
import java.util.UUID;
import java.util.zip.Adler32;
import java.util.zip.CRC32;
import java.util.zip.Checksum;

import com.datastax.driver.core.PreparedStatement;
import com.datastax.driver.core.ResultSet;
import com.datastax.driver.core.Session;
import com.datastax.driver.core.utils.Bytes;
import com.datastax.driver.mapping.Mapper;
import com.datastax.driver.mapping.MappingManager;
import com.datastax.driver.mapping.Result;
import com.datastax.driver.mapping.annotations.ClusteringColumn;
import com.datastax.driver.mapping.annotations.Column;
import com.datastax.driver.mapping.annotations.PartitionKey;
import com.datastax.driver.mapping.annotations.Table;
import com.jul.newauth.util.NewAuthUtils;

@Table(keyspace = "newauthusers", name = "imagedatabymetadata")
public class ImageDataByMetaData {
	
	@Column(name = "id")
	private UUID imageid;
	private UUID userid;
	
	@ClusteringColumn(0)
	@Column(name = "seq")
	private int imageseq;
	@PartitionKey
	private String size;
	
	
	@Column(name = "height")
	private int imageheight; // e.g. '1024
	
	@Column(name = "width")
	private int imagewidth; // e.g. '768
	//@ClusteringColumn(0)
	@Column(name = "ar")
	private float aspectratio; 
	
	@Column(name = "type")
	private String imagetype;
	
	@Column(name = "crdt")
	private Date createdate;
	@Column(name = "accdt")
    private Date lastaccessdate;
   
    private List<String> tags;
    
    private static PreparedStatement insertps = null;
    
    private static MappingManager manager;
    
    public ImageDataByMetaData() {}

    public static String getInsertQueryStringWithQMarks() {
		
		return " INSERT INTO newauthusers.imagedatabymetadata ( id, userid, seq, size, height, width, ar, type, crdt, accdt, tags ) values (?, ?,?, ?,?, ?,?, ?,?, ?,?); " ;
	}
    
	public ImageDataByMetaData(UUID imageid, UUID userid, int imageseq, String size, int imageheight, int imagewidth,
			float aspectratio, String imagetype, Date createdate, Date lastaccessdate, List<String> tags) {
		super();
		this.imageid = imageid;
		this.userid = userid;
		this.imageseq = imageseq;
		this.size = size;
		this.imageheight = imageheight;
		this.imagewidth = imagewidth;
		this.aspectratio = aspectratio;
		this.imagetype = imagetype;
		this.createdate = createdate;
		this.lastaccessdate = lastaccessdate;
		this.tags = tags;
	}






	public UUID getImageid() {
		return imageid;
	}
	public void setImageid(UUID imageid) {
		this.imageid = imageid;
	}
	public UUID getUserid() {
		return userid;
	}
	public void setUserid(UUID userid) {
		this.userid = userid;
	}
	
	
	public Date getCreatedate() {
		return createdate;
	}
	public void setCreatedate(Date createdate) {
		this.createdate = createdate;
	}
	public Date getLastaccessdate() {
		return lastaccessdate;
	}
	public void setLastaccessdate(Date lastaccessdate) {
		this.lastaccessdate = lastaccessdate;
	}
	public List<String> getTags() {
		return tags;
	}
	public void setTags(List<String> tags) {
		this.tags = tags;
	}
	
	public String getSize() {
		return size;
	}

	public void setSize(String size) {
		this.size = size;
	}

	public String getImagetype() {
		return imagetype;
	}

	public void setImagetype(String imagetype) {
		this.imagetype = imagetype;
	}

	public int getImageheight() {
		return imageheight;
	}

	public int getImageseq() {
		return imageseq;
	}



	public void setImageseq(int imageseq) {
		this.imageseq = imageseq;
	}



	public void setImageheight(int imageheight) {
		this.imageheight = imageheight;
	}

	public int getImagewidth() {
		return imagewidth;
	}

	public void setImagewidth(int imagewidth) {
		this.imagewidth = imagewidth;
	}

	public float getAspectratio() {
		return aspectratio;
	}



	public void setAspectratio(float aspectratio) {
		this.aspectratio = aspectratio;
	}



	public void createViaMapper(Session sess) {
		
		MappingManager manager = new MappingManager(sess);

		Mapper<ImageDataByMetaData> mapper = manager.mapper(ImageDataByMetaData.class);
		
		long starttime = System.currentTimeMillis();
		mapper.save(this);
		System.out.println("Added imagedata: UUID: " + this.getImageid() + " size: "  + this.getImageheight() + "X" + this.getImagewidth() + " in " + (System.currentTimeMillis() - starttime) + "ms");
		
	}
	
	public byte[] readViaMapper(Session sess) {
		MappingManager manager = new MappingManager(sess);
		Mapper<ImageDataByMetaData> mapper = manager.mapper(ImageDataByMetaData.class);
		long starttime = System.currentTimeMillis();

		// Get imageData first
		ImageDataByMetaData img = mapper.get(this.getSize(), this.getAspectratio(), this.getImagewidth(), this.getCreatedate());
		
		if (img != null) {
			// Get Blobdata next
			Mapper<BlobData> bmapper = manager.mapper(BlobData.class);
			BlobData blob = bmapper.get(img.getImageid());
			
			// Get blob chunks next
			Mapper<BlobChunkData> cmapper = manager.mapper(BlobChunkData.class);
			byte[] imagebytes = new byte [(int) blob.getSize()];
			
			ByteBuffer buf = ByteBuffer.allocate((int) blob.getSize());
			ByteArrayOutputStream outputStream = new ByteArrayOutputStream( );
			for (int i=1; i<=blob.getChunk_count(); i++) {
				BlobChunkData chunk = cmapper.get(img.getImageid(), i);
				
				//System.out.println("\tFile segment " + i + ": last 4 bytes [" + chunk.getData().array()[(int) (chunk.getChunk_size()-4)] + chunk.getData().array()[(int) (chunk.getChunk_size()-3)] + chunk.getData().array()[(int) (chunk.getChunk_size()-2)] + chunk.getData().array()[(int) (chunk.getChunk_size()-1)] + "]");
				
				outputStream.write(chunk.getData().array(), 0, (int)chunk.getChunk_size());
			}
			
			Checksum  chksum = new CRC32();
			imagebytes = outputStream.toByteArray();
			chksum.update(imagebytes,0,imagebytes.length);
			
			System.out.println("Read imagedata back in: " + (System.currentTimeMillis() - starttime) + "ms" + " size: " + imagebytes.length);
			if (chksum.getValue() == Long.parseLong(blob.getChecksum())) {
				//saveFile(imagebytes);
				return imagebytes;
			} else {
				System.out.println("Checksum match failed: in " + blob.getChecksum() + " out " + chksum.getValue());
				return null;
			}
		} else {
			System.out.println("Mapper returned no image for ID " + this.getImageid());
			return null;
		}
		
		
	}
	
	
	public ImageDataByMetaData getImageBySizeAndSeq(Session sess) {
		MappingManager manager = new MappingManager(sess);
		Mapper<ImageDataByMetaData> mapper = manager.mapper(ImageDataByMetaData.class);
		long starttime = System.currentTimeMillis();

		// Get imageData first
		ImageDataByMetaData img = mapper.get(this.getSize(), this.getImageseq());
		System.out.println("Read one image back from imagedatabymetadata by size and seq in: " + (System.currentTimeMillis() - starttime) + "ms" );
		
		
		return img;
		
	}
	
	
	public Result<ImageDataByMetaData> getImagesBySizeAr(Session sess, int lastSeq, Float[] aspectratios) {
		
		MappingManager manager = new MappingManager(sess);
		Mapper<ImageDataByMetaData> mapper = manager.mapper(ImageDataByMetaData.class);
		long starttime = System.currentTimeMillis();

		String arclause = "";
		
		if (aspectratios.length > 0) {
			
			String instring = "";
			
			for (float ar: aspectratios) {
				instring += ar + ",";
			}
			arclause = " and ar in (" + instring.substring(0, instring.length()-1) + ") ";
		}
		
		String seqclause = "";
		
		if (lastSeq > 0) 
			seqclause = " and seq > " + lastSeq;
		
		String[] allowedsizes = NewAuthUtils.getSizesBiggerThanThisSize(this.getSize());
		
		String sizeclause = "";
		
		if (allowedsizes.length > 0) {
			String instring = "'";
			
			for (String sz: allowedsizes) {
				instring += sz + "','";
			}
			sizeclause = " size in (" + instring.substring(0, instring.length()-2) + ") ";
		}
		

		ResultSet results = sess.execute("SELECT * FROM newauthusers.imagedatabymetadata " + 
														" where " + sizeclause 
														// + arclause + seqclause
														);
		Result<ImageDataByMetaData> out = mapper.map(results);
		System.out.println("Read list of images back from imagedatabymetadata in: " + (System.currentTimeMillis() - starttime) + "ms" );
		
		
		return out;
		
	}
	
	public ImageDataByMetaData getTinyImageOfAnotherImage(Session sess, ImageDataByMetaData originalimage) {
		
		ImageDataByMetaData out = null;
		
		if (manager == null)
			manager = new MappingManager(sess);
		
		Mapper<ImageDataByMetaData> mapper = manager.mapper(ImageDataByMetaData.class);
		long starttime = System.currentTimeMillis();
		
		if (originalimage.getImageseq() == 0) {
			if (originalimage.getImageid() != null) {
				ImageDataByImageID img = new ImageDataByImageID();
				img.setImageid(originalimage.getImageid());
				
				img = img.readViaMapper(sess);
				
				if (img != null)
					originalimage.setImageseq(img.getImageseq());
				
			}
		}

		
		ResultSet results = sess.execute("SELECT * FROM newauthusers.imagedatabymetadata where size = 'T' "
																				//+ arclause 
																				+ " and seq = " + originalimage.getImageseq() );
		Result<ImageDataByMetaData> resultdata = mapper.map(results);
		
		if (resultdata != null)
			System.out.println("Read Tiny image of a large image back from imagedatabymetadata in: " + (System.currentTimeMillis() - starttime) + "ms" );
		else
			System.out.println("Could not find Tiny image of a large image back from imagedatabymetadata in: " + (System.currentTimeMillis() - starttime) + "ms" );
		
		if (resultdata != null) {
			out = resultdata.one();
		}
				
		return out;
		
	}
	
	public ImageDataByMetaData getAnotherImageByTinyImage(Session sess, ImageDataByMetaData tinyimage, String size) {
		
		ImageDataByMetaData out = null;

		if (manager == null)
			manager = new MappingManager(sess);
		
		Mapper<ImageDataByMetaData> mapper = manager.mapper(ImageDataByMetaData.class);
		long starttime = System.currentTimeMillis();
		
		/*float ar = NewAuthUtils.getImageAspectRatio(tinyimage.getImagewidth(), tinyimage.getImageheight());
		
		Float[] allowedars = NewAuthUtils.getAllowedAspectRatios(ar, (short) 5);
		
		String arclause = "";
		
		if (allowedars.length > 0) {
			String instring = "";
			
			for (float onear: allowedars) {
				instring += onear + ",";
			}
			arclause = " and ar in (" + instring.substring(0, instring.length()-1) + ") ";
		}
*/
		
		ResultSet results = sess.execute("SELECT * FROM newauthusers.imagedatabymetadata where size = '" + size + "' and seq = " + tinyimage.getImageseq() );
		Result<ImageDataByMetaData> resultdata = mapper.map(results);
		System.out.println("Read size " + size + " image back from imagedatabymetadata in: " + (System.currentTimeMillis() - starttime) + "ms" );
		
		if (resultdata != null) {
			out = resultdata.one();
		}
				
		return out;
		
	}
	
	public int lastSeqBySizeAndAR(Session sess, String size, Float[] aspectratios) {
		int out = 0;
		
		if (manager == null)
			manager = new MappingManager(sess);
		
		Mapper<ImageDataByMetaData> mapper = manager.mapper(ImageDataByMetaData.class);
		long starttime = System.currentTimeMillis();

		String arclause = "";
		
		if (aspectratios.length > 0) {
			String instring = "";
			
			for (float ar: aspectratios) {
				instring += ar + ",";
			}
			arclause = " and ar in (" + instring.substring(0, instring.length()-1) + ") ";
		}
				
		ResultSet results = sess.execute("SELECT seq FROM newauthusers.imagedatabymetadata where size = '" + size  +	"' "
														// + arclause 
														+ " limit 1"
														);
		Result<ImageDataByMetaData> result = mapper.map(results);
		System.out.println("Read list of images back from imagedatabymetadata in: " + (System.currentTimeMillis() - starttime) + "ms" );
		
		for (ImageDataByMetaData obj: result) {
			out = obj.getImageseq();
		}		
		
		return out;
	}
	
	
	private void saveFile(byte[] filedata) {
		FileOutputStream fos = null;
		try {
			fos = new FileOutputStream("c:\\temp\\readfromcass.jpg");
			fos.write(filedata);
			fos.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				if (fos != null)
					fos.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
	}

	public static void insertViaCQL(Session session, ImageDataByMetaData imgbyseq) {
		long starttime = System.currentTimeMillis();
		if (insertps == null)
			insertps = session.prepare(getInsertQueryStringWithQMarks());

		session.executeAsync(insertps.bind(
					
					imgbyseq.getImageid(),
					imgbyseq.getUserid(),
					imgbyseq.getImageseq(), 
					imgbyseq.getSize(),
					imgbyseq.getImageheight(),
					imgbyseq.getImagewidth(),
					imgbyseq.getAspectratio(),
					imgbyseq.getImagetype(),
					imgbyseq.getCreatedate(),
					imgbyseq.getLastaccessdate(),
					imgbyseq.getTags()
					
					));
		
		System.out.println("Added ImageDataByMetaData via cql in " +  (System.currentTimeMillis()-starttime) + "ms");
		
	}
    
}
