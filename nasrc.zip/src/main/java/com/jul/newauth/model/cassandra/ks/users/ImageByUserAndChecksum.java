package com.jul.newauth.model.cassandra.ks.users;

import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.Date;
import java.util.List;
import java.util.UUID;
import java.util.zip.Adler32;
import java.util.zip.CRC32;
import java.util.zip.Checksum;

import com.datastax.driver.core.Session;
import com.datastax.driver.core.utils.Bytes;
import com.datastax.driver.mapping.Mapper;
import com.datastax.driver.mapping.MappingManager;
import com.datastax.driver.mapping.annotations.ClusteringColumn;
import com.datastax.driver.mapping.annotations.Column;
import com.datastax.driver.mapping.annotations.PartitionKey;
import com.datastax.driver.mapping.annotations.Table;

@Table(keyspace = "newauthusers", name = "imagebyuserandchecksum")
public class ImageByUserAndChecksum {
	
	@Column(name = "id")
	private UUID imageid;
	
	@PartitionKey(0)
	private String userid;
	
	@PartitionKey(1)
	@Column(name = "size")
	private String size;
	
	@PartitionKey(2)
	@Column(name = "sum")
	private String checksum;
	
    
   
    public ImageByUserAndChecksum() {}

	
   



	public ImageByUserAndChecksum(UUID imageid, String userid, String size, String checksum) {
		super();
		this.imageid = imageid;
		this.userid = userid;
		this.size = size;
		this.checksum = checksum;
	}






	public UUID getImageid() {
		return imageid;
	}
	public void setImageid(UUID imageid) {
		this.imageid = imageid;
	}
	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	



	public String getChecksum() {
		return checksum;
	}









	public void setChecksum(String checksum) {
		this.checksum = checksum;
	}









	public String getSize() {
		return size;
	}









	public void setSize(String size) {
		this.size = size;
	}









	public void createViaMapper(Session sess) {
		
		MappingManager manager = new MappingManager(sess);

		Mapper<ImageByUserAndChecksum> mapper = manager.mapper(ImageByUserAndChecksum.class);
		
		long starttime = System.currentTimeMillis();
		mapper.save(this);
		System.out.println("Added user and checksum combination: userID: " + this.getUserid() + " size: "  + this.getSize() + " checksum: "  + this.getChecksum() + " in " + (System.currentTimeMillis() - starttime) + "ms");
		
	}
	
	public ImageByUserAndChecksum readViaMapper(Session sess) {
		MappingManager manager = new MappingManager(sess);
		Mapper<ImageByUserAndChecksum> mapper = manager.mapper(ImageByUserAndChecksum.class);
		long starttime = System.currentTimeMillis();

		// Get imageData first
		ImageByUserAndChecksum img = mapper.get(this.getUserid(), this.getSize(), this.getChecksum());
		
		
		return img;
	}
	
	
    
}
