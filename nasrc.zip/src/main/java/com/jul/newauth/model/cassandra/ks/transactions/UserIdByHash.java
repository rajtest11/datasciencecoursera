package com.jul.newauth.model.cassandra.ks.transactions;

import java.net.InetAddress;
import java.util.Date;
import java.util.UUID;

import com.datastax.driver.core.Session;
import com.datastax.driver.mapping.Mapper;
import com.datastax.driver.mapping.MappingManager;
import com.datastax.driver.mapping.annotations.Column;
import com.datastax.driver.mapping.annotations.PartitionKey;
import com.datastax.driver.mapping.annotations.Table;
import com.jul.newauth.model.cassandra.ks.users.UsersByUsername;

@Table(keyspace = "newauthtransactions", name = "uidbyhash")
public class UserIdByHash {

	private UUID userid;
	@Column(name = "ip")
	private InetAddress ipaddress;
	@PartitionKey(0)
	private String useridhash;
	private String username;
	private String fullname;
	@Column(name = "init")
	private boolean initdevice;
	@Column(name = "remote")
	private boolean remotedetection;
	@Column(name = "height")
    private int devicedisplayheight ;
   	@Column(name = "width")
    private int devicedisplaywidth ;
	private String useragent;
	@Column(name = "indcnf")
    private Date individualconfirmdate;
    @Column(name = "grpcnf")
	private Date groupconfirmdate;
    @Column(name = "pubcnf")
	private Date publicconfirmdate;	
	
    private static MappingManager manager;
    
	public UserIdByHash() {
		
	}

	public UserIdByHash(UUID userid, InetAddress ipaddress, String useridhash, String username, String fullname,
			boolean initdevice, boolean remotedetection, int devicedisplayheight, int devicedisplaywidth,
			String useragent, Date individualconfirmdate, Date groupconfirmdate, Date publicconfirmdate) {
		super();
		this.userid = userid;
		this.ipaddress = ipaddress;
		this.useridhash = useridhash;
		this.username = username;
		this.fullname = fullname;
		this.initdevice = initdevice;
		this.remotedetection = remotedetection;
		this.devicedisplayheight = devicedisplayheight;
		this.devicedisplaywidth = devicedisplaywidth;
		this.useragent = useragent;
		this.individualconfirmdate = individualconfirmdate;
		this.groupconfirmdate = groupconfirmdate;
		this.publicconfirmdate = publicconfirmdate;
	}


	public UUID getUserid() {
		return userid;
	}
	public void setUserid(UUID userid) {
		this.userid = userid;
	}
	public String getUsername() {
		return username;
	}





	public void setUsername(String username) {
		this.username = username;
	}





	public String getFullname() {
		return fullname;
	}





	public void setFullname(String fullname) {
		this.fullname = fullname;
	}





	public InetAddress getIpaddress() {
		return ipaddress;
	}
	public void setIpaddress(InetAddress ipaddress) {
		this.ipaddress = ipaddress;
	}
	public String getUseridhash() {
		return useridhash;
	}
	public void setUseridhash(String useridhash) {
		this.useridhash = useridhash;
	}
	public boolean isInitdevice() {
		return initdevice;
	}
	public void setInitdevice(boolean initdevice) {
		this.initdevice = initdevice;
	}
	public boolean isRemotedetection() {
		return remotedetection;
	}


	public void setRemotedetection(boolean remotedetection) {
		this.remotedetection = remotedetection;
	}


	public int getDevicedisplayheight() {
		return devicedisplayheight;
	}
	public void setDevicedisplayheight(int devicedisplayheight) {
		this.devicedisplayheight = devicedisplayheight;
	}
	public int getDevicedisplaywidth() {
		return devicedisplaywidth;
	}
	public void setDevicedisplaywidth(int devicedisplaywidth) {
		this.devicedisplaywidth = devicedisplaywidth;
	}
	 
	
	public String getUseragent() {
		return useragent;
	}



	public void setUseragent(String useragent) {
		this.useragent = useragent;
	}



	public Date getIndividualconfirmdate() {
		return individualconfirmdate;
	}





	public void setIndividualconfirmdate(Date individualconfirmdate) {
		this.individualconfirmdate = individualconfirmdate;
	}





	public Date getGroupconfirmdate() {
		return groupconfirmdate;
	}





	public void setGroupconfirmdate(Date groupconfirmdate) {
		this.groupconfirmdate = groupconfirmdate;
	}





	public Date getPublicconfirmdate() {
		return publicconfirmdate;
	}





	public void setPublicconfirmdate(Date publicconfirmdate) {
		this.publicconfirmdate = publicconfirmdate;
	}





	public void createViaMapper(Session sess) {
		
		if (manager == null)
			manager = new MappingManager(sess);

		Mapper<UserIdByHash> mapper = manager.mapper(UserIdByHash.class);
		
		long starttime = System.currentTimeMillis();
		mapper.saveAsync(this);
		System.out.println("Added UserIdByHash entry - Asynch : " + this.getUserid().toString() + " IP : "  + this.getIpaddress().toString() + " in " + (System.currentTimeMillis() - starttime) + "ms");
		
	}
	
	public UserIdByHash readViaMapper(Session sess) {
		if (manager == null)
			manager = new MappingManager(sess);
		Mapper<UserIdByHash> mapper = manager.mapper(UserIdByHash.class);
		long starttime = System.currentTimeMillis();

		UserIdByHash out = mapper.get(this.getUseridhash());
		
		System.out.println("Read UserIdByHash back in: " + (System.currentTimeMillis() - starttime) + "ms" );
		
		return out;
	}
	 
}
