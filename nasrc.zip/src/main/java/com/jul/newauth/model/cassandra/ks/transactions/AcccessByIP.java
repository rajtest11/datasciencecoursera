package com.jul.newauth.model.cassandra.ks.transactions;

import java.net.InetAddress;
import java.util.Date;
import java.util.UUID;

import com.datastax.driver.core.PreparedStatement;
import com.datastax.driver.core.Session;
import com.datastax.driver.mapping.Mapper;
import com.datastax.driver.mapping.MappingManager;
import com.datastax.driver.mapping.annotations.ClusteringColumn;
import com.datastax.driver.mapping.annotations.Column;
import com.datastax.driver.mapping.annotations.PartitionKey;
import com.datastax.driver.mapping.annotations.Table;

@Table(keyspace = "newauthtransactions", name = "accessbyip")
public class AcccessByIP {
	
	@PartitionKey
	private InetAddress ip;
	private UUID userid;
	@ClusteringColumn
   	@Column(name = "acc")
   	private Date accesstime;
	
	public AcccessByIP() {
		
	}
	
	
	public AcccessByIP(InetAddress ip, UUID userid, Date accesstime) {
		super();
		this.ip = ip;
		this.userid = userid;
		this.accesstime = accesstime;
	}


	public InetAddress getIp() {
		return ip;
	}
	public void setIp(InetAddress ip) {
		this.ip = ip;
	}
	public UUID getUserid() {
		return userid;
	}
	public void setUserid(UUID userid) {
		this.userid = userid;
	}
	public Date getAccesstime() {
		return accesstime;
	}
	public void setAccesstime(Date accesstime) {
		this.accesstime = accesstime;
	}

	public void createViaMapper(Session sess) {
		
		MappingManager manager = new MappingManager(sess);

		Mapper<AcccessByIP> mapper = manager.mapper(AcccessByIP.class);
		
		long starttime = System.currentTimeMillis();
		mapper.saveAsync(this);
		System.out.println("Added AcccessByIP entry - Asynch : "  + " IP : "  + this.getIp().toString() + " in " + (System.currentTimeMillis() - starttime) + "ms");
		
	}
	
	public void createViaDirectCQL(Session session) {
		long starttime = System.currentTimeMillis();
		PreparedStatement ps = session.prepare(
				   getInsertQueryStringWithQMarks()
				);
		
		session.executeAsync(ps.bind(getIp(), 
										getUserid(), 
										getAccesstime()
										));
		System.out.println("Added AcccessByIP entry - Direct CQL : " + 
				((this.getUserid() ==null)?"":this.getUserid().toString()) + 
				" IP : "  + this.getIp().toString() + 
				" in " + (System.currentTimeMillis() - starttime) + "ms");

	}
	
	public static String getInsertQueryStringWithQMarks() {
		
		return " INSERT INTO newauthtransactions.accessbyip (ip, userid, acc ) values (?, ?, ?); " ;
	}
	
	
	
}
