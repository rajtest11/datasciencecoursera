package com.jul.newauth.model;

public class AuthenticationResponseVO extends BaseVO {
	
	private String responsedata;

	public String getResponsedata() {
		return responsedata;
	}

	public void setResponsedata(String responsedata) {
		this.responsedata = responsedata;
	}
	
	
	 

}
