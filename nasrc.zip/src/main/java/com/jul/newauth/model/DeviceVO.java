package com.jul.newauth.model;

import java.net.InetAddress;
import java.util.Date;

public class DeviceVO extends BaseVO {
	
	private InetAddress ipaddress;
	private int screenwidth; // Screen width of the device
	private int screenheight;
	private int windowwidth; // Browser window width
	private int windowheight;
	private String useragent;
	private Date individualdeviceconfirmdate;
	private Date groupdeviceconfirmdate;
	private Date publicdeviceconfirmdate;
	
	
	
	public InetAddress getIpaddress() {
		return ipaddress;
	}
	public void setIpaddress(InetAddress ipaddress) {
		this.ipaddress = ipaddress;
	}
	public int getScreenwidth() {
		return screenwidth;
	}
	public void setScreenwidth(int screenwidth) {
		this.screenwidth = screenwidth;
	}
	public int getScreenheight() {
		return screenheight;
	}
	public void setScreenheight(int screenheight) {
		this.screenheight = screenheight;
	}
	public int getWindowwidth() {
		return windowwidth;
	}
	public void setWindowwidth(int windowwidth) {
		this.windowwidth = windowwidth;
	}
	public int getWindowheight() {
		return windowheight;
	}
	public void setWindowheight(int windowheight) {
		this.windowheight = windowheight;
	}
	public String getUseragent() {
		return useragent;
	}
	public void setUseragent(String useragent) {
		this.useragent = useragent;
	}
	public Date getIndividualdeviceconfirmdate() {
		return individualdeviceconfirmdate;
	}
	public void setIndividualdeviceconfirmdate(Date individualdeviceconfirmdate) {
		this.individualdeviceconfirmdate = individualdeviceconfirmdate;
	}
	public Date getGroupdeviceconfirmdate() {
		return groupdeviceconfirmdate;
	}
	public void setGroupdeviceconfirmdate(Date groupdeviceconfirmdate) {
		this.groupdeviceconfirmdate = groupdeviceconfirmdate;
	}
	public Date getPublicdeviceconfirmdate() {
		return publicdeviceconfirmdate;
	}
	public void setPublicdeviceconfirmdate(Date publicdeviceconfirmdate) {
		this.publicdeviceconfirmdate = publicdeviceconfirmdate;
	}
	
	

}
