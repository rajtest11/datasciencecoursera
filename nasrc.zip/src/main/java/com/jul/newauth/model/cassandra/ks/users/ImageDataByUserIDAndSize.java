package com.jul.newauth.model.cassandra.ks.users;

import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.UUID;
import java.util.zip.Adler32;
import java.util.zip.CRC32;
import java.util.zip.Checksum;

import com.datastax.driver.core.PreparedStatement;
import com.datastax.driver.core.ResultSet;
import com.datastax.driver.core.Session;
import com.datastax.driver.core.utils.Bytes;
import com.datastax.driver.mapping.Mapper;
import com.datastax.driver.mapping.MappingManager;
import com.datastax.driver.mapping.Result;
import com.datastax.driver.mapping.annotations.ClusteringColumn;
import com.datastax.driver.mapping.annotations.Column;
import com.datastax.driver.mapping.annotations.PartitionKey;
import com.datastax.driver.mapping.annotations.Table;
import com.jul.newauth.model.cassandra.ks.transactions.HashByIpAndUserAgent;

@Table(keyspace = "newauthusers", name = "imagedatabyuserandsize")
public class ImageDataByUserIDAndSize {
	
	@Column(name = "id")
	private UUID imageid;
	
	@PartitionKey(0)
	private UUID userid;
	
	@ClusteringColumn(0)
	@Column(name = "seq") // seq number for this user and size
	private short imageseq;
	
	@Column(name = "gseq") // seq number for this image globally, system and all
	private short globalSequence;
	
	@PartitionKey(1)
	private String size;
	
	@Column(name = "height")
	private int imageheight; // e.g. '1024
	@Column(name = "width")
	private int imagewidth; // e.g. '768
	
	//@ClusteringColumn(0)
	@Column(name = "ar")
	private float aspectratio; 
	
	@Column(name = "type")
	private String imagetype;
	
	//@ClusteringColumn(1)
	@Column(name = "crdt")
	private Date createdate;
	@Column(name = "accdt")
    private Date lastaccessdate;
   
    private List<String> tags;
    private static PreparedStatement insertps = null;
    
    private static MappingManager manager;
  

    public static String getInsertQueryStringWithQMarks() {
		
		return " INSERT INTO newauthusers.imagedatabyuserandsize ( id, userid, seq, gseq, size, height, width, ar, type, crdt, accdt, tags ) values (?, ?,?, ?,?, ?, ?,?, ?,?, ?,?); " ;
	}
    
   
    public ImageDataByUserIDAndSize() {}

	
 
	public ImageDataByUserIDAndSize(UUID imageid, UUID userid, short imageseq, short globalSequence, String size,
			int imageheight, int imagewidth, float aspectratio, String imagetype, Date createdate, Date lastaccessdate,
			List<String> tags) {
		super();
		this.imageid = imageid;
		this.userid = userid;
		this.imageseq = imageseq;
		this.globalSequence = globalSequence;
		this.size = size;
		this.imageheight = imageheight;
		this.imagewidth = imagewidth;
		this.aspectratio = aspectratio;
		this.imagetype = imagetype;
		this.createdate = createdate;
		this.lastaccessdate = lastaccessdate;
		this.tags = tags;
	}


	public UUID getImageid() {
		return imageid;
	}
	public void setImageid(UUID imageid) {
		this.imageid = imageid;
	}
	public UUID getUserid() {
		return userid;
	}
	public void setUserid(UUID userid) {
		this.userid = userid;
	}
	public short getImageseq() {
		return imageseq;
	}
	public void setImageseq(short imageseq) {
		this.imageseq = imageseq;
	}
	
	public short getGlobalSequence() {
		return globalSequence;
	}


	public void setGlobalSequence(short globalSequence) {
		this.globalSequence = globalSequence;
	}


	public Date getCreatedate() {
		return createdate;
	}
	public void setCreatedate(Date createdate) {
		this.createdate = createdate;
	}
	public Date getLastaccessdate() {
		return lastaccessdate;
	}
	public void setLastaccessdate(Date lastaccessdate) {
		this.lastaccessdate = lastaccessdate;
	}
	public List<String> getTags() {
		return tags;
	}
	public void setTags(List<String> tags) {
		this.tags = tags;
	}
	
	public String getSize() {
		return size;
	}

	public void setSize(String size) {
		this.size = size;
	}

	public String getImagetype() {
		return imagetype;
	}

	public void setImagetype(String imagetype) {
		this.imagetype = imagetype;
	}

	public int getImageheight() {
		return imageheight;
	}

	public void setImageheight(int imageheight) {
		this.imageheight = imageheight;
	}

	public int getImagewidth() {
		return imagewidth;
	}

	public void setImagewidth(int imagewidth) {
		this.imagewidth = imagewidth;
	}

	public float getAspectratio() {
		return aspectratio;
	}



	public void setAspectratio(float aspectratio) {
		this.aspectratio = aspectratio;
	}



	public void createViaMapper(Session sess) {
		
		if (manager == null)
			manager = new MappingManager(sess);

		Mapper<ImageDataByUserIDAndSize> mapper = manager.mapper(ImageDataByUserIDAndSize.class);
		
		long starttime = System.currentTimeMillis();
		mapper.save(this);
		System.out.println("Added imagedata: UUID: " + this.getImageid() + " size: "  + this.getImageheight() + "X" + this.getImagewidth() + " in " + (System.currentTimeMillis() - starttime) + "ms");
		
	}
	
	public ImageDataByUserIDAndSize readViaMapper(Session sess) {
		if (manager == null)
			manager = new MappingManager(sess);
		
		Mapper<ImageDataByUserIDAndSize> mapper = manager.mapper(ImageDataByUserIDAndSize.class);
		long starttime = System.currentTimeMillis();

		// Get imageData first
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss SSS z");
		
		ImageDataByUserIDAndSize img = mapper.get(this.getUserid(), this.getSize(),this.getAspectratio(), this.getCreatedate());
		System.out.println("Read ImageDataByUserIDAndSize by mapper in: " + (System.currentTimeMillis() - starttime) + "ms. Based on userid " 
							+ this.getUserid() + " size: " 
							+ this.getSize() + " ar: " + this.getAspectratio() + " crdt: " 
							+ sdf.format(this.getCreatedate()) );
		return img;
		
		
	}
	
	
	
	public Result<ImageDataByUserIDAndSize> getImagesByUserAndSize(Session sess, UUID userid, String size ) {
		
		if (manager == null)
			manager = new MappingManager(sess);
		
		Mapper<ImageDataByUserIDAndSize> mapper = manager.mapper(ImageDataByUserIDAndSize.class);
		long starttime = System.currentTimeMillis();
		
		ResultSet results = sess.execute("SELECT * FROM newauthusers.imagedatabyuserandsize where userid = " + userid + 
															" and size in  ('S', 'M', 'L', 'E') ");
		Result<ImageDataByUserIDAndSize> out = mapper.map(results);
		
		System.out.println("Read ImageDataByUserIDAndSize by query for : " + userid + " and ALL sizes in " + (System.currentTimeMillis() - starttime) + "ms" );
		
		return out;
		
	}
	
	
	public byte[] readImageBytesViaMapper(Session sess) {
		if (manager == null)
			manager = new MappingManager(sess);
		
		Mapper<ImageDataByUserIDAndSize> mapper = manager.mapper(ImageDataByUserIDAndSize.class);
		long starttime = System.currentTimeMillis();

		// Get imageData first
		ImageDataByUserIDAndSize img = mapper.get(this.getUserid(), this.getSize());
		
		if (img != null) {
			// Get Blobdata next
			Mapper<BlobData> bmapper = manager.mapper(BlobData.class);
			BlobData blob = bmapper.get(img.getImageid());
			
			// Get blob chunks next
			Mapper<BlobChunkData> cmapper = manager.mapper(BlobChunkData.class);
			byte[] imagebytes = new byte [(int) blob.getSize()];
			
			ByteBuffer buf = ByteBuffer.allocate((int) blob.getSize());
			ByteArrayOutputStream outputStream = new ByteArrayOutputStream( );
			for (int i=1; i<=blob.getChunk_count(); i++) {
				BlobChunkData chunk = cmapper.get(img.getImageid(), i);
				
				//System.out.println("\tFile segment " + i + ": last 4 bytes [" + chunk.getData().array()[(int) (chunk.getChunk_size()-4)] + chunk.getData().array()[(int) (chunk.getChunk_size()-3)] + chunk.getData().array()[(int) (chunk.getChunk_size()-2)] + chunk.getData().array()[(int) (chunk.getChunk_size()-1)] + "]");
				
				outputStream.write(chunk.getData().array(), 0, (int)chunk.getChunk_size());
			}
			
			Checksum  chksum = new CRC32();
			imagebytes = outputStream.toByteArray();
			chksum.update(imagebytes,0,imagebytes.length);
			
			System.out.println("Read imagedata back in: " + (System.currentTimeMillis() - starttime) + "ms" + " size: " + imagebytes.length);
			if (chksum.getValue() == Long.parseLong(blob.getChecksum())) {
				//saveFile(imagebytes);
				return imagebytes;
			} else {
				System.out.println("Checksum match failed: in " + blob.getChecksum() + " out " + chksum.getValue());
				return null;
			}
		} else {
			System.out.println("Mapper returned no image for ID " + this.getImageid());
			return null;
		}
		
		
	}
	
	public Result<ImageDataByUserIDAndSize> getImagesByUserAndSizeAndAspectRatio(Session sess, UUID userid, String size, float ar ) {
		
		if (manager == null)
			manager = new MappingManager(sess);
		
		Mapper<ImageDataByUserIDAndSize> mapper = manager.mapper(ImageDataByUserIDAndSize.class);
		long starttime = System.currentTimeMillis();
		
		String arclause = "";
		
		if (ar > 0)
			arclause = (ar < 1)?" and ar < 1":" and ar >= 1";

		ResultSet results = sess.execute("SELECT * FROM newauthusers.imagedatabyuserandsize where userid = " + userid + 
															" and size = '" + size + "'" 
																//+ arclause
																);
		Result<ImageDataByUserIDAndSize> out = mapper.map(results);
		
		/*for (ImageDataByUserIDAndSize u : out) {
		    System.out.println("images from user : " + u.getUserid().toString() + " size - " + u.getSize() + " imageid " + u.getImageid());
		}*/
		
		System.out.println("Read ImageDataByUserIDAndSize by query in: " + (System.currentTimeMillis() - starttime) + "ms" );
		
		return out;
		
	}
	
	public int lastSeqByUserSizeAndAR(Session sess, UUID userid, String size, Float[] aspectratios) {
		int out = -1;
		
		if (manager == null)
			manager = new MappingManager(sess);
		
		Mapper<ImageDataByMetaData> mapper = manager.mapper(ImageDataByMetaData.class);
		long starttime = System.currentTimeMillis();

		String arclause = "";
		
		if (aspectratios.length > 0) {
			String instring = "";
			
			for (float ar: aspectratios) {
				instring += ar + ",";
			}
			arclause = " and ar in (" + instring.substring(0, instring.length()-1) + ") ";
		}
				
		ResultSet results = sess.execute("SELECT seq FROM newauthusers.imagedatabyuserandsize where userid = " + userid + " and size = '" + size + "' " 
															 + 
															// 	arclause + 
															 " order by crdt desc limit 1" );
		Result<ImageDataByMetaData> result = mapper.map(results);
		System.out.println("Read last seq for images back from imagedatabymetadata in: " + (System.currentTimeMillis() - starttime) + "ms" );
		
		for (ImageDataByMetaData obj: result) {
			out = obj.getImageseq();
		}		
		
		return out;
	}
	
	
	public static void insertViaCQL(Session session, ImageDataByUserIDAndSize imgbyseq) {
		long starttime = System.currentTimeMillis();
		if (insertps == null)
			insertps = session.prepare(getInsertQueryStringWithQMarks());

		session.executeAsync(insertps.bind(
					
					imgbyseq.getImageid(),
					imgbyseq.getUserid(),
					imgbyseq.getImageseq(),
					imgbyseq.getGlobalSequence(),
					imgbyseq.getSize(),
					imgbyseq.getImageheight(),
					imgbyseq.getImagewidth(),
					imgbyseq.getAspectratio(),
					imgbyseq.getImagetype(),
					imgbyseq.getCreatedate(),
					imgbyseq.getLastaccessdate(),
					imgbyseq.getTags()
					
					));
		
		System.out.println("Added ImageDataByUserIDAndSize via cql in " +  (System.currentTimeMillis()-starttime) + "ms");
		
	}
    
}
