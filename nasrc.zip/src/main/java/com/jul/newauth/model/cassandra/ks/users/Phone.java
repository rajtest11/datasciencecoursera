package com.jul.newauth.model.cassandra.ks.users;

import java.util.Set;

import com.datastax.driver.mapping.annotations.UDT;

@UDT(keyspace = "newauthusers", name = "phone")
public class Phone {

	public Phone() {
		
	}
	
	private String number;
	private Set<String> tags;
	
	public String getNumber() {
		if (number == null)
			number = "";
		return number;
	}
	public void setNumber(String number) {
		this.number = number;
	}
	public Set<String> getTags() {
		return tags;
	}
	public void setTags(Set<String> tags) {
		this.tags = tags;
	}
	public Phone(String number, Set<String> tags) {
		
		this.number = number;
		this.tags = tags;
	}
	
	
}
