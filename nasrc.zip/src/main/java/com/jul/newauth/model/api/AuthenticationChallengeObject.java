package com.jul.newauth.model.api;

public class AuthenticationChallengeObject {

}
