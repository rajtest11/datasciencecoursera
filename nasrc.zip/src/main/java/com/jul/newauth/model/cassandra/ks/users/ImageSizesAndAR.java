package com.jul.newauth.model.cassandra.ks.users;

import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.Date;
import java.util.List;
import java.util.UUID;
import java.util.zip.Adler32;
import java.util.zip.CRC32;
import java.util.zip.Checksum;

import com.datastax.driver.core.ResultSet;
import com.datastax.driver.core.Session;
import com.datastax.driver.core.utils.Bytes;
import com.datastax.driver.mapping.Mapper;
import com.datastax.driver.mapping.MappingManager;
import com.datastax.driver.mapping.Result;
import com.datastax.driver.mapping.annotations.ClusteringColumn;
import com.datastax.driver.mapping.annotations.Column;
import com.datastax.driver.mapping.annotations.PartitionKey;
import com.datastax.driver.mapping.annotations.Table;

@Table(keyspace = "newauthusers", name = "imagesizesandar")
public class ImageSizesAndAR {
	
	
	@PartitionKey
	private String size;
	
	@ClusteringColumn
	@Column(name = "ar")
	private float aspectratio; 
	
	private static MappingManager manager;
   
    public ImageSizesAndAR() {}

	
   


	
	public ImageSizesAndAR(String size, float aspectratio) {
		super();
		this.size = size;
		this.aspectratio = aspectratio;
	}






	public String getSize() {
		return size;
	}

	public void setSize(String size) {
		this.size = size;
	}

	
	public float getAspectratio() {
		return aspectratio;
	}



	public void setAspectratio(float aspectratio) {
		this.aspectratio = aspectratio;
	}

	public static String getInsertQueryStringWithQMarks() {
		
		return " INSERT INTO newauthusers.imagesizesandar ( size, ar ) values (?, ?); " ;
	}
   	

	public void createViaMapper(Session sess) {
		
		if (manager == null) manager = new MappingManager(sess);

		Mapper<ImageSizesAndAR> mapper = manager.mapper(ImageSizesAndAR.class);
		
		long starttime = System.currentTimeMillis();
		mapper.save(this);
		System.out.println("Added imagesizesandar :  " + size + " " + aspectratio + " in " + (System.currentTimeMillis() - starttime) + "ms");
		
	}
	
	public ImageSizesAndAR readViaMapper(Session sess) {
		
		ImageSizesAndAR out = null;
		
		if (manager == null)  manager = new MappingManager(sess);
		Mapper<ImageSizesAndAR> mapper = manager.mapper(ImageSizesAndAR.class);
		long starttime = System.currentTimeMillis();

		// Get imageData first
		out = mapper.get(this.getSize(), this.getAspectratio());
		
		System.out.println("Read imagesizesandar :  " + out.getSize() + " " + out.getAspectratio() + " in " + (System.currentTimeMillis() - starttime) + "ms");
		
		return out;
		
	}
	
	
	public Result<ImageSizesAndAR> getAvailableARsForSize(Session sess, float startar, float endar) {
		
		if (manager == null)  manager = new MappingManager(sess);
		Mapper<ImageSizesAndAR> mapper = manager.mapper(ImageSizesAndAR.class);
		long starttime = System.currentTimeMillis();
		
		String arclause = "";
		
		if (startar > 0)
			arclause += " and ar >= " + startar + " ";
		
		if (endar > 0)
			arclause += " and ar <= " + endar + " ";

		ResultSet results = sess.execute("SELECT * FROM newauthusers.imagesizesandar where size = '" +  size + "'" + arclause);
		
		Result<ImageSizesAndAR> ars = mapper.map(results);

		
		System.out.println("Read ars based on size from imagesizesandar :  "  + " in " + (System.currentTimeMillis() - starttime) + "ms");
		
		return ars;
		
	}
	
	
	
	
	
    
}
