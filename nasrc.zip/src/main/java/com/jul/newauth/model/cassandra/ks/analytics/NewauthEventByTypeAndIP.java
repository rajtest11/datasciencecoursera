package com.jul.newauth.model.cassandra.ks.analytics;

import java.net.InetAddress;
import java.util.Date;
import java.util.UUID;

import com.datastax.driver.core.Session;
import com.datastax.driver.mapping.Mapper;
import com.datastax.driver.mapping.MappingManager;
import com.datastax.driver.mapping.Mapper.Option;
import com.datastax.driver.mapping.annotations.ClusteringColumn;
import com.datastax.driver.mapping.annotations.Column;
import com.datastax.driver.mapping.annotations.PartitionKey;
import com.datastax.driver.mapping.annotations.Table;

@Table(keyspace = "newauthanalytics", name = "eventsbytypeandip")
public class NewauthEventByTypeAndIP {
	
	
	@Column(name = "id")
	private UUID eventID;
	
	@PartitionKey(0)
	@Column(name = "type")
	private String eventType;
	
	@ClusteringColumn
	@Column(name = "ts")
   	private Date eventTime;
	
	@Column(name = "uid")
	private UUID userId;	
	
	@PartitionKey(1)
	@Column(name = "ip")
   	private InetAddress ip;
	
	@Column(name = "sip")
   	private InetAddress serverip;
	
	@Column(name = "data")
   	private String eventData;

	private static MappingManager manager;
	

	public NewauthEventByTypeAndIP(UUID eventID, String eventType, Date eventTime, UUID userId, InetAddress ip,
			InetAddress serverip, String eventData) {
		super();
		this.eventID = eventID;
		this.eventType = eventType;
		this.eventTime = eventTime;
		this.userId = userId;
		this.ip = ip;
		this.serverip = serverip;
		this.eventData = eventData;
	}

	public UUID getEventID() {
		return eventID;
	}

	public void setEventID(UUID eventID) {
		this.eventID = eventID;
	}

	public String getEventType() {
		return eventType;
	}

	public void setEventType(String eventType) {
		this.eventType = eventType;
	}

	public Date getEventTime() {
		return eventTime;
	}

	public void setEventTime(Date eventTime) {
		this.eventTime = eventTime;
	}

	public UUID getUserId() {
		return userId;
	}

	public void setUserId(UUID userId) {
		this.userId = userId;
	}

	public InetAddress getIp() {
		return ip;
	}

	public void setIp(InetAddress ip) {
		this.ip = ip;
	}

	public InetAddress getServerip() {
		return serverip;
	}

	public void setServerip(InetAddress serverip) {
		this.serverip = serverip;
	}

	public String getEventData() {
		return eventData;
	}

	public void setEventData(String eventData) {
		this.eventData = eventData;
	}
   	
	public static String getInsertQueryStringWithQMarks() {
		
		return " INSERT INTO newauthanalytics.eventsbytypeandip (id, type, ts, uid, ip, sip, data ) values (?, ?, ?, ?, ?, ?, ?) USING TTL 3600; " ;
	}

	public void createViaMapper(Session sess) {
		
		if (manager == null) manager = new MappingManager(sess);

		Mapper<NewauthEventByTypeAndIP> mapper = manager.mapper(NewauthEventByTypeAndIP.class);
		
		long starttime = System.currentTimeMillis();
		mapper.saveAsync(this,  Option.ttl(3600));
		System.out.println("Added NewauthEventByTypeAndIP entry - Asynch : "  + " IP : "  + this.getIp().toString() + " in " + (System.currentTimeMillis() - starttime) + "ms");
		
	}
	
	
	public NewauthEventByTypeAndIP readViaMapper(Session sess) {
		if (manager == null) manager = new MappingManager(sess);
		Mapper<NewauthEventByTypeAndIP> mapper = manager.mapper(NewauthEventByTypeAndIP.class);
		long starttime = System.currentTimeMillis();

		NewauthEventByTypeAndIP out = mapper.get(this.getEventType(), this.getIp());
		
		System.out.println("Read NewauthEventByTypeAndIP back in: " + (System.currentTimeMillis() - starttime) + "ms" );
		
		return out;
	}


}
