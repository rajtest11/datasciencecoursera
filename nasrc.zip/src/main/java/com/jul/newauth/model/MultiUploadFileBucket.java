package com.jul.newauth.model;

import java.util.ArrayList;
import java.util.List;
 
public class MultiUploadFileBucket {
 
    List<UploadFileBucket> files = new ArrayList<UploadFileBucket>();
     
    public MultiUploadFileBucket(){
        files.add(new UploadFileBucket());
        files.add(new UploadFileBucket());
        files.add(new UploadFileBucket());
    }
     
    public List<UploadFileBucket> getFiles() {
        return files;
    }
 
    public void setFiles(List<UploadFileBucket> files) {
        this.files = files;
    }
}
