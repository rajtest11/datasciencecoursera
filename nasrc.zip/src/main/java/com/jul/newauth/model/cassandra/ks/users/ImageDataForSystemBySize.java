package com.jul.newauth.model.cassandra.ks.users;

import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;
import java.util.zip.Adler32;
import java.util.zip.CRC32;
import java.util.zip.Checksum;

import com.datastax.driver.core.PreparedStatement;
import com.datastax.driver.core.ResultSet;
import com.datastax.driver.core.Session;
import com.datastax.driver.core.utils.Bytes;
import com.datastax.driver.mapping.Mapper;
import com.datastax.driver.mapping.MappingManager;
import com.datastax.driver.mapping.Result;
import com.datastax.driver.mapping.annotations.ClusteringColumn;
import com.datastax.driver.mapping.annotations.Column;
import com.datastax.driver.mapping.annotations.PartitionKey;
import com.datastax.driver.mapping.annotations.Table;
import com.jul.newauth.util.NewAuthUtils;

@Table(keyspace = "newauthusers", name = "imagedataforsystembysize")
public class ImageDataForSystemBySize {
	
	@Column(name = "id")
	private UUID imageid;
	private UUID userid;
	
	@ClusteringColumn(0)
	@Column(name = "seq")
	private short imageseq;
	@PartitionKey
	private String size;
	
	
	@Column(name = "height")
	private int imageheight; // e.g. '1024
	
	@Column(name = "width")
	private int imagewidth; // e.g. '768
	//@ClusteringColumn(0)
	@Column(name = "ar")
	private float aspectratio; 
	
	@Column(name = "type")
	private String imagetype;
	
	@Column(name = "crdt")
	private Date createdate;
	@Column(name = "accdt")
    private Date lastaccessdate;
   
    private List<String> tags;
    
    private static PreparedStatement insertps = null;
    
    private static MappingManager manager;
    
    public ImageDataForSystemBySize() {}

    public static String getInsertQueryStringWithQMarks() {
		
		return " INSERT INTO newauthusers.imagedataforsystembysize ( id, userid, seq, size, height, width, ar, type, crdt, accdt, tags ) values (?, ?,?, ?,?, ?,?, ?,?, ?,?); " ;
	}
    
	public ImageDataForSystemBySize(UUID imageid, UUID userid, short imageseq, String size, int imageheight, int imagewidth,
			float aspectratio, String imagetype, Date createdate, Date lastaccessdate, List<String> tags) {
		super();
		this.imageid = imageid;
		this.userid = userid;
		this.imageseq = imageseq;
		this.size = size;
		this.imageheight = imageheight;
		this.imagewidth = imagewidth;
		this.aspectratio = aspectratio;
		this.imagetype = imagetype;
		this.createdate = createdate;
		this.lastaccessdate = lastaccessdate;
		this.tags = tags;
	}






	public UUID getImageid() {
		return imageid;
	}
	public void setImageid(UUID imageid) {
		this.imageid = imageid;
	}
	public UUID getUserid() {
		return userid;
	}
	public void setUserid(UUID userid) {
		this.userid = userid;
	}
	
	
	public Date getCreatedate() {
		return createdate;
	}
	public void setCreatedate(Date createdate) {
		this.createdate = createdate;
	}
	public Date getLastaccessdate() {
		return lastaccessdate;
	}
	public void setLastaccessdate(Date lastaccessdate) {
		this.lastaccessdate = lastaccessdate;
	}
	public List<String> getTags() {
		return tags;
	}
	public void setTags(List<String> tags) {
		this.tags = tags;
	}
	
	public String getSize() {
		return size;
	}

	public void setSize(String size) {
		this.size = size;
	}

	public String getImagetype() {
		return imagetype;
	}

	public void setImagetype(String imagetype) {
		this.imagetype = imagetype;
	}

	public int getImageheight() {
		return imageheight;
	}

	public short getImageseq() {
		return imageseq;
	}



	public void setImageseq(short imageseq) {
		this.imageseq = imageseq;
	}



	public void setImageheight(int imageheight) {
		this.imageheight = imageheight;
	}

	public int getImagewidth() {
		return imagewidth;
	}

	public void setImagewidth(int imagewidth) {
		this.imagewidth = imagewidth;
	}

	public float getAspectratio() {
		return aspectratio;
	}



	public void setAspectratio(float aspectratio) {
		this.aspectratio = aspectratio;
	}

	
	
	public ImageDataForSystemBySize getImageBySizeAndSeq(Session sess) {
		if (manager == null)
			manager = new MappingManager(sess);
		
		Mapper<ImageDataForSystemBySize> mapper = manager.mapper(ImageDataForSystemBySize.class);
		long starttime = System.currentTimeMillis();

		// Get imageData first
		ImageDataForSystemBySize img = mapper.get(this.getSize(), this.getImageseq());
		System.out.println("Read one image back from imagedatabymetadata by size and seq in: " + (System.currentTimeMillis() - starttime) + "ms" );
		
		
		return img;
		
	}
	

	
	public List<Integer> allSeqForSystemBySize(Session sess, String size) {
		List<Integer> out = new ArrayList<Integer> ();
		
		if (manager == null)
			manager = new MappingManager(sess);
		
		Mapper<ImageDataForSystemBySize> mapper = manager.mapper(ImageDataForSystemBySize.class);
		long starttime = System.currentTimeMillis();

		ResultSet results = sess.execute("SELECT seq FROM newauthusers.imagedataforsystembysize where size = '" + size  +	"' " );
		Result<ImageDataForSystemBySize> result = mapper.map(results);
		System.out.println("Read list of images back from imagedataforsystembysize in: " + (System.currentTimeMillis() - starttime) + "ms" );
		
		
		for (ImageDataForSystemBySize obj: result) {
			out.add((int) obj.getImageseq());
		}		
		
		return out;
	}
	
	

	public static void insertViaCQL(Session session, ImageDataForSystemBySize imgbyseq) {
		long starttime = System.currentTimeMillis();
		if (insertps == null)
			insertps = session.prepare(getInsertQueryStringWithQMarks());

		session.executeAsync(insertps.bind(
					
					imgbyseq.getImageid(),
					imgbyseq.getUserid(),
					imgbyseq.getImageseq(), 
					imgbyseq.getSize(),
					imgbyseq.getImageheight(),
					imgbyseq.getImagewidth(),
					imgbyseq.getAspectratio(),
					imgbyseq.getImagetype(),
					imgbyseq.getCreatedate(),
					imgbyseq.getLastaccessdate(),
					imgbyseq.getTags()
					
					));
		
		System.out.println("Added imagedataforsystembysize via cql in " +  (System.currentTimeMillis()-starttime) + "ms");
		
	}
    
}
