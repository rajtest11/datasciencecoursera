package com.jul.newauth.model.cassandra.ks.users;

import java.nio.ByteBuffer;
import java.util.UUID;

import com.datastax.driver.core.PreparedStatement;
import com.datastax.driver.core.ResultSet;
import com.datastax.driver.core.Row;
import com.datastax.driver.core.Session;
import com.datastax.driver.mapping.Mapper;
import com.datastax.driver.mapping.MappingManager;
import com.datastax.driver.mapping.annotations.Column;
import com.datastax.driver.mapping.annotations.PartitionKey;
import com.datastax.driver.mapping.annotations.Table;

@Table(keyspace = "newauthusers", name = "blobchunkdata")
public class BlobChunkData {
	
	@PartitionKey(0)
	private UUID object_id;
	@PartitionKey(1)	
	@Column(name = "seq")
	private int order;
	@Column(name = "sz")
	private long chunk_size;
	private ByteBuffer data;
	private static PreparedStatement readEntityps;
	private static MappingManager manager ;
	
	public BlobChunkData() {}
	
	
	public BlobChunkData(UUID object_id, int order, long chunk_size, ByteBuffer data) {
		super();
		this.object_id = object_id;
		this.order = order;
		this.chunk_size = chunk_size;
		this.data = data;
	}

	
	 public BlobChunkData getEntityFromCQL(Session sess) {
			
	    	String cql = "SELECT object_id, seq, sz, data  from newauthusers.blobchunkdata where object_id = ? and seq = ?" ;
	    	
			if (readEntityps == null)
				readEntityps = sess.prepare(cql);
			
			ResultSet rs = sess.execute(readEntityps.bind(this.getObject_id(), this.getOrder()));
			
			BlobChunkData out = new BlobChunkData();
			
			 for (Row row : rs) {
				 
				 out.setObject_id(row.getUUID("object_id"));
				 out.setOrder(row.getInt("seq"));
				 out.setChunk_size(row.getLong("sz"));
				 out.setData(row.getBytes("data"));
				
		     }
			return out;
			 
		}

	public UUID getObject_id() {
		return object_id;
	}
	public void setObject_id(UUID object_id) {
		this.object_id = object_id;
	}
	
	public int getOrder() {
		return order;
	}


	public void setOrder(int order) {
		this.order = order;
	}


	public long getChunk_size() {
		return chunk_size;
	}
	public void setChunk_size(long chunk_size) {
		this.chunk_size = chunk_size;
	}
	public ByteBuffer getData() {
		return data;
	}
	public void setData(ByteBuffer data) {
		this.data = data;
	}
	
	
public void createViaMapper(Session sess) {
		
		if (manager == null) manager = new MappingManager(sess);

		Mapper<BlobChunkData> mapper = manager.mapper(BlobChunkData.class);
		
		long starttime = System.currentTimeMillis();
		mapper.save(this);
		System.out.println("Added blobchunkdata: UUID: " + this.getObject_id() + " chunk: "  + this.getOrder() + " size: "  + this.getChunk_size() + " in " + (System.currentTimeMillis() - starttime) + "ms");
		
	}

}
