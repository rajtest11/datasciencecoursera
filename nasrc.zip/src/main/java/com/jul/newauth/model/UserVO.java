package com.jul.newauth.model;

import java.net.InetAddress;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.jul.newauth.model.cassandra.ks.users.Address;
import com.jul.newauth.model.cassandra.ks.users.Phone;

public class UserVO extends BaseVO {

	private String userid;
	private String username;
	private String usernameclear;
	private String firstname;
	private String middleinitial;
	private String lastname;
	private int validations;
	private Date createdate;
	private Date lastupdatedate;
	private Date lastaccessdate;
    
	private Map<String, Address> addresses ;
	private List<Phone> phones;
	private List<String> emails;
	private List<InetAddress> ipaddresses;
	
	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getUsernameclear() {
		return usernameclear;
	}
	public void setUsernameclear(String usernameclear) {
		this.usernameclear = usernameclear;
	}
	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public String getMiddleinitial() {
		return middleinitial;
	}
	public void setMiddleinitial(String middleinitial) {
		this.middleinitial = middleinitial;
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	public int getValidations() {
		return validations;
	}
	public void setValidations(int validations) {
		this.validations = validations;
	}
	public Date getCreatedate() {
		return createdate;
	}
	public void setCreatedate(Date createdate) {
		this.createdate = createdate;
	}
	public Date getLastupdatedate() {
		return lastupdatedate;
	}
	public void setLastupdatedate(Date lastupdatedate) {
		this.lastupdatedate = lastupdatedate;
	}
	public Date getLastaccessdate() {
		return lastaccessdate;
	}
	public void setLastaccessdate(Date lastaccessdate) {
		this.lastaccessdate = lastaccessdate;
	}
	public Map<String, Address> getAddresses() {
		return addresses;
	}
	public void setAddresses(Map<String, Address> addresses) {
		this.addresses = addresses;
	}
	public List<Phone> getPhones() {
		if (phones == null)
			phones = new ArrayList<Phone>(Arrays.asList(new Phone()));
		return phones;
	}
	public void setPhones(List<Phone> phones) {
		this.phones = phones;
	}
	public List<String> getEmails() {
		if (emails == null)
			emails = new ArrayList<String>(Arrays.asList(""));
		return emails;
	}
	public void setEmails(List<String> emails) {
		this.emails = emails;
	}
	public List<InetAddress> getIpaddresses() {
		return ipaddresses;
	}
	public void setIpaddresses(List<InetAddress> ipaddresses) {
		this.ipaddresses = ipaddresses;
	}
	
	
}
