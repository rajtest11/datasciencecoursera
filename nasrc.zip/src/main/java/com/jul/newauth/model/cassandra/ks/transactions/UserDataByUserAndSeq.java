package com.jul.newauth.model.cassandra.ks.transactions;

import java.util.Date;
import java.util.UUID;

import com.datastax.driver.core.PreparedStatement;
import com.datastax.driver.core.ResultSet;
import com.datastax.driver.core.Session;
import com.datastax.driver.mapping.Mapper;
import com.datastax.driver.mapping.MappingManager;
import com.datastax.driver.mapping.Result;
import com.datastax.driver.mapping.annotations.ClusteringColumn;
import com.datastax.driver.mapping.annotations.Column;
import com.datastax.driver.mapping.annotations.PartitionKey;
import com.datastax.driver.mapping.annotations.Table;

@Table(keyspace = "newauthtransactions", name = "databyuserandseq")
public class UserDataByUserAndSeq {

	@PartitionKey
    @Column(name = "id")
    private UUID userid;
	
	@ClusteringColumn
    @Column(name = "seq")
	private short sequence;
	
	private String salt;
	
	@Column(name = "itns")
	private int iterations;
	
	private String data;
	
	@Column(name = "udt")
	private Date lastupdatedate;
	
	@Column(name = "crdt")
	private Date createdate;

	private static MappingManager manager;
	
	public UUID getUserid() {
		return userid;
	}

	public void setUserid(UUID userid) {
		this.userid = userid;
	}

	public short getSequence() {
		return sequence;
	}

	public void setSequence(short sequence) {
		this.sequence = sequence;
	}

	public String getSalt() {
		return salt;
	}

	public void setSalt(String salt) {
		this.salt = salt;
	}

	public int getIterations() {
		return iterations;
	}

	public void setIterations(int iterations) {
		this.iterations = iterations;
	}

	public String getData() {
		return data;
	}

	public void setData(String data) {
		this.data = data;
	}

	public Date getLastupdatedate() {
		return lastupdatedate;
	}

	public void setLastupdatedate(Date lastupdatedate) {
		this.lastupdatedate = lastupdatedate;
	}

	public Date getCreatedate() {
		return createdate;
	}

	public void setCreatedate(Date createdate) {
		this.createdate = createdate;
	}

	public UserDataByUserAndSeq() {
		
	}
	
	
	public UserDataByUserAndSeq(UUID userid, short sequence, String salt, int iterations, String data,
			Date lastupdatedate, Date createdate) {
		super();
		this.userid = userid;
		this.sequence = sequence;
		this.salt = salt;
		this.iterations = iterations;
		this.data = data;
		this.lastupdatedate = lastupdatedate;
		this.createdate = createdate;
	}

	public void createViaDirectCQL(Session session) {
		long starttime = System.currentTimeMillis();
		PreparedStatement ps = session.prepare(
				   getInsertQueryStringWithQMarks()
				);
		
		session.executeAsync(ps.bind(getUserid(), 
									getSequence(),
									getSalt(), 
									getIterations(),
									getData(),
									getLastupdatedate(),
										getCreatedate()
										));
		System.out.println("Added UserDataByUserAndSeq entry - Direct CQL : " + 
				((this.getUserid() ==null)?"":this.getUserid().toString()) + 
				" seq : "  + this.getSequence() + 
				" in " + (System.currentTimeMillis() - starttime) + "ms");

	}
	
	public static String getInsertQueryStringWithQMarks() {
		
		return " INSERT INTO newauthtransactions.databyuserandseq (id. seq, salt, itns, data, udt, crdt ) values (?, ?, ?, ?, ?, ?, ?); " ;
	}
	
	public Result<UserDataByUserAndSeq> readViaUserId(Session sess, UUID userid) {
		if (manager == null)
			manager = new MappingManager(sess);
		
		Mapper<UserDataByUserAndSeq> mapper = manager.mapper(UserDataByUserAndSeq.class);
		long starttime = System.currentTimeMillis();

		ResultSet results = sess.execute("SELECT * FROM newauthtransactions.databyuserandseq where id = " + userid );
		Result<UserDataByUserAndSeq> out = mapper.map(results);
		
		/*for (UserIdsByIP u : out) {
		   // System.out.println("Users from IP : " + ip.toString() + " - "+ u.getUserid());
		}*/
		
		System.out.println("Read UserDataByUserAndSeq by userid query in: " + (System.currentTimeMillis() - starttime) + "ms" );
		
		return out;
	}
	
	
	
}
