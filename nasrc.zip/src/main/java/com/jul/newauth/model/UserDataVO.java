package com.jul.newauth.model;

import java.util.Date;
import java.util.UUID;

import com.jul.newauth.util.NewAuthUtils;

public class UserDataVO {	
	
    private UUID userid;	
	private short sequence; // 1 - 'sites', 2 - 'financial', 3 - 'official', 4 - 'personal' ....
	private String salt;	
	private int iterations;	
	private String data;
	private Date lastupdatedate;
	private Date createdate;
	
	public UUID getUserid() {
		return userid;
	}
	public void setUserid(UUID userid) {
		this.userid = userid;
	}
	public short getSequence() {
		return sequence;
	}
	public void setSequence(short sequence) {
		this.sequence = sequence;
	}
	public String getSalt() {
		return salt;
	}
	public void setSalt(String salt) {
		this.salt = salt;
	}
	public int getIterations() {
		return iterations;
	}
	public void setIterations(int iterations) {
		this.iterations = iterations;
	}
	public String getData() {
		return data;
	}
	public void setData(String data) {
		this.data = data;
	}
	public Date getLastupdatedate() {
		return lastupdatedate;
	}
	public void setLastupdatedate(Date lastupdatedate) {
		this.lastupdatedate = lastupdatedate;
	}
	public Date getCreatedate() {
		return createdate;
	}
	public void setCreatedate(Date createdate) {
		this.createdate = createdate;
	}
	
	@Override
	public String toString() {
	    return NewAuthUtils.toStringForPrint(this);
	}

}
