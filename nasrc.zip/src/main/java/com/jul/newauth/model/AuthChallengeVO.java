package com.jul.newauth.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;

public class AuthChallengeVO extends BaseVO {
	
	private Date ts;
	private UUID sessionid;
	private List<String> images;
	private List<Integer> seqs;
	private UUID userid;
	
	public Date getTs() {
		return ts;
	}
	public void setTs(Date ts) {
		this.ts = ts;
	}
	public UUID getSessionid() {
		return sessionid;
	}
	public void setSessionid(UUID sessionid) {
		this.sessionid = sessionid;
	}
	public List<String> getImages() {
		if (images == null)
			return new ArrayList<String>();
		return images;
	}
	
	public List<Integer> getSeqs() {
		return seqs;
	}
	public void setSeqs(List<Integer> seqs) {
		this.seqs = seqs;
	}
	public UUID getUserid() {
		return userid;
	}
	public void setUserid(UUID userid) {
		this.userid = userid;
	}
	

}
