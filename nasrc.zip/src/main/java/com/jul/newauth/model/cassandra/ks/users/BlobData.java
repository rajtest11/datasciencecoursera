package com.jul.newauth.model.cassandra.ks.users;

import java.util.UUID;

import com.datastax.driver.core.PreparedStatement;
import com.datastax.driver.core.ResultSet;
import com.datastax.driver.core.Row;
import com.datastax.driver.core.Session;
import com.datastax.driver.mapping.Mapper;
import com.datastax.driver.mapping.MappingManager;
import com.datastax.driver.mapping.annotations.Column;
import com.datastax.driver.mapping.annotations.PartitionKey;
import com.datastax.driver.mapping.annotations.Table;

@Table(keyspace = "newauthusers", name = "blobdata")
public class BlobData {

	@PartitionKey
	private UUID object_id;
	@Column(name = "cnt")
	private int chunk_count;
	@Column(name = "chsz")
	private long chunk_size;
	@Column(name = "sz")
	private long size;
	@Column(name = "sum")
	private String checksum;
	private static PreparedStatement readEntityps;
	
	private static MappingManager manager ;
	
	public BlobData() {}
	
	public static String getInsertQueryStringWithQMarks() {
		
		return " INSERT INTO newauthusers.blobdata ( object_id, cnt, chsz, sz, sum ) values (?, ?,?, ?,?); " ;
	}
	
	
	 public BlobData getEntityFromCQL(Session sess) {
			
	    	String cql = "SELECT object_id, cnt, chsz, sz, sum from newauthusers.blobdata where object_id = ?;" ;
	    	
			if (readEntityps == null)
				readEntityps = sess.prepare(cql);
			
			ResultSet rs = sess.execute(readEntityps.bind(this.getObject_id()));
			
			BlobData out = new BlobData();
			
			 for (Row row : rs) {
				 
				 out.setObject_id(row.getUUID("object_id"));
				 out.setChunk_count(row.getInt("cnt"));
				 out.setChunk_size(row.getLong("chsz"));
				 out.setChecksum(row.getString("sum"));
				 out.setSize(row.getLong("sz"));
				 
		     }
			return out;
			 
		}

	public BlobData(UUID object_id, int chunk_count, long chunk_size, long size, String checksum) {
		super();
		this.object_id = object_id;
		this.chunk_count = chunk_count;
		this.chunk_size = chunk_size;
		this.size = size;
		this.checksum = checksum;
	}

	public UUID getObject_id() {
		return object_id;
	}

	public void setObject_id(UUID object_id) {
		this.object_id = object_id;
	}

	public int getChunk_count() {
		return chunk_count;
	}

	public void setChunk_count(int chunk_count) {
		this.chunk_count = chunk_count;
	}

	public long getChunk_size() {
		return chunk_size;
	}

	public void setChunk_size(long chunk_size) {
		this.chunk_size = chunk_size;
	}

	public long getSize() {
		return size;
	}

	public void setSize(long size) {
		this.size = size;
	}

	public String getChecksum() {
		return checksum;
	}

	public void setChecksum(String checksum) {
		this.checksum = checksum;
	}
	
	public void createViaMapper(Session sess) {
		
		if (manager == null) manager = new MappingManager(sess);

		Mapper<BlobData> mapper = manager.mapper(BlobData.class);
		
		long starttime = System.currentTimeMillis();
		mapper.save(this);
		System.out.println("Added blobdata: UUID: " + this.getObject_id() + " checksum: "  + this.getChecksum() + " chunks: "  + this.getChunk_count() + " in " + (System.currentTimeMillis() - starttime) + "ms");
		
	}
	
}
