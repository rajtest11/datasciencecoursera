package com.jul.newauth.model.cassandra.ks.transactions;

import java.util.Date;
import java.util.List;
import java.util.UUID;

import com.datastax.driver.core.ResultSet;
import com.datastax.driver.core.Session;
import com.datastax.driver.mapping.Mapper;
import com.datastax.driver.mapping.MappingManager;
import com.datastax.driver.mapping.Result;
import com.datastax.driver.mapping.annotations.ClusteringColumn;
import com.datastax.driver.mapping.annotations.Column;
import com.datastax.driver.mapping.annotations.PartitionKey;
import com.datastax.driver.mapping.annotations.Table;

@Table(keyspace = "newauthtransactions", name = "userimagememory")
public class UserImageClickMemoryData {
	
	
	@Column(name = "id")
	private UUID imageid;	
	
	@PartitionKey
	private UUID userid;
	
	@ClusteringColumn
	@Column(name = "gseq")
	private int globalSeq;	
	
	private int clickx;
	private int clicky;
	
	private int imgwidth;
	private int imgheight;
	private String locationhash;
	private String progressivehash;
	private int delay; // delay in milliseconds
	private Date recordcreatedate;
	private Date lastupdatedate;
	private List<Integer> delayhistory;
	private List<String> phashhistory; // TODO: useful in tracking replay attacks and also tweaking auth score based on user pattern
	
	private int avgdelay;
	private int mindelay;
	private int maxdelay;
	private int meddelay;  // Median delay
	@Column(name="rtclk")
	private int successcount;
	
	@Column(name="flclk")
	private int failurecount;
	
	private static MappingManager manager;
   
    public UserImageClickMemoryData() {}

	


	public UserImageClickMemoryData(UUID imageid, UUID userid, int globalSeq, int clickx, int clicky, int imgwidth,
			int imgheight, String locationhash, String progressivehash, int delay, Date recordcreatedate,
			Date lastupdatedate, List<Integer> delayhistory, List<String> phashhistory, int avgdelay, int mindelay,
			int maxdelay, int meddelay, int successcount, int failurecount) {
		super();
		this.imageid = imageid;
		this.userid = userid;
		this.globalSeq = globalSeq;
		this.clickx = clickx;
		this.clicky = clicky;
		this.imgwidth = imgwidth;
		this.imgheight = imgheight;
		this.locationhash = locationhash;
		this.progressivehash = progressivehash;
		this.delay = delay;
		this.recordcreatedate = recordcreatedate;
		this.lastupdatedate = lastupdatedate;
		this.delayhistory = delayhistory;
		this.phashhistory = phashhistory;
		this.avgdelay = avgdelay;
		this.mindelay = mindelay;
		this.maxdelay = maxdelay;
		this.meddelay = meddelay;
		this.successcount = successcount;
		this.failurecount = failurecount;
	}




	public UUID getImageid() {
		return imageid;
	}
	public void setImageid(UUID imageid) {
		this.imageid = imageid;
	}
	public UUID getUserid() {
		return userid;
	}
	public void setUserid(UUID userid) {
		this.userid = userid;
	}
	

	public int getGlobalSeq() {
		return globalSeq;
	}

	public void setGlobalSeq(int globalSeq) {
		this.globalSeq = globalSeq;
	}

	public static String getInsertQueryStringWithQMarks() {		
				
		return " INSERT INTO newauthtransactions.userimagememory (id , userid ,gseq ,clickx ,clicky ,imgwidth ,imgheight ,locationhash ,progressivehash ,delay ,recordcreatedate , lastupdatedate ,  delayhistory , phashhistory ,avgdelay , mindelay , maxdelay , meddelay, rtclk , flclk ) values (?, ?, ?,?, ?, ?,?, ?, ?,?, ?, ?,?, ?, ?,?, ?, ?, ?,?); " ;
	}
	
	public void createViaMapper(Session sess) {
		
		if (manager == null)
			manager = new MappingManager(sess);

		Mapper<UserImageClickMemoryData> mapper = manager.mapper(UserImageClickMemoryData.class);
		
		long starttime = System.currentTimeMillis();
		mapper.save(this);
		System.out.println("Added imageclickdata: UUID: " + this.getImageid() + " user: " + this.getUserid() + " in " + (System.currentTimeMillis() - starttime) + "ms");
		
	}
	
	public UserImageClickMemoryData readViaMapper(Session sess) {
		
		if (manager == null)
			manager = new MappingManager(sess);
		Mapper<UserImageClickMemoryData> mapper = manager.mapper(UserImageClickMemoryData.class);
		long starttime = System.currentTimeMillis();

		
		UserImageClickMemoryData img = mapper.get(this.getUserid(), this.getGlobalSeq());
		System.out.println("Read UserImageClickMemoryData by mapper in: " + (System.currentTimeMillis() - starttime) + "ms. Based on userid " 
							+ this.getUserid() + " gseq: " 
							+ this.getGlobalSeq() );
		return img;
		
		
	}
	
	
	public Result<UserImageClickMemoryData> readAllImageRecordsBasedOnUserid(Session sess) {
		
		long starttime = System.currentTimeMillis();
		if (manager == null)
			manager = new MappingManager(sess);
		Mapper<UserImageClickMemoryData> mapper = manager.mapper(UserImageClickMemoryData.class);
		
		ResultSet results = sess.execute("SELECT * FROM newauthtransactions.userimagememory where userid = " +  this.getUserid() );
		
		Result<UserImageClickMemoryData> img = mapper.map(results);
		
		System.out.println("Read UserImageClickMemoryData by cql in: " + (System.currentTimeMillis() - starttime) + "ms. Based on userid " 
							+ this.getUserid()  );
		return img;
		
		
	}
	
	
	
	
	public Result<UserImageClickMemoryData> readImageRecordsWithNoClearClickDataBasedOnUserid(Session sess) { /// These are the records
																										// Which have finalized click data converted to hash
		
		long starttime = System.currentTimeMillis();
		if (manager == null)
			manager = new MappingManager(sess);
		Mapper<UserImageClickMemoryData> mapper = manager.mapper(UserImageClickMemoryData.class);
		
		ResultSet results = sess.execute("SELECT * FROM newauthtransactions.userimagememory where userid = " +  this.getUserid());
		
		Result<UserImageClickMemoryData> img = mapper.map(results);
		
		System.out.println("Read UserImageClickMemoryData by cql in: " + (System.currentTimeMillis() - starttime) + "ms. Based on userid " 
							+ this.getUserid()  );
		return img;
		
		
	}
	
	



	public int getClickx() {
		return clickx;
	}












	public void setClickx(int clickx) {
		this.clickx = clickx;
	}












	public int getClicky() {
		return clicky;
	}












	public void setClicky(int clicky) {
		this.clicky = clicky;
	}












	public int getImgwidth() {
		return imgwidth;
	}


	public void setImgwidth(int imgwidth) {
		this.imgwidth = imgwidth;
	}


	public int getImgheight() {
		return imgheight;
	}


	public void setImgheight(int imgheight) {
		this.imgheight = imgheight;
	}


	public String getLocationhash() {
		return locationhash;
	}












	public void setLocationhash(String locationhash) {
		this.locationhash = locationhash;
	}












	public int getDelay() {
		return delay;
	}












	public void setDelay(int delay) {
		this.delay = delay;
	}












	public Date getRecordcreatedate() {
		return recordcreatedate;
	}












	public void setRecordcreatedate(Date recordcreatedate) {
		this.recordcreatedate = recordcreatedate;
	}












	public Date getLastupdatedate() {
		return lastupdatedate;
	}












	public void setLastupdatedate(Date lastupdatedate) {
		this.lastupdatedate = lastupdatedate;
	}












	public List<Integer> getDelayhistory() {
		return delayhistory;
	}












	public void setDelayhistory(List<Integer> delayhistory) {
		this.delayhistory = delayhistory;
	}







	public String getProgressivehash() {
		return progressivehash;
	}







	public void setProgressivehash(String progressivehash) {
		this.progressivehash = progressivehash;
	}







	public int getAvgdelay() {
		return avgdelay;
	}







	public void setAvgdelay(int avgdelay) {
		this.avgdelay = avgdelay;
	}







	public int getMindelay() {
		return mindelay;
	}







	public void setMindelay(int mindelay) {
		this.mindelay = mindelay;
	}







	public int getMaxdelay() {
		return maxdelay;
	}







	public void setMaxdelay(int maxdelay) {
		this.maxdelay = maxdelay;
	}




	public int getMeddelay() {
		return meddelay;
	}




	public void setMeddelay(int meddelay) {
		this.meddelay = meddelay;
	}




	public List<String> getPhashhistory() {
		return phashhistory;
	}




	public void setPhashhistory(List<String> phashhistory) {
		this.phashhistory = phashhistory;
	}




	public int getSuccesscount() {
		return successcount;
	}




	public void setSuccesscount(int successcount) {
		this.successcount = successcount;
	}




	public int getFailurecount() {
		return failurecount;
	}




	public void setFailurecount(int failurecount) {
		this.failurecount = failurecount;
	}
    
}
