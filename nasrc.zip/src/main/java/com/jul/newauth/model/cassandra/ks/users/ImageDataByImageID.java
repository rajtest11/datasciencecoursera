package com.jul.newauth.model.cassandra.ks.users;

import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.Date;
import java.util.List;
import java.util.UUID;
import java.util.zip.Adler32;
import java.util.zip.CRC32;
import java.util.zip.Checksum;

import com.datastax.driver.core.PreparedStatement;
import com.datastax.driver.core.ResultSet;
import com.datastax.driver.core.Row;
import com.datastax.driver.core.Session;
import com.datastax.driver.core.utils.Bytes;
import com.datastax.driver.mapping.Mapper;
import com.datastax.driver.mapping.MappingManager;
import com.datastax.driver.mapping.annotations.ClusteringColumn;
import com.datastax.driver.mapping.annotations.Column;
import com.datastax.driver.mapping.annotations.PartitionKey;
import com.datastax.driver.mapping.annotations.Table;
import com.jul.newauth.model.ImageVO;

@Table(keyspace = "newauthusers", name = "imagedatabyuuid")
public class ImageDataByImageID {
	
	@PartitionKey
	@Column(name = "id")
	private UUID imageid;
	private UUID userid;
	@Column(name = "seq")
	private int imageseq;
	private String size;
	@Column(name = "height")
	private int imageheight; // e.g. '1024
	@Column(name = "width")
	private int imagewidth; // e.g. '768
	@Column(name = "ar")
	private float aspectratio; 
	
	@Column(name = "type")
	private String imagetype;
	@Column(name = "crdt")
	private Date createdate;
	@Column(name = "accdt")
    private Date lastaccessdate;
    private List<String> tags;
    
    private static PreparedStatement readEntityps = null;
    
    private static MappingManager manager;
    
    public ImageDataByImageID() {}

	
    public static String getInsertQueryStringWithQMarks() {
		
		return " INSERT INTO newauthusers.imagedatabyuuid ( id, userid, seq, size, height, width, ar, type, crdt, accdt, tags ) values (?, ?,?, ?,?, ?,?, ?,?, ?,?); " ;
	}

	
    public ImageDataByImageID getEntityFromCQL(Session sess) {
		
    	String cql = "SELECT id, userid, seq, size, height, width, ar, type, crdt, accdt, tags from newauthusers.imagedatabyuuid where id = ?;" ;
    	
		if (readEntityps == null)
			readEntityps = sess.prepare(cql);
		
		ResultSet rs = sess.execute(readEntityps.bind(this.getImageid()));
		
		ImageDataByImageID out = new ImageDataByImageID();
		
		 for (Row row : rs) {
			 
			 out.setImageid(row.getUUID("id"));
			 out.setUserid(row.getUUID("userid"));
			 out.setImageseq(row.getInt("seq"));
			 out.setSize(row.getString("size"));
			 out.setImageheight(row.getInt("height"));
			 out.setImagewidth(row.getInt("width"));
			 out.setAspectratio(row.getFloat("ar"));
			 out.setImagetype(row.getString("type"));
			 out.setCreatedate(row.getTimestamp("crdt"));
			 out.setLastaccessdate(row.getTimestamp("accdt"));
			 out.setTags(row.getList("tags", String.class));
			 
	           
	     }
		return out;
		 
	}




	public ImageDataByImageID(UUID imageid, UUID userid, int imageseq, String size, int imageheight, int imagewidth,
			float aspectratio, String imagetype, Date createdate, Date lastaccessdate, List<String> tags) {
		super();
		this.imageid = imageid;
		this.userid = userid;
		this.imageseq = imageseq;
		this.size = size;
		this.imageheight = imageheight;
		this.imagewidth = imagewidth;
		this.aspectratio = aspectratio;
		this.imagetype = imagetype;
		this.createdate = createdate;
		this.lastaccessdate = lastaccessdate;
		this.tags = tags;
	}









	public UUID getImageid() {
		return imageid;
	}
	public void setImageid(UUID imageid) {
		this.imageid = imageid;
	}
	public UUID getUserid() {
		return userid;
	}
	public void setUserid(UUID userid) {
		this.userid = userid;
	}
	
	public String getSize() {
		return size;
	}

	public void setSize(String size) {
		this.size = size;
	}
	public Date getCreatedate() {
		return createdate;
	}
	public void setCreatedate(Date createdate) {
		this.createdate = createdate;
	}
	public Date getLastaccessdate() {
		return lastaccessdate;
	}
	public void setLastaccessdate(Date lastaccessdate) {
		this.lastaccessdate = lastaccessdate;
	}
	public List<String> getTags() {
		return tags;
	}
	public void setTags(List<String> tags) {
		this.tags = tags;
	}
	
	public String getImagetype() {
		return imagetype;
	}

	public void setImagetype(String imagetype) {
		this.imagetype = imagetype;
	}

	public int getImageheight() {
		return imageheight;
	}

	public void setImageheight(int imageheight) {
		this.imageheight = imageheight;
	}

	public int getImageseq() {
		return imageseq;
	}









	public void setImageseq(int imageseq) {
		this.imageseq = imageseq;
	}









	public int getImagewidth() {
		return imagewidth;
	}

	public void setImagewidth(int imagewidth) {
		this.imagewidth = imagewidth;
	}

	


	public float getAspectratio() {
		return aspectratio;
	}









	public void setAspectratio(float aspectratio) {
		this.aspectratio = aspectratio;
	}









	public void createViaMapper(Session sess) {
		
		
		if (manager == null) manager = new MappingManager(sess);

		Mapper<ImageDataByImageID> mapper = manager.mapper(ImageDataByImageID.class);
		
		long starttime = System.currentTimeMillis();
		mapper.save(this);
		System.out.println("Added imagedata: UUID: " + this.getImageid() + " size: "  + this.getImageheight() + "X" + this.getImagewidth() + " in " + (System.currentTimeMillis() - starttime) + "ms");
		
	}
	
	public ImageVO getImageBlobDataByImageID(Session sess) {
		if (manager == null)  manager = new MappingManager(sess);
		Mapper<ImageDataByImageID> mapper = manager.mapper(ImageDataByImageID.class);
		long starttime = System.currentTimeMillis();

		ImageVO out = new ImageVO();
		
		out.setImageid(this.getImageid());
		// Get imageData first
		ImageDataByImageID img = mapper.get(this.getImageid());
		
		if (img != null) {
			// Get Blobdata next
			Mapper<BlobData> bmapper = manager.mapper(BlobData.class);
			BlobData blob = bmapper.get(img.getImageid());
			
			// Get blob chunks next
			Mapper<BlobChunkData> cmapper = manager.mapper(BlobChunkData.class);
			byte[] imagebytes = new byte [(int) blob.getSize()];
			
			ByteBuffer buf = ByteBuffer.allocate((int) blob.getSize());
			ByteArrayOutputStream outputStream = new ByteArrayOutputStream( );
			for (int i=1; i<=blob.getChunk_count(); i++) {
				BlobChunkData chunk = cmapper.get(img.getImageid(), i);
				
				//System.out.println("\tFile segment " + i + ": last 4 bytes [" + chunk.getData().array()[(int) (chunk.getChunk_size()-4)] + chunk.getData().array()[(int) (chunk.getChunk_size()-3)] + chunk.getData().array()[(int) (chunk.getChunk_size()-2)] + chunk.getData().array()[(int) (chunk.getChunk_size()-1)] + "]");
				
				outputStream.write(chunk.getData().array(), 0, (int)chunk.getChunk_size());
			}
			
			Checksum  chksum = new CRC32();
			imagebytes = outputStream.toByteArray();
			chksum.update(imagebytes,0,imagebytes.length);
			
			System.out.println("Read image " +  this.getImageid() + ":" + this.getSize() + " back by mapper in: " + (System.currentTimeMillis() - starttime) + "ms" + " size: " + imagebytes.length);
			if (chksum.getValue() == Long.parseLong(blob.getChecksum())) {
				//saveFile(imagebytes);
				
				out.setChecksum(Long.parseLong(blob.getChecksum()));
				out.setImagebytes(imagebytes);
				out.setImagesize(blob.getSize());
				out.setImagetype(img.getImagetype());
				return out;
			} else {
				System.out.println("Checksum match failed: in " + blob.getChecksum() + " out " + chksum.getValue() + " ImageID: " + getImageid());
				return null;
			}
		} else {
			System.out.println("Mapper returned no image for ID " + this.getImageid());
			return null;
		}
		
		
	}
	
	
	public ImageVO getImageBlobDataByImageIDViaCQL(Session sess) {
		long starttime = System.currentTimeMillis();
		if (manager == null)
			manager = new MappingManager(sess);


		ImageVO out = new ImageVO();
		
		out.setImageid(this.getImageid());
		// Get imageData first
		ImageDataByImageID img = getEntityFromCQL(sess);
		
		if (img != null) {
			// Get Blobdata next
			BlobData bd = new BlobData();
			bd.setObject_id(img.getImageid());
			
			BlobData blob = bd.getEntityFromCQL(sess);
			
			// Get blob chunks next
			byte[] imagebytes = new byte [(int) blob.getSize()];
			
			ByteBuffer buf = ByteBuffer.allocate((int) blob.getSize());
			ByteArrayOutputStream outputStream = new ByteArrayOutputStream( );
			for (int i=1; i<=blob.getChunk_count(); i++) {
				BlobChunkData bcd = new BlobChunkData();
				bcd.setObject_id(img.getImageid());
				bcd.setOrder(i);
				BlobChunkData chunk = bcd.getEntityFromCQL(sess);
				
				//System.out.println("\tFile segment " + i + ": last 4 bytes [" + chunk.getData().array()[(int) (chunk.getChunk_size()-4)] + chunk.getData().array()[(int) (chunk.getChunk_size()-3)] + chunk.getData().array()[(int) (chunk.getChunk_size()-2)] + chunk.getData().array()[(int) (chunk.getChunk_size()-1)] + "]");
				
				outputStream.write(chunk.getData().array(), 0, (int)chunk.getChunk_size());
			}
			
			Checksum  chksum = new CRC32();
			imagebytes = outputStream.toByteArray();
			chksum.update(imagebytes,0,imagebytes.length);
			
			System.out.println("Read image " +  this.getImageid()  + ":" + this.getSize() + " back by CQL in: " + (System.currentTimeMillis() - starttime) + "ms" + " size: " + imagebytes.length);
			if (chksum.getValue() == Long.parseLong(blob.getChecksum())) {
				//saveFile(imagebytes);
				
				out.setChecksum(Long.parseLong(blob.getChecksum()));
				out.setImagebytes(imagebytes);
				out.setImagesize(blob.getSize());
				out.setImagetype(img.getImagetype());
				return out;
			} else {
				System.out.println("Checksum match failed: in " + blob.getChecksum() + " out " + chksum.getValue() + " ImageID: " + getImageid());
				return null;
			}
		} else {
			System.out.println("Mapper returned no image for ID " + this.getImageid());
			return null;
		}
		
		
	}
	
	private void saveFile(byte[] filedata) {
		FileOutputStream fos = null;
		try {
			fos = new FileOutputStream("c:\\temp\\readfromcass.jpg");
			fos.write(filedata);
			fos.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				if (fos != null)
					fos.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
	}



	public ImageDataByImageID readViaMapper(Session session) {
		if (manager == null)  manager = new MappingManager(session);
		Mapper<ImageDataByImageID> mapper = manager.mapper(ImageDataByImageID.class);
		long starttime = System.currentTimeMillis();

		ImageDataByImageID img = mapper.get(this.getImageid());
		
		System.out.println("Read imagedata: UUID: " + this.getImageid() + " size: "  + this.getSize() + " in " + (System.currentTimeMillis() - starttime) + "ms");
		
		return img;
		
	}
    
}
