package com.jul.newauth.model;

import org.apache.commons.lang3.builder.ToStringBuilder;

public class BaseVO {
	
	public String toString()
	{
		return ToStringBuilder.reflectionToString(this);
	}

}
