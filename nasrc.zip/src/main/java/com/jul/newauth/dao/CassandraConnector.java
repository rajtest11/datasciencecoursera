package com.jul.newauth.dao;

import com.datastax.driver.core.Cluster;
import com.datastax.driver.core.Cluster.Builder;
import com.datastax.driver.core.Host;

import com.datastax.driver.core.Metadata;
import com.datastax.driver.core.QueryLogger;
import com.datastax.driver.core.Session;

import static java.lang.System.out;


import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * 
 * Class used for connecting to Cassandra database.
 * 
 */
@Component
public class CassandraConnector

{

	/** Cassandra Cluster. */

	private Cluster cluster;

	
	/** Cassandra Session. */

	private Session session;

	@Value("${spring.data.cassandra.contact-points}")
	private String contactPoints;

	@Value("${spring.data.cassandra.port}")
	private String port;
	
	@Autowired
	CreateNewAuthSchema schema;

	
	@PostConstruct
	private void InstantiateCassandraConnector() {
		connect();
	}
	
	/**
	 * 
	 * Connect to Cassandra Cluster 
	 * 
	 */

	private void connect()

	{

		Builder b = Cluster.builder();

		String[] cpArr = contactPoints.split(",");

		for (String node : cpArr) {
			b.addContactPoint(node);
			Integer p = Integer.parseInt(port);
			if (null != p)
				b.withPort(p);
		}
		this.cluster = b.build();
		
		// Attach query logger
		
		QueryLogger queryLogger = QueryLogger.builder()
			    .withConstantThreshold(100)
			    .withMaxQueryStringLength(300)
			.build();
		
		this.cluster.register(queryLogger);

		final Metadata metadata = cluster.getMetadata();

		out.println("");
		out.printf("Connected to cluster: %s\n", metadata.getClusterName());

		for (final Host host : metadata.getAllHosts())

		{

			out.printf("Datacenter: %s; Host: %s; Rack: %s\n",

					host.getDatacenter(), host.getAddress(), host.getRack());

		}
		out.println("");
		
		this.session = cluster.connect();
		
		schema.createKeySpaces();
		schema.createTables();
		
		
		//schema.deleteImages();
		//schema.deleteUsers();
		//schema.createUserData();
		//schema.createImageDataFromFile();
	}

	/**
	 * 
	 * Provide my Session.
	 * 
	 */

	public Session getSession()

	{
		if (this.session == null)
			connect();
		
		return  this.session;

	}
	
	public Cluster getCluster() {
		return cluster;
	}


	/** Close cluster. */

	public void close()

	{

		cluster.close();

	}

	public void create(String cql) {
		
		System.out.println("Inserting record from baseclass. CQL: " + cql);
		session.execute(cql);
	}
	
	
	public void update(String cql) {
		
		System.out.println("Updating record from baseclass. CQL: " + cql);
		session.execute(cql);
		
	}
}
