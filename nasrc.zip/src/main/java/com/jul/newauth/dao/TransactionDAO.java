package com.jul.newauth.dao;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.datastax.driver.core.BatchStatement;
import com.datastax.driver.core.BoundStatement;
import com.datastax.driver.core.PreparedStatement;
import com.datastax.driver.mapping.Mapper;
import com.datastax.driver.mapping.MappingManager;
import com.datastax.driver.mapping.Result;
import com.jul.newauth.model.SessionDataVO;
import com.jul.newauth.model.cassandra.ks.analytics.NewauthEvent;
import com.jul.newauth.model.cassandra.ks.analytics.NewauthEventByIP;
import com.jul.newauth.model.cassandra.ks.analytics.NewauthEventByServerIP;
import com.jul.newauth.model.cassandra.ks.analytics.NewauthEventByType;
import com.jul.newauth.model.cassandra.ks.analytics.NewauthEventByTypeAndIP;
import com.jul.newauth.model.cassandra.ks.analytics.NewauthEventByTypeAndServerIP;
import com.jul.newauth.model.cassandra.ks.analytics.NewauthEventByUser;
import com.jul.newauth.model.cassandra.ks.analytics.NewauthEventByUserAndType;
import com.jul.newauth.model.cassandra.ks.transactions.AcccessByIP;
import com.jul.newauth.model.cassandra.ks.transactions.AccessByUserID;
import com.jul.newauth.model.cassandra.ks.transactions.AccessByUserIDAndSession;
import com.jul.newauth.model.cassandra.ks.transactions.HashByIpAndUserAgent;
import com.jul.newauth.model.cassandra.ks.transactions.UserIdByHash;
import com.jul.newauth.model.cassandra.ks.transactions.UserIdsByIP;
import com.jul.newauth.model.cassandra.ks.transactions.UserImageClickMemoryData;
import com.jul.newauth.model.cassandra.ks.users.ImageDataByImageID;
import com.jul.newauth.model.cassandra.ks.users.ImageSizesAndAR;
import com.jul.newauth.model.cassandra.ks.users.UsersByUserid;
import com.jul.newauth.model.cassandra.ks.users.UsersByUsername;
import com.jul.newauth.util.NewAuthUtils;

@Component
public class TransactionDAO {

	@Autowired
	CassandraConnector cassconnector;

	public UserIdByHash getUserBasedonHash(String hash) {
		UserIdByHash out = new UserIdByHash();
		out.setUseridhash(hash);

		out = out.readViaMapper(cassconnector.getSession());

		return out;
	}

	public HashByIpAndUserAgent getUserBasedonIpAndUserAgentAndUserName(InetAddress ip, String useragent,
			String username) {
		HashByIpAndUserAgent out = new HashByIpAndUserAgent();
		out.setIpaddress(ip);
		out.setUseragent(useragent);
		out.setUsername(username);

		out = out.readViaCQLAndMapper(cassconnector.getSession());

		return out;
	}

	public Result<UserIdsByIP> getUserBasedonIpAndUserID(InetAddress ip, UUID userid) {
		Result<UserIdsByIP> out = null;
		UserIdsByIP objhash = new UserIdsByIP();
		out = objhash.readViaIPAndUserId(cassconnector.getSession(), ip, userid);

		return out;
	}
	
	public UserImageClickMemoryData getClickDataBasedonUserAndImage(UUID userid, int seq) {
		
		UserImageClickMemoryData obj = new UserImageClickMemoryData();
		obj.setGlobalSeq(seq);
		obj.setUserid(userid);
		
		return obj.readViaMapper(cassconnector.getSession());
	}
	
	
	public int getFinalizedUserImageCount(UUID userid) {
		
		int out = 0;
		UserImageClickMemoryData obj = new UserImageClickMemoryData();		
		obj.setUserid(userid);
		
		Result<UserImageClickMemoryData> records = obj.readAllImageRecordsBasedOnUserid(cassconnector.getSession());
		
		for (UserImageClickMemoryData onerec: records) {
			if (onerec.getSuccesscount() >= 3) // This image has been clicked at the same location 3 times
				out++;
			
		}
		
		return out;
	}
	
	public List<UserImageClickMemoryData> getFinalizedUserImages(UUID userid) { // return UUIDs of finalized user images
		
		List<UserImageClickMemoryData> out = new ArrayList<UserImageClickMemoryData>();
		UserImageClickMemoryData obj = new UserImageClickMemoryData();		
		obj.setUserid(userid);
		
		Result<UserImageClickMemoryData> records = obj.readAllImageRecordsBasedOnUserid(cassconnector.getSession());
		
		for (UserImageClickMemoryData onerec: records) {
			if (onerec.getSuccesscount() >= 3) // This image has been clicked at the same location 3 times
				out.add(onerec);
			
		}
		
		return out;
	}
	

	
	
	public int getGlobalSeqForImage(UUID imgid) {
		int out = 0;
		
		ImageDataByImageID obj = new ImageDataByImageID();		
		obj.setImageid(imgid);
		
		ImageDataByImageID img = obj.getEntityFromCQL(cassconnector.getSession());
		
		if (img != null) 
			out =  img.getImageseq();
		
		return out;
	}
	
	
	public void saveClickDataBasedonUserAndImage(UserImageClickMemoryData input) {		
		
		//MappingManager manager = new MappingManager(cassconnector.getSession());
		//Mapper<UserImageClickMemoryData> mapper = manager.mapper(UserImageClickMemoryData.class);
		long start = System.currentTimeMillis();
		input.createViaMapper(cassconnector.getSession());
		//System.out.println("Added UserImageClickMemoryData  : " + " imgID : "
		//		+ input.getImageid() + " user: " + input.getUserid() + " in " + (System.currentTimeMillis() - start) + "ms");
		
	}
	
	public void saveMultipleClickDataBasedonUserAndImage(List<UserImageClickMemoryData> input) {		
		
			long start = System.currentTimeMillis();
			
			PreparedStatement ps = cassconnector.getSession().prepare(
					  UserImageClickMemoryData.getInsertQueryStringWithQMarks() 
					);
			
			BoundStatement bs = new BoundStatement(ps);
			
			BatchStatement batch = new BatchStatement();
			
			for (UserImageClickMemoryData data: input) {
				batch.add(bs.bind(data.getImageid(), 
						data.getUserid(), 
						data.getGlobalSeq(),
						data.getClickx(),//clickx, 
						data.getClicky(), //clicky, 
						data.getImgwidth(),//width, 
						data.getImgheight(), //height, 
						 data.getLocationhash(),//locationhash
						 data.getProgressivehash(),
						 data.getDelay(), //delay
						 data.getRecordcreatedate(), //recordcreatedate
						 data.getLastupdatedate(), //lastupdatedate
						 data.getDelayhistory(), //, delayhistory
						 data.getPhashhistory(),
						 data.getAvgdelay(),
						 data.getMindelay(),
						 data.getMaxdelay(),
						 data.getMeddelay(),
						 data.getSuccesscount(),
						 data.getFailurecount() ));
			}
			
				cassconnector.getSession().executeAsync(batch);
			
			System.out.println("Added (ttl:3600) UserImageClickMemoryData, " + input.size() + " lines in direct CQL batch  : " + " user : "
					+ input.get(0).getUserid() +  " in " + (System.currentTimeMillis() - start) + "ms");

		
	}
	
	

	public String createHashEntries(UserIdByHash inhash) {

		String hash = NewAuthUtils
				.generateSHA256Hash(inhash.getUserid().toString() + " " + inhash.getIpaddress().toString() + " " + inhash.getUseragent());

		UserIdByHash existinguseripcomb = getUserBasedonHash(hash);

		if (existinguseripcomb == null) {

			inhash.setUseridhash(hash);

			HashByIpAndUserAgent hashentry2 = new HashByIpAndUserAgent(inhash.getUserid(), inhash.getIpaddress(),
					inhash.getUseridhash(), inhash.getUsername(), inhash.getFullname(), inhash.isInitdevice(),
					inhash.isRemotedetection(), inhash.getDevicedisplayheight(), inhash.getDevicedisplaywidth(),
					inhash.getUseragent(), inhash.getIndividualconfirmdate(), inhash.getGroupconfirmdate(),
					inhash.getPublicconfirmdate());

			UserIdsByIP ipentry = new UserIdsByIP(inhash.getIpaddress(), inhash.getUserid(), inhash.getDevicedisplayheight(),
					inhash.getDevicedisplaywidth(), inhash.getIndividualconfirmdate(), inhash.getGroupconfirmdate(),
					inhash.getPublicconfirmdate());

			// inhash.createViaMapper(cassconnector.getSession());
			// hashentry2.createViaMapper(cassconnector.getSession());

			BatchStatement batch = new BatchStatement();

			MappingManager manager = new MappingManager(cassconnector.getSession());

			Mapper<UserIdByHash> mapper = manager.mapper(UserIdByHash.class);
			batch.add(mapper.saveQuery(inhash));

			Mapper<HashByIpAndUserAgent> mapper2 = manager.mapper(HashByIpAndUserAgent.class);
			batch.add(mapper2.saveQuery(hashentry2));

			Mapper<UserIdsByIP> mapper3 = manager.mapper(UserIdsByIP.class);
			batch.add(mapper3.saveQuery(ipentry));

			long start = System.currentTimeMillis();

			cassconnector.getSession().execute(batch);

			System.out.println("Added UserIdByHash, HashByIp, UserIdsByIP in batch  : " + " IP : "
					+ inhash.getIpaddress().toString() + " in " + (System.currentTimeMillis() - start) + "ms");

		}

		return hash;

	}

	public void createDeviceEntry(UserIdsByIP deviceentry) {
		//MappingManager manager = new MappingManager(cassconnector.getSession());
		//Mapper<UserIdsByIP> mapper = manager.mapper(UserIdsByIP.class);

		deviceentry.createViaDirectCQL(cassconnector.getSession());
	}

	public boolean createDeviceEntry(String ip, HttpSession session) {
		//MappingManager manager = new MappingManager(cassconnector.getSession());
		//Mapper<UserIdsByIP> mapper = manager.mapper(UserIdsByIP.class);

		SessionDataVO sessionData = (SessionDataVO) session.getAttribute("session");
		
		InetAddress ipadd = null;
		try {
			ipadd = InetAddress.getByName(ip);

		} catch (UnknownHostException e1) {
			System.out.println("Invalid IP address." + ip);
			sessionData.setRisk(sessionData.getRisk() + 30);
			return false;
		}

		sessionData.getDeviceinfo().setIpaddress(ipadd);
		UserIdsByIP deviceentry = new UserIdsByIP(ipadd, new UUID(0L, 0L), 0, 0, null, null, null);
		deviceentry.createViaDirectCQL(cassconnector.getSession());
		return true;
	}

	/*public void createAccessEntries(UUID userid, InetAddress ip, String useragent) {
		
		BatchStatement batch = new BatchStatement();

		MappingManager manager = new MappingManager(cassconnector.getSession());
		
		Date accesstime = sessionData.getSessioncreatetime();
		
		AcccessByIP accip = new AcccessByIP(ip, userid, accesstime);

		Mapper<AcccessByIP> mapper = manager.mapper(AcccessByIP.class);
		batch.add(mapper.saveQuery(accip));
		
		if (userid != null) {
			
			AccessByUserID accid = new AccessByUserID(userid,ip,useragent,accesstime);
			Mapper<AccessByUserID> mapper2 = manager.mapper(AccessByUserID.class);
			batch.add(mapper2.saveQuery(accid));
		}

		long start = System.currentTimeMillis();

		cassconnector.getSession().executeAsync(batch);

		System.out.println("Added AcccessByIP, AccessByUserID in batch - Asynch : " + "uid, IP, accesstime : "
				+ userid + " , " + ip + "," + accesstime + " in " + (System.currentTimeMillis() - start) + "ms");
	}*/
	
	public void createAccessEntries2(UUID userid, InetAddress ip, String useragent, Date accesstime, short lastauthscore, String sessionid) {
		
		long start = System.currentTimeMillis();
		
		//Date accesstime = sessionData.getSessioncreatetime();
		PreparedStatement ps = cassconnector.getSession().prepare(
				   "BEGIN BATCH" +
						   AcccessByIP.getInsertQueryStringWithQMarks() +					
						   ((userid == null)?"":AccessByUserID.getInsertQueryStringWithQMarks()) + 
						   ((userid == null)?"":AccessByUserIDAndSession.getInsertQueryStringWithQMarks()) + 
				   "APPLY BATCH"
				);
		
		if (userid == null)
			cassconnector.getSession().executeAsync(ps.bind(ip, userid, accesstime 
														));
		else 
			cassconnector.getSession().executeAsync(ps.bind(ip, userid, accesstime,
															userid,ip,useragent,accesstime,lastauthscore, sessionid,
															userid,ip,useragent,accesstime,lastauthscore, sessionid));
		
		System.out.println("Added AcccessByIP, AccessByUserID in direct CQL batch  : " + " IP : "
				+ ip.toString() + " in " + (System.currentTimeMillis() - start) + "ms");
	}

}
