package com.jul.newauth.dao;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.RandomAccessFile;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.nio.ByteBuffer;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.UUID;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import java.util.zip.Adler32;
import java.util.zip.CRC32;
import java.util.zip.Checksum;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Component;

import com.datastax.driver.core.Cluster;
import com.datastax.driver.core.ConsistencyLevel;
import com.datastax.driver.core.KeyspaceMetadata;
import com.datastax.driver.core.Session;
import com.datastax.driver.core.SimpleStatement;
import com.datastax.driver.core.utils.UUIDs;
import com.datastax.driver.mapping.Mapper;
import com.datastax.driver.mapping.MappingManager;
import com.jul.newauth.model.cassandra.ks.users.Address;
import com.jul.newauth.model.cassandra.ks.users.BlobChunkData;
import com.jul.newauth.model.cassandra.ks.users.BlobData;
import com.jul.newauth.model.cassandra.ks.users.ImageDataByMetaData;
import com.jul.newauth.model.cassandra.ks.users.Phone;
import com.jul.newauth.model.cassandra.ks.users.UsersByUsername;
import com.jul.newauth.util.SimpleImageInfo;

@Component
public class CreateNewAuthSchema {
	
	@Autowired
	CassandraConnector cassconnector;
	
	@Autowired
	CassandraKeySpaces keyspaces;
	
	@Value("${spring.data.cassandra.keySpaceStrategy}")
	String keyspacestrategy;
	
	@Value("${spring.data.cassandra.replicationFactor}")
	String replicationfactor;
	
	
	public void createKeySpaces() {
		String dropquery = "drop keyspace if exists test";
		String query = "CREATE KEYSPACE IF NOT EXISTS KKK WITH replication = {'class':'SSS', 'replication_factor':FFF}";
		
		Cluster cl = cassconnector.getCluster();
		
		for (String ks: keyspaces.getKeySpaces()) {
			boolean exists = false;
			
			for (KeyspaceMetadata ksmeta: cl.getMetadata().getKeyspaces()) {
				if (ksmeta.getName().equalsIgnoreCase(ks)) {
					exists = true;
					break;
				}
			}
		
			if (exists) {
				System.out.println("KeySpace "+ ks + " exists. Skipping create... " );
				continue;
			} 
				
			Session sess = cassconnector.getSession();
					
			String newquery = query.replaceAll("SSS", keyspacestrategy);
			newquery = newquery.replaceAll("FFF", replicationfactor);
			newquery = newquery.replaceAll("KKK", ks);
			
			
			long starttime = System.currentTimeMillis();
			sess.execute(new SimpleStatement(newquery).setConsistencyLevel(ConsistencyLevel.QUORUM));
			System.out.println("Executed: " + newquery + " in " + (System.currentTimeMillis() - starttime) + "ms");
		}
		
	}
	
	public void deleteImages() {
		System.out.println("CreateNewAuthSchema.deleteImages------------\n Deleting images: ");
		
		String[] cqls = null;
		
		Resource resource = new ClassPathResource("data/deleteimages.cql");
		try {
			InputStream resourceInputStream = resource.getInputStream();
			
			//cqls = new BufferedReader(new InputStreamReader(resourceInputStream)).lines().collect(Collectors.joining("\n"));
			cqls = getQueriesFromInputStream(resourceInputStream);
			resourceInputStream.close();
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		if (cqls.length > 0) {
			for (String cql: cqls) {
				cql = cql.trim();
				if (cql.length() > 0) {
					long starttime = System.currentTimeMillis();
					cassconnector.getSession().execute(new SimpleStatement(cql).setConsistencyLevel(ConsistencyLevel.ALL));
					System.out.println("\tExecuted: " + cql + " in " + (System.currentTimeMillis() - starttime) + " ms");
				}
			}
		}
	}
	
	public void deleteUsers() {
		System.out.println("CreateNewAuthSchema.deleteUsers------------\n Deleting userdata: ");
		
		String[] cqls = null;
		
		Resource resource = new ClassPathResource("data/deleteuserdata.cql");
		try {
			InputStream resourceInputStream = resource.getInputStream();
			
			//cqls = new BufferedReader(new InputStreamReader(resourceInputStream)).lines().collect(Collectors.joining("\n"));
			cqls = getQueriesFromInputStream(resourceInputStream);
			resourceInputStream.close();
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		if (cqls.length > 0) {
			for (String cql: cqls) {
				cql = cql.trim();
				if (cql.length() > 0) {
					long starttime = System.currentTimeMillis();
					cassconnector.getSession().execute(new SimpleStatement(cql).setConsistencyLevel(ConsistencyLevel.ALL));
					System.out.println("\tExecuted: " + cql + " in " + (System.currentTimeMillis() - starttime) + " ms");
				}
			}
		}
	}
	
	public void createTables() {
		
		System.out.println("------------\n CREATING TABLES: ");
		
		for (String ks: keyspaces.getKeySpaces()) {
			
			String[] cqls = null;
			
			Resource resource = new ClassPathResource("data/" + ks + ".cql");
			try {
				InputStream resourceInputStream = resource.getInputStream();
				
				//cqls = new BufferedReader(new InputStreamReader(resourceInputStream)).lines().collect(Collectors.joining("\n"));
				cqls = getQueriesFromInputStream(resourceInputStream);
				resourceInputStream.close();
				
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			if (cqls.length > 0) {
				for (String cql: cqls) {
					cql = cql.trim();
					if (cql.length() > 0) {
						long starttime = System.currentTimeMillis();
						cassconnector.getSession().execute(new SimpleStatement(cql).setConsistencyLevel(ConsistencyLevel.QUORUM));
						System.out.println("\tExecuted: " + cql.substring(0, cql.indexOf("(")) + " in " + (System.currentTimeMillis() - starttime) + "ms");
					}
				}
			}
		}
		
	}
	
	public void createUserData() {
		//Usersbyusername
		
		UUID userId = UUIDs.random();
		
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		Calendar nowcal = Calendar.getInstance();
		String currentdatetime = dateFormat.format(nowcal.getTime());
				
		UsersByUsername nauser = null;
		try {
			nauser = new UsersByUsername(userId 
												, "testuser1" //username
												, "test" //firstname
												, "u" //middleinitial
												, "ser1" //lastname
												, (short) 0
												, nowcal.getTime() // creationdate
												, nowcal.getTime() // lastupdatedate
												, null // lastaccessdate
												, new HashMap<String, Address>() {{
														 put("home",	new Address("st some", "city1", "ST", "Country", 11111));
														 put("office",	new Address(null,null,null,null,0) );
												}} // addresses
												, Stream.of(new Phone("1234567890", null), new Phone("2222222222", null)).collect(Collectors.toSet())
												// phones
												, null // emails
												, Stream.of(InetAddress.getLocalHost()).collect(Collectors.toSet()) // ipaddresses
												);
		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		nauser.createViaMapper(cassconnector.getSession());
	}
	
	/*public void createImageDataFromFile() {
		
		FileInputStream fis;
		try {			
			
			//String filename = "C:\\temp\\Aarav.jpg";	
			String filename = "C:\\temp\\AaravSmall.jpg";
			//String filename = "C:\\temp\\htmlunit-2.11.jar";			
			
			int maxbuffersize = 1024000; //1024000;			
			
			File fileforsimplefileinfo = new File(filename);
			// RAF method for file mapping			

			FileChannel inChannel = new RandomAccessFile(filename, "r").getChannel();
			MappedByteBuffer mbbuffer = null;
			
			System.out.println("Filename: " +  filename + "  size: " + inChannel.size());
			System.out.println("Maxbuffer: " + maxbuffersize);
			
			
			SimpleImageInfo imageinfo = new SimpleImageInfo(fileforsimplefileinfo);
			
			UUID imguuid = UUIDs.random();
			Date imgcreatetime = Calendar.getInstance().getTime();
			
			ImageData imagedata = new ImageData(imguuid ,
												null,
												(short) 0, //imageseq
												imageinfo.getHeight() ,
												imageinfo.getWidth(),
												imageinfo.getMimeType(),
												imgcreatetime,
												null, //lastaccessdate
												null	// tags											
					);
			
			imagedata.createViaMapper(cassconnector.getSession());				
			long length = inChannel.size();
			
			
			// Normal IO
			fis = new FileInputStream(filename);
			byte[] b= new byte[fis.available()+1];
			int length=b.length;
			fis.read(b);
			
			ByteBuffer buffer = ByteBuffer.wrap(b);
			
			mbbuffer = inChannel.map(FileChannel.MapMode.READ_ONLY, 0, inChannel.size());
			Checksum  chksum = new CRC32();
			byte[] imagebytes = new byte [(int) inChannel.size()];
			mbbuffer.get(imagebytes,0, (int)inChannel.size());
			
			chksum.update(imagebytes,0, imagebytes.length);
			
			int numberofchunks = (int) ((maxbuffersize == 0)?1:(length/maxbuffersize + 1));
			
			long chunksize = (maxbuffersize == 0)?length:maxbuffersize;
			
			BlobData bd =  new BlobData(imagedata.getImageid(), numberofchunks, chunksize, length, Long.toString(chksum.getValue()));
			
			bd.createViaMapper(cassconnector.getSession());				
						
			int segments = 0;
			if (maxbuffersize > 0 && inChannel.size() > maxbuffersize) {
				for (int i = 0; i < inChannel.size()/maxbuffersize; i++) {
					//System.out.println("file segment " + i );
					segments++;
					mbbuffer = inChannel.map(FileChannel.MapMode.READ_ONLY, maxbuffersize*i, maxbuffersize);
					
					//System.out.println("\tFile segment " + segments + ": last 4 bytes [" + mbbuffer.get(maxbuffersize-4) + mbbuffer.get(maxbuffersize-3) + mbbuffer.get(maxbuffersize-2) + mbbuffer.get(maxbuffersize-1) + "]");
					
					BlobChunkData bcd = new BlobChunkData(imagedata.getImageid(), 
																segments, 
																maxbuffersize, 
																mbbuffer);


					bcd.createViaMapper(cassconnector.getSession());
					
				}
				
				mbbuffer = inChannel.map(FileChannel.MapMode.READ_ONLY, segments*maxbuffersize, (inChannel.size()-segments*maxbuffersize));
				
				System.out.println("\tFile segment " + (segments+1) + ": last 4 bytes [" + 
																						mbbuffer.get((int) ((inChannel.size()-segments*maxbuffersize) -4)) + 
																						mbbuffer.get((int) ((inChannel.size()-segments*maxbuffersize) -3)) + 
																						mbbuffer.get((int) ((inChannel.size()-segments*maxbuffersize) -2)) + 
																						mbbuffer.get((int) ((inChannel.size()-segments*maxbuffersize) -1)) + 
																						"]");
				
				BlobChunkData bcd = new BlobChunkData(imagedata.getImageid(), 
																segments+1, 
																(inChannel.size()- (segments*maxbuffersize)), 
																mbbuffer);


				bcd.createViaMapper(cassconnector.getSession());
			// access the buffer as you wish.
			} else { // Just one chunk
				mbbuffer = inChannel.map(FileChannel.MapMode.READ_ONLY, 0, inChannel.size());
				BlobChunkData bcd = new BlobChunkData(imagedata.getImageid(), 
																	1, 
																	inChannel.size(), 
																	mbbuffer);


				bcd.createViaMapper(cassconnector.getSession());
			}
			
			inChannel.close();
			
			
			
			// TEST reading the image back
			
			System.out.println("Reading image back....");
			ImageData inputimg = new ImageData(imguuid, null, (short) 0, imageinfo.getHeight() , imageinfo.getWidth(), null, imgcreatetime, null, null);
			
			byte[] outputimg = inputimg.readViaMapper(cassconnector.getSession());
			
			if (outputimg == null)
				System.out.println("Image could not be read..");
			else
				System.out.println("Read image : " + outputimg.toString());
			
		} catch (FileNotFoundException e) {
			System.out.println("FileNotFoundException processing image file.");
			System.out.println(e.getMessage());
		} catch (IOException e) {
			System.out.println("IOException processing image file.");
			System.out.println(e.getMessage());
		}
		
	}*/
	

	
	private String[] getQueriesFromInputStream(InputStream ins) throws IOException {
		ByteArrayOutputStream result = new ByteArrayOutputStream();
		byte[] buffer = new byte[1024];
		int length;
		while ((length = ins.read(buffer)) != -1) {
		    result.write(buffer, 0, length);
		}
		return result.toString("UTF-8").split(";");
	}

}
