package com.jul.newauth.dao;

import java.util.List;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties("spring.data.cassandra")
public class CassandraKeySpaces {
	
	private List<String> keySpaces;

	public List<String> getKeySpaces() {
		return keySpaces;
	}

	public void setKeySpaces(List<String> keySpaces) {
		this.keySpaces = keySpaces;
	}

}
