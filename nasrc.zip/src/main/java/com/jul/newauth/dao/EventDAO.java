package com.jul.newauth.dao;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.datastax.driver.core.BatchStatement;
import com.datastax.driver.core.PreparedStatement;
import com.datastax.driver.mapping.Mapper;
import com.datastax.driver.mapping.MappingManager;
import com.datastax.driver.mapping.Result;
import com.jul.newauth.model.SessionDataVO;
import com.jul.newauth.model.cassandra.ks.analytics.NewauthEvent;
import com.jul.newauth.model.cassandra.ks.analytics.NewauthEventByIP;
import com.jul.newauth.model.cassandra.ks.analytics.NewauthEventByServerIP;
import com.jul.newauth.model.cassandra.ks.analytics.NewauthEventByType;
import com.jul.newauth.model.cassandra.ks.analytics.NewauthEventByTypeAndIP;
import com.jul.newauth.model.cassandra.ks.analytics.NewauthEventByTypeAndServerIP;
import com.jul.newauth.model.cassandra.ks.analytics.NewauthEventByUser;
import com.jul.newauth.model.cassandra.ks.analytics.NewauthEventByUserAndType;
import com.jul.newauth.model.cassandra.ks.transactions.AcccessByIP;
import com.jul.newauth.model.cassandra.ks.transactions.AccessByUserID;
import com.jul.newauth.model.cassandra.ks.transactions.HashByIpAndUserAgent;
import com.jul.newauth.model.cassandra.ks.transactions.UserIdByHash;
import com.jul.newauth.model.cassandra.ks.transactions.UserIdsByIP;
import com.jul.newauth.model.cassandra.ks.transactions.UserImageClickMemoryData;
import com.jul.newauth.model.cassandra.ks.users.ImageSizesAndAR;
import com.jul.newauth.model.cassandra.ks.users.UsersByUserid;
import com.jul.newauth.model.cassandra.ks.users.UsersByUsername;
import com.jul.newauth.util.NewAuthUtils;

@Component
public class EventDAO {

	@Autowired
	CassandraConnector cassconnector;

	@Autowired
	SessionDataVO sessionData;

	public void createEvent(NewauthEvent in) {
		long start = System.currentTimeMillis();
		PreparedStatement ps = cassconnector.getSession().prepare(
				   "BEGIN BATCH" +
					NewauthEvent.getInsertQueryStringWithQMarks() +
					NewauthEventByIP.getInsertQueryStringWithQMarks() +
					NewauthEventByServerIP.getInsertQueryStringWithQMarks() +
					NewauthEventByType.getInsertQueryStringWithQMarks() +
					NewauthEventByTypeAndIP.getInsertQueryStringWithQMarks() +
					NewauthEventByTypeAndServerIP.getInsertQueryStringWithQMarks() +
					((in.getUserId() == null)?"":NewauthEventByUser.getInsertQueryStringWithQMarks()) + 
					((in.getUserId() == null)?"":NewauthEventByUserAndType.getInsertQueryStringWithQMarks()) + 
				   "APPLY BATCH"
				);
		
		if (in.getUserId() == null)
			cassconnector.getSession().executeAsync(ps.bind(in.getEventID(), in.getEventType(), in.getEventTime(), in.getUserId(), in.getIp(), in.getServerip(), in.getEventData(), 
														in.getEventID(), in.getEventType(), in.getEventTime(), in.getUserId(), in.getIp(), in.getServerip(), in.getEventData(), 
														in.getEventID(), in.getEventType(), in.getEventTime(), in.getUserId(), in.getIp(), in.getServerip(), in.getEventData(), 
														in.getEventID(), in.getEventType(), in.getEventTime(), in.getUserId(), in.getIp(), in.getServerip(), in.getEventData(),
														in.getEventID(), in.getEventType(), in.getEventTime(), in.getUserId(), in.getIp(), in.getServerip(), in.getEventData(),
														in.getEventID(), in.getEventType(), in.getEventTime(), in.getUserId(), in.getIp(), in.getServerip(), in.getEventData()));
		else 
			cassconnector.getSession().executeAsync(ps.bind(in.getEventID(), in.getEventType(), in.getEventTime(), in.getUserId(), in.getIp(), in.getServerip(), in.getEventData(), 
					in.getEventID(), in.getEventType(), in.getEventTime(), in.getUserId(), in.getIp(), in.getServerip(), in.getEventData(), 
					in.getEventID(), in.getEventType(), in.getEventTime(), in.getUserId(), in.getIp(), in.getServerip(), in.getEventData(), 
					in.getEventID(), in.getEventType(), in.getEventTime(), in.getUserId(), in.getIp(), in.getServerip(), in.getEventData(), 
					in.getEventID(), in.getEventType(), in.getEventTime(), in.getUserId(), in.getIp(), in.getServerip(), in.getEventData(), 
					in.getEventID(), in.getEventType(), in.getEventTime(), in.getUserId(), in.getIp(), in.getServerip(), in.getEventData(),
					in.getEventID(), in.getEventType(), in.getEventTime(), in.getUserId(), in.getIp(), in.getServerip(), in.getEventData(),
					in.getEventID(), in.getEventType(), in.getEventTime(), in.getUserId(), in.getIp(), in.getServerip(), in.getEventData()));
		
		System.out.println("Added (ttl:3600) NewauthEvent, NewauthEventByIP, NewauthEventByServerIP, NewauthEventByType, NewauthEventByTypeAndIP, NewauthEventByTypeAndServerIP, NewauthEventByUser , NewauthEventByUserAndType in direct CQL batch  : " + " IP : "
				+ in.getIp().toString() + " serverIP: " + in.getServerip().toString() + " event: " + in.getEventType() + " in " + (System.currentTimeMillis() - start) + "ms");

	}
	
	
	public Result<NewauthEventByUserAndType> findEventsByUseridAndType(String userid, String type) {
		NewauthEventByUserAndType out = new NewauthEventByUserAndType();
		//out.setUserId(UUID.fromString(userid));
		//out.setEventType(type);
		
		Result<NewauthEventByUserAndType> res = out.getEventsByUserAndType(cassconnector.getSession(), userid, type);
		
		return res;
		
	}
	
	
	
}
