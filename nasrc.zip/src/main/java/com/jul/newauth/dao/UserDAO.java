package com.jul.newauth.dao;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.HashSet;
import java.util.UUID;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.datastax.driver.core.BatchStatement;
import com.datastax.driver.core.utils.UUIDs;
import com.datastax.driver.mapping.Mapper;
import com.datastax.driver.mapping.MappingManager;
import com.jul.newauth.model.UserVO;
import com.jul.newauth.model.cassandra.ks.transactions.UserIdByHash;
import com.jul.newauth.model.cassandra.ks.users.Address;
import com.jul.newauth.model.cassandra.ks.users.Phone;
import com.jul.newauth.model.cassandra.ks.users.UsersByUserid;
import com.jul.newauth.model.cassandra.ks.users.UsersByUsername;


@Component
public class UserDAO {
	@Autowired
	CassandraConnector cassconnector;
	
	public String createUser(UserVO user) {
		UUID userId = UUIDs.random();
		
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		Calendar nowcal = Calendar.getInstance();
		String currentdatetime = dateFormat.format(nowcal.getTime());

		/// Initialize Set of Phone objects
		//Stream.of(new Phone("1234567890", null), new Phone("2222222222", null)).collect(Collectors.toSet())
		
		/// Initialize Set of IP address objects
		//Stream.of(InetAddress.getLocalHost()).collect(Collectors.toSet())
		
		// Initialize map of addresses
		/*new HashMap<String, Address>() {{
		 		put("home",	new Address("st some", "city1", "ST", "Country", 11111));
		 		put("office",	new Address(null,null,null,null,0) );
			}} */
				
		UsersByUsername nauser = null;
		nauser = new UsersByUsername(userId 
									, user.getUsername() //username
									, user.getFirstname() //firstname
									, user.getMiddleinitial() //middleinitial
									, user.getLastname() //lastname
									, (short) 0
									, nowcal.getTime() // creationdate
									, nowcal.getTime() // lastupdatedate
									, null // lastaccessdate
									, user.getAddresses()// addresses
									, new HashSet<Phone>(user.getPhones())	// phones
									, new HashSet<String>(user.getEmails()) // emails
									, (user.getIpaddresses()==null)?null:new HashSet<InetAddress>(user.getIpaddresses()) // ipaddresses
									);

		
		UsersByUserid useriduser = new UsersByUserid(userId 
										, user.getUsername() //username
										, user.getFirstname() //firstname
										, user.getMiddleinitial() //middleinitial
										, user.getLastname() //lastname
										, (short) 0
										, nowcal.getTime() // creationdate
										, nowcal.getTime() // lastupdatedate
										, null // lastaccessdate
										, user.getAddresses()// addresses
										, new HashSet<Phone>(user.getPhones())	// phones
										, new HashSet<String>(user.getEmails()) // emails
										, (user.getIpaddresses()==null)?null:new HashSet<InetAddress>(user.getIpaddresses()) // ipaddresses
										);
		
		BatchStatement batch = new BatchStatement();
		
		MappingManager manager = new MappingManager(cassconnector.getSession());

		Mapper<UsersByUsername> mapper = manager.mapper(UsersByUsername.class);
		batch.add(mapper.saveQuery(nauser));
		
		Mapper<UsersByUserid> mapper2 = manager.mapper(UsersByUserid.class);
		batch.add(mapper2.saveQuery(useriduser));
		
		long start = System.currentTimeMillis();
		
		cassconnector.getSession().execute(batch);
		
		System.out.println("Added UsersByUsername, UsersByUserid in batch : " + nauser.getUsername() + " UUID: "  + nauser.getUserid().toString() + " in " + (System.currentTimeMillis() - start) + "ms");
		
		//nauser.createViaMapper(cassconnector.getSession());
		//useriduser.createViaMapper(cassconnector.getSession());
		
		return userId.toString();
	}
	
	public UsersByUsername findUserByUsername(String username) {
		UsersByUsername out = new UsersByUsername();
		out.setUsername(username);
		
		out = out.readViaMapper(cassconnector.getSession());
		
		return out;
		
	}
	
	public UsersByUserid findUserByUserid(String userid) {
		UsersByUserid out = new UsersByUserid();
		out.setUserid(UUID.fromString(userid));
		
		out = out.readViaMapper(cassconnector.getSession());
		
		return out;
		
	}
	
	public UserIdByHash findUserByHash(String hash) {
		UserIdByHash out = new UserIdByHash();
		out.setUseridhash(hash);
		
		out = out.readViaMapper(cassconnector.getSession());
		
		return out;
		
	}
	
	

}
