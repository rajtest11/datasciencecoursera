package com.jul.newauth.dao;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.zip.CRC32;
import java.util.zip.Checksum;

import javax.servlet.http.HttpSession;

import org.hibernate.validator.internal.util.privilegedactions.GetAnnotationParameter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.datastax.driver.core.BatchStatement;
import com.datastax.driver.core.PreparedStatement;
import com.datastax.driver.core.utils.UUIDs;
import com.datastax.driver.mapping.Mapper;
import com.datastax.driver.mapping.MappingManager;
import com.datastax.driver.mapping.Result;
import com.jul.newauth.model.EventTypes;
import com.jul.newauth.model.ImageVO;
import com.jul.newauth.model.ImgIDTranslatorVO;
import com.jul.newauth.model.SessionDataVO;
import com.jul.newauth.model.cassandra.ks.transactions.UserImageClickMemoryData;
import com.jul.newauth.model.cassandra.ks.users.BlobChunkData;
import com.jul.newauth.model.cassandra.ks.users.BlobData;
import com.jul.newauth.model.cassandra.ks.users.ImageByUserAndChecksum;
import com.jul.newauth.model.cassandra.ks.users.ImageDataByImageID;
import com.jul.newauth.model.cassandra.ks.users.ImageDataByMetaData;
import com.jul.newauth.model.cassandra.ks.users.ImageDataByUserIDAndSize;
import com.jul.newauth.model.cassandra.ks.users.ImageDataForSystemBySize;
import com.jul.newauth.model.cassandra.ks.users.ImageSizesAndAR;
import com.jul.newauth.util.NewAuthUtils;
import com.jul.newauth.util.SimpleImageInfo;

@Component
public class ImageDataDAO {

	@Autowired
	CassandraConnector cassconnector;
	
	@Autowired
	TransactionDAO trandao;
	
	@Autowired
	EventDAO eventdao;

	//@Autowired
	//SessionDataVO sessiondata;
	@Value("${initializeImageSetSize}")
	private int initializeImageSetSize;	
	
	@Value("${maxnumberofimages}")
	private int maxnumberofimages;		

	@Value("${maxbuffersize}")
	private String maxbuffer; // This value is used to chunk the data before storing in database
	
	private static MappingManager manager;
	
	public String createImageDataFromBytes(String filename, byte[] imagebytes, List<String> tags, short imageseq, Date imgcreatetime, boolean addtouserrecord, HttpSession session) {
		UUID imguuid = null;
		String imguuidstr = null;
		//Date imgcreatetime = Calendar.getInstance().getTime();
		
		SessionDataVO sessiondata = (SessionDataVO) session.getAttribute("session");
		try {

			SimpleImageInfo imageinfo = new SimpleImageInfo(imagebytes);
			Checksum chksum = new CRC32();

			chksum.update(imagebytes, 0, imagebytes.length);
			
			String imagesize = NewAuthUtils.getImageSize(imageinfo.getWidth(), imageinfo.getHeight());
			float aspectratio = NewAuthUtils.getImageAspectRatio(imageinfo.getWidth(), imageinfo.getHeight());
			
			String existingimagewithsamechecksum = getExistingImageWithSameCheckSum(
					(sessiondata.getUserauthenticated() == null)?"SYSTEM":sessiondata.getUserauthenticated(), 
					NewAuthUtils.getImageSize(imageinfo.getWidth(), imageinfo.getHeight()),
					chksum.getValue());

			if (existingimagewithsamechecksum != null) {
				System.out.println("This user has already uploaded this image: " + existingimagewithsamechecksum);
				return existingimagewithsamechecksum;
			} 

			if (addtouserrecord)
				imguuidstr = createUserImageDataFromBytes(filename, imagebytes, tags, imgcreatetime, session);
			
			if (imguuidstr != null) {
				imguuid = UUID.fromString(imguuidstr);
			} else {
				imguuid = UUIDs.random();
			}
	
			// We need to use the last seq for 'T' - TINY images because a tiny copy is always created
			//int currentseq = getlastseqforsystemimagesforsizeandar(imageinfo.getWidth(), imageinfo.getHeight());
			int currentseq = getlastseqforsystemimagesforsizeandar(100, 100);
			
			//if (imageseq == 0)
			imageseq =  (short) (currentseq + 1);
			
			
			int maxbuffersize = (int) NewAuthUtils.fileSizeToBytes(maxbuffer);
			FileInputStream fis;

			ImageSizesAndAR imgsizear = new ImageSizesAndAR(imagesize,aspectratio );
			
			ImageDataByMetaData imagedata = new ImageDataByMetaData(imguuid, sessiondata.getUserid(), imageseq, // imageseq
					imagesize, imageinfo.getHeight(),
					imageinfo.getWidth(), aspectratio, imageinfo.getMimeType(),
					imgcreatetime, null, // lastaccessdate
					tags // tags
			);

			ImageDataByImageID imagedatauuid = new ImageDataByImageID(imguuid, sessiondata.getUserid(), imageseq, // imageseq
					imagesize, imageinfo.getHeight(),
					imageinfo.getWidth(), aspectratio, imageinfo.getMimeType(),
					imgcreatetime, null, // lastaccessdate
					tags // tags
			);
			
			ImageDataForSystemBySize sysimgsize = new ImageDataForSystemBySize(imguuid, sessiondata.getUserid(), (short) imageseq, // imageseq
					imagesize, imageinfo.getHeight(),
					imageinfo.getWidth(), aspectratio, imageinfo.getMimeType(),
					imgcreatetime, null, // lastaccessdate
					tags // tags;
					);
			
			
			long length = imagebytes.length;
			
			int numberofchunks = (int) ((maxbuffersize == 0) ? 1 : (length / maxbuffersize + 1));

			long chunksize = (maxbuffersize == 0) ? length : maxbuffersize;

			BlobData bd = new BlobData(imagedata.getImageid(), numberofchunks, chunksize, length,
					Long.toString(chksum.getValue()));

			
			PreparedStatement ps = cassconnector.getSession().prepare(
					   "BEGIN BATCH" +
							   ImageSizesAndAR.getInsertQueryStringWithQMarks() +
							   ImageDataByMetaData.getInsertQueryStringWithQMarks() +
							   ImageDataByImageID.getInsertQueryStringWithQMarks() +
							   BlobData.getInsertQueryStringWithQMarks() +
							   ((sessiondata.getUserid() == null)?ImageDataForSystemBySize.getInsertQueryStringWithQMarks():"") + 
						"APPLY BATCH"
					);
			
			if ((sessiondata.getUserid() == null)) {
				System.out.println("Adding size:" + imagesize + " -- ImageSizesAndAR, ImageDataByMetaData, ImageDataByImageID, ImageDataForSystemBySize, BlobData via direct CQL BATCH...");
				cassconnector.getSession().executeAsync(ps.bind(imagesize,aspectratio, 
															imguuid, sessiondata.getUserid(), (int) imageseq, imagesize, imageinfo.getHeight(),imageinfo.getWidth(), aspectratio, imageinfo.getMimeType(),imgcreatetime, null, tags,
															imguuid, sessiondata.getUserid(), (int) imageseq, imagesize, imageinfo.getHeight(),imageinfo.getWidth(), aspectratio, imageinfo.getMimeType(),imgcreatetime, null, tags,
															imagedata.getImageid(), numberofchunks, chunksize, length, Long.toString(chksum.getValue()),
															imguuid, sessiondata.getUserid(), (short) imageseq, imagesize, imageinfo.getHeight(),imageinfo.getWidth(), aspectratio, imageinfo.getMimeType(),imgcreatetime, null, tags
														));
			} else {
				System.out.println("Adding size:" + imagesize + " -- ImageSizesAndAR, ImageDataByMetaData, ImageDataByImageID, BlobData via direct CQL BATCH...");
				cassconnector.getSession().executeAsync(ps.bind(imagesize,aspectratio, 
															imguuid, sessiondata.getUserid(), (int) imageseq, imagesize, imageinfo.getHeight(),imageinfo.getWidth(), aspectratio, imageinfo.getMimeType(),imgcreatetime, null, tags,
															imguuid, sessiondata.getUserid(), (int) imageseq, imagesize, imageinfo.getHeight(),imageinfo.getWidth(), aspectratio, imageinfo.getMimeType(),imgcreatetime, null, tags,
															imagedata.getImageid(), numberofchunks, chunksize, length, Long.toString(chksum.getValue())
														));
			}
		

		
			int segments = 0;
			if (maxbuffersize > 0 && length > maxbuffersize) {
				for (int i = 0; i < length / maxbuffersize; i++) {
					// System.out.println("file segment " + i );
					segments++;
					byte[] maxbuffersizebytes = new byte[maxbuffersize];

					maxbuffersizebytes = Arrays.copyOfRange(imagebytes, maxbuffersize * i, maxbuffersize * (i + 1));

					BlobChunkData bcd = new BlobChunkData(imagedata.getImageid(), segments, maxbuffersize,
							ByteBuffer.wrap(maxbuffersizebytes));

					bcd.createViaMapper(cassconnector.getSession());

				}

				int remainingsize = (int) (length - segments * maxbuffersize);

				byte[] remainingbytes = new byte[remainingsize];

				remainingbytes = Arrays.copyOfRange(imagebytes, segments * maxbuffersize, imagebytes.length);
				BlobChunkData bcd = new BlobChunkData(imagedata.getImageid(), segments + 1, remainingsize,
						ByteBuffer.wrap(remainingbytes));

				bcd.createViaMapper(cassconnector.getSession());
			} else { // Just one chunk

				BlobChunkData bcd = new BlobChunkData(imagedata.getImageid(), 1, length, ByteBuffer.wrap(imagebytes));

				bcd.createViaMapper(cassconnector.getSession());
			}

			//cassconnector.getSession().execute(batch);

		} catch (FileNotFoundException e) {
			System.out.println("FileNotFoundException processing image file.");
			System.out.println(e.getMessage());
		} catch (IOException e) {
			System.out.println("IOException processing image file.");
			System.out.println(e.getMessage());
		}

		return (imguuid == null) ? "" : imguuid.toString();
	}

	private int getlastseqforsystemimagesforsizeandar(int width, int height) {
									
		int out = 0;							
		String size = NewAuthUtils.getImageSize(width, height);
		
		ImageSizesAndAR input = new ImageSizesAndAR(size, 0);
		
		//Get ALL ARs so that we can pass them in the last seq query
		Result<ImageSizesAndAR> arsforthissize = input.getAvailableARsForSize(cassconnector.getSession(), 0, 0);
		
		if (arsforthissize.isExhausted())
			return out;
		
		List<Float> arlist = new ArrayList<Float>();
		for (ImageSizesAndAR thisitem: arsforthissize) {
			arlist.add(thisitem.getAspectratio());
		}
			
		Float[] allowedars = arlist.toArray(new Float[0]);
		
		ImageDataByMetaData imgbymeta = new ImageDataByMetaData();
	
		out = imgbymeta.lastSeqBySizeAndAR(cassconnector.getSession(), size, allowedars);

		return out;
	}
	
	private List<Integer> getAllseqforsystemimagesforsizer(int width, int height) {
		
		List<Integer> out;
		
		String size = NewAuthUtils.getImageSize(width, height);
		
		ImageDataForSystemBySize imgbysize = new ImageDataForSystemBySize();
	
		out = imgbysize.allSeqForSystemBySize(cassconnector.getSession(), size);

		return out;
	}
	
	private int getlastseqforuserimagesforsizeandar(UUID userid, int width, int height) {
		
		int out = 0;							
		String size = NewAuthUtils.getImageSize(width, height);
		
		ImageSizesAndAR input = new ImageSizesAndAR(size, 0);
		
		//Get ALL ARs so that we can pass them in the last seq query
		Result<ImageSizesAndAR> arsforthissize = input.getAvailableARsForSize(cassconnector.getSession(), 0, 0);
		
		List<Float> arlist = new ArrayList<Float>();
		for (ImageSizesAndAR thisitem: arsforthissize) {
			arlist.add(thisitem.getAspectratio());
		}
			
		Float[] allowedars = arlist.toArray(new Float[0]);
		
		ImageDataByUserIDAndSize imgbymeta = new ImageDataByUserIDAndSize();
	
		out = imgbymeta.lastSeqByUserSizeAndAR(cassconnector.getSession(), userid, size, allowedars);

		return out;
	}

	public String createUserImageDataFromBytes(String filename, byte[] imagebytes, List<String> tags, Date imgcreatetime, HttpSession session) {
		
		UUID imguuid = null;
		SessionDataVO sessiondata = (SessionDataVO) session.getAttribute("session");
		try {

			SimpleImageInfo imageinfo = new SimpleImageInfo(imagebytes);

			//Date imgcreatetime = Calendar.getInstance().getTime();			
						
			//ImageByUserAndChecksum
			Checksum chksum = new CRC32();
			chksum.update(imagebytes, 0, imagebytes.length);
			
			String imagesize = NewAuthUtils.getImageSize(imageinfo.getWidth(), imageinfo.getHeight());
			float aspectratio = NewAuthUtils.getImageAspectRatio(imageinfo.getWidth(), imageinfo.getHeight());
			
			BatchStatement batch = new BatchStatement();
			
			
			if (manager == null) manager = new MappingManager(cassconnector.getSession());
			
			ImageSizesAndAR imgsizear = new ImageSizesAndAR(imagesize,aspectratio );
			Mapper<ImageSizesAndAR> imgsizearmapper = manager.mapper(ImageSizesAndAR.class);
			batch.add(imgsizearmapper.saveQuery(imgsizear));
			
			imguuid = UUIDs.random();
			ImageByUserAndChecksum userimg = new ImageByUserAndChecksum(imguuid, 
																(sessiondata.getUserid() == null)?"SYSTEM":sessiondata.getUserid().toString(), 
																imagesize,
																Long.toString(chksum.getValue()));
			
			/* THis is getting added elsewhere also
			 * ImageDataByImageID imagedatauuid = new ImageDataByImageID(imguuid,
									sessiondata.getUserid(), 0, // imageseq
					imagesize, imageinfo.getHeight(),
					imageinfo.getWidth(), aspectratio, imageinfo.getMimeType(),
					imgcreatetime, null, // lastaccessdate
					tags // tags
			);*/
			
			Mapper<ImageByUserAndChecksum> userimgmapper = manager.mapper(ImageByUserAndChecksum.class);
			batch.add(userimgmapper.saveQuery(userimg));
		

			//Mapper<ImageDataByImageID> imgidmapper = manager.mapper(ImageDataByImageID.class);
			//batch.add(imgidmapper.saveQuery(imagedatauuid));
			
			//ImageDataByUserIDAndSize
			
			if (sessiondata.getUserid() != null) {
				int currentseq = getlastseqforuserandsize(sessiondata.getUserid(), imagesize);
				
				//int globalseq = getlastseqforsystemimagesforsizeandar(imageinfo.getWidth(), imageinfo.getHeight());
				int globalseq = getlastseqforsystemimagesforsizeandar(100, 100);
				
				short imageseq = (short) (currentseq + 1);	
				
				globalseq++;
				
				ImageDataByUserIDAndSize userimgsize = new ImageDataByUserIDAndSize(imguuid, sessiondata.getUserid(), (short) imageseq, // imageseq
						(short)globalseq,
						imagesize, imageinfo.getHeight(),
						imageinfo.getWidth(), aspectratio, imageinfo.getMimeType(),
						imgcreatetime, null, // lastaccessdate
						tags // tags;
						);
				
				Mapper<ImageDataByUserIDAndSize> imgsizemapper = manager.mapper(ImageDataByUserIDAndSize.class);
				batch.add(imgsizemapper.saveQuery(userimgsize));
				
				
			}

			cassconnector.getSession().execute(batch);
			
		} catch (IOException e) {
			System.out.println("IOException processing image file.");
			System.out.println(e.getMessage());
		}
		return imguuid.toString();
	}

	public int getlastseqforuserandsize(UUID userid, String imageSize) {
		ImageDataByUserIDAndSize img = new ImageDataByUserIDAndSize();
		img.setSize(imageSize);
		img.setUserid(userid);
		
		Result<ImageDataByUserIDAndSize> readimg = img.getImagesByUserAndSize(cassconnector.getSession(), userid, imageSize);
		
		int maxseq = 0;
		
		for (ImageDataByUserIDAndSize u : readimg) {
		    System.out.println("images from user : " + u.getUserid().toString() + " size - " + u.getSize() + " imageid " + u.getImageid());
		    
		    if (u.getImageseq() > maxseq)
		    	maxseq = u.getImageseq();
		}
		
		return maxseq;
	}
	
	public Result<ImageDataByUserIDAndSize> getImagesforuserandsize(UUID userid, String imageSize) {
		ImageDataByUserIDAndSize img = new ImageDataByUserIDAndSize();
		img.setSize(imageSize);
		img.setUserid(userid);
		
		Result<ImageDataByUserIDAndSize> readimg = img.getImagesByUserAndSize(cassconnector.getSession(), userid, imageSize);
		
		
		return readimg;
	}
	
	
	public Result<ImageDataByMetaData> getImagesforsizeandar(String imageSize, int width, int height, int lastSeq) {
		ImageDataByMetaData img = new ImageDataByMetaData();
		img.setSize(imageSize);
		float ar = NewAuthUtils.getImageAspectRatio(width, height);
		img.setAspectratio(ar);
		
		short tolerance = 10;
		if (ar > 1.5)
			tolerance = 8;
		
		if (ar < .75)
			tolerance = 15;
		
		Float[] allowedars = NewAuthUtils.getAllowedAspectRatios(ar, tolerance); // 
		
		System.out.println("Searching for images by size: " + imageSize + " aratios: " + allowedars[0] + "-" + allowedars[allowedars.length-1] + " lastseq: " + lastSeq);
		
		Result<ImageDataByMetaData> readimg = img.getImagesBySizeAr(cassconnector.getSession(), lastSeq, allowedars);
		
		
		return readimg;
	}
	
	public ImageDataByMetaData getTinyImageCopyOfAnImage(ImageDataByMetaData originalimage) {
		ImageDataByMetaData img = new ImageDataByMetaData();
		
		ImageDataByMetaData readimg = img.getTinyImageOfAnotherImage(cassconnector.getSession(), originalimage);
		
		
		return readimg;
	}
	
	public ImageDataByMetaData getAnotherSizeImageCopyOfATinyImage(ImageDataByMetaData originalimage, String newsize) {
		ImageDataByMetaData img = new ImageDataByMetaData();
		
		ImageDataByMetaData readimg = img.getAnotherImageByTinyImage(cassconnector.getSession(), originalimage, newsize);
		
		
		return readimg;
	}
	
	
	
	
	public List<Float> getAspectRatiosForSize(String size) {
		List<Float> out = new ArrayList<Float>();
		
		ImageSizesAndAR input = new ImageSizesAndAR(size, 0);
		
		Result<ImageSizesAndAR> results = input.getAvailableARsForSize(cassconnector.getSession(), 0, 0);
		
		for (ImageSizesAndAR ardata: results) {
			out.add(ardata.getAspectratio());
		}
		
		return out;
	}
	

	private String getExistingImageWithSameCheckSum(String userid, String size, long value) {
		ImageByUserAndChecksum img = new ImageByUserAndChecksum();
		img.setUserid(userid);
		img.setChecksum(Long.toString(value));
		img.setSize(size);
		
		ImageByUserAndChecksum readimg = img.readViaMapper(cassconnector.getSession());
		
		if (readimg != null)
			return readimg.getImageid().toString();
		
		return null;
	}

	public ImageVO getImageBlobDataBasedOnId(String uuid) {
		ImageVO outputimg = null;
		if (uuid != null && uuid.length() > 0) {
			//System.out.println("Reading image blob ...." + uuid);
			ImageDataByImageID inputimg = new ImageDataByImageID(UUID.fromString(uuid), null, (short) 0, "", 0, 0,
					(float) 0.0, null, null, null, null);

			//outputimg = inputimg.getImageBlobDataByImageID(cassconnector.getSession());
			outputimg = inputimg.getImageBlobDataByImageIDViaCQL(cassconnector.getSession());

			if (outputimg == null)
				System.out.println("Image Blob could not be read.. " + uuid);
			
		}
		return outputimg;
	}
	
	public ImageDataByImageID getImageDataBasedOnId(String uuid) {
		ImageDataByImageID outputimg = null;
		if (uuid != null && uuid.length() > 0) {
			//System.out.println("Reading image back...." + uuid);
			ImageDataByImageID inputimg = new ImageDataByImageID(UUID.fromString(uuid), null, (short) 0, "", 0, 0,
					(float) 0.0, null, null, null, null);

			outputimg = inputimg.readViaMapper(cassconnector.getSession());

			if (outputimg == null)
				System.out.println("Image data could not be read.. " + uuid);
			
		}
		return outputimg;
	}

	public ImageDataByUserIDAndSize getImageDataBasedOnUserIdSizeARAndCreateDate(UUID userid, String imageSize, float ar,
			Date createdate) {
		ImageDataByUserIDAndSize img = new ImageDataByUserIDAndSize();
		img.setSize(imageSize);
		img.setUserid(userid);
		img.setCreatedate(createdate);
		img.setAspectratio(ar);
		
		ImageDataByUserIDAndSize readimg = img.readViaMapper(cassconnector.getSession());
		
		return readimg;
	}
	
	
	public List<ImgIDTranslatorVO> selectRandomImagesForUserAuth(String userid, int width, int height, int initializeImageSetSize, HttpSession session) {
		
		String imgsz = NewAuthUtils.getImageSize(width,height);
		List<ImgIDTranslatorVO> imgIds = null;
		
		SessionDataVO sessiondata = (SessionDataVO) session.getAttribute("session");
		
		 
		// setting imgsz based on window size --just for testing
		//imgsz = NewAuthUtils.getImageSize(sessiondata.getDeviceinfo().getWindowwidth(),sessiondata.getDeviceinfo().getWindowheight());
		// done setting
		
		if (sessiondata.getCurrentimagesforuser().get(sessiondata.getUserinfo().getUsername()) != null) {
			// if there is a cached entry, return that, it is a refresh attempt to guess the image by seeing different options
			// this cached entry will be cleared when a selection is made
			System.out.println("Got cached images.");
			return sessiondata.getCurrentimagesforuser().get(sessiondata.getUserinfo().getUsername());
		}
		
		if (sessiondata.getUserimageseqnumbers() == null || sessiondata.getUserimageseqnumbers().size() == 0) {
			
			sessiondata.getUserimageseqnumbers().addAll(getValidseqforuserandsize(UUID.fromString(userid), imgsz));
		}
		
				
		System.out.println("Screen size: " + imgsz);
		
		if (imgsz.equals("S") || imgsz.equals("M")) { // For small screens we send a collage containing one (or more) user images
													// We are getting system images here			
			
			List<Integer> fulllist = null;
			
			if (sessiondata.getSystemimageseqnumbersforcollage() == null || sessiondata.getSystemimageseqnumbersforcollage().size() == 0) { // We want to make sure that fake images get selected from a large
																																			// set, this is different from fake auth section
				int availablesystemimages = getlastseqforsystemimagesforsizeandar(width, height);
				int minimageSetSize = maxnumberofimages; //TODO: do we want a separate parameter for collage size?
				
				int maximageSetSize = 3 * maxnumberofimages; // we want a big enough pool, but we also do not too huge a pool
				if (minimageSetSize > availablesystemimages) {
					System.out.println("ImageDataDAO: selectRandomImagesForUserAuth-- collage section-  FAILURE -- SYSTEM does not have " + minimageSetSize + " images");
					return imgIds;
				}		
				
				int[] allnos = IntStream.rangeClosed(1, availablesystemimages).toArray();
				long seed = System.nanoTime();
				
				fulllist = IntStream.of(allnos).boxed().collect(Collectors.toList());
				
				// remove user images from full list first
				fulllist.removeAll(sessiondata.getUserimageseqnumbers());
				
				Collections.shuffle(fulllist, new Random(seed));
			
				if (fulllist.size() > maximageSetSize)
					sessiondata.getSystemimageseqnumbersforcollage().addAll(fulllist.subList(0, maximageSetSize));
				else
					sessiondata.getSystemimageseqnumbersforcollage().addAll(fulllist);
				System.out.println("ImageDataDAO: selectRandomImagesForUserAuth-- collage section- complete randomized list of system images, size: " + sessiondata.getSystemimageseqnumbersforcollage().size() + " with seed " + seed + " - " + sessiondata.getSystemimageseqnumbersforcollage());
			}
		}
		
		int failedauthsinanhour = eventdao.findEventsByUseridAndType(userid, EventTypes.AUTH_CHALLENGE_FAIL).all().size();
		 
		 sessiondata.setRisk(sessiondata.getRisk() + failedauthsinanhour);
		 
		 System.out.println("Current failed auths in last hour: " + failedauthsinanhour + " current risk: " + sessiondata.getRisk());
		 
		 int initialfakeimagesetsize = NewAuthUtils.getInitialFakeImageSetSize(sessiondata.getUserinfo(), sessiondata.getRisk());		
	
		List<Integer> currentimagesforuser = sessiondata.getUserimageseqnumbers();
		// TODO: filter this list if needed
		// we may not want to repeat same image in subsequent attempts -- lets not do this... let randomness take care of this
		
		if (currentimagesforuser.size() < initializeImageSetSize) {
			System.out.println("ImageDataDAO: selectRandomImagesForUserAuth FAILURE -- user " + userid + " does not have enough [ " + initializeImageSetSize + "] images");
			return imgIds;
		}
		
		int[] allnos = new int[currentimagesforuser.size()];		
		int offset = 0;
		for(final Integer i : currentimagesforuser){
			allnos[offset++] = i.intValue();
        }
		
		List<Integer> list = IntStream.of(allnos).boxed().collect(Collectors.toList());
		long seed = System.nanoTime();
		Collections.shuffle(list, new Random(seed));
		
		if (imgsz.equals("S") || imgsz.equals("M")) { // Now, we need to take one image from this list and stuff it in the collage
			if (sessiondata.getSystemimageseqnumbersforcollage() != null && sessiondata.getSystemimageseqnumbersforcollage().size() > 0) {
				
				imgsz = "T";
				
				int indextoswitch = ThreadLocalRandom.current().nextInt(0, maxnumberofimages);
				
				if (indextoswitch >= sessiondata.getSystemimageseqnumbersforcollage().size()) {
					indextoswitch = sessiondata.getSystemimageseqnumbersforcollage().size() -1;
				}
				
				sessiondata.getSystemimageseqnumbersforcollage().set(indextoswitch, list.get(0));
				
				list = sessiondata.getSystemimageseqnumbersforcollage();
				
				initializeImageSetSize = (list.size()>maxnumberofimages)?maxnumberofimages:list.size()-1;
				
				System.out.println("ImageDataDAO: selectRandomImagesForUserAuth -- collage section- randomized seq list, size: " + initializeImageSetSize + " with seed " + seed + " - " + list.subList(0, initializeImageSetSize));
			}
		} else {
		
			if (initialfakeimagesetsize > 0) {// we need to add initialfakeimagesetsize fake images into usual userimage list
				
				List<Integer> indexestopickfrom = new ArrayList<Integer>();
					
				List<Integer> allavailablesystemimages = getAllseqforsystemimagesforsizer(width, height);
				// remove user images from full list first
				allavailablesystemimages.removeAll(sessiondata.getUserimageseqnumbers());
				
				
				for (int q=0; q<initialfakeimagesetsize; q++) {
					int thisindex = ThreadLocalRandom.current().nextInt(0, allavailablesystemimages.size());
					
					if (thisindex >= allavailablesystemimages.size())
						thisindex = allavailablesystemimages.size() - 1;
					
					indexestopickfrom.add(thisindex);
				}
				
				
				
				list = list.subList(0, initializeImageSetSize);
				
				for (int q=0; q<initialfakeimagesetsize; q++) {
					list.add(allavailablesystemimages.get(indexestopickfrom.get(q)));
					System.out.println("Added seq: " + allavailablesystemimages.get(indexestopickfrom.get(q)) + " as a fake image");
					
				}				
				
				//Shuffle the list again, otherwise fake image will always be the last one
				seed = System.nanoTime();
				Collections.shuffle(list, new Random(seed));
				
				initializeImageSetSize = initializeImageSetSize + initialfakeimagesetsize;
			}
			System.out.println("ImageDataDAO: selectRandomImagesForUserAuth randomized seq list with seed " + seed + " - " + list);
		}
					
		imgIds = new ArrayList<ImgIDTranslatorVO>();
		
		for (int seq: list.subList(0, initializeImageSetSize)) { 
			ImageDataByMetaData imgbyseq = new ImageDataByMetaData();
			imgbyseq.setSize(imgsz);
			imgbyseq.setImageseq(seq);				
			
			imgbyseq = imgbyseq.getImageBySizeAndSeq(cassconnector.getSession());
			
			if (imgbyseq != null) {
				
				ImgIDTranslatorVO translator = new ImgIDTranslatorVO();
				translator.setNormalID(imgbyseq.getImageid().toString());
				
				translator.setNormalwidth(imgbyseq.getImagewidth());
				translator.setNormalheight(imgbyseq.getImageheight());
				
				//ImageDataByMetaData tinyimg = getTinyImageCopyOfAnImage(imgbyseq);
				//if (tinyimg != null) {
				//	translator.setTinyID(tinyimg.getImageid().toString());
				imgIds.add(translator);
				//}			
				
			}
		}
				
		
		return imgIds;
	}

	private List<Integer> getValidseqforuserandsize(UUID user, String imgsz) { // return ALL finalized images from here
																		
		List<UserImageClickMemoryData> finalizedimages = trandao.getFinalizedUserImages(user);
		
		List<Integer> out = new ArrayList<Integer>();
		
		for (UserImageClickMemoryData data: finalizedimages) {
			
					out.add(data.getGlobalSeq());
			
		}
		
		return out;
	}
	
	

	public List<ImgIDTranslatorVO> assignRandomImagesToUser(String userid, int width, int height, int initializeImageSetSize) {
		
		String imgsz = NewAuthUtils.getImageSize(width,height);
		List<ImgIDTranslatorVO> imgIds = null;
		
		int availablesystemimages = getlastseqforsystemimagesforsizeandar(width, height);
		List<Integer> allavailablesystemimages = getAllseqforsystemimagesforsizer(width, height);
		int currentimagesforuser = getlastseqforuserandsize(UUID.fromString(userid), imgsz);
		
		if (currentimagesforuser >= initializeImageSetSize) {
			System.out.println("ImageDataDAO: assignRandomImagesToUser FAILURE -- user " + userid + " already has more than " + initializeImageSetSize + " images");
			return imgIds;
		}
		
		if (initializeImageSetSize > allavailablesystemimages.size()) {
			System.out.println("ImageDataDAO: assignRandomImagesToUser FAILURE -- SYSTEM does not have " + initializeImageSetSize + " images");
			return imgIds;
		}
		
		if ((initializeImageSetSize - currentimagesforuser ) > allavailablesystemimages.size() ) {
			System.out.println("ImageDataDAO: assignRandomImagesToUser FAILURE -- SYSTEM does not have " + (initializeImageSetSize - currentimagesforuser ) + " images to assign to user");
			return imgIds;
		} else {
			int maxseqforcurrentuser = currentimagesforuser;
			
			//int[] allnos = IntStream.rangeClosed(currentimagesforuser+1, availablesystemimages).toArray();
			int[] allnos = allavailablesystemimages.stream().mapToInt(i->i).toArray();
			//allavailablesystemimages.toArray(allnos);
			
			List<Integer> list = IntStream.of(allnos).boxed().collect(Collectors.toList());
			long seed = System.nanoTime();
			Collections.shuffle(list, new Random(seed));
			
			System.out.println("ImageDataDAO: assignRandomImagesToUser randomized seq list with seed " + seed + " - " + list.subList(0, initializeImageSetSize));
			
			ImageDataByUserIDAndSize userimages = new ImageDataByUserIDAndSize();
			userimages.setSize(imgsz);
			userimages.setUserid(UUID.fromString(userid));
			
			Result<ImageDataByUserIDAndSize> userresults = userimages.getImagesByUserAndSize(cassconnector.getSession(), UUID.fromString(userid), imgsz);
			ArrayList<String> userimglist = new ArrayList<String>();
			
			for (ImageDataByUserIDAndSize oneimg: userresults) {
				userimglist.add(oneimg.getImageid().toString());
			}
			
			imgIds = new ArrayList<ImgIDTranslatorVO>();
									
			for (int seq: list.subList(0, initializeImageSetSize)) { // Add these images to user's record
				ImageDataByMetaData imgbyseq = new ImageDataByMetaData();
				imgbyseq.setSize(imgsz);
				imgbyseq.setImageseq(seq);				
				
				imgbyseq = imgbyseq.getImageBySizeAndSeq(cassconnector.getSession());
				
				if (imgbyseq != null && !userimglist.contains(imgbyseq.getImageid().toString())) {
					
					ImgIDTranslatorVO translator = new ImgIDTranslatorVO();
					translator.setNormalID(imgbyseq.getImageid().toString());
					
					ImageDataByMetaData tinyimg = getTinyImageCopyOfAnImage(imgbyseq);
					if (tinyimg != null) {
						translator.setTinyID(tinyimg.getImageid().toString());
						imgIds.add(translator);
					}
					ImageDataByUserIDAndSize userimg =  new ImageDataByUserIDAndSize(
							imgbyseq.getImageid(),
							UUID.fromString(userid),
							(short) (currentimagesforuser + 1), 
							(short) imgbyseq.getImageseq(),
							imgbyseq.getSize(),
							imgbyseq.getImageheight(),
							imgbyseq.getImagewidth(),
							imgbyseq.getAspectratio(),
							imgbyseq.getImagetype(),
							imgbyseq.getCreatedate(),
							imgbyseq.getLastaccessdate(),
							imgbyseq.getTags()		
																);
					
					ImageDataByUserIDAndSize.insertViaCQL(cassconnector.getSession(), userimg) ;
					
					currentimagesforuser++;
				}
			}
		}
		return imgIds;
	}
	
	
	public List<ImgIDTranslatorVO> assignRandomImagesForFakeAuth( int width, int height, int imageSetSize, HttpSession session) {
		
		String imgsz = NewAuthUtils.getImageSize(width,height);
		List<ImgIDTranslatorVO> imgIds = null;
		
		SessionDataVO sessiondata = (SessionDataVO) session.getAttribute("session");
		
		List<Integer> fulllist = null;
		if (sessiondata.getSystemimageseqnumbers() == null || sessiondata.getSystemimageseqnumbers().size() == 0) { // We want to make sure that fake images also come from a small sample similar to a normal user's set
			int availablesystemimages = getlastseqforsystemimagesforsizeandar(width, height);
			
			if (imageSetSize > availablesystemimages) {
				System.out.println("ImageDataDAO: assignRandomImagesForFakeAuth FAILURE -- SYSTEM does not have " + imageSetSize + " images");
				return imgIds;
			}		
			
			int[] allnos = IntStream.rangeClosed(1, availablesystemimages).toArray();
			long seed = System.nanoTime();
			
			fulllist = IntStream.of(allnos).boxed().collect(Collectors.toList());
			Collections.shuffle(fulllist, new Random(seed));
		
			sessiondata.getSystemimageseqnumbers().addAll(fulllist.subList(0, initializeImageSetSize));
			System.out.println("ImageDataDAO: assignRandomImagesForFakeAuth complete randomized list with seed " + seed + " - " + fulllist.subList(0, initializeImageSetSize));
		}
		
		List<Integer> list = sessiondata.getSystemimageseqnumbers();					
	
		long seed = System.nanoTime();
		Collections.shuffle(list, new Random(seed));
		
		System.out.println("ImageDataDAO: assignRandomImagesForFakeAuth randomized transaction list with seed " + seed + " - " + list.subList(0, imageSetSize));
		
		imgIds = new ArrayList<ImgIDTranslatorVO>();
								
		for (int seq: list.subList(0, imageSetSize)) { // Add these images to fake auth attempt
			ImageDataByMetaData imgbyseq = new ImageDataByMetaData();
			imgbyseq.setSize(imgsz);
			imgbyseq.setImageseq(seq);				
			
			imgbyseq = imgbyseq.getImageBySizeAndSeq(cassconnector.getSession());
			
			ImgIDTranslatorVO translator = new ImgIDTranslatorVO();
			translator.setNormalID(imgbyseq.getImageid().toString());
			translator.setNormalwidth(imgbyseq.getImagewidth());
			translator.setNormalheight(imgbyseq.getImageheight());
			
			//ImageDataByMetaData tinyimg = getTinyImageCopyOfAnImage(imgbyseq);
			//if (tinyimg != null) {
			//	translator.setTinyID(tinyimg.getImageid().toString());
				imgIds.add(translator);
			//}
			
		}
		
		return imgIds;
	}

	public List<ImgIDTranslatorVO> getUserImagesForPwdSet(UUID userid, int screenwidth, int screenheight) {
		List<ImgIDTranslatorVO> imgIds = new ArrayList<ImgIDTranslatorVO>();
		
		String devicesize = NewAuthUtils.getImageSize(screenwidth, screenheight);
		Result<ImageDataByUserIDAndSize> userimgs = getImagesforuserandsize(userid, devicesize);
		
		for (ImageDataByUserIDAndSize oneimg: userimgs) {
			ImgIDTranslatorVO translator = new ImgIDTranslatorVO();
			translator.setNormalID(oneimg.getImageid().toString());
			
			ImageDataByMetaData imgbyseq = new ImageDataByMetaData();
			imgbyseq.setSize(oneimg.getSize());
			imgbyseq.setImageseq(oneimg.getGlobalSequence());	
			ImageDataByMetaData tinyimg = getTinyImageCopyOfAnImage(imgbyseq);
			
			if (!oneimg.getSize().equals(devicesize)) {
				ImageDataByMetaData realimgfordevice = tinyimg.getAnotherImageByTinyImage(cassconnector.getSession(), tinyimg, devicesize);
				if (realimgfordevice != null)
					translator.setNormalID(realimgfordevice.getImageid().toString());
			}
			
			if (tinyimg != null) {
				translator.setTinyID(tinyimg.getImageid().toString());
				
				UserImageClickMemoryData clkdata = trandao.getClickDataBasedonUserAndImage(userid, oneimg.getGlobalSequence() );
				
				if (clkdata != null) {
					translator.setNormalclickx(clkdata.getClickx());
					translator.setNormalclicky(clkdata.getClicky());
					translator.setNormalwidth(clkdata.getImgwidth());
					translator.setNormalheight(clkdata.getImgheight());
					translator.setMatchingClickCount(clkdata.getSuccesscount());
				}
				imgIds.add(translator);
			}
		}
		
		return imgIds;
	}

}
