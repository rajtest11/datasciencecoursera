package com.jul.newauth.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.datastax.driver.core.BatchStatement;
import com.datastax.driver.mapping.Mapper;
import com.datastax.driver.mapping.MappingManager;
import com.datastax.driver.mapping.Result;
import com.jul.newauth.model.UserDataVO;

import com.jul.newauth.model.cassandra.ks.transactions.UserDataByUserAndSeq;


@Component
public class UserDataDAO {
	@Autowired
	CassandraConnector cassconnector;
	
	private static MappingManager manager;
	
	public void createUserData(UserDataVO user) {
		
		// No need to save this... the call by user and seq is working bu user alone too
		/*UserDataByUser nauser = null;
		nauser = new UserDataByUser(user.getUserid(),
									user.getSequence(),
									user.getSalt(),
									user.getIterations(),
									user.getData(),
									user.getLastupdatedate(),
									user.getCreatedate()
									);*/
		
		UserDataByUserAndSeq useriduser = new UserDataByUserAndSeq(user.getUserid(),
											user.getSequence(),
											user.getSalt(),
											user.getIterations(),
											user.getData(),
											user.getLastupdatedate(),
											user.getCreatedate()
										);
		
		BatchStatement batch = new BatchStatement();
		
		if (manager == null)
			manager = new MappingManager(cassconnector.getSession());

		//Mapper<UserDataByUser> mapper = manager.mapper(UserDataByUser.class);
		//batch.add(mapper.saveQuery(nauser));
		
		Mapper<UserDataByUserAndSeq> mapper2 = manager.mapper(UserDataByUserAndSeq.class);
		batch.add(mapper2.saveQuery(useriduser));
		
		long start = System.currentTimeMillis();
		
		cassconnector.getSession().execute(batch);
		
		System.out.println("Added UserDataByUserAndSeq in batch : " + useriduser.getUserid() + " seq: "  + useriduser.getSequence() + " in " + (System.currentTimeMillis() - start) + "ms");
		
	
	}
	
	
	
	public List<UserDataVO> findUserDataByUserid(String userid) {
		UserDataByUserAndSeq obj = new UserDataByUserAndSeq();
		
		obj.setUserid(UUID.fromString(userid));		
		
		Result<UserDataByUserAndSeq> res = obj.readViaUserId(cassconnector.getSession(), UUID.fromString(userid));
		
		List<UserDataVO> listuserdata = new ArrayList<UserDataVO>();
		
		for (UserDataByUserAndSeq data: res) {
			UserDataVO vo = new UserDataVO();
			vo.setCreatedate(data.getCreatedate());
			vo.setData(data.getData());
			vo.setIterations(data.getIterations());
			vo.setLastupdatedate(data.getLastupdatedate());
			vo.setSalt(data.getSalt());
			vo.setSequence(data.getSequence());
			vo.setUserid(data.getUserid());
			
			listuserdata.add(vo);
		}
		
		return listuserdata;
	}
	
	
	

}
