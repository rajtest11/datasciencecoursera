package com.jul.newauth.api.web;

import java.util.Calendar;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.jul.newauth.dao.UserDataDAO;
import com.jul.newauth.model.SessionDataVO;
import com.jul.newauth.model.UserDataVO;
import com.jul.newauth.util.NewAuthUtils;

@Controller
@RequestMapping(value = "/secure")
public class SecureDataController {
	@Autowired
    UserDataDAO userdatadao;
	
	 @RequestMapping(value = { "/adduserdata" }, method = RequestMethod.POST)
	 @ResponseStatus(value = HttpStatus.OK) // adding this because nothing is being returned
	 public void addUserData( @RequestBody UserDataVO userdata,
			 					ModelMap model, HttpSession session)  {
		 
		 System.out.println("\nNew Request------------" + NewAuthUtils.getTimeStampString());
		 System.out.println("In addUserData");
		 SessionDataVO sessiondata = (SessionDataVO) session.getAttribute("session");		 
		
		 if (sessiondata.getUserid() == null) {
			// return "error";
			 System.out.println("Session did not have a userID. Looks like a stale session. Discard.");
			 return;
		 }
		 
		 userdata.setUserid(sessiondata.getUserid());
		 if (userdata.getCreatedate() == null) {
			 userdata.setCreatedate(Calendar.getInstance().getTime());
			 userdata.setLastupdatedate(Calendar.getInstance().getTime());
		 } else {
			 userdata.setLastupdatedate(Calendar.getInstance().getTime());
		 }
		 
		 System.out.println("userdata received " + NewAuthUtils.toStringForPrint(userdata ));
		 // Remove "\" from the data field
		 
		 userdata.setData(userdata.getData().replace("\\", ""));  /// or replaceAll("\\\\", "")
		 userdatadao.createUserData(userdata);
		 

		 
	 }
	 

}
