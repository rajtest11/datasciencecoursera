package com.jul.newauth.api.web;

import java.net.InetAddress;
import java.util.Calendar;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.messaging.MessageHeaders;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.SendTo;
import org.springframework.messaging.simp.SimpMessageHeaderAccessor;
import org.springframework.messaging.simp.SimpMessageSendingOperations;
import org.springframework.messaging.simp.SimpMessageType;
import org.springframework.messaging.simp.annotation.SendToUser;
import org.springframework.stereotype.Controller;
import org.springframework.web.context.request.NativeWebRequest;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;

import com.jul.newauth.dao.EventDAO;
import com.jul.newauth.dao.UserDAO;
import com.jul.newauth.model.EventTypes;
import com.jul.newauth.model.LocalHostVO;
import com.jul.newauth.model.UserNameCheckVO;
import com.jul.newauth.model.cassandra.ks.analytics.NewauthEvent;
import com.jul.newauth.model.cassandra.ks.users.UsersByUsername;
import com.jul.newauth.util.NewAuthUtils;

@Controller
	public class WebSocketNewAuthController {
	
	 @Autowired
     public SimpMessageSendingOperations messagingTemplate;
	
		@Autowired
		UserDAO userdao;	
		
		@Autowired
		EventDAO eventdao;

		@Value("${storeusernameclear}")
		private boolean storeusernameclear;
		
		@Autowired
		private LocalHostVO hostip;
	    
	    @MessageMapping("/usernamecheck")
	    @SendToUser("/queue/usernamecheck")
	    public void doesuserExist(SimpMessageHeaderAccessor accessor, UserNameCheckVO message) throws Exception {
	        System.out.print("In websocket controller.doesuserExist: username:" 
	        									+ message.getUserName() 
	        									+ ((!storeusernameclear)?"":" [" + message.getUsernameclear() + "] ")
	        									+ " session: " + accessor.getSessionId()
	        									+ " clientip: " + message.getClientip());
	    	
	    	UsersByUsername existinguser = userdao.findUserByUsername(message.getUserName()) ;
	    	
	    	String out = "";
	    	
	    	if (existinguser != null) {
	    		out = "EXISTS";
	    		
	    		//Stuff sessionid in the message
	    		message.setClientsession(accessor.getSessionId());
	    		NewauthEvent ev = new NewauthEvent(UUID.randomUUID(), 
	    											EventTypes.USER_EXISTS, 
	    											Calendar.getInstance().getTime(), 
	    											null, //UserID
	    											InetAddress.getByName(message.getClientip()),
	    											hostip.getHostip(),
	    											NewAuthUtils.toStringForPrint(message));
	    		
	    		eventdao.createEvent(ev);
	    	}
	    	
	    	System.out.println(out);
	    	
	       SimpMessageHeaderAccessor headerAccessor = SimpMessageHeaderAccessor
	    		    .create(SimpMessageType.MESSAGE);
	    		headerAccessor.setSessionId(accessor.getSessionId());
	    		headerAccessor.setLeaveMutable(true);	    		
	    		
	    	messagingTemplate.convertAndSendToUser(accessor.getSessionId(),
	    											"/queue/usernamecheck", 
	    											new UserNameCheckVO(message.getUserName() ,"", out, message.getClientip(), null) 
	    											,headerAccessor.getMessageHeaders()
	    											);
	    }
	    
	    
	    
	    	@MessageMapping("/someotherop")
		    @SendTo("/topic/someothertopic")		    
		    public UserNameCheckVO someotherop(UserNameCheckVO message) throws Exception {
		        //Thread.sleep(1000); // simulated delay
		    	System.out.println("In websocket controller someop: username:" + message.getUserName() );
		    	
		    	UsersByUsername existinguser = userdao.findUserByUsername(message.getUserName()) ;
		    	
		    	String out = "";
		    	
		    	if (existinguser != null)
		    		out = "EXISTS";
		    	
		        return new UserNameCheckVO(message.getUserName() ,"",  out, null, null);
		    	
		    	
		    }
	    	
	    	
	    	
	    	
	    
	    
	}

