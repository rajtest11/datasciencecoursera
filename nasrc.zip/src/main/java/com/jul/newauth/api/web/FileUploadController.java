package com.jul.newauth.api.web;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.apache.commons.io.FilenameUtils;
import org.apache.commons.io.IOUtils;
import org.apache.commons.validator.routines.UrlValidator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.util.FileCopyUtils;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.multipart.MultipartFile;

import com.datastax.driver.mapping.Result;
import com.jul.newauth.dao.ImageDataDAO;
import com.jul.newauth.model.DeviceVO;
import com.jul.newauth.model.ImageVO;
import com.jul.newauth.model.ImgIDTranslatorVO;
import com.jul.newauth.model.MultiUploadFileBucket;
import com.jul.newauth.model.SessionDataVO;
import com.jul.newauth.model.UploadFileBucket;
import com.jul.newauth.model.UserVO;
import com.jul.newauth.model.cassandra.ks.users.ImageDataByImageID;
import com.jul.newauth.model.cassandra.ks.users.ImageDataByMetaData;
import com.jul.newauth.model.cassandra.ks.users.ImageDataByUserIDAndSize;
import com.jul.newauth.model.cassandra.ks.users.ImageSizesAndAR;
import com.jul.newauth.util.NewAuthUtils;
import com.jul.newauth.util.SimpleImageInfo;
import com.jul.newauth.util.UploadFileValidator;
import com.jul.newauth.util.UploadMultiFileValidator;

@Controller
public class FileUploadController {

	private static String UPLOAD_LOCATION = "C:/temp/FileUploadTests/";

	@Autowired
	ImageDataDAO imagedatadao;

	@Autowired
	UploadFileValidator fileValidator;

	@Autowired
	UploadMultiFileValidator multiFileValidator;

	@InitBinder("UploadFileBucket")
	protected void initBinderUploadFileBucket(WebDataBinder binder) {
		binder.setValidator(fileValidator);
	}

	@InitBinder("multiUploadFileBucket")
	protected void initBinderMultiUploadFileBucket(WebDataBinder binder) {
		binder.setValidator(multiFileValidator);
	}

	@RequestMapping(value = "/singleUpload", method = RequestMethod.GET)
	public String getSingleUploadPage(ModelMap model, HttpSession session) {

		System.out.println("");
		System.out.println("New GET request for singleUpload page---------");

		SessionDataVO sessiondata = (SessionDataVO) session.getAttribute("session");

		if (sessiondata == null || sessiondata.getDeviceinfo() == null) {
			System.out.println("No session data");
			UserVO userModel = new UserVO();
			DeviceVO device = new DeviceVO();
			model.addAttribute("user", userModel);
			model.addAttribute("device", device);
			return "welcome";

		}

		if (sessiondata.getUserauthenticated() == null) {
			// TODO: make it active after testing - IN PROD
			// return "failure";
		}

		System.out.println(NewAuthUtils.toStringForPrint(sessiondata.getDeviceinfo()));
		System.out.println(NewAuthUtils.toStringForPrint(sessiondata));

		if (sessiondata.getDeviceinfo() != null && sessiondata.getDeviceinfo().getScreenwidth() > 0
				&& sessiondata.getDeviceinfo().getScreenheight() > 0) {
			String screensize = NewAuthUtils.getImageSize(sessiondata.getDeviceinfo().getScreenwidth(),
					sessiondata.getDeviceinfo().getScreenheight());
			/*
			 * Result<ImageDataByMetaData> images =
			 * imagedatadao.getImagesforsizeandar(screensize,
			 * sessiondata.getDeviceinfo().getScreenwidth(),
			 * sessiondata.getDeviceinfo().getScreenheight(),
			 * sessiondata.getLastImageSeq());
			 */
			// Testing with getting images for window's aspect ratio instead of
			// screen

			List<ImgIDTranslatorVO> imgIds = new ArrayList<ImgIDTranslatorVO>();

			if (sessiondata.getUserid() != null) {
				Result<ImageDataByUserIDAndSize> images = imagedatadao.getImagesforuserandsize(sessiondata.getUserid(),
						screensize);

				List<ImageDataByUserIDAndSize> listofimages = images.all();

				System.out.println(listofimages.size() + " user images found.");

				for (ImageDataByUserIDAndSize imgdata : listofimages) {
					ImgIDTranslatorVO translator = new ImgIDTranslatorVO();
					translator.setNormalID(imgdata.getImageid().toString());

					ImageDataByMetaData imgdatacopy = new ImageDataByMetaData(imgdata.getImageid(),
							sessiondata.getUserid(), imgdata.getGlobalSequence(), // imageseq
							imgdata.getSize(), imgdata.getImageheight(), imgdata.getImagewidth(),
							imgdata.getAspectratio(), imgdata.getImagetype(), imgdata.getCreatedate(), null, // lastaccessdate
							imgdata.getTags());

					ImageDataByMetaData tinyimg = imagedatadao.getTinyImageCopyOfAnImage(imgdatacopy);
					if (tinyimg != null) {
						translator.setTinyID(tinyimg.getImageid().toString());
						imgIds.add(translator);
					}
				}
			} else {
				Result<ImageDataByMetaData> images = imagedatadao.getImagesforsizeandar(screensize,
						sessiondata.getDeviceinfo().getWindowwidth(), sessiondata.getDeviceinfo().getWindowheight(),
						sessiondata.getLastImageSeq());

				List<ImageDataByMetaData> listofimages = images.all();

				System.out.println(listofimages.size() + " system images found.");

				for (ImageDataByMetaData imgdata : listofimages) {
					ImgIDTranslatorVO translator = new ImgIDTranslatorVO();
					translator.setNormalID(imgdata.getImageid().toString());

					ImageDataByMetaData tinyimg = imagedatadao.getTinyImageCopyOfAnImage(imgdata);
					if (tinyimg != null) {
						translator.setTinyID(tinyimg.getImageid().toString());
						imgIds.add(translator);
					}
				}
			}

			model.addAttribute("imageIds", imgIds);

		}

		UploadFileBucket fileModel = new UploadFileBucket();
		model.addAttribute("UploadFileBucket", fileModel);

		model.addAttribute("device", sessiondata.getDeviceinfo());

		// width > 1200 -- desktop
		// width < 1200 -- laptop
		// width < 1024 -- tablet
		// width < 768 -- phone
		if (sessiondata.getDeviceinfo() != null && sessiondata.getDeviceinfo().getScreenwidth() <= 768)
			return "singleFileUploader_mobile";

		return "singleFileUploader";
	}

	@RequestMapping(value = "/image/{id}", method = RequestMethod.GET)
	@ResponseBody
	public ResponseEntity<InputStreamResource> getImageByUUID(@PathVariable("id") String id, HttpSession session) {

		System.out.println("");
		System.out.println("New request for image --------- " + id);
		SessionDataVO sessiondata = (SessionDataVO) session.getAttribute("session");

		String realid = NewAuthUtils.getRealIDForTempImgID(id, sessiondata);

		if (realid != null) {
			id = realid;
			System.out.println("Found realID for image --------- " + id);
		}

		ImageVO imageobj = imagedatadao.getImageBlobDataBasedOnId(id);

		return ResponseEntity.ok().contentLength(imageobj.getImagesize())
				.contentType(MediaType.parseMediaType(imageobj.getImagetype()))
				.body(new InputStreamResource(new ByteArrayInputStream(imageobj.getImagebytes())));
	}

	@RequestMapping(value = { "/imageicon/{id}", "/imageicon/{id}/{width}",
			"/imageicon/{id}/{width}/{height}" }, method = RequestMethod.GET)
	@ResponseBody
	public ResponseEntity<InputStreamResource> getImageIconByUUID(@PathVariable Map<String, String> pathVariables,
			HttpSession session) {

		System.out.println("");
		System.out.println("New request for imageicon---------");
		byte[] rescaledimage = null;
		if (pathVariables.containsKey("id")) {
			int width = 100;
			int height = 100;

			SessionDataVO sessiondata = (SessionDataVO) session.getAttribute("session");
			String id = pathVariables.get("id");
			String realid = NewAuthUtils.getRealIDForTempImgID(id, sessiondata);

			if (realid != null) {
				id = realid;
				System.out.println("Found realID for image --------- " + id);
			}

			ImageDataByImageID imageobj = imagedatadao.getImageDataBasedOnId(pathVariables.get("id"));

			if (pathVariables.containsKey("width")) {
				width = Integer.parseInt(pathVariables.get("width"));
			}

			if (pathVariables.containsKey("height")) {
				height = Integer.parseInt(pathVariables.get("height"));
			}

			String iconsize = NewAuthUtils.getImageSize(width, height);

			if (!iconsize.equals(imageobj.getSize())) {
				// The size of requested image is not the same as the one in DB
				// Lets see if we have the same image in small size
				float aspectratio = NewAuthUtils.getImageAspectRatio(width, height);

				ImageDataByUserIDAndSize smallimg = imagedatadao.getImageDataBasedOnUserIdSizeARAndCreateDate(
						imageobj.getUserid(), iconsize, aspectratio, imageobj.getCreatedate());

				if (smallimg != null && smallimg.getImageid() != null) {
					ImageVO imgblob = imagedatadao.getImageBlobDataBasedOnId(smallimg.getImageid().toString());

					if (imgblob != null) {
						rescaledimage = imgblob.getImagebytes();
						System.out.println("Got small version of big image: " + pathVariables.get("id")
								+ " small image id " + imgblob.getImageid());
						return ResponseEntity.ok().contentLength(rescaledimage.length)
								.contentType(MediaType.parseMediaType(smallimg.getImagetype()))
								.body(new InputStreamResource(new ByteArrayInputStream(rescaledimage)));
					}

				}
			}

			// If tiny image is not returned based on above, we need to rescale
			// the big image
			// This should not normally happen
			ImageVO imgblob = imagedatadao.getImageBlobDataBasedOnId(pathVariables.get("id"));
			rescaledimage = NewAuthUtils.reScaleImage(imgblob.getImagebytes(), width, height, true);
			System.out.println("Getting rescaled image from big image: " + pathVariables.get("id"));

			if (rescaledimage != null) {
				return ResponseEntity.ok().contentLength(rescaledimage.length)
						.contentType(MediaType.parseMediaType(imageobj.getImagetype()))
						.body(new InputStreamResource(new ByteArrayInputStream(rescaledimage)));
			} else {
				return null;
			}
		} else {
			System.out.println("No id sent in imageicon request");
			return null;
		}
	}

	/*
	 * @RequestMapping(value = "/singleUpload", method = RequestMethod.POST)
	 * public String singleFileUpload(@Valid UploadFileBucket UploadFileBucket,
	 * BindingResult result, ModelMap model) throws IOException {
	 * 
	 * System.out.println("In singleFileUpload() the non-stream version"); long
	 * start = System.currentTimeMillis(); if (result.hasErrors()) {
	 * System.out.println("validation errors"); return "singleFileUploader"; }
	 * else { System.out.println("Fetching file"); MultipartFile multipartFile =
	 * UploadFileBucket.getFile();
	 * 
	 * // Now do something with file...
	 * 
	 * Path p = Paths.get(UploadFileBucket.getFile().getOriginalFilename());
	 * FileCopyUtils.copy(UploadFileBucket.getFile().getBytes(), new File(
	 * UPLOAD_LOCATION + p.getFileName().toString())); String fileName =
	 * multipartFile.getOriginalFilename(); model.addAttribute("fileName",
	 * fileName); System.out.println("Streamed write complete in " +
	 * (System.currentTimeMillis() - start) + "ms . Bytes: " +
	 * multipartFile.getSize()); return "success"; } }
	 */

	@RequestMapping(value = "/singleUpload", method = RequestMethod.POST)
	// public String singleFileUploadStream(@RequestParam("file") MultipartFile
	// uploadedFileRef, ModelMap model) throws IOException {
	public String singleFileUploadStream(@Valid @ModelAttribute UploadFileBucket uploadedFileBucket,
			@ModelAttribute DeviceVO devicevo, BindingResult result, ModelMap model, HttpSession session)
			throws IOException {

		fileValidator.validate(uploadedFileBucket, result);

		SessionDataVO sessiondata = (SessionDataVO) session.getAttribute("session");

		if (sessiondata.getDeviceinfo() == null)
			sessiondata.setDeviceinfo(devicevo);
		else {
			if (sessiondata.getDeviceinfo().getScreenheight() == 0)
				sessiondata.getDeviceinfo().setScreenheight(devicevo.getScreenheight());

			if (sessiondata.getDeviceinfo().getScreenwidth() == 0)
				sessiondata.getDeviceinfo().setScreenwidth(devicevo.getScreenwidth());
		}

		System.out.println("");
		System.out.println("New request ---------------");
		System.out.println("In singleFileUploadStream -- uploading a file");
		if (result.hasErrors()) {
			System.out.println("validation errors in single upload");
			return "singleFileUploader";
		}

		if (uploadedFileBucket.getFile().getInputStream() != null) {
			if (uploadedFileBucket.getFile().getInputStream().markSupported()) {
				uploadedFileBucket.getFile().getInputStream().mark(1);
				final int bytesRead = uploadedFileBucket.getFile().getInputStream().read(new byte[1]);
				uploadedFileBucket.getFile().getInputStream().reset();
				if (bytesRead != -1) {
					processFile(uploadedFileBucket.getFile(), model, session);
				}
			} else { // Mark not supported
				if (uploadedFileBucket.getFile().getInputStream().available() > 0)
					processFile(uploadedFileBucket.getFile(), model, session);
			}
		}

		if (uploadedFileBucket.getUrl() != null && uploadedFileBucket.getUrl().length() > 4) {
			// String[] schemes = {"http","https"};

			if (UrlValidator.getInstance().isValid(uploadedFileBucket.getUrl()))
				processUrl(uploadedFileBucket.getUrl(), model, session);
		}

		return "singleUploadSuccess";

	}

	private void processUrl(String url, ModelMap model, HttpSession session) throws MalformedURLException, IOException {
		long start = System.currentTimeMillis();
		byte[] imageBytes = null;
		URL u = new URL(url);
		InputStream is = null;
		String cassId = "";
		Date imgcreatetime = Calendar.getInstance().getTime();

		try {
			is = u.openStream();
			imageBytes = IOUtils.toByteArray(is);

			// GET Tags from filename
			String[] filesplit = u.toString().split("\\.:_|- ");

			List<String> tags = Arrays.asList(filesplit);

			// cassId = imagedatadao.createImageDataFromBytes(url, imageBytes,
			// tags,(short) 0);

			SimpleImageInfo imageinfo = new SimpleImageInfo(imageBytes);

			if (imageinfo.getWidth() > 1024 * 1.5 || imageinfo.getHeight() > 768 * 1.5) { // this
																							// is
																							// a
																							// big
																							// image
				cassId = imagedatadao.createImageDataFromBytes(url, NewAuthUtils.reScaleImage(imageBytes, "L", true),
						tags, (short) 0, imgcreatetime, true, session);
			}

		} catch (IOException e) {
			System.err.printf("Failed while reading bytes from %s: %s", u.toExternalForm(), e.getMessage());
			e.printStackTrace();
			// Perform any other exception handling that's appropriate.
		} finally {
			if (is != null) {
				is.close();
			}
		}
		System.out.println("Image streamed write complete in " + (System.currentTimeMillis() - start) + "ms . Bytes: "
				+ imageBytes.length);
		model.addAttribute("fileName", url);
		model.addAttribute("imgid", cassId);
	}

	private void processFile(MultipartFile multipartFile, ModelMap model, HttpSession session) throws IOException {
		long start = System.currentTimeMillis();
		// Get name of uploaded file.
		String fileName = multipartFile.getOriginalFilename();

		FileInputStream reader = null;

		int totalBytes = 0;
		String cassId = "";

		try {
			// Create the input stream to uploaded file to read data from it.
			reader = (FileInputStream) multipartFile.getInputStream();

			FileChannel fc = reader.getChannel();

			MappedByteBuffer mbbuffer = fc.map(FileChannel.MapMode.READ_ONLY, 0, fc.size());

			// read data from 'uploadedFileRef'
			/*
			 * byte[] inputdatabytes = new byte [(int) fc.size()];
			 * mbbuffer.get(inputdatabytes,0, (int)fc.size()); totalBytes =
			 * inputdatabytes.length;
			 */

			fc.close();

			// GET Tags from filename
			Path p = Paths.get(fileName);
			String basename = FilenameUtils.getBaseName(p.getFileName().toString());
			String[] filesplit = basename.split("\\.|:|_|-|\\| ");

			List<String> tags = Arrays.asList(filesplit);

			int fullsize = mbbuffer.capacity();
			totalBytes = fullsize;
			
			byte[] smallchunkforsimpleimageinfo = new byte[fullsize];
			mbbuffer.get(smallchunkforsimpleimageinfo, 0, fullsize);

			Date imgcreatetime = Calendar.getInstance().getTime();

			SimpleImageInfo imageinfo = new SimpleImageInfo(smallchunkforsimpleimageinfo);
			String currentimagestandardsize = NewAuthUtils.getImageSize(imageinfo.getWidth(), imageinfo.getHeight());

			SessionDataVO sessiondata = (SessionDataVO) session.getAttribute("session");

			if (imageinfo.getWidth() > sessiondata.getDeviceinfo().getScreenwidth()
					|| imageinfo.getHeight() > sessiondata.getDeviceinfo().getScreenheight()) {
				System.out.println("This is an image larger than the screen size");

				String deviceprofilesize = NewAuthUtils.getImageSize(sessiondata.getDeviceinfo().getScreenwidth(),
						sessiondata.getDeviceinfo().getScreenheight());

				// If deviceprofilesize is greater than S
				if (deviceprofilesize.equals("M") || deviceprofilesize.equals("L") || deviceprofilesize.equals("E")) {
					// SAVE A SIZE ACCORDING TO DEVICE SIZE

					cassId = imagedatadao.createImageDataFromBytes(fileName,
							NewAuthUtils.reScaleImage(smallchunkforsimpleimageinfo, deviceprofilesize, true), tags,
							(short) 0, imgcreatetime, true, session);

				} else { // this is the case where device was small but image was large, we want to save that large image also
					// THIS IS IMAGE ACCORDING TO IMAGE SIZE

					cassId = imagedatadao.createImageDataFromBytes(fileName,
							NewAuthUtils.reScaleImage(smallchunkforsimpleimageinfo, currentimagestandardsize, true),
							tags, (short) 0, imgcreatetime, true, session);					
					
				}
				
				// If the image is not SMALL, save a small size copy also -- do not add a record under user
				if (!currentimagestandardsize.equalsIgnoreCase("S")) {
					cassId = imagedatadao.createImageDataFromBytes(fileName,
							NewAuthUtils.reScaleImage(smallchunkforsimpleimageinfo, "S", true), tags, (short) 0,
							imgcreatetime, false, session);
				}

				// Also save a TINY version copy -- do not add a record under user
				cassId = imagedatadao.createImageDataFromBytes(fileName,
						NewAuthUtils.reScaleImage(smallchunkforsimpleimageinfo, "T", true), tags, (short) 0,
						imgcreatetime, false, session);
			} else {
				System.out.println("This is an image smaller than the screen size");
				cassId = imagedatadao.createImageDataFromBytes(fileName, smallchunkforsimpleimageinfo, tags, (short) 0,
						imgcreatetime, true, session);
				
				// If the image is not already SMALL, save a small size copy also -- do not add a record under user
				if (!currentimagestandardsize.equalsIgnoreCase("S")) {
					cassId = imagedatadao.createImageDataFromBytes(fileName,
							NewAuthUtils.reScaleImage(smallchunkforsimpleimageinfo, "S", true), tags, (short) 0,
							imgcreatetime, false, session);
				}

				// If the image is not already TINY, save a TINY version copy also -- do not add a record under user
				if (!currentimagestandardsize.equalsIgnoreCase("T")) {
					cassId = imagedatadao.createImageDataFromBytes(fileName,
							NewAuthUtils.reScaleImage(smallchunkforsimpleimageinfo, "T", true), tags, (short) 0,
							imgcreatetime, false,session);
				}
			}

			mbbuffer.clear();
		} catch (IOException e) {
			System.out.println("Internal server IO error");
			/// return "Internal server IO error";
		} finally {
			// baos.close();
			if (reader != null)
				reader.close();
			// if (writer != null)
			// writer.close();
		}

		System.out.println("Image streamed write complete in " + (System.currentTimeMillis() - start) + "ms . Bytes: "	+ totalBytes);
		model.addAttribute("fileName", fileName);
		model.addAttribute("imgid", cassId);
	}

	@RequestMapping(value = "/multiUpload", method = RequestMethod.GET)
	public String getMultiUploadPage(ModelMap model) {
		MultiUploadFileBucket filesModel = new MultiUploadFileBucket();
		model.addAttribute("multiUploadFileBucket", filesModel);
		return "multiFileUploader";
	}

	@RequestMapping(value = "/multiUpload", method = RequestMethod.POST)
	public String multiFileUpload(@Valid MultiUploadFileBucket multiUploadFileBucket, BindingResult result,
			ModelMap model) throws IOException {

		if (result.hasErrors()) {
			System.out.println("validation errors in multi upload");
			return "multiFileUploader";
		} else {
			System.out.println("Fetching files");
			List<String> fileNames = new ArrayList<String>();
			// Now do something with file...
			for (UploadFileBucket bucket : multiUploadFileBucket.getFiles()) {
				FileCopyUtils.copy(bucket.getFile().getBytes(),
						new File(UPLOAD_LOCATION + bucket.getFile().getOriginalFilename()));
				fileNames.add(bucket.getFile().getOriginalFilename());
			}

			model.addAttribute("fileNames", fileNames);
			return "multiSuccess";
		}
	}

}