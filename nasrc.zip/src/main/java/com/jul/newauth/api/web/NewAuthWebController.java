package com.jul.newauth.api.web;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.lang.reflect.InvocationTargetException;
import java.math.BigInteger;
import java.net.InetAddress;
import java.net.URLEncoder;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.apache.commons.beanutils.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.datastax.driver.mapping.Result;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.databind.type.TypeFactory;
import com.jul.newauth.dao.CassandraConnector;
import com.jul.newauth.dao.EventDAO;
import com.jul.newauth.dao.ImageDataDAO;
import com.jul.newauth.dao.TransactionDAO;
import com.jul.newauth.dao.UserDAO;
import com.jul.newauth.dao.UserDataDAO;
import com.jul.newauth.model.AuthChallengeVO;
import com.jul.newauth.model.AuthenticationResponseVO;
import com.jul.newauth.model.DeviceVO;
import com.jul.newauth.model.EventTypes;
import com.jul.newauth.model.ImageClickInfoVO;
import com.jul.newauth.model.ImgIDTranslatorVO;
import com.jul.newauth.model.LocalHostVO;
import com.jul.newauth.model.SessionDataVO;
import com.jul.newauth.model.UserDataVO;
import com.jul.newauth.model.UserVO;
import com.jul.newauth.model.cassandra.ks.analytics.NewauthEvent;
import com.jul.newauth.model.cassandra.ks.transactions.HashByIpAndUserAgent;
import com.jul.newauth.model.cassandra.ks.transactions.UserIdByHash;
import com.jul.newauth.model.cassandra.ks.transactions.UserIdsByIP;
import com.jul.newauth.model.cassandra.ks.transactions.UserImageClickMemoryData;
import com.jul.newauth.model.cassandra.ks.users.ImageDataByImageID;
import com.jul.newauth.model.cassandra.ks.users.ImageDataByMetaData;
import com.jul.newauth.model.cassandra.ks.users.ImageDataByUserIDAndSize;
import com.jul.newauth.model.cassandra.ks.users.Phone;
import com.jul.newauth.model.cassandra.ks.users.UsersByUsername;
import com.jul.newauth.util.MedianOfIntegerStream;
import com.jul.newauth.util.NewAuthUtils;


@Controller
@RequestMapping(value = "/newauth")
public class NewAuthWebController {
	
	@Autowired
	CassandraConnector cassconnector;
	
	@Autowired
    TransactionDAO trandao;
	
	@Autowired
    UserDAO userdao;
	
	@Autowired
	ImageDataDAO imagedao;
	
	@Autowired
	UserDataDAO userdatadao;
	
	@Autowired
	EventDAO eventdao;
	
	@Value("${cookiettl}")
	private int cookiettl;
	
	@Value("${initializeImageSetSize}")
	private int initializeImageSetSize;	
	
	@Value("${minnumberofimages}")
	private int minnumberofimages;	
	
	@Value("${maxnumberofimages}")
	private int maxnumberofimages;		
	
	@Value("${clickstoregister}")
	private int clickstoregister;
	
	@Value("${thresholdhashmatchpercent}")
	private int thresholdhashmatchpercent;
	
	@Value("${thresholdauthmatchpercent}")
	private int thresholdauthmatchpercent;
	
	@Value("${reducedSensitivityZone}")
	private boolean reducedSensitivityZone;
	
	
	@Autowired
	private LocalHostVO hostip;
	
	private static ObjectMapper jsonmapper = new ObjectMapper();	 
	private static SecureRandom random = new SecureRandom();
		
	
	 @RequestMapping(value = { "/",  "/welcome" }, method = RequestMethod.GET)
	 public String getHomePage( ModelMap model, HttpServletRequest request, HttpServletResponse response, HttpSession session)  {
		 
		 System.out.println("\nNew Request------------" + NewAuthUtils.getTimeStampString());
		 System.out.println("In gethomepage");
		 
		 SessionDataVO sessiondata = new SessionDataVO();
		 
		 sessiondata.setSessioncreatetime(Calendar.getInstance().getTime());
		 sessiondata.setDeviceinfo(new DeviceVO());

		 session.setAttribute("session", sessiondata); 
		  if (!trandao.createDeviceEntry(request.getRemoteAddr(), session)) { // this will set the IP address from the request
			  model.addAttribute("failureMessage", "Something went wrong. Code 1");
			  return "failure";
		  }
		  
		  sessiondata.getDeviceinfo().setUseragent(request.getHeader("user-agent"));	
		  trandao.createAccessEntries2(sessiondata.getUserid(), sessiondata.getDeviceinfo().getIpaddress(), sessiondata.getDeviceinfo().getUseragent(), sessiondata.getSessioncreatetime(), (short)sessiondata.getAuthscore(), null);
	      
		  String newauthcookie = NewAuthUtils.getNewauthCookie(request);
	      
	      // we want to read this cookie in chunks of 44
		  if (newauthcookie != null) {
			  
			  if (newauthcookie.length()%44 > 0) {
				  System.out.println("Invalid cookie in request");
				  model.addAttribute("failureMessage", "Something went wrong. Code 2");
				  
				  NewauthEvent ev = new NewauthEvent(UUID.randomUUID(), 
							EventTypes.INVALID_COOKIE, 
							Calendar.getInstance().getTime(), 
							sessiondata.getUserid(), //UserID
							sessiondata.getDeviceinfo().getIpaddress(), 
							hostip.getHostip(),
							newauthcookie);

				  eventdao.createEvent(ev);
				  return "failure";
			  }
			  
			  sessiondata.setCookiedata(newauthcookie);
			  
			  if (newauthcookie.length() >= 44) {
				  List<String> usernamelist = new ArrayList<String>();
				  List<String> fullnamelist = new ArrayList<String>();
				  for (int i=0; i<newauthcookie.length()/44; i++) {
					  String acookie = newauthcookie.substring(i*44, (i+1)*44);
					  UserIdByHash user = trandao.getUserBasedonHash(acookie);
				 		
				 		if (user != null) { // Valid hash present
				 			
				 			try {
								usernamelist.add(URLEncoder.encode(acookie, "UTF-8"));
							} catch (UnsupportedEncodingException e) {
								System.out.println("Failed to encode cookie " + acookie);
								NewAuthUtils.removeCookie(sessiondata.getCookiedata(), response, acookie, cookiettl);
								model.addAttribute("failureMessage", "Something went wrong. Code 3");
								return "failure";
							}
				 			fullnamelist.add(user.getFullname());
				 			
				 		} else { // No user info for this hash //// SOMETHING fishy???
				 			NewAuthUtils.removeCookie(sessiondata.getCookiedata(), response, acookie, cookiettl);
				 			// TODO:LOG this IP?
				 			
				 		}
				 		
				  }
				  
				  model.addAttribute("userid", usernamelist);
				  model.addAttribute("fullName", fullnamelist);
			 		
			  }
		 		
			 
		 		
		 	} else { // No hash found on client. may be check based on IP and useragent
		 		// Do not send hashes unless group or indiv device confirmed
		 		
		 		//if (request.getParameter("df564d554ht6ffs54") != null) {
		 			
		 		//} else {
			 		System.out.println(" no newauth cookie in request");
			 		String ipadd = request.getRemoteAddr();
			 		System.out.println("Checking for IP: " + ipadd);
			 		// Storing a blank cookie so we do not go to intro the next time
			 		NewAuthUtils.addCookie(null, response, "", cookiettl * 24 * 30 * 12 * 10);   // this cookie will not expire for 10 years
			 		return "intro";
		 		//}
		 	}
		  
		  	UserVO userModel = new UserVO();
	        //DeviceVO device = new DeviceVO();
	        model.addAttribute("user", userModel);
	        model.addAttribute("device", sessiondata.getDeviceinfo());
		 	return "welcome";
	    }
	 
	 
	 @RequestMapping(value = { "/display/image/{id}/{width}/{height}/{winwidth}/{winheight}" }, method = RequestMethod.GET)
	 public String displayImage( @PathVariable Map<String, String> pathVariables,
			 					ModelMap model, 
			 					HttpServletRequest request, 
			 					HttpServletResponse response)  {
		 
		 System.out.println("\nNew Request------------" + NewAuthUtils.getTimeStampString());
		 System.out.println("In display image");
		 String id = "";
		 
		 if (pathVariables.containsKey("id")) {
			 id = pathVariables.get("id");
			 
			 if (pathVariables.containsKey("winwidth"))
				 model.addAttribute("winwidth", pathVariables.get("winwidth"));
			 if (pathVariables.containsKey("winheight"))
				 model.addAttribute("winheight", pathVariables.get("winheight"));
		 } else {
			 return "welcome";
		 }
				 
		 ImageDataByImageID imginfo = imagedao.getImageDataBasedOnId(id);
		 
		 if (imginfo != null)
		 
	        model.addAttribute("imgid", id);
		 	model.addAttribute("imagewidth", imginfo.getImagewidth());
		 	model.addAttribute("imageheight", imginfo.getImageheight());
		 	
		 	System.out.println("winwidth: " + pathVariables.get("winwidth") + 
		 						" winheight: " + pathVariables.get("winheight") + 
		 						" imgwidth: " + imginfo.getImagewidth() + 
		 						" imgheight: " + imginfo.getImageheight());
		 						
	        
		 	return "displayImage";
	    }
	 
	 
	 @RequestMapping(value = { "/setimgpwd/{width}/{height}/{winwidth}/{winheight}/{id}" }, method = RequestMethod.GET)
	 public String setImagePassword( @PathVariable Map<String, String> pathVariables,
			 					ModelMap model, 
			 					HttpServletRequest request, 
			 					HttpServletResponse response,
			 					HttpSession session)  {
		 
			 System.out.println("\nNew Request------------" + NewAuthUtils.getTimeStampString());
			 System.out.println("In setimgpwd");
			 
			 if (pathVariables.containsKey("winwidth")) {
				 
				 if (pathVariables.containsKey("winwidth"))
					 model.addAttribute("winwidth", pathVariables.get("winwidth"));
				 if (pathVariables.containsKey("winheight"))
					 model.addAttribute("winheight", pathVariables.get("winheight"));
			 } else {
				 return "welcome";
			 }
			 
			 SessionDataVO sessiondata = (SessionDataVO) session.getAttribute("session");
			
			 if (sessiondata != null && sessiondata.getDeviceinfo() != null) {
				 List<ImgIDTranslatorVO> listofimages = imagedao.getUserImagesForPwdSet(sessiondata.getUserid(), sessiondata.getDeviceinfo().getScreenwidth(), sessiondata.getDeviceinfo().getScreenheight());
				 
				 model.addAttribute("imageIds", listofimages);		
				 
				 ImageDataByImageID imginfo = null;
				 String inputimgID = null;
				 
				 if (pathVariables.containsKey("id")) {
					 
					inputimgID = pathVariables.get("id");
					imginfo = imagedao.getImageDataBasedOnId(inputimgID);
					
					int clickcount =  listofimages.stream()
			                  			.filter(img -> img.getNormalID().equals(pathVariables.get("id")))
			                  			.findFirst()
			                  			.get()
			                  			.getMatchingClickCount();
					
					model.addAttribute("confirmedclicks", clickcount);
					
					if (clickcount > 2) {
						
						float normalx = listofimages.stream()
	                  			.filter(img -> img.getNormalID().equals(pathVariables.get("id")))
	                  			.findFirst()
	                  			.get()
	                  			.getNormalclickx();
						
						float normalwidth = listofimages.stream()
	                  			.filter(img -> img.getNormalID().equals(pathVariables.get("id")))
	                  			.findFirst()
	                  			.get()
	                  			.getNormalwidth();
						
						float normaly = listofimages.stream()
	                  			.filter(img -> img.getNormalID().equals(pathVariables.get("id")))
	                  			.findFirst()
	                  			.get()
	                  			.getNormalclicky();
						
						float normalheight = listofimages.stream()
	                  			.filter(img -> img.getNormalID().equals(pathVariables.get("id")))
	                  			.findFirst()
	                  			.get()
	                  			.getNormalheight();
						
						model.addAttribute("clickxlocation", normalx/normalwidth);
						model.addAttribute("clickylocation", normaly/normalheight);
					}
					
				 } else {
					 inputimgID = listofimages.get(0).getNormalID();
					 imginfo = imagedao.getImageDataBasedOnId(listofimages.get(0).getNormalID());
				 }
		
				 if (imginfo != null) {
				 
			        model.addAttribute("imgid", inputimgID);
				 	model.addAttribute("imagewidth", imginfo.getImagewidth());
				 	model.addAttribute("imageheight", imginfo.getImageheight());
				 }
				 	
				 String clientscreensize = NewAuthUtils.getScreenSize(sessiondata.getDeviceinfo().getScreenwidth(), sessiondata.getDeviceinfo().getScreenheight());
				 if (clientscreensize.equals("S") || clientscreensize.equals("T")) {
					 return "setImagePwd_mobile";
				 } else {
					 return "setImagePwd";
				 }
			 }
		 
		 return "welcome";
	    }
	 
	 
	 @RequestMapping(value = {"/authenticate/{hash}", "/authenticate/{hash}/{width}",
			 					"/authenticate/{hash}/{width}/{height}", "/authenticate/{hash}/{width}/{height}/{winwidth}", 
			 					"/authenticate/{hash}/{width}/{height}/{winwidth}/{winheight}"}, method = RequestMethod.GET)
	 public String authenticateByUserHash(@PathVariable Map<String, String> pathVariables,
			 												@ModelAttribute DeviceVO devicevo,
												    		ModelMap model, 
															HttpServletResponse response,
															HttpServletRequest request,
															HttpSession session) {
		 String useridhash = "";
		 
		 if (pathVariables.containsKey("hash")) {
			 useridhash = pathVariables.get("hash");
			 
			 if (pathVariables.containsKey("width"))
				 devicevo.setScreenwidth(Integer.parseInt(pathVariables.get("width")));
			 if (pathVariables.containsKey("height"))
				 devicevo.setScreenheight(Integer.parseInt(pathVariables.get("height")));
			 
			 if (pathVariables.containsKey("winwidth"))
				 devicevo.setWindowwidth(Integer.parseInt(pathVariables.get("winwidth")));
			 if (pathVariables.containsKey("winheight"))
				 devicevo.setWindowheight(Integer.parseInt(pathVariables.get("winheight")));
		 }
			 
		useridhash.replaceAll("_", "/"); /// While generating hash, we replaced '/' with '_' ... doing the reverse
		System.out.println("\nNew Request------------" + NewAuthUtils.getTimeStampString());
		
				 
		SessionDataVO sessiondata = (SessionDataVO) session.getAttribute("session");
		
		if (sessiondata == null) {
			System.out.println("No session data. Forwarding to home.");
			return "welcome";
		 }
		
		
		 System.out.println("In authenticate by Userhash. Userhash passed " + useridhash);
		 if (devicevo.getUseragent() == null) {
			 devicevo.setUseragent(sessiondata.getDeviceinfo().getUseragent());
		 }
		 
		 if (devicevo.getIpaddress() == null) {
			 devicevo.setIpaddress(sessiondata.getDeviceinfo().getIpaddress());
		 }
		 sessiondata.setDeviceinfo(devicevo);
		 
		 sessiondata.setAccessidtype("U"); // access by username
		 UserIdByHash user = userdao.findUserByHash(useridhash);
		 
		 if (user.getFullname() != null) {
			 sessiondata.setUserid(user.getUserid());
			 sessiondata.setUserinfo((sessiondata.getUserinfo()== null)? new UserVO():sessiondata.getUserinfo());
			 
			 if (sessiondata.getUserinfo().getUsername() == null)
				 sessiondata.getUserinfo().setUsername(user.getUsername());
			 
			 trandao.createAccessEntries2(sessiondata.getUserid(), sessiondata.getDeviceinfo().getIpaddress(), sessiondata.getDeviceinfo().getUseragent(), sessiondata.getSessioncreatetime(), (short)sessiondata.getAuthscore(), session.getId());
				
			 int finalizeduserimages = trandao.getFinalizedUserImageCount(user.getUserid());
			 
			 if (finalizeduserimages < minnumberofimages) {
				 
				 model.addAttribute("finalizeduserimagecount", finalizeduserimages);
				 
				 UsersByUsername userbyname = new UsersByUsername();
				 try {
					BeanUtils.copyProperties(userbyname, user);
				} catch (IllegalAccessException | InvocationTargetException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				 return forwardtoSetupUser(userbyname, devicevo, model, session);
			 } else { // got enough image records with -ve clickx and clicky
			 
			 /// DO authentication stuff
			// sessiondata.setUserauthenticated(uservo.getUsername());
				 return forwardtoAuthenticateUser(user.getUserid(), devicevo, model, session);
			 }
			 
		 } else {
			 // There is no such user 
			 System.out.println("No such user was found. returning to homepage. Something weird because a hash was sent.");
			 trandao.createAccessEntries2(sessiondata.getUserid(), sessiondata.getDeviceinfo().getIpaddress(), sessiondata.getDeviceinfo().getUseragent(), sessiondata.getSessioncreatetime(), (short)sessiondata.getAuthscore(), null);
			 UserVO userModel = new UserVO();
	         //DeviceVO device = new DeviceVO();
	         model.addAttribute("user", userModel);
	         model.addAttribute("device", sessiondata.getDeviceinfo());
		 	 return "welcome";
			 
		 }		
		
	 }
 
	 
	 @RequestMapping(value = "/authenticate", method = RequestMethod.POST)
	 public String authenticateByFormSubmit(@Valid @ModelAttribute UserVO uservo,
			 									@ModelAttribute DeviceVO devicevo,
												BindingResult result, 
												ModelMap model, 
												HttpServletResponse response,
												HttpServletRequest request,
												HttpSession session) throws IOException {
		 
		 System.out.println("\nNew Request------------" + NewAuthUtils.getTimeStampString() + NewAuthUtils.getTimeStampString());
		 
		 System.out.println("In authenticate by form submit. Username passed " + uservo.getUsername());
		 SessionDataVO sessiondata = (SessionDataVO) session.getAttribute("session");
		 
		 if (sessiondata == null || sessiondata.getDeviceinfo() == null) {
			System.out.println("No session data. Forwarding to home.");
			return "welcome";
		 }
			
		 if (devicevo.getUseragent() == null) {
			 devicevo.setUseragent(sessiondata.getDeviceinfo().getUseragent());
		 }
		 
		 if (devicevo.getIpaddress() == null) {
			 devicevo.setIpaddress(sessiondata.getDeviceinfo().getIpaddress());
		 }
		 
		 sessiondata.setDeviceinfo(devicevo);
		 
		
		 if (uservo.getUsername() == null || uservo.getUsername().length() == 0) { // No username, send back to home
			 UserVO userModel = new UserVO();
		     //DeviceVO device = new DeviceVO();
		     model.addAttribute("user", userModel);
		     model.addAttribute("device", sessiondata.getDeviceinfo());
			 return "welcome";
		 } else {
			 sessiondata.setUserinfo(uservo);
		 }
		 
		 sessiondata.setAccessidtype("U"); // access by username
		//is this a valid username?
		 UsersByUsername userbyname = userdao.findUserByUsername(uservo.getUsername());
		 
		 if (userbyname != null) {
			 System.out.println("This is a valid username. Determine how complex an authentication challenge to throw");
			 sessiondata.setUserid(userbyname.getUserid());
			 
			 if (sessiondata.getUserinfo().getFirstname() == null || sessiondata.getUserinfo().getFirstname().length() == 0) {
				// populate user data in session... will be used to set hash in case of successful authentication
				 sessiondata.getUserinfo().setFirstname(userbyname.getFirstname());
				 sessiondata.getUserinfo().setLastname(userbyname.getLastname());
				 sessiondata.getUserinfo().setMiddleinitial(userbyname.getMiddleinitial());
			 }
			 trandao.createAccessEntries2(sessiondata.getUserid(), sessiondata.getDeviceinfo().getIpaddress(), sessiondata.getDeviceinfo().getUseragent(), sessiondata.getSessioncreatetime(), (short)sessiondata.getAuthscore(), null);
		     
			 // Now, get the user through ip , useragent combination
			 HashByIpAndUserAgent hash = trandao.getUserBasedonIpAndUserAgentAndUserName(InetAddress.getByName(request.getRemoteAddr()), sessiondata.getDeviceinfo().getUseragent(), uservo.getUsername());
			 
			 if (hash == null) {
				 System.out.println("This user is not connecting from a known device on a known network");
				 //up the risklevel
				 sessiondata.setRisk(sessiondata.getRisk() + 10);
				 
				 // Now see if the user has logged in from this network before may be from a different device
				 Result<UserIdsByIP> records = trandao.getUserBasedonIpAndUserID(InetAddress.getByName(request.getRemoteAddr()), sessiondata.getUserid());
				 
				 if (records != null) {
					// Generate a hash for this device, username, ip,useragent combination
					UserIdsByIP objuserid = records.one();
					 
					if (objuserid != null) {
						 UserIdByHash hashentry = new UserIdByHash(objuserid.getUserid(), 
			 						//InetAddress.getByAddress(ipaddressbytes), 
			 						sessiondata.getDeviceinfo().getIpaddress(),
			 						null, 
			 						userbyname.getUsername(),
			 						userbyname.getFirstname() + " " + userbyname.getMiddleinitial() + " " + userbyname.getLastname(),
			 						true, 
			 						false,
			 						sessiondata.getDeviceinfo().getScreenheight(), 
			 						sessiondata.getDeviceinfo().getScreenwidth(),
			 						sessiondata.getDeviceinfo().getUseragent(),
			 						null,
			 						null,
			 						null);
		
						 String newhash = trandao.createHashEntries(hashentry);
		
						 NewAuthUtils.addCookie(sessiondata.getCookiedata(), response, newhash, cookiettl);
					}
				 } else {
					 // A totally new network for this username. Up the risk
					 sessiondata.setRisk(sessiondata.getRisk() + 30);
				 }
				 
				 model.addAttribute("user", new UserVO());
		         model.addAttribute("device", sessiondata.getDeviceinfo());
				 
			 } else {
				 // Hash found for this ip, device and username
				 // check if the device is init
				 if (hash.isInitdevice()) {
					 sessiondata.setRisk(sessiondata.getRisk() - 5);
				 }
				 // The user had come in through form submit... add hash through cookie if it is not set already
				 NewAuthUtils.addCookie(NewAuthUtils.getNewauthCookie(request), response, hash.getUseridhash(), cookiettl);
			 }
		 } else {
			 // There is no such user 
			 UserVO userModel = new UserVO();
			 trandao.createAccessEntries2(new UUID(0L, 0L), sessiondata.getDeviceinfo().getIpaddress(), sessiondata.getDeviceinfo().getUseragent(), sessiondata.getSessioncreatetime(), (short)sessiondata.getAuthscore(), null);
			 
			 // Create event because it may be a fishing attempt
			 
			 NewauthEvent ev = new NewauthEvent(UUID.randomUUID(), 
						EventTypes.USER_FISHING, 
						Calendar.getInstance().getTime(), 
						new UUID(0L, 0L), //UserID
						sessiondata.getDeviceinfo().getIpaddress(), 
						hostip.getHostip(),
						NewAuthUtils.toStringForPrint(uservo)); 

			 eventdao.createEvent(ev);
		     
	         //DeviceVO device = new DeviceVO();
	         model.addAttribute("user", userModel);
	         model.addAttribute("device", sessiondata.getDeviceinfo());
	         
	         sessiondata.setUserid(new UUID(0L, 0L));;
	         /// We will send fake images in this case, we want to avoid an indicator for no user found case 
	         // return "welcome";
	         return forwardtoAuthenticateUser(sessiondata.getUserid(), devicevo, model, session);
			 
		 }		 
		  
		 // Check if there is enough image data to authenticate this user
		 
		 int finalizeduserimages = trandao.getFinalizedUserImageCount(userbyname.getUserid());
		 
		 if (finalizeduserimages < minnumberofimages) {
			 
			 model.addAttribute("finalizeduserimagecount", finalizeduserimages);
			 
			 return forwardtoSetupUser(userbyname, devicevo, model, session);
		 } else { // got enough image records with -ve clickx and clicky
		 
		 /// DO authentication stuff
			 sessiondata.getUserimageseqnumbers().clear(); // remove seq numbers from other attempts if
			 return forwardtoAuthenticateUser(userbyname.getUserid(), devicevo, model, session);
		 }
		 
				 
		 
	 }
	 
	 private String forwardtoAuthenticateUser(UUID userid, DeviceVO devicevo, ModelMap model, HttpSession session) {
		 
		 SessionDataVO sessiondata = (SessionDataVO) session.getAttribute("session");
		 
		 model.addAttribute("device", sessiondata.getDeviceinfo());
		// String screensize = NewAuthUtils.getImageSize(sessiondata.getDeviceinfo().getScreenwidth(),sessiondata.getDeviceinfo().getScreenheight());
		 
		
		 int initialImageSetSize = NewAuthUtils.getInitialImageSetSize(sessiondata.getUserinfo(), sessiondata.getRisk());
		 
		 List<ImgIDTranslatorVO> listofimages = null;
		 
		 
		 if (!userid.equals(new UUID(0L, 0L))) {
			 listofimages = imagedao.selectRandomImagesForUserAuth(userid.toString(), sessiondata.getDeviceinfo().getScreenwidth(), 
				 												sessiondata.getDeviceinfo().getScreenheight(), initialImageSetSize, session);
		 } else {
			 listofimages = imagedao.assignRandomImagesForFakeAuth(sessiondata.getDeviceinfo().getScreenwidth(), 
														sessiondata.getDeviceinfo().getScreenheight(), initialImageSetSize, session);
		 }
	
		 		
		 if (listofimages != null 
				 	//&& listofimages.size() == initialImageSetSize
				 ) {
			 			
			 model.addAttribute("imageIds", listofimages);
			 
			 model.addAttribute("authResponseForm", new AuthenticationResponseVO());
			 
			 AuthChallengeVO acv = new AuthChallengeVO();
			 acv.setSessionid(UUID.randomUUID());
			 acv.setUserid(sessiondata.getUserid());
			 acv.setTs(Calendar.getInstance().getTime());
			 
			 List<Integer> widths = new ArrayList<Integer>();
			 List<Integer> heights = new ArrayList<Integer>();
			int counter = 0;
			
			 for (ImgIDTranslatorVO img: listofimages) {
				 acv.getImages().add(img.getNormalID());
				 
				 // Swap imageIDs for temp ones
				 // IF it is not already a temp one :)
				 
				 if (NewAuthUtils.getRealIDForTempImgID(img.getNormalID(), sessiondata) == null)
					 img.setNormalID(NewAuthUtils.getTempImgIDForRealID(img.getNormalID(), sessiondata));
				 
				 // Also set height and width for client view
				 widths.add( img.getNormalwidth());	
				 heights.add(img.getNormalheight());
				 
				 float imgar = (float)img.getNormalwidth()/img.getNormalheight();
				 float windowar = (float) sessiondata.getDeviceinfo().getWindowwidth()/sessiondata.getDeviceinfo().getWindowheight();
					 
				 if (windowar <= imgar)  {
					 
					 if (sessiondata.getDeviceinfo().getWindowwidth() < img.getNormalwidth()) {
						 double maxwidth = sessiondata.getDeviceinfo().getWindowwidth() * 0.9;
						 widths.set(counter, (int) maxwidth);
					 	 heights.set(counter, new Float(widths.get(counter)/imgar).intValue());
					 }
				 } else {
					 
					 if (sessiondata.getDeviceinfo().getWindowheight() < img.getNormalheight()) {
						 double maxheight = sessiondata.getDeviceinfo().getWindowheight() * 0.85;
						 heights.set(counter, (int) maxheight);
						 widths.set(counter, new Float(heights.get(counter)*imgar).intValue());
					 }
					 
				 }
				 counter++;
			 }
			 
			 model.addAttribute("imgwidths", widths);
			 model.addAttribute("imgheights", heights);
			 
			 System.out.println("Widths: " + widths  + " heights: " + heights );
			 
			 NewauthEvent ev = new NewauthEvent(UUID.randomUUID(), 
						EventTypes.AUTH_CHALLENGE_SENT, 
						Calendar.getInstance().getTime(), 
						sessiondata.getUserid(), //UserID
						sessiondata.getDeviceinfo().getIpaddress(), 
						hostip.getHostip(),
						NewAuthUtils.toStringForPrint(acv)); 
	
			 if (!userid.equals(new UUID(0L, 0L))) {
				 eventdao.createEvent(ev);
			 }
			 
			// save this list in session - this is to prevent a user from trying to guess the picture without submitting a response
			// once a selection is done, we will remove this entry
			sessiondata.getCurrentimagesforuser().put(sessiondata.getUserinfo().getUsername(), listofimages);	
				
			 
			 model.addAttribute("authMessage", "Images seem unfamiliar? Please check the username...");
			 return "doAuthenticate";
		 } else {
			 return "error";
		 }
	}


	@RequestMapping(value = { "/setupUser" }, method = RequestMethod.GET)
	 public String setupUser(
				ModelMap model, 
				HttpServletRequest request, 
				HttpServletResponse response,
				HttpSession session) {
		 
		 System.out.println("\nNew Request------------ \nIn setupUser. "  + NewAuthUtils.getTimeStampString());
		 String username = "";		 
		 
		 SessionDataVO sessiondata = (SessionDataVO) session.getAttribute("session");
		 
		 if (sessiondata == null) {
			System.out.println("No session data. Forwarding to home.");
			return "welcome";
		 } else {
			 if (sessiondata.getUserinfo() == null || sessiondata.getUserinfo().getUsername() == null ) {
				 System.out.println("No userinfo found in session data. Forwarding to home.");
				 model.addAttribute("user", new UserVO());
			     model.addAttribute("device", new DeviceVO());
			     return "welcome";
			 }
			 
			 username = sessiondata.getUserinfo().getUsername();
		 }		 
		 
		 System.out.println("Username found " + username);	
		 
		 UsersByUsername userbyname = userdao.findUserByUsername(username);
		 
		 if (userbyname != null) { // TODO: We will later need to ensure authentication before returning this page
			 						
			 System.out.println("This is a valid username. Allow setup... Have we checked authentication????");
			 sessiondata.setUserid(userbyname.getUserid());
			 
			 
			 return forwardtoSetupUser(userbyname, sessiondata.getDeviceinfo(), model, session);
		 } else {
			// There is no such user 
			 UserVO userModel = new UserVO();
			 trandao.createAccessEntries2(new UUID(0L, 0L), sessiondata.getDeviceinfo().getIpaddress(), sessiondata.getDeviceinfo().getUseragent(), sessiondata.getSessioncreatetime(), (short)sessiondata.getAuthscore(), null);
		     
	         //DeviceVO device = new DeviceVO();
	         model.addAttribute("user", userModel);
	         model.addAttribute("device", sessiondata.getDeviceinfo());
		 	 return "welcome";
		 }
	 }
	
	
	@RequestMapping(value = { "/securePage" }, method = RequestMethod.GET)
	 public String showSecurePage(
				ModelMap model, 
				HttpServletRequest request, 
				HttpServletResponse response,
				HttpSession session) {
		 
		 System.out.println("\nNew Request------------ \nIn showSecurePage. "  + NewAuthUtils.getTimeStampString());
		 String username = "";		 
		 
		 SessionDataVO sessiondata = (SessionDataVO) session.getAttribute("session");
		 
		 if (sessiondata == null) {
			System.out.println("No session data. Forwarding to home.");
			model.addAttribute("user", new UserVO());
		     model.addAttribute("device", new DeviceVO());
			return "welcome";
		 } else {
			 if (sessiondata.getUserinfo() == null || sessiondata.getUserinfo().getUsername() == null ) {
				 System.out.println("No userinfo found in session data. Forwarding to home.");
				 model.addAttribute("user", new UserVO());
			     model.addAttribute("device", new DeviceVO());
			     return "welcome";
			 }
			 
			 username = sessiondata.getUserinfo().getUsername();
		 }
		 
		 if (sessiondata.getAccessidtype().equals("U")) { // this use authenticated by passing username
			 if (sessiondata.getAuthscore() > thresholdauthmatchpercent) {
				 return forwardtoSecurePage( sessiondata.getDeviceinfo(), model, session);
			 }
		 }
		 
		 model.addAttribute("user", sessiondata.getUserinfo());
	     model.addAttribute("device", sessiondata.getDeviceinfo());
	     
		return "welcome";
	 }
	 
	 private String forwardtoSecurePage(DeviceVO deviceinfo, ModelMap model, HttpSession session) {
		
		 SessionDataVO sessiondata = (SessionDataVO) session.getAttribute("session");
		 
		 String fullname = ((sessiondata.getUserinfo().getFirstname()!= null)?sessiondata.getUserinfo().getFirstname():"") + " " 
		 			+ ((sessiondata.getUserinfo().getMiddleinitial() != null)?sessiondata.getUserinfo().getMiddleinitial()+ ". ":"")  + 
		 			sessiondata.getUserinfo().getLastname() ;

		 model.addAttribute("fullName", fullname);
		 
		 List<UserDataVO> udlist = userdatadao.findUserDataByUserid(sessiondata.getUserauthenticated());
		 
		 List<String> jsonrep = new ArrayList<String>();
		 
		 for (UserDataVO onedata: udlist) {
			 onedata.setUserid(null);
			 byte[] salt = new byte[16];
			 random.nextBytes(salt);
			 onedata.setSalt(salt.toString());
			 onedata.setIterations(random.nextInt(10000 - 1000 + 1) + 1000);
			 try {	
				 ObjectMapper mapper = new ObjectMapper().enable(SerializationFeature.WRITE_SINGLE_ELEM_ARRAYS_UNWRAPPED);
				 
				 jsonrep.add(mapper.writeValueAsString(onedata).replace("\\", "\\\\"));
				 
				} catch (IOException e) {
					System.out.println("INFO: IOException while converting userdatavo to json");
					System.out.println("INFO: vo: "+ onedata);
				}	
		 }
		 
		System.out.println(jsonrep);
		model.addAttribute("userdatalist", jsonrep );
		
		UserDataVO blankudata = new UserDataVO();
		byte[] salt = new byte[16];
		random.nextBytes(salt);
		blankudata.setSalt(salt.toString());
		blankudata.setIterations(random.nextInt(10000 - 1000 + 1) + 1000);
		model.addAttribute("userdata", blankudata);
		return "securePage";
	}


	private String forwardtoSetupUser(UsersByUsername userbyname, DeviceVO devicevo, ModelMap model, HttpSession session) {
		 SessionDataVO sessiondata = (SessionDataVO) session.getAttribute("session");
		 
		 model.addAttribute("minnumberofimages", minnumberofimages);		 
		model.addAttribute("maxnumberofimages", maxnumberofimages);
		 
		int finalizeduserimages = 0;		 
		 
		 model.addAttribute("userName", userbyname.getUsername());
		 
		 if (!model.containsAttribute("finalizeduserimagecount")) {
			 finalizeduserimages = trandao.getFinalizedUserImageCount(userbyname.getUserid());
			 model.addAttribute("finalizeduserimagecount", finalizeduserimages);
		 } else {
			 finalizeduserimages = (int) model.get("finalizeduserimagecount");
		 }
		 
		 BigInteger minpwds = new BigInteger("0");
		 BigInteger maxpwds = new BigInteger("0");
		 BigInteger usrpwds = new BigInteger("0");
		 
		 for (int i=3; i<7; i++) {
			 minpwds = minpwds.add(NewAuthUtils.getpermutations(minnumberofimages, i));
			 maxpwds = maxpwds.add(NewAuthUtils.getpermutations(maxnumberofimages, i));
			 
			 if (finalizeduserimages > 6)
				 usrpwds = usrpwds.add(NewAuthUtils.getpermutations(finalizeduserimages, i));
		 }
		 		 
		 model.addAttribute("minpwds", minpwds);
		 model.addAttribute("maxpwds", maxpwds);
		 model.addAttribute("usrpwds", usrpwds);
		
		 String fullname = ((userbyname.getFirstname()!= null)?userbyname.getFirstname():"") + " " 
				 			+ ((userbyname.getMiddleinitial() != null)?userbyname.getMiddleinitial()+ ". ":"")  + 
				 			userbyname.getLastname() ;
		 
		 model.addAttribute("fullName", fullname);
		 
		 if (userbyname.getPhones() != null && userbyname.getPhones().size() > 0) {
			 String sphones = "";
			 
			 for (Phone ph: userbyname.getPhones()) {
				 sphones += ph.getNumber() + ",";
			 }
		 
			 model.addAttribute("phones", sphones.substring(0, sphones.length()-1));
		 }
		 
		 if (userbyname.getEmails() != null && userbyname.getEmails().size() > 0 ) {
			 
			 System.out.println("Email addresses found...");
			 String semails = "";
			 
			 for (String em: userbyname.getEmails()) {
				 semails += em + ",";
			 }
		 
			 model.addAttribute("emails", semails.substring(0, semails.length()-1));
		 }
	    		 
		 model.addAttribute("device", sessiondata.getDeviceinfo());
		 String screensize = NewAuthUtils.getImageSize(sessiondata.getDeviceinfo().getScreenwidth(),sessiondata.getDeviceinfo().getScreenheight());
		 
		 ImageDataByUserIDAndSize userimages = new ImageDataByUserIDAndSize();
		 userimages.setSize(screensize);
		 userimages.setUserid(userbyname.getUserid());
			
		 Result<ImageDataByUserIDAndSize> userresults = userimages.getImagesByUserAndSize(cassconnector.getSession(), userbyname.getUserid(), screensize);
		 List<ImgIDTranslatorVO> listofimages = new ArrayList<ImgIDTranslatorVO>();
		 
		 for (ImageDataByUserIDAndSize imgbyseq: userresults) {
			 
			 ImageDataByMetaData imgmeta = new ImageDataByMetaData();
			 imgmeta.setImageseq(imgbyseq.getGlobalSequence());
			ImgIDTranslatorVO translator = new ImgIDTranslatorVO();
			translator.setNormalID(imgbyseq.getImageid().toString());
			
			ImageDataByMetaData tinyimg = imagedao.getTinyImageCopyOfAnImage(imgmeta);
			
			if (!imgbyseq.getSize().equals(screensize)) {
				ImageDataByMetaData realimgfordevice = tinyimg.getAnotherImageByTinyImage(cassconnector.getSession(), tinyimg, screensize);
				if (realimgfordevice != null)
					translator.setNormalID(realimgfordevice.getImageid().toString());
			}
			
			if (tinyimg != null) {
				translator.setTinyID(tinyimg.getImageid().toString());
				
				UserImageClickMemoryData clkdata = trandao.getClickDataBasedonUserAndImage(userbyname.getUserid(), imgbyseq.getGlobalSequence() );
				
				if (clkdata != null && clkdata.getDelayhistory().size() > clickstoregister) {
					translator.setNormalclickx(clkdata.getClickx());
					translator.setNormalclicky(clkdata.getClicky());
					translator.setNormalwidth(imgbyseq.getImagewidth());
					translator.setNormalheight(imgbyseq.getImageheight());
				}
				listofimages.add(translator);
			}
		 }
			
		 model.addAttribute("imageIds", listofimages);
		 
		 return "setupUser";
	 
	}


	@RequestMapping(value = { "/postRegisterClickData" }, method = RequestMethod.POST)
	 @ResponseStatus(value = HttpStatus.OK) // adding this because nothing is being returned
	 public void processImageClickForRegister( @RequestBody ImageClickInfoVO clickinfo,
			 					ModelMap model, HttpSession session)  {
		 
		 System.out.println("\nNew Request------------" + NewAuthUtils.getTimeStampString());
		 System.out.println("In process image click for register");
		 SessionDataVO sessiondata = (SessionDataVO) session.getAttribute("session");

		 if (sessiondata.getUserid() == null) {
			// return "error";
			 System.out.println("Session did not have a userID. Looks like a stale session. Discard.");
			 return;
		 }
		 
		 
		
		 clickinfo.setUserID(sessiondata.getUserid().toString());
		 System.out.println(clickinfo.toString());
		 Date currenttime =  Calendar.getInstance().getTime();
		 
		 String progressivehash = NewAuthUtils.generateProgressiveHashFromClickData(clickinfo);
		 
		 int imageglobalseq = trandao.getGlobalSeqForImage(UUID.fromString(clickinfo.getImgID()));
		 
		 UserImageClickMemoryData existingrecord = trandao.getClickDataBasedonUserAndImage(UUID.fromString(clickinfo.getUserID()), imageglobalseq);
		 UserImageClickMemoryData clickdata = null;
		 
		  
		 if (existingrecord == null) {
			 
			 List<Integer> delayhist = new ArrayList<Integer>();
			 delayhist.add(Integer.parseInt(clickinfo.getDelay()));
			 
			 List<String> hashhist = new ArrayList<String>();
			 hashhist.add(progressivehash);
			 
			 System.out.println("Generated progressive hash from click: " + progressivehash);
			 
			 clickdata = new UserImageClickMemoryData(UUID.fromString(clickinfo.getImgID()), 
					 UUID.fromString(clickinfo.getUserID()), 
					 imageglobalseq,
					 Integer.parseInt(clickinfo.getClickX()),//clickx, 
					 Integer.parseInt(clickinfo.getClickY()), //clicky, 
					 Integer.parseInt(clickinfo.getImgWidth()),//width, 
					 Integer.parseInt(clickinfo.getImgHeight()), //height, 
					 null,//locationhash
					 progressivehash,					
					 Integer.parseInt(clickinfo.getDelay()), //delay
					 currenttime, //recordcreatedate
					 currenttime, //lastupdatedate
					 delayhist, // delayhistory
					 hashhist,
					 Integer.parseInt(clickinfo.getDelay()), //avgdelay
					 Integer.parseInt(clickinfo.getDelay()), //mindelay
					 Integer.parseInt(clickinfo.getDelay()), //maxdelay
					 Integer.parseInt(clickinfo.getDelay()), //meddelay
					 0,
					 0
					 );			 
			 
		 } else {
			 			
			 int matchpct = NewAuthUtils.computeProgressiveHashMatch(progressivehash, existingrecord.getProgressivehash());
			 
			 System.out.println("Generated p hash from click: " + progressivehash + " stored: " + existingrecord.getProgressivehash() + " match : " + matchpct + " old location: " + existingrecord.getClickx() + "-" + existingrecord.getClicky());
			 
			 if (matchpct > thresholdhashmatchpercent) { // Add to delayhist and keep the old clickx and clicky
				 
				 System.out.println("Closely matches last click: " + matchpct + "pc. Adding to existing record");
				 
				 List<Integer> delayhist = existingrecord.getDelayhistory();
				 
				 if (delayhist.size() > 100)
					 delayhist = delayhist.subList(delayhist.size()-100, delayhist.size());
				 
				 List<String> hashhist = existingrecord.getPhashhistory();
				 
				 if (hashhist.size() > 100)
					 hashhist = hashhist.subList(hashhist.size()-100, hashhist.size());
				 
				 int oldavgdelay = (int) delayhist.stream().mapToInt(i -> i).average().orElse(0);
				 int oldmindelay = (int) delayhist.stream().mapToInt(i -> i).min().orElse(0);
				 int oldmaxdelay = (int) delayhist.stream().mapToInt(i -> i).max().orElse(0); 
				 
				 
				 MedianOfIntegerStream medcalc = new MedianOfIntegerStream();
				 for (int p: delayhist) {
					 medcalc.addNumberToStream(p);
				 }
				
				 int oldmeddelay = medcalc.getMedian().intValue();
				 
				 delayhist.add(Integer.parseInt(clickinfo.getDelay()));
				 
				 medcalc.addNumberToStream(Integer.parseInt(clickinfo.getDelay()));
				 
				 hashhist.add(progressivehash);
				 
				 int avgdelay = (int) delayhist.stream().mapToInt(i -> i).average().orElse(0);
				 int mindelay = (int) delayhist.stream().mapToInt(i -> i).min().orElse(0);
				 int maxdelay = (int) delayhist.stream().mapToInt(i -> i).max().orElse(0);
				 int meddelay = medcalc.getMedian().intValue();
				 
				 clickdata = new UserImageClickMemoryData(existingrecord.getImageid(), 
						 existingrecord.getUserid(), 
						 imageglobalseq,
						 existingrecord.getClickx(),//clickx, 
						 existingrecord.getClicky(), //clicky, 
						 existingrecord.getImgwidth(),//width, 
						 existingrecord.getImgheight(), //height, 
						 null,//locationhash
						 existingrecord.getProgressivehash(),
						 Integer.parseInt(clickinfo.getDelay()), //delay
						 existingrecord.getRecordcreatedate(), //recordcreatedate
						 currenttime, //lastupdatedate
						 delayhist, //, delayhistory
						 hashhist,
						 avgdelay,
						 mindelay,
						 maxdelay,
						 meddelay,
						 existingrecord.getSuccesscount()+1,
						 existingrecord.getFailurecount()
						 );	
			 } else { // Update the click data with new clickx and clicky
				 System.out.println("Did not match last click: " + matchpct + "pc. Will use this click data next time");
				 
				 List<Integer> delayhist = new ArrayList<Integer>();
				 delayhist.add(Integer.parseInt(clickinfo.getDelay()));
				 
				 List<String> hashhist = new ArrayList<String>();
				 hashhist.add(progressivehash);
				 
				 clickdata = new UserImageClickMemoryData(existingrecord.getImageid(), 
						 existingrecord.getUserid(), 
						 imageglobalseq,
						 Integer.parseInt(clickinfo.getClickX()),//clickx, 
						 Integer.parseInt(clickinfo.getClickY()), //clicky, 
						 Integer.parseInt(clickinfo.getImgWidth()),//width, 
						 Integer.parseInt(clickinfo.getImgHeight()), //height, 
						 null,//locationhash
						 progressivehash,
						 Integer.parseInt(clickinfo.getDelay()), //delay
						 currenttime, //recordcreatedate
						 currenttime, //lastupdatedate
						 delayhist, // delayhistory
						 hashhist,
						 0, //avgdelay
						 0, //mindelay
						 0, //maxdelay
						 0, // meddelay
						 0, // success count
						 0 // failure count
						 );	
			 }
		 }
		 
		 trandao.saveClickDataBasedonUserAndImage(clickdata);
		 
		 NewauthEvent ev = new NewauthEvent(UUID.randomUUID(), 
					EventTypes.IMAGE_CLICK, 
					Calendar.getInstance().getTime(), 
					sessiondata.getUserid(), //UserID
					sessiondata.getDeviceinfo().getIpaddress(), 
					hostip.getHostip(),
					NewAuthUtils.toStringForPrint(clickdata)); // In auth scenario, we will not save this click data with the event

		 eventdao.createEvent(ev);
		 
		 
		 
		 
				
		 						
	    }
	
	@RequestMapping(value = { "/postAuthClickData" }, method = RequestMethod.POST, consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE)
	// @ResponseStatus(value = HttpStatus.OK) // adding this because nothing is being returned
	 public String processImageClickForAuthentication( @ModelAttribute("authResponseForm") AuthenticationResponseVO respdata, 
			 					ModelMap model, HttpServletResponse response, HttpSession session)  {
		 
		 System.out.println("\nNew Request------------" + NewAuthUtils.getTimeStampString());
		 System.out.println("In process image click for authentication");
		 SessionDataVO sessiondata = (SessionDataVO) session.getAttribute("session");
		 
		// a response came in, clear the current list
		if (sessiondata.getCurrentimagesforuser().get(sessiondata.getUserinfo().getUsername()) != null) {				
			 sessiondata.getCurrentimagesforuser().remove(sessiondata.getUserinfo().getUsername());
		}
		 
		 if (reducedSensitivityZone) {	// NEVER in prod	
			 System.out.println("ERROR: THIS LINE SHOULD NEVER APPEAR IN PRODUCTION. processImageClickForAuthentication 1");
			 // Format input JSON for pretty view
			 Object json;
			 try {
				json = jsonmapper.readValue(respdata.getResponsedata(), Object.class);
				model.addAttribute("inputClickData" , jsonmapper.writerWithDefaultPrettyPrinter().writeValueAsString(json));
			} catch (IOException e) {
				System.out.println("INFO: IOException while prettifying input auth response JSON... processing continues");
			}			 
		 }
		 
		List<ImageClickInfoVO> clickinfos;
		try {
			clickinfos = jsonmapper.readValue(respdata.getResponsedata(), jsonmapper.getTypeFactory().constructCollectionType(List.class, ImageClickInfoVO.class));
			
			for (ImageClickInfoVO clickinfo: clickinfos) {
				if (Integer.parseInt(clickinfo.getClickX()) < 0 || Integer.parseInt(clickinfo.getClickX()) > Integer.parseInt(clickinfo.getImgWidth()) )
					return "error";
				
				if (Integer.parseInt(clickinfo.getClickY()) < 0 || Integer.parseInt(clickinfo.getClickY()) > Integer.parseInt(clickinfo.getImgHeight()) )
					return "error";
			}
		} catch (IOException e) {
			System.out.println("Could not get proper Authentication response data from data received from client: responsedata: " + respdata.getResponsedata());
			return "error";
		}

		
		 if (sessiondata == null || sessiondata.getUserid() == null) {
			// return "error";
			 System.out.println("Session did not have a userID. Looks like a stale session. Discard.");
			 return "error";
		 }
		 
		 if (sessiondata.getUserid().equals(new UUID(0L, 0L))) { // this is a fishing attempt, will keep running in loop :)
			 // No need to look at response data
			 sessiondata.getAuthAttempts().add(clickinfos.size()); // Authattempts is an array, with each element specifying how many images were sent in that attempt
			 model.addAttribute("authMessage", "Authentication failed. Please try again.");
			 model.addAttribute("authAttempts", sessiondata.getAuthAttempts());
			 return forwardtoAuthenticateUser(sessiondata.getUserid(), sessiondata.getDeviceinfo(), model, session);
		 }
		 
		 // TODO: Also check that the returned imageids are the same ones that were sent
		 // May be not needed since we already converted temp image ids to real ones
		 
		 List<UserImageClickMemoryData> clickmemorydatalist = new ArrayList<UserImageClickMemoryData>();	
		 
		 List<String> indivimgids = new ArrayList<String>();
		 List<Integer> indivmatchpc = new ArrayList<Integer>();
		 List<String> indivhashes = new ArrayList<String>();
		 List<Integer> indivdelays = new ArrayList<Integer>();
		 
		 int aggregatematchpct=0;
		 
		for (ImageClickInfoVO clickinfo: clickinfos) {
			//First convert temp image id into real one
			clickinfo.setImgID(NewAuthUtils.getRealIDForTempImgID(clickinfo.getImgID(), sessiondata));
						
			if (reducedSensitivityZone) {// NEVER in prod
				System.out.println("ERROR: THIS LINE SHOULD NEVER APPEAR IN PRODUCTION. processImageClickForAuthentication 2");
				ImageDataByMetaData imgmeta = new ImageDataByMetaData();
				imgmeta.setImageid(UUID.fromString(clickinfo.getImgID()));
				
				ImageDataByMetaData tinyimg = imagedao.getTinyImageCopyOfAnImage(imgmeta);
				
				if (tinyimg != null) {
					indivimgids.add(tinyimg.getImageid().toString());
				}
				
				indivdelays.add(Integer.parseInt(clickinfo.getDelay()));
			}			
			
			 clickinfo.setUserID(sessiondata.getUserid().toString());
			 System.out.println(clickinfo.toString());
			 Date currenttime =  Calendar.getInstance().getTime();
			 
			 String progressivehash = NewAuthUtils.generateProgressiveHashFromClickData(clickinfo);
			 
			 indivhashes.add(progressivehash);
			 int imageglobalseq = trandao.getGlobalSeqForImage(UUID.fromString(clickinfo.getImgID()));
			 
			 UserImageClickMemoryData existingrecord = trandao.getClickDataBasedonUserAndImage(UUID.fromString(clickinfo.getUserID()), imageglobalseq);
			 
			 if (existingrecord == null) { // this is the case where user selected incorrect image from collage and then clicked on a segment there
				 							// Also when system added a fake image to the set
				 // send back to auth only in first case (collage case)
				 String scrsz = NewAuthUtils.getScreenSize(sessiondata.getDeviceinfo().getScreenwidth(), sessiondata.getDeviceinfo().getScreenheight());
				 if (scrsz.equals("S") || scrsz.equals("M")) {
					 sessiondata.getAuthAttempts().add(clickinfos.size());
					 model.addAttribute("authMessage", "Authentication failed. Please try again.");
					 //model.addAttribute("authAttempts", sessiondata.getAuthAttempts());
					 return forwardtoAuthenticateUser(sessiondata.getUserid(), sessiondata.getDeviceinfo(), model, session);
				 }
			 } else {
			 			
				 int matchpct = NewAuthUtils.computeProgressiveHashMatch(progressivehash, existingrecord.getProgressivehash());
				 indivmatchpc.add(matchpct);
				 
				 System.out.println("Generated p hash from click: " + progressivehash + " stored: " + existingrecord.getProgressivehash() + " match : " + matchpct + " old location: " + existingrecord.getClickx() + "-" + existingrecord.getClicky());
				 
				 List<Integer> delayhist = existingrecord.getDelayhistory();
				 
				 if (delayhist.size() > 100)
					 delayhist = delayhist.subList(delayhist.size()-100, delayhist.size());
				 
				 List<String> hashhist = existingrecord.getPhashhistory();
				 
				 if (hashhist.size() > 100)
					 hashhist = hashhist.subList(hashhist.size()-100, hashhist.size());
				 
				 delayhist.add(Integer.parseInt(clickinfo.getDelay()));
				 
				 hashhist.add(progressivehash);
				 
				 int avgdelay = (int) delayhist.stream().mapToInt(i -> i).average().orElse(0);
				 int mindelay = (int) delayhist.stream().mapToInt(i -> i).min().orElse(0);
				 int maxdelay = (int) delayhist.stream().mapToInt(i -> i).max().orElse(0);
				 
				 MedianOfIntegerStream medcalc = new MedianOfIntegerStream();
				 for (int p: delayhist) {
					 medcalc.addNumberToStream(p);
				 }
				
				 int meddelay = medcalc.getMedian().intValue();
				 
				 UserImageClickMemoryData clickdata = null;
				 
				 clickdata = new UserImageClickMemoryData(existingrecord.getImageid(), 
						 existingrecord.getUserid(), 
						 imageglobalseq,
						 existingrecord.getClickx(),//clickx, 
						 existingrecord.getClicky(), //clicky, 
						 existingrecord.getImgwidth(),//width, 
						 existingrecord.getImgheight(), //height, 
						 null,//locationhash
						 existingrecord.getProgressivehash(),
						 Integer.parseInt(clickinfo.getDelay()), //delay
						 existingrecord.getRecordcreatedate(), //recordcreatedate
						 currenttime, //lastupdatedate
						 delayhist, //, delayhistory
						 hashhist,
						 avgdelay,
						 mindelay,
						 maxdelay,
						 meddelay,
						 existingrecord.getSuccesscount(),
						 existingrecord.getFailurecount()
						 );	
				 
				 if (matchpct > thresholdhashmatchpercent) { // Add to successcount
					 
					 System.out.println("Closely matches last click: " + matchpct + "pc. Adding to success count");
					 
					 clickdata.setSuccesscount(existingrecord.getSuccesscount()+1);
					 
					 
				 } else { // Add to fail count
					 clickdata.setFailurecount(existingrecord.getFailurecount()+1);
				 }
			 
				 clickmemorydatalist.add(clickdata);	
			 }
		 
		}
		
		if (reducedSensitivityZone) {	// Not in prod	
			System.out.println("ERROR: THIS LINE SHOULD NEVER APPEAR IN PRODUCTION. processImageClickForAuthentication 3");
			model.addAttribute("indivimgids", indivimgids);
			model.addAttribute("indivmatchpc" , indivmatchpc);
			model.addAttribute("indivhashes" , indivhashes);
			model.addAttribute("indivdelays" , indivdelays);
		}
		
		int authscore = NewAuthUtils.computeAggregateAuthScore(indivmatchpc, indivdelays);
		
		model.addAttribute("authenticationScore", authscore);
		sessiondata.setAuthscore(authscore);
		sessiondata.setUserauthenticated(sessiondata.getUserid().toString());
		
		// Now evaluate this score based on risk and thresholdauthmatchpercent
		 
		trandao.saveMultipleClickDataBasedonUserAndImage(clickmemorydatalist);
		
		 NewauthEvent ev = new NewauthEvent(UUID.randomUUID(), 
					((thresholdauthmatchpercent >= authscore)?EventTypes.AUTH_CHALLENGE_FAIL:EventTypes.AUTH_CHALLENGE_SUCCESS), 
					Calendar.getInstance().getTime(), 
					sessiondata.getUserid(), //UserID
					sessiondata.getDeviceinfo().getIpaddress(), 
					hostip.getHostip(),
					//NewAuthUtils.toStringForPrint(clickdata)
					"{authenticationScore:" + authscore + ", delaydata:" + indivdelays + "}" 
					); 

		 eventdao.createEvent(ev);
		 
		if (authscore < thresholdauthmatchpercent) {
			sessiondata.getAuthAttempts().add(clickinfos.size());
			model.addAttribute("authMessage", "Authentication failed. Please try again.");
			model.addAttribute("authAttempts", sessiondata.getAuthAttempts());
			return forwardtoAuthenticateUser(sessiondata.getUserid(), sessiondata.getDeviceinfo(), model, session);
			 
		} else {
			//Set hash on device for Authentication by Hash
			
			UserIdByHash hashentry = new UserIdByHash(sessiondata.getUserid(), 
						//InetAddress.getByAddress(ipaddressbytes), 
						sessiondata.getDeviceinfo().getIpaddress(),
						null, 
						sessiondata.getUserinfo().getUsername(),
						sessiondata.getUserinfo().getFirstname() + " " + sessiondata.getUserinfo().getMiddleinitial() + " " + sessiondata.getUserinfo().getLastname(),
						true, 
						false,
						sessiondata.getDeviceinfo().getScreenheight(), 
						sessiondata.getDeviceinfo().getScreenwidth(),
						sessiondata.getDeviceinfo().getUseragent(),
						null,
						null,
						null);

			String newhash = trandao.createHashEntries(hashentry);

			NewAuthUtils.addCookie(sessiondata.getCookiedata(), response, newhash, cookiettl);
		}
			
		return "authenticationResult";
		 						
    }
	
	
	@RequestMapping(value = { "/postAuthColClickData/{id}" }, method = RequestMethod.GET)
	// @ResponseStatus(value = HttpStatus.OK) // adding this because nothing is being returned
	 public String processCollageClickForAuthentication( @PathVariable(value="id") String imgid, 
			 					ModelMap model, HttpServletResponse response, HttpSession session)  {
		 
		 System.out.println("\nNew Request------------" + NewAuthUtils.getTimeStampString());
		 System.out.println("In process collage click for authentication");
		 SessionDataVO sessiondata = (SessionDataVO) session.getAttribute("session");
		 			
		 if (sessiondata == null || sessiondata.getUserid() == null) {
			// return "error";
			 System.out.println("Session did not have a userID. Looks like a stale session. Discard.");
			 return "error";
		 }
		 
		// a response came in, check if the id belonged in the list and then clear the current list
		if (sessiondata.getCurrentimagesforuser().get(sessiondata.getUserinfo().getUsername()) != null) {	
			boolean found = false;
			for (ImgIDTranslatorVO tvo : sessiondata.getCurrentimagesforuser().get(sessiondata.getUserinfo().getUsername())) {
				if (tvo.getNormalID().equals(imgid)) {
					found =  true;
					break;
				}
			}
			
			if (!found) {
				System.out.println("Where did this come from - 2? " );
				return "error";
				
			}
			System.out.println("Cleared cached collage.");
			sessiondata.getCurrentimagesforuser().remove(sessiondata.getUserinfo().getUsername());
		} else {
			System.out.println("Where did this come from? " );
			return "error";
		}
			 
		/* if (sessiondata.getUserid().equals(new UUID(0L, 0L))) { // this is a fishing attempt, will keep running in loop :)
			 // No need to look at response data
			 sessiondata.getAuthAttempts().add(clickinfos.size()); // Authattempts is an array, with each element specifying how many images were sent in that attempt
			 model.addAttribute("authMessage", "Authentication failed. Please try again.");
			 model.addAttribute("authAttempts", sessiondata.getAuthAttempts());
			 return forwardtoAuthenticateUser(sessiondata.getUserid(), sessiondata.getDeviceinfo(), model, session);
		 }*/
		 
		  
		//for (ImageClickInfoVO clickinfo: clickinfos) {
			//First convert temp image id into real one
			imgid = NewAuthUtils.getRealIDForTempImgID(imgid, sessiondata);
						
			ImageDataByImageID tinyimg = imagedao.getImageDataBasedOnId(imgid);
			ImageDataByMetaData originalimage = new ImageDataByMetaData();
			originalimage.setSize(tinyimg.getSize());
			originalimage.setImageseq(tinyimg.getImageseq());
			
			String targetsize = NewAuthUtils.getImageSize(sessiondata.getDeviceinfo().getScreenwidth(), sessiondata.getDeviceinfo().getScreenheight());
			ImageDataByMetaData imgforscreen = imagedao.getAnotherSizeImageCopyOfATinyImage(originalimage, targetsize);
			
			
			List<ImgIDTranslatorVO> imgIds = new ArrayList<ImgIDTranslatorVO>();
			
				
			if (imgforscreen != null) {
				System.out.println("Found " + targetsize + " size image for seq" + originalimage.getImageseq() + " : size " + originalimage.getSize());				
				
				ImgIDTranslatorVO translator = new ImgIDTranslatorVO();
				translator.setNormalID(imgforscreen.getImageid().toString());
				
				translator.setNormalwidth(imgforscreen.getImagewidth());
				translator.setNormalheight(imgforscreen.getImageheight());
				
				//ImageDataByMetaData tinyimg = getTinyImageCopyOfAnImage(imgbyseq);
				//if (tinyimg != null) {
				//	translator.setTinyID(tinyimg.getImageid().toString());
				imgIds.add(translator);
				//}			
				
			} else {
				System.out.println("Could not find " + targetsize + " size image for " + originalimage.getImageid() + " : size " + originalimage.getSize());		
			}
			
			List<Integer> widths = new ArrayList<Integer>();
			 List<Integer> heights = new ArrayList<Integer>();
			 int counter = 0;
			for (ImgIDTranslatorVO img: imgIds) {
				 
				 // Swap imageIDs for temp ones
				// IF it is not already a temp one :)
				if (NewAuthUtils.getRealIDForTempImgID(img.getNormalID(), sessiondata) == null)
					img.setNormalID(NewAuthUtils.getTempImgIDForRealID(img.getNormalID(), sessiondata));
				 
				 // Also set height and width for client view
				 widths.add( img.getNormalwidth());	
				 heights.add(img.getNormalheight());
				 
				 float imgar = (float)img.getNormalwidth()/img.getNormalheight();
				 float windowar = (float) sessiondata.getDeviceinfo().getWindowwidth()/sessiondata.getDeviceinfo().getWindowheight();
					 
				 if (windowar <= imgar)  {
					 
					 if (sessiondata.getDeviceinfo().getWindowwidth() < img.getNormalwidth()) {
						 double maxwidth = sessiondata.getDeviceinfo().getWindowwidth() * 0.9;
						 widths.set(counter, (int) maxwidth);
					 	 heights.set(counter, new Float(widths.get(counter)/imgar).intValue());
					 }
				 } else {
					 
					 if (sessiondata.getDeviceinfo().getWindowheight() < img.getNormalheight()) {
						 double maxheight = sessiondata.getDeviceinfo().getWindowheight() * 0.85;
						 heights.set(counter, (int) maxheight);
						 widths.set(counter, new Float(heights.get(counter)*imgar).intValue());
					 }
					 
				 }
				 counter++;
			 }
			model.addAttribute("imageIds", imgIds);
			 
			 model.addAttribute("authResponseForm", new AuthenticationResponseVO());
			 
			 model.addAttribute("imgwidths", widths);
			 model.addAttribute("imgheights", heights);
			 
			 System.out.println("Widths: " + widths  + " heights: " + heights );
		
			 model.addAttribute("authMessage", "Click on your secret location");
			 return "doAuthenticate";
			
	
		 						
	    }
	 
	 
}
