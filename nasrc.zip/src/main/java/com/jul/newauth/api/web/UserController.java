package com.jul.newauth.api.web;

import java.io.IOException;
import java.util.Calendar;
import java.util.List;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.jul.newauth.dao.EventDAO;
import com.jul.newauth.dao.ImageDataDAO;
import com.jul.newauth.dao.TransactionDAO;
import com.jul.newauth.dao.UserDAO;
import com.jul.newauth.model.DeviceVO;
import com.jul.newauth.model.EventTypes;
import com.jul.newauth.model.ImageClickInfoVO;
import com.jul.newauth.model.ImgIDTranslatorVO;
import com.jul.newauth.model.LocalHostVO;
import com.jul.newauth.model.SessionDataVO;
import com.jul.newauth.model.UserVO;
import com.jul.newauth.model.cassandra.ks.analytics.NewauthEvent;
import com.jul.newauth.model.cassandra.ks.transactions.UserIdByHash;
import com.jul.newauth.model.cassandra.ks.users.Phone;
import com.jul.newauth.model.cassandra.ks.users.UsersByUsername;
import com.jul.newauth.util.NewAuthUtils;


@Controller
public class UserController {
	
	@Autowired
    UserDAO userdao;
	
	@Autowired
    TransactionDAO trandao;
	
	@Autowired
    ImageDataDAO imagedao;
	
	@Autowired
	EventDAO eventdao;
		
	@Value("${cookiettl}")
	private int cookiettl;
	
	@Value("${initializeImageSetSize}")
	private int initializeImageSetSize;	
	
	@Value("${reducedSensitivityZone}")
	private boolean reducedSensitivityZone;
	
	@Autowired
	private LocalHostVO hostip;
	
	@RequestMapping(value = "/createUser", method = RequestMethod.GET)
    public String getCreateUserPage(ModelMap model, HttpSession session) {
		
		System.out.println("\nNew Request------------");
		System.out.println("in getcreateuserpage");
		 
		SessionDataVO sessiondata = (SessionDataVO) session.getAttribute("session");
        UserVO userModel = new UserVO();
        //DeviceVO device = new DeviceVO();
        //userModel.getEmails().add("");
        if (reducedSensitivityZone) { // NEVER in PROD
        	System.out.println("ERROR: THIS LINE SHOULD NEVER APPEAR IN PRODUCTION. getCreateUserPage 1");
			 model.addAttribute("oktopassclearusername", true);
		 } 
        
        model.addAttribute("user", userModel);
        model.addAttribute("device", sessiondata.getDeviceinfo());
        return "createUser";
    }
	
	 @RequestMapping(value = "/createUser", method = RequestMethod.POST)
	 public String createUser(@Valid @ModelAttribute UserVO uservo,
			 						@ModelAttribute DeviceVO devicevo,
			 						BindingResult result, 
			 						ModelMap model, 
			 						HttpServletResponse response,
			 						HttpServletRequest request,
			 						HttpSession session) throws IOException {
		 
		 System.out.println("\nNew Request------------");
		 System.out.println("Creating user");
		 SessionDataVO sessiondata = (SessionDataVO) session.getAttribute("session");
		 
		 if (!reducedSensitivityZone) {
			 System.out.println("Removing clear username");
			 uservo.setUsernameclear("");
			 model.addAttribute("oktopassclearusername", false);
		 } 
		 
		 if (sessiondata == null) {
				System.out.println("No session data. Forwarding to home.");
				return "welcome";
		 }
		 
		 if (devicevo.getUseragent() == null) {
			 devicevo.setUseragent(sessiondata.getDeviceinfo().getUseragent());
		 }
		 
		 if (devicevo.getIpaddress() == null) {
			 devicevo.setIpaddress(sessiondata.getDeviceinfo().getIpaddress());
		 }
		 
		 sessiondata.setDeviceinfo(devicevo);
		 model.addAttribute("device", sessiondata.getDeviceinfo());
		 
		 System.out.println("x-forwarded-for header: " +  request.getHeader("X-FORWARDED-FOR"));
		 
		 System.out.println("Devicevo received: " + NewAuthUtils.toStringForPrint(devicevo));
		 
		 UsersByUsername existinguser = userdao.findUserByUsername(uservo.getUsername()) ;
		 
		 if (existinguser == null) {
			 
			 String userid = userdao.createUser(uservo);	
			 sessiondata.setUserid(UUID.fromString(userid));
			 
			 //Create event
			 NewauthEvent ev = new NewauthEvent(UUID.randomUUID(), 
						EventTypes.USER_CREATED, 
						Calendar.getInstance().getTime(), 
						sessiondata.getUserid(), //UserID
						sessiondata.getDeviceinfo().getIpaddress(), 
						hostip.getHostip(),
						NewAuthUtils.toStringForPrint(uservo));

			 eventdao.createEvent(ev);
			 
			 List<ImgIDTranslatorVO> listofimages = imagedao.assignRandomImagesToUser(userid, sessiondata.getDeviceinfo().getScreenwidth(), sessiondata.getDeviceinfo().getScreenheight(), initializeImageSetSize);
		 
			 model.addAttribute("imageIds", listofimages);
				
			 model.addAttribute("userName", uservo.getUsername());
			 
			 String fullname = ((uservo.getFirstname()!= null)?uservo.getFirstname():"") + " " 
					 			+ ((uservo.getMiddleinitial() != null)?uservo.getMiddleinitial()+ ". ":"")  + 
					 			uservo.getLastname() ;
			 
			 model.addAttribute("fullName", fullname);
			 
			 if (uservo.getPhones() != null && uservo.getPhones().size() > 0) {
				 String sphones = "";
				 
				 for (Phone ph: uservo.getPhones()) {
					 sphones += ph.getNumber() + ",";
				 }
			 
				 model.addAttribute("phones", sphones.substring(0, sphones.length()-1));
			 }
			 
			 if (uservo.getEmails() != null && uservo.getEmails().size() > 0 && uservo.getEmails().get(0).length() > 0) {
				 
				 System.out.println("Email addresses found...");
				 String semails = "";
				 
				 for (String em: uservo.getEmails()) {
					 semails += em + ",";
				 }
			 
				 model.addAttribute("emails", semails.substring(0, semails.length()-1));
			 }
		    		     
		     UserIdByHash hashentry = new UserIdByHash(UUID.fromString(userid), 
		    		 						//InetAddress.getByAddress(ipaddressbytes), 
		    		 						sessiondata.getDeviceinfo().getIpaddress(),
		    		 						null, 
		    		 						uservo.getUsername(),
		    		 						uservo.getFirstname() + " " + uservo.getMiddleinitial() + " " + uservo.getLastname(),
		    		 						true, 
		    		 						false,
		    		 						sessiondata.getDeviceinfo().getScreenheight(), 
		    		 						sessiondata.getDeviceinfo().getScreenwidth(),
		    		 						sessiondata.getDeviceinfo().getUseragent(),
		    		 						null,
		    		 						null,
		    		 						null);
		     
		     String hash = trandao.createHashEntries(hashentry);
		     
		     NewAuthUtils.addCookie(sessiondata.getCookiedata(), response, hash, cookiettl);
		     System.out.println("Returning setupUser");
		     return "setupUser"; // TODO: Does not quite work... need to forward it to webcontroller.setupuser
		 } else {
			 
			 model.addAttribute("failureMessage", "Sorry, a user with that username already exists. Please try again");
			 model.addAttribute("returnUrl", "/createUser");
			 
			 System.out.println("Returning failure");
			 return "failure";
		 }
		
	 }

	
	
		 

}
