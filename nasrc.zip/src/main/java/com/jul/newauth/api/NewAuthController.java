package com.jul.newauth.api;

public class NewAuthController {

}
