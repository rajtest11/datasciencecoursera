package com.jul.newauth;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
// @SpringBootApplication is same as adding all 3:
// @Configuration, @EnableAutoConfiguration, @ComponentScan
public class NewAuthBootApplication implements CommandLineRunner {
	private static Logger logger = LoggerFactory.getLogger(NewAuthBootApplication.class);
	public static void main(String[] args) {
		
		SpringApplication app = new SpringApplication(NewAuthBootApplication.class);
		app.run(args);
	}

	@Override
	public void run(String... arg0) throws Exception {
		if (arg0.length > 0 && arg0[0].equals("exitcode")) {
			throw new Exception();
		}
	}
	
	

}

