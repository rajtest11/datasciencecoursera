package com.jul.newauth.util;



import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.Transparency;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.math.RoundingMode;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.imageio.ImageIO;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.springframework.ui.ModelMap;

import com.jul.newauth.model.DeviceVO;
import com.jul.newauth.model.ImageClickInfoVO;
import com.jul.newauth.model.SessionDataVO;
import com.jul.newauth.model.UserVO;
import com.jul.newauth.model.cassandra.ks.users.Phone;
import com.jul.newauth.model.cassandra.ks.users.UsersByUsername;

public class NewAuthUtils {
	
	public static Hashtable<String, BigInteger> permutationsdata;

	public static void main(String[] args) {
		// System.out.println(NewAuthUtils.fileSizeToBytes("1mb"));

		//System.out.println(NewAuthUtils.generateSHA256Hash("fc713125-b3fa-46a0-ade0-ce11ea1e29b1 192.168.1.2"));
		
		//System.out.println(Arrays.toString(NewAuthUtils.getAllowedAspectRatios((float)1.25, (short)5)));
		System.out.println(NewAuthUtils.getpermutations(6, 5));  //100, 16 == 28159159160078012637630259200000
	}
	
	private static final SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH.mm.ss.SSS");

	public static long fileSizeToBytes(String filesize) {
		long returnValue = -1;
		Pattern patt = Pattern.compile("([\\d.]+)([GMK]B)", Pattern.CASE_INSENSITIVE);
		Matcher matcher = patt.matcher(filesize);
		Map<String, Integer> powerMap = new HashMap<String, Integer>();
		powerMap.put("GB", 3);
		powerMap.put("MB", 2);
		powerMap.put("KB", 1);
		if (matcher.find()) {
			String number = matcher.group(1);
			int pow = powerMap.get(matcher.group(2).toUpperCase());
			BigDecimal bytes = new BigDecimal(number);
			bytes = bytes.multiply(BigDecimal.valueOf(1024).pow(pow));
			returnValue = bytes.longValue();
		}
		return returnValue;
	}

	public static String generateSHA256Hash(String input) {
		String out = "";
		long start = System.currentTimeMillis();

		MessageDigest messageDigest;
		try {
			messageDigest = MessageDigest.getInstance("SHA-256");
			messageDigest.update(input.getBytes());
			// out = new String(messageDigest.digest());

			out = Base64.getEncoder().encodeToString(messageDigest.digest()).replaceAll("/", "_");
		} catch (NoSuchAlgorithmException e) {
			// TODO Auto-generated catch block
			System.out.println("Exception while generating SHA256 hash for: " + input);
		}

		System.out.println(
				"SHA 256 hash for : " + input + " generated in " + (System.currentTimeMillis() - start) + "ms");

		return out;
	}

	public static String toStringForPrint(Object obj) {
		return ToStringBuilder.reflectionToString(obj);
	}
	
	private static Map<String, String> stringToMap(String input) {
	    LinkedHashMap<String, String> ret = new LinkedHashMap<String, String>();
	    String partsString = StringUtils.substringBetween(input, "[", "]");
	    String[] parts = partsString.split(",");
	    for (String part:parts) {
	        String[] nv = part.split("=");
	        if (!StringUtils.equals("<null>", nv[1])) {
	            ret.put(nv[0], nv[1]);
	        }
	    }
	    return ret;
	}

	public static <T> T fromStringToPrint(String input) throws IllegalAccessException, InvocationTargetException, InstantiationException {
		Class<T> clazz;
		try {
			clazz = (Class<T>) Class.forName(input.split("@")[0]);
			Map<String, String> map = stringToMap(input);
		    T ret = clazz.newInstance();
		    BeanUtils.copyProperties(ret, map);
		    return ret;
		} catch (ClassNotFoundException e) {
			System.out.println("NewAuthUtils.fromStringToPrint: Failed to instantiate class based on input string representasion.");
		}
	    return null;
	}

	public static String getNewauthCookie(HttpServletRequest request) {
		Cookie[] cookiearr = request.getCookies();
		String newauthcookie = null;
		if (cookiearr != null && cookiearr.length > 0) {
			System.out.print("cookies found thru request:");
			for (Cookie c : cookiearr) {
				// System.out.println("\t" + NewAuthUtils.toStringForPrint(c));

				System.out.print("\t" + c.getName() + ":" + c.getValue());
				if (c.getName().equals("newauth"))
					newauthcookie = c.getValue();

			}
			System.out.println();
		}
		return newauthcookie;
	}

	public static void addCookie(String existingcookie, HttpServletResponse response, String hash, int cookiettl) {

		if (existingcookie != null) {
			if ( !existingcookie.contains(hash)) {
				hash = (existingcookie == null || existingcookie.length() == 0) ? hash : existingcookie + hash;
	
				Cookie c = new Cookie("newauth", hash);
				c.setMaxAge(cookiettl);
				c.setHttpOnly(true);
				c.setSecure(true);
				response.addCookie(c);
	
				System.out.println("Added to an existing cookie to response: " + hash);
			}
		} else {
			Cookie c = new Cookie("newauth", hash);
			c.setMaxAge(cookiettl);
			c.setHttpOnly(true);
			c.setSecure(true);
			response.addCookie(c);

			System.out.println("Added new cookie to response: " + hash);
		}

	}

	public static void removeCookie(String existingcookie, HttpServletResponse response, String cookietoremove,
			int cookiettl) {

		if (existingcookie.contains(cookietoremove)) {
			Cookie c = new Cookie("newauth", existingcookie.replace(cookietoremove, ""));
			c.setMaxAge(cookiettl);
			response.addCookie(c);

			System.out.println("Removed cookie from response: " + cookietoremove);
		}

	}

	public static void compareObjects(DeviceVO fromReq, DeviceVO inSession) {
		System.out.println("In Session: ");
		System.out.println(toStringForPrint(inSession));
		System.out.println("From Request: ");
		System.out.println(toStringForPrint(fromReq));
	}

	private static BufferedImage getFasterScaledInstance(BufferedImage img, int targetWidth, int targetHeight,
			boolean progressiveBilinear) {
		int type = (img.getTransparency() == Transparency.OPAQUE) ? BufferedImage.TYPE_INT_RGB
				: BufferedImage.TYPE_INT_ARGB;
		BufferedImage ret = (BufferedImage) img;
		BufferedImage scratchImage = null;
		Graphics2D g2 = null;
		int w, h;
		int prevW = ret.getWidth();
		int prevH = ret.getHeight();
		if (progressiveBilinear) {
			w = img.getWidth();
			h = img.getHeight();
		} else {
			w = targetWidth;
			h = targetHeight;
		}
		do {
			if (progressiveBilinear && w > targetWidth) {
				w /= 2;
				if (w < targetWidth) {
					w = targetWidth;
				}
			}

			if (progressiveBilinear && h > targetHeight) {
				h /= 2;
				if (h < targetHeight) {
					h = targetHeight;
				}
			}

			if (scratchImage == null) {
				scratchImage = new BufferedImage(w, h, type);
				g2 = scratchImage.createGraphics();
			}
			g2.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
			g2.drawImage(ret, 0, 0, w, h, 0, 0, prevW, prevH, null);
			prevW = w;
			prevH = h;
			ret = scratchImage;
		} while (w != targetWidth || h != targetHeight);

		if (g2 != null) {
			g2.dispose();
		}

		if (targetWidth != ret.getWidth() || targetHeight != ret.getHeight()) {
			scratchImage = new BufferedImage(targetWidth, targetHeight, type);
			g2 = scratchImage.createGraphics();
			g2.drawImage(ret, 0, 0, null);
			g2.dispose();
			ret = scratchImage;
		}
		System.out.println("ret is " + ret);
		return ret;
	}
	
	
	private static BufferedImage getScaledInstance(
	        BufferedImage img, int targetWidth,
	        int targetHeight, Object hint, 
	        boolean higherQuality)
	    {
	        int type =
	            (img.getTransparency() == Transparency.OPAQUE)
	            ? BufferedImage.TYPE_INT_RGB : BufferedImage.TYPE_INT_ARGB;
	        BufferedImage ret = (BufferedImage) img;
	        int w, h;
	        if (higherQuality)
	        {
	            // Use multi-step technique: start with original size, then
	            // scale down in multiple passes with drawImage()
	            // until the target size is reached
	            w = img.getWidth();
	            h = img.getHeight();
	        }
	        else
	        {
	            // Use one-step technique: scale directly from original
	            // size to target size with a single drawImage() call
	            w = targetWidth;
	            h = targetHeight;
	        }

	        do
	        {
	            if (higherQuality && w > targetWidth)
	            {
	                w /= 2;
	                if (w < targetWidth)
	                {
	                    w = targetWidth;
	                }
	            }

	            if (higherQuality && h > targetHeight)
	            {
	                h /= 2;
	                if (h < targetHeight)
	                {
	                    h = targetHeight;
	                }
	            }

	            BufferedImage tmp = new BufferedImage(w, h, type);
	            Graphics2D g2 = tmp.createGraphics();
	            g2.setRenderingHint(RenderingHints.KEY_INTERPOLATION, hint);
	            g2.drawImage(ret, 0, 0, w, h, null);
	            g2.dispose();

	            ret = tmp;
	        } while (w != targetWidth || h != targetHeight);

	        return ret;
	    }
	
	
	public static byte[] reScaleImage(byte[] inputimage, String standardsize, boolean keepaspectratio) { 
		// Standard sizes
		// 'T'iny, 'S'mall, 'M'edium, 'L'arge, 'E'xtra large
		// 
		String writerNames[] = ImageIO.getWriterFormatNames();		
		//System.out.println("Image formats supported in this JRE: " + Arrays.toString(writerNames));
		
		byte[] out = null;
		try {
			SimpleImageInfo imageinfo = new SimpleImageInfo(inputimage);	
			
			BufferedImage bImageFromConvert = ImageIO.read(new ByteArrayInputStream(inputimage));
			
			int screenwidth = 0;
			int screenheight = 0;
			
			switch(standardsize) {
				case "T": 	screenwidth = 100;
							screenheight = 100;
							break;
				case "S": 	screenwidth = 400;
							screenheight = 300;
							break;	
				case "M": 	screenwidth = 800;
							screenheight = 600;
							break;
				case "L": 	screenwidth = 1024;
							screenheight = 768;
							break;
				case "E": 	screenwidth = 2560;
							screenheight = 1440;
							break;
				default: 	screenwidth = imageinfo.getWidth();
							screenheight = imageinfo.getHeight();
                			break;
				
			}
			
			double scalingratio = getImageScale(imageinfo.getWidth(), imageinfo.getHeight(), screenwidth, screenheight);
			
			if (scalingratio == 1)
				return inputimage;
								
			if (keepaspectratio) {
				screenwidth = (int) (imageinfo.getWidth()*scalingratio);
				screenheight = (int) (imageinfo.getHeight()*scalingratio);
				
			}
			
			String screensize =  screenwidth + "x" + screenheight;
			
			if ( imageinfo.getWidth() > screenwidth && imageinfo.getHeight() > screenheight ) {
				//Scale the image
				long start = System.currentTimeMillis();
				long startsize = inputimage.length;
				BufferedImage scaledimage = null;
				
				if (scalingratio < 0.2) {
					scaledimage = getScaledInstance(bImageFromConvert, screenwidth, screenheight,  RenderingHints.VALUE_INTERPOLATION_BICUBIC,true);
				} else {
					scaledimage = getFasterScaledInstance(bImageFromConvert, screenwidth, screenheight,  true);
				}
				//ImageIO.write(scaledimage, "jpg", new File("C:/temp/FileUploadTests/new.jpg"));
				ByteArrayOutputStream baos = new ByteArrayOutputStream();
				ImageIO.write(scaledimage, imageinfo.getImgformat(), baos);
				baos.flush();
				out = baos.toByteArray();
				baos.close();
				
				System.out.println("Scaled image to " + screensize +" in " + (System.currentTimeMillis()-start) + " ms. Size " + startsize + " to " + out.length);
			}
		} catch (IOException ioe) {
			System.out.println("IOException caught when rescaling the image.");
		}
		
		return out;
	}
	
	
	
	public static byte[] reScaleImage(byte[] inputimage, int screenwidth, int screenheight, boolean keepaspectratio) { 
		// Standard sizes
		// 'T'iny, 'S'mall, 'M'edium, 'L'arge, 'E'xtra large
		// 
		//String writerNames[] = ImageIO.getWriterFormatNames();		
		//System.out.println("Image formats supported in this JRE: " + Arrays.toString(writerNames));
		System.out.println("Inside rescale image...");
		
		byte[] out = null;
		try {
			SimpleImageInfo imageinfo = new SimpleImageInfo(inputimage);	
			
			BufferedImage bImageFromConvert = ImageIO.read(new ByteArrayInputStream(inputimage));
			
			double scalingratio = getImageScale(imageinfo.getWidth(), imageinfo.getHeight(), screenwidth, screenheight);
			
			if (scalingratio >= 0.97 && scalingratio <= 1.03 )
				return inputimage;
								
			if (keepaspectratio) {
				screenwidth = (int) (imageinfo.getWidth()*scalingratio);
				screenheight = (int) (imageinfo.getHeight()*scalingratio);
				
			}
			
			String screensize =  screenwidth + "x" + screenheight;
			
			if ( imageinfo.getWidth() > screenwidth && imageinfo.getHeight() > screenheight ) {
				//Scale the image
				long start = System.currentTimeMillis();
				long startsize = inputimage.length;
				BufferedImage scaledimage = null;
				
				if (scalingratio < 0.2) {
					scaledimage = getScaledInstance(bImageFromConvert, screenwidth, screenheight,  RenderingHints.VALUE_INTERPOLATION_BICUBIC,true);
				} else {
					scaledimage = getFasterScaledInstance(bImageFromConvert, screenwidth, screenheight,  true);
				}
				//ImageIO.write(scaledimage, "jpg", new File("C:/temp/FileUploadTests/new.jpg"));
				ByteArrayOutputStream baos = new ByteArrayOutputStream();
				ImageIO.write(scaledimage, imageinfo.getImgformat(), baos);
				baos.flush();
				out = baos.toByteArray();
				baos.close();
				
				System.out.println("Scaled image to " + screensize +" in " + (System.currentTimeMillis()-start) + " ms. Size " + startsize + " to " + out.length);
			}
		} catch (IOException ioe) {
			System.out.println("IOException caugh when rescaling the image.");
		}
		
		return out;
	}
	
	private static double getImageScale(int sourceWidth, int sourceHeight, int targetWidth, int targetHeight) {

		double scalex = (double) targetWidth / sourceWidth;
		double scaley = (double) targetHeight / sourceHeight;
		return Math.min(scalex, scaley);
	}
	
	public static String getImageSize(int sourceWidth, int sourceHeight) {

		if (sourceWidth >= 1024 || sourceHeight >= 768)
			return "E";
		
		if (sourceWidth <= 100 || sourceHeight <= 100)
			return "T";
		
		if (sourceWidth <= 800 || sourceHeight <= 600 )
			return "S";
		
		if (sourceWidth <= 1024 || sourceHeight <= 768)
			return "M";
		
		return "L";
	}
	
	public static float getImageAspectRatio(int sourceWidth, int sourceHeight) {		
		
		if (sourceHeight == 0) return 0;
		
		return roundFloatToDecimalPlaces((double)sourceWidth/(double)sourceHeight, (short) 2);
	}
	
	
	
	public static float roundFloatToDecimalPlaces(double f, short numplaces) {
		NumberFormat formatter = NumberFormat.getInstance(Locale.US);
		formatter.setMaximumFractionDigits(numplaces);
		formatter.setMinimumFractionDigits(numplaces);
		formatter.setRoundingMode(RoundingMode.HALF_UP); 
		return new Float(formatter.format(f));
	}

	public static Float[] getAllowedAspectRatios(float ar, short tolerancepct) {
		// Returning +- tolerancepct % of this ar value
		
		List<Float> list = new ArrayList<Float>();
		
		BigDecimal ratio = new BigDecimal(tolerancepct/100.0);
		
		BigDecimal multiplier = new BigDecimal("1.0").subtract(ratio);
		BigDecimal startar = new BigDecimal(Float.toString(ar)).multiply(multiplier);
		
		multiplier = new BigDecimal("1.0").add(ratio);
		BigDecimal endar = new BigDecimal(Float.toString(ar)).multiply(multiplier);
		
		BigDecimal totalvalues = endar.subtract(startar).multiply(new BigDecimal(100));
		
		if (totalvalues.intValue() > 0) {
			BigDecimal jump = endar.subtract(startar).divide(totalvalues);
			
			for (int i=0; i<totalvalues.intValue(); i++) {
				BigDecimal arval = startar.add(jump.multiply(new BigDecimal(i)));
				list.add(roundFloatToDecimalPlaces(arval.floatValue(), (short) 2));
			}
		} else {
			list.add(roundFloatToDecimalPlaces(ar, (short) 2));
		}
		
		// If list does not already contain -9 till 1.1, add those
		
		for (int i=0; i<=20; i++) {
			BigDecimal arval = new BigDecimal("0.9");
			BigDecimal toaddvalue = arval.add(new BigDecimal("0.01").multiply(new BigDecimal(i)));
			
			if (!list.contains(toaddvalue.floatValue()))
				list.add(roundFloatToDecimalPlaces(toaddvalue.floatValue(), (short) 2));
		}
		
		Collections.sort(list);
		
		//System.out.println(list);
		return list.toArray(new Float[0]);
	}

	public static String[] getSizesBiggerThanThisSize(String imageSize) {
		// TODO Auto-generated method stub
		
		String allsizes = "TSMLEO";
		
		String[] splitsizes = allsizes.split("");
		return Arrays.copyOfRange(splitsizes, allsizes.indexOf(imageSize), splitsizes.length-1);
	}

	public static String generateProgressiveHashFromClickData(ImageClickInfoVO clickinfo) {
		String phash = "";
		
		int splitcount = 0;
		
		int clickx = Integer.parseInt(clickinfo.getClickX());
		int clicky = Integer.parseInt(clickinfo.getClickY());
		int width = Integer.parseInt(clickinfo.getImgWidth());
		int height = Integer.parseInt(clickinfo.getImgHeight());
		
		while (splitcount < 10 && width > 5 && height > 5) {
			
			if (clickx > width)  {
				clickx = clickx - width;
			}
			
			if (clicky > height) {
				clicky = clicky - height;
			}
			
			if (splitcount > 0) {
				width = width/2;
				height = height/2;
			}
			
			int cb = getclickbox(clickx, clicky, width, height);
			phash += cb;
			
			//if (cb % 2 == 0)
			//	clickx = clickx/2;
			//else
			//	clicky = clicky/2;
			
			splitcount++;
		}
		
		
		return phash;
	}
	
	private static int getclickbox (int clickx, int clicky, int width, int height) {
		
		int out = 0;		
		
		if (clickx <= width/2 && clicky <= height/2)
			out = 1;
	 		
		if (clickx > width/2 && clicky <= height/2)
			out = 2;
		
		if (clickx <= width/2 && clicky > height/2)
			out = 3;
		
		if (clickx > width/2 && clicky > height/2)
			out = 4;
		
		//System.out.println("clickx: " + clickx + " clicky: " + clicky + " width: " + width + " height: " + height + "    " + out);
		
		
		return out;
		
	}

	public static int computeProgressiveHashMatch(String newhash, String existinghash) {
		int out = 0;
		
		int[] matchpctarr = {0, 5, 13, 34, 55, 70, 89, 95, 100};
		
		int minLen = Math.min(newhash.length(), existinghash.length());
		
		int firstdifferenceindex = minLen;
		
		for (int i = 0 ; i < minLen ; i++) {
		    char chA = newhash.charAt(i);
		    char chB = existinghash.charAt(i);
		    if (chA != chB) {
		    	firstdifferenceindex = i;
		    	break;
		    }
		}
		
		System.out.println("Computing match between newhash " + newhash + " and existinghash " + existinghash + " firstdifferenceindex " + firstdifferenceindex);
		if (firstdifferenceindex > 8)
			out = 100;
		else {
			
			if (minLen < 9)
				out = matchpctarr[firstdifferenceindex + 8 - minLen];
			else
				out = matchpctarr[firstdifferenceindex];
		}
		
		
		return out;
	}

	public static void populateUserDetailsinModel(ModelMap model, UsersByUsername uservo) {
		String fullname = ((uservo.getFirstname() != null) ? uservo.getFirstname() : "") + " "
				+ ((uservo.getMiddleinitial() != null) ? uservo.getMiddleinitial() + ". " : "") + uservo.getLastname();

		model.addAttribute("fullName", fullname);

		if (uservo.getPhones() != null && uservo.getPhones().size() > 0) {
			String sphones = "";

			for (Phone ph : uservo.getPhones()) {
				sphones += ph.getNumber() + ",";
			}

			model.addAttribute("phones", sphones.substring(0, sphones.length() - 1));
		}

		if (uservo.getEmails() != null && uservo.getEmails().size() > 0 ) {

			System.out.println("Email addresses found...");
			String semails = "";

			for (String em : uservo.getEmails()) {
				semails += em + ",";
			}

			model.addAttribute("emails", semails.substring(0, semails.length() - 1));
		}

	}

	public static int getInitialImageSetSize(UserVO userVO, int i) {
		int out = 0;
		// TODO Complete this
		
		// if known ip (been known for some time) return default 
		// if unknown ip, increase size
		// if unknown ip and multiple userids, increase size even more
		// if known ip and recent successful auth reduce size
		// also, increase size for number of failed attempts
		if (i<= 13)
			out = 3;
		
		if (i > 13)
			out = 4;
		
		if (i > 25)
			out = 5;
		
		System.out.println("Setting initialimagesetsize to :" + out);
		return out;
	}
	
	public static int getInitialFakeImageSetSize(UserVO userVO, int i) {
		int out = 0;
		// TODO Complete this
		
		// if known ip (been known for some time) return default 
		// if unknown ip, increase size
		// if unknown ip and multiple userids, increase size even more
		// if known ip and recent successful auth reduce size
		if (i<= 13)
			out = 0;
		
		if (i > 13)
			out = 1;
		
		if (i > 25)
			out = 2;
		
		System.out.println("Injecting :" + out + " fake images.");
		return out;
	}

	public static String getTempImgIDForRealID(String normalID, SessionDataVO sessiondata) {
		
		if (sessiondata.getImgidtotempimgid().containsKey(normalID))
			return sessiondata.getImgidtotempimgid().get(normalID);
		else {
			String tempid = UUID.randomUUID().toString();
			sessiondata.getImgidtotempimgid().put(normalID, tempid);
			sessiondata.getTempimgidtoimgid().put(tempid,normalID);
			return tempid;
		}		
		
	}
	
	public static String getRealIDForTempImgID(String tempid, SessionDataVO sessiondata) {
		
		if (sessiondata.getTempimgidtoimgid().containsKey(tempid))
			return sessiondata.getTempimgidtoimgid().get(tempid);
		else
			return null;
				
		
	}

	public static int computeAggregateAuthScore(List<Integer> indivmatchpc, List<Integer> indivdelays) {
		// TODO Complete this
		int out = 0;
		
		for (int onepc: indivmatchpc) {
			out += onepc;
		}
		return out/indivmatchpc.size();
	}

	public static String getTimeStampString() {
		// TODO Auto-generated method stub
		return sdf.format(new Date());
	}

	public static String getScreenSize(int sourceWidth, int sourceHeight) {
		if (sourceWidth >= 1024 || sourceHeight >= 768)
			return "E";
		
		if (sourceWidth <= 100 || sourceHeight <= 100)
			return "T";
		
		if (sourceWidth <= 800 || sourceHeight <= 600 )
			return "S";
		
		if (sourceWidth <= 1024 || sourceHeight <= 768)
			return "M";
		
		return "L";
	}
	
	public static BigInteger getpermutations(int possiblechoices, int choices) {
		String key = Integer.toString(possiblechoices) + ":" + Integer.toString(choices);
		
		if (permutationsdata == null) {
			permutationsdata = new Hashtable<String, BigInteger>();
			permutationsdata.put(key, binomial(possiblechoices, choices));
			return permutationsdata.get(key);
		} else {
			if (permutationsdata.containsKey(key)) {
				return permutationsdata.get(key);
			} else {
				permutationsdata.put(key, binomial(possiblechoices, choices));
				return permutationsdata.get(key);
			}
		}
		
	}
	
	private static BigInteger binomial(final int N, final int K) {
	    BigInteger ret = BigInteger.ONE;
	    
	    int limitk = (K < N-K)?K:N-K;
	    for (int k = 0; k < limitk; k++) {
	       // ret = ret.multiply(BigInteger.valueOf(N-k)).divide(BigInteger.valueOf(k+1));
	        ret = ret.multiply(BigInteger.valueOf(N-k));
	    }
	    return ret;
	}
	
}
