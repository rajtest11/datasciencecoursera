package com.jul.newauth.util;

import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import com.jul.newauth.model.UploadFileBucket;
  
@Component
public class UploadFileValidator implements Validator {
     
    public boolean supports(Class<?> clazz) {
        return UploadFileBucket.class.isAssignableFrom(clazz);
    }
 
    public void validate(Object obj, Errors errors) {
    	UploadFileBucket file = (UploadFileBucket) obj;
         
    	boolean empty = false;
        if(file.getFile()!=null){
            if (file.getFile().getSize() == 0) {
            	empty = true;
               // errors.rejectValue("file", "missing.file");
            }
        }
        
        if(file.getUrl() == null || file.getUrl().length() == 0) {
            if (empty) {
            	errors.rejectValue("file", "missing.file");
            }
        }
    }
}