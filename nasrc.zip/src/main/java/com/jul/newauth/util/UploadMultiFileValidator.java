package com.jul.newauth.util;

import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import com.jul.newauth.model.MultiUploadFileBucket;
import com.jul.newauth.model.UploadFileBucket;
 

 
@Component
public class UploadMultiFileValidator implements Validator {
     
    public boolean supports(Class<?> clazz) {
        return MultiUploadFileBucket.class.isAssignableFrom(clazz);
    }
 
    public void validate(Object obj, Errors errors) {
    	MultiUploadFileBucket multiBucket = (MultiUploadFileBucket) obj;
         
        int index=0;
         
        for(UploadFileBucket file : multiBucket.getFiles()){
            if(file.getFile()!=null){
                if (file.getFile().getSize() == 0) {
                    errors.rejectValue("files["+index+"].file", "missing.file");
                }
            }
            index++;
        }
         
    }
}
