var secretkey = '';

document.addEventListener('DOMContentLoaded', function() {
	//alert('screen width ' + window.screen.availWidth + 
	//		' screen height ' + window.screen.availHeight +
	//		' window width ' + window.innerWidth + 
	//		' window height ' + window.innerHeight
	//		);
	
	if (document.forms[0] != undefined && document.forms[0].screenwidth) {
		document.forms[0].screenwidth.value = window.screen.availWidth;
		document.forms[0].screenheight.value = window.screen.availHeight;
	
		document.forms[0].windowwidth.value = window.innerWidth;
		document.forms[0].windowheight.value = window.innerHeight;
	}
	
	
 
}, false);

// fade out

function fadeOut(el) {
	el.style.opacity = 1;
	//alert('..in fadeout');
	(function fade() {
		if ((el.style.opacity -= .1) < 0) {
			el.style.display = "none";
		} else {
			requestAnimationFrame(fade);
		}
	})();
}

// fade in

function fadeIn(el, display) {
	el.style.opacity = 0;
	el.style.display = display || "block";

	(function fade() {
		var val = parseFloat(el.style.opacity);
		if (!((val += .1) > 1)) {
			el.style.opacity = val;
			requestAnimationFrame(fade);
		}
	})();
}

var waitForFinalResizeEvent = (function() {
	var timers = {};
	return function(callback, ms, uniqueId) {
		if (!uniqueId) {
			uniqueId = "Don't call this twice without a uniqueId";
		}
		if (timers[uniqueId]) {
			clearTimeout(timers[uniqueId]);
		}
		timers[uniqueId] = setTimeout(callback, ms);
	};
})();

window.addEventListener('resize', function() {
	waitForFinalResizeEvent(function() {

		
		var newar = window.innerWidth / window.innerHeight;
		newar = Math.round(newar * 100) / 100;
		var el = document.querySelector('.js-fade');

		if (typeof e1 !== undefined && e1) {
			el.innerHTML = newar;
			fadeIn(el);
			// fadeIn(el, "inline-block");
			setTimeout(fadeOut(el), 4000);
		}

	}, 500, "some unique string");
});

function authenticate(user) {
	
	//var hash = hashUserForAuthentication(user);
	username = user;

	var url = "/newauth/authenticate/" + user + "/" + window.screen.availWidth
			+ "/" + window.screen.availHeight + "/" + window.innerWidth + "/"
			+ window.innerHeight;

	location.href = url;
	return false;
}

function setupUser() {
	
	var url = "/newauth/setupUser"  ;
	
	location.href = url;
	//return false;
}

function showPrivateDataPage() {
	
	var url = "/newauth/securePage"  ;
	
	location.href = url;
	//return false;
}


function convertusernametohash() {
	
	var user = document.forms[0].username.value;
	var hash = hashUserForAuthentication(user);
	
	secretkey = user;
	if (document.forms[0].elements.namedItem("usernameclear") != null) {
		document.forms[0].usernameclear.value=user;
	}
	
	document.forms[0].username.value=hash;
}

function submitcreatewithuserhash() {
	
	if (document.forms[0].username.value.length < 5) {
		var x = document.getElementsByClassName("has-error");
		x[0].innerHTML = 'Invalid username. Username has to be at least 5 characters long';
		setTimeout("clearUserNameErrorDiv()", 2000);
		return false;
	}
	
	if (confirm('You are about to create a user account in Newauth with username  ' + document.forms[0].username.value
					+ '  . Newauth Username is supposed to be only known to you. Newauth does not store your username. ' +
					' If you need to make a note of your username, do so now. Click OK to continue.')) {
		convertusernametohash();	
		document.forms[0].submit();	
	} else {
		return false;
	}
}

function encryptwithstretchedkey(type, username) {
	
	var passwordSalt;
	var derivedKey;
	
	if (document.forms[type].slt.value == '') {
		document.forms[type].slt.value = "cf7488cd1e48e84990f51b3f121e161318ba2098aa6c993ded1012c955d5a3e8";
		passwordSalt = sjcl.codec.hex.toBits( "cf7488cd1e48e84990f51b3f121e161318ba2098aa6c993ded1012c955d5a3e8" );
	} else
		passwordSalt = sjcl.codec.hex.toBits( document.forms[type].slt.value );
	
	if (document.forms[type].itns.value == 0) {
		document.forms[type].itns.value = 10000;
		derivedKey = sjcl.misc.pbkdf2( username, passwordSalt, 10000, 256 );
	} else
		derivedKey = sjcl.misc.pbkdf2( username, passwordSalt, document.forms[type].itns.value, 256 );
	
	
	//var hexKey = sjcl.codec.hex.fromBits( derivedKey );
	
//	return sjcl.encrypt(derivedKey, document.forms[type].data.value, {ks: 256, salt: sjcl.codec.hex.fromBits(passwordSalt), iter: document.forms[type].itns.value});   // removed the third param , {mode : "ccm || gcm || ocb2"} CCM is default
	return sjcl.encrypt(username, document.forms[type].data.value,
									{
										ks: 256, 
										salt: sjcl.codec.hex.fromBits(passwordSalt), 
										iter: document.forms[type].itns.value
									}
			);
									
}



function decryptwithstretchedkey(type, username, encval) {
	
	var passwordSalt;
	var derivedKey;
	
	if (document.forms[type].slt.value == '')
		passwordSalt = sjcl.codec.hex.toBits( "cf7488cd1e48e84990f51b3f121e161318ba2098aa6c993ded1012c955d5a3e8" );
	else
		passwordSalt = sjcl.codec.hex.toBits( document.forms[type].slt.value );
	
	if (document.forms[type].itns.value == '0') {
		document.forms[type].itns.value = 10000;
		derivedKey = sjcl.misc.pbkdf2( username, passwordSalt, 100, 256 );
	} else
		derivedKey = sjcl.misc.pbkdf2( username, passwordSalt, document.forms[type].itns.value, 256 );
	
	
	//var hexKey = sjcl.codec.hex.fromBits( derivedKey );
	
	//return sjcl.decrypt(derivedKey, encval);  
	var original;
	try {
		original = sjcl.decrypt(username, encval); 
	} catch(e) {
		throw e;
	}
	return  original;
}


function submitencuserdata(type) {
	
	// first check if values filled in
	
	var elements = document.forms[type].elements;
	
	for (var i = 0, element; element = elements[i++];) {
	    if (element.type === "text" || element.type === "password") {	    	
	    	if (element.value.length == 0) return false;
	    }
	}
	
	createUserData(type);
	//alert('after createdata');
	if (type === 'sites')
		document.forms[type].seq.value = '1';
	
	if (type === 'fin')
		document.forms[type].seq.value = '2';
	
	var xhr = new XMLHttpRequest();
	
	var cleardata =  document.forms[type].data.value ;
	
	//var encrypteddata =	JSON.stringify( encryptwithstretchedkey(type, secretkey));
	var encrypteddata =	encryptwithstretchedkey(type, secretkey);
	//alert(cleardata + ' --> enc data: ' +  encrypteddata);	
	
    xhr.open('POST', '/secure/adduserdata', false);
    xhr.setRequestHeader('Content-Type', 'application/json');     
   
         xhr.send(JSON.stringify({
     	   	group: type,
     	   	salt: document.forms[type].slt.value,
     	   	iterations: document.forms[type].itns.value,
     	   	data: encrypteddata ,
     	   	sequence: document.forms[type].seq.value,
     	   	createdate: document.forms[type].crdate.value,
     	   	lastupdatedate: document.forms[type].upddate.value
     		}));
         
    showDataAddDiv(type + 'Div');
    return false;		 
}

function createUserData(type) {
	var userdata = '';	
	var elements = document.forms[type].elements;
	
	for (var i = 0, element; element = elements[i++];) {
	    if (element.type === "text" || element.type === "password") {
	    	
	    	if (element.value.length == 0) return false;
	    	
	    	userdata += '"' + element.name + '":"' + element.value +'"';  	    	
	    	userdata += ', ';	    		    	
	    }
	        
	}
	if (type === 'sites')
		addWebsiteToSecurePage(document.forms[type]);
	
	if (type === 'fin')
		addFinDataToSecurePage(document.forms[type]);
	
	//alert(userdatainsystem);
	var userdatainsystemobj = JSON.parse(userdatainsystem);
	
	//alert('userdatainsystemobj.length ' + userdatainsystemobj.length + ' type ' + type);
	if (userdatainsystemobj.length > 0) {
		if (type === 'sites' ) {
			
			var existingsites = '';
			//var obj = JSON.parse(userdatainsystemobj[0].data); 
			var obj = JSON.parse(decryptwithstretchedkey('sites', secretkey, userdatainsystemobj[0].data)); 
			
			
			for (var i=0; i< obj.length; i++) {
				
				existingsites += JSON.stringify(obj[i]) +", ";
			}
			
			document.forms[type].data.value = '[' + existingsites + '{' + userdata.substring(0, userdata.length-2) + '}]';
		} 
		
		if (type === 'fin') {
			
			var existingfin = '';
			
			if (userdatainsystemobj.length > 1) {
				var obj = JSON.parse(decryptwithstretchedkey('sites', secretkey, userdatainsystemobj[1].data)); 
				
				for (var i=0; i< obj.length; i++) {
					
					existingfin += JSON.stringify(obj[i]) +", ";
				}
			}	
			
			document.forms[type].data.value = '[' + existingfin + '{' + userdata.substring(0, userdata.length-2) + '}]';
		
		}
	} else {
		document.forms[type].data.value = '[{' + userdata.substring(0, userdata.length-2) + '}]';
	}
	
	
}

function addWebsiteToSecurePage(inputform) {
	var els = inputform.elements;
	var siteurl, siteusername, sitepass;
	
	for (var i = 0, element; element = els[i++];) {
	    if (element.type === "text" || element.type === "password") {	    	
	    	
	    	if (element.name === 'siteUrl') {
	    		siteurl = element.value;
	    	} 
	    	
	    	if (element.name === 'siteuser') {
	    		siteusername = element.value;
	    	}
	    	
	    	if (element.name === 'sitepwd') {
	    		sitepass = element.value;
	    	}
	    		    	
	    }
	        
	}
	
	var divelem = document.createElement("div");
	divelem.classList.add('col-xs-2');
	
	var imgelem = document.createElement("img");
	imgelem.setAttribute("src", "https://www.google.com/s2/favicons?domain=" + siteurl);
	imgelem.setAttribute("height", "32");
	imgelem.setAttribute("width", "32");
	imgelem.setAttribute("alt", siteurl);
	imgelem.classList.add('center-block');	
	
	var p = document.createElement("p")  ;
	p.style.wordWrap = "break-word"; 
	p.style.maxWidth = "100px";
	p.style.textAlign = 'center';
	var textelem = document.createTextNode(siteusername); 
	
	p.appendChild(textelem);  
	p.addEventListener("click", function(){
		loadExtUrl(siteurl, siteusername, sitepass);
	}, false);
	
	divelem.appendChild(imgelem);	
	divelem.appendChild(p);
	
	document.getElementById("securedata-sites").appendChild(divelem);
	
}


function addFinDataToSecurePage(inputform) {
	var els = inputform.elements;
	var institution, accnumber;
	
	for (var i = 0, element; element = els[i++];) {
	    if (element.type === "text" || element.type === "password") {
	    	
	    	
	    	if (element.name === 'institution') {
	    		institution = element.value;
	    	} 
	    	
	    	if (element.name === 'acctNum') {
	    		accnumber = " " + element.value;
	    	}
	    		    	
	    }
	        
	}
	var rowelem = document.createElement("div");
	rowelem.classList.add('row');
	
	var divelem = document.createElement("div");
	divelem.classList.add('col-xs-12');
	
	
	var p = document.createElement("p")  ;
	p.style.wordWrap = "break-word"; 
	p.style.maxWidth = "50%";
	p.style.display = 'inline-block';
	var textelem = document.createTextNode(institution); 
	
	p.appendChild(textelem);  	
	divelem.appendChild(p);
		
	p = document.createElement("p")  ;
	p.style.wordWrap = "break-word"; 
	p.style.maxWidth = "50%";
	p.style.display = 'inline-block';
	var textelem = document.createTextNode(accnumber); 
	
	p.appendChild(textelem); 
	divelem.appendChild(p);
	
	rowelem.appendChild(divelem);
	
	document.getElementById("securedata-fin").appendChild(rowelem);
	
}

function loadExtUrl(url, id, pwd) {
	
	if (!url.startsWith("http")) {
		url = 'http://' + url;
	}
	
	//url = "https://localhost:8443/newauth/welcome?df564d554ht6ffs54=Y";
	
	var win = window.open(url, '_blank');
	  
	  win.onload = function() {
		  alert(win.document.title);
		  alert('in onload');
		  win.focus();
		  alert(win.document.forms.lenth);
	  };
}

function submitwithuserhash() {
	
	if (document.forms[0].username.value.length < 5) {
		var x = document.getElementsByClassName("has-error");
		x[0].innerHTML = 'Invalid username. Username has to be at least 5 characters long';
		setTimeout("clearUserNameErrorDiv()", 2000);
		return false;
	}
	
	
		convertusernametohash();	
		document.forms[0].submit();	
	
}


function hashUserForAuthentication(user) {	
	
	// Each random "word" is 4 bytes, so 8 would be 32 bytes
	//var saltBits = sjcl.random.randomWords(8);
	// eg. [588300265, -1755622410, -533744668, 1408647727, -876578935, 12500664, 179736681, 1321878387]
	
	// We are using a constant salt
	
	var saltBits = sjcl.codec.base64.toBits('sugar');

	// I left out the 5th argument, which defaults to HMAC which in turn defaults to use SHA256
	var derivedKey1 = sjcl.misc.pbkdf2(user, saltBits, 1, 256);
	var derivedKey2 = sjcl.misc.pbkdf2(user, saltBits, 2, 256);
	var derivedKey1000 = sjcl.misc.pbkdf2(user, saltBits, 1000, 256);
	// eg. [-605875851, 757263041, -993332615, 465335420, 1306210159, -1270931768, -1185781663, -477369628]

	// Storing the key is probably easier encoded and not as a bitArray
	// I choose base64 just because the output is shorter, but you could use sjcl.codec.hex.fromBits
	var key1 = sjcl.codec.base64.fromBits(derivedKey1);
	var key2 = sjcl.codec.base64.fromBits(derivedKey2);
	var key1000 = sjcl.codec.base64.fromBits(derivedKey1000);
	// eg. "2+MRdS0i6sHEyvJ5G7x0fE3bL2+0Px7IuVJoYeOL6uQ="
	
	var salt = sjcl.codec.base64.fromBits(saltBits);
	
	// And to get the bitArray back, you would do the exact opposite
	//saltBits = sjcl.codec.base64.toBits(salt);
	
	//alert('Value: ' + user + '\n Salt: ' + salt + '\n Hash1: ' + key1
	//		+ '\n Hash2: ' + key2
	//		+ '\n Hash1000: ' + key1000);
	return key1000;
}

function displayImage(id) {
	var url = "/newauth/display/image/" + id + "/" + window.screen.availWidth
			+ "/" + window.screen.availHeight + "/" + window.innerWidth + "/"
			+ window.innerHeight;

	location.href = url;
	return false;
}


function selectSegmentOnImage(id) {
	var url = "/newauth/setimgpwd/" + window.screen.availWidth
			+ "/" + window.screen.availHeight + "/" + window.innerWidth + "/"
			+ window.innerHeight + "/" + id;

	location.href = url;
	return false;
}

function postCollageSelection(id) {
	var url = "/newauth/postAuthColClickData/" + id;

	location.href = url;
	return false;
}


function loadImage(id) {
	var url = "/newauth/setimgpwd/" + window.screen.availWidth
			+ "/" + window.screen.availHeight + "/" + window.innerWidth + "/"
			+ window.innerHeight + "/" + id;

	location.href = url;
	return false;
}



// Returns a function, that, as long as it continues to be invoked, will not
// be triggered. The function will be called after it stops being called for
// N milliseconds. If `immediate` is passed, trigger the function on the
// leading edge, instead of the trailing.
function debounce(func, wait, immediate) {
	var timeout;
	return function() {
		var context = this, args = arguments;
		var later = function() {
			timeout = null;
			if (!immediate)
				func.apply(context, args);
		};
		var callNow = immediate && !timeout;
		clearTimeout(timeout);
		timeout = setTimeout(later, wait);
		if (callNow)
			func.apply(context, args);
	};
};



/// Websocket stuff

var stompClient = null;

function setConnected(connected) {
    $("#connect").prop("disabled", connected);
    $("#disconnect").prop("disabled", !connected);
    if (connected) {
        $("#conversation").show();
    }
    else {
        $("#conversation").hide();
    }
    $("#greetings").html("");
}

function wsconnect() {
    var socket = new SockJS('/newauth-websocket');
    stompClient = Stomp.over(socket);
    stompClient.connect({}, function (frame) {
        //setConnected(true);
        console.log('Connected: ' + frame);
        stompClient.subscribe('/user/queue/usernamecheck', function (response) { 
        	handleUsernamecheck(JSON.parse(response.body));        	
        });
    });
    
}

function wsdisconnect() {
    if (stompClient != null) {
        stompClient.disconnect();
    }
    console.log('tearing down stomp');
    //setConnected(false);
    console.log("Disconnected");
}

function checkName() {
	
	stompClient.send("/app/newauth/usernamecheck", {}, JSON.stringify({'userName': hashUserForAuthentication(document.forms[0].username.value),
    																	'usernameclear':document.forms[0].username.value,
    																	'clientip':document.forms[0].clientip.value
   	    																}));
   
}

function clearUserNameErrorDiv() {
	var x = document.getElementsByClassName("has-error");
	x[0].innerHTML ='';
}

function handleUsernamecheck(message) {
	if (message.response == 'EXISTS') {	
		var x = document.getElementsByClassName("has-error");
		x[0].innerHTML = 'The username  ' + document.forms[0].username.value + '  is already taken. Please select another username.';
		//alert('The username  ' + document.forms[0].username.value + '  is already taken. Please select another username.');
		document.forms[0].username.value = '';
		document.forms[0].username.focus();
		
		setTimeout("clearUserNameErrorDiv()", 3000);
	}
}

// For image click timer
var starttime = Date.now();

function restartTimer() {
	starttime = Date.now();
}

function gettimetoclick() {
	return Date.now() - starttime;
}