package com.num.generator.action;

import java.util.Hashtable;
import java.util.Set;

import com.num.generator.dataaccess.ObservationsEntity;
import com.opensymphony.xwork2.ActionSupport;

public class ObservationsMapAction extends ActionSupport {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String inParam;
	
	private int historySize = 25;
	
	private Hashtable<Integer,Integer> observationPercentileMap = new Hashtable<Integer, Integer>();
	private Hashtable<Integer, Hashtable<Integer,Integer>> observationPercentileMaps = new Hashtable<Integer, Hashtable<Integer,Integer>>();
	
	private String obsPerJSObject = "";
	
	private String selectedGameCode;
	
	public String execute() throws Exception {
		
		return SUCCESS;
	}

	

	public String getInParam() {
		return inParam;
	}

	public void setInParam(String inParam) {
		this.inParam = inParam;
	}



	public String getSelectedGameCode() {
		String inparm = getInParam();
		
		if (inparm != null && inparm.length() > 0) { // Format gameCode:targetDate
			
			setSelectedGameCode(inparm);
			
			
		}
		return this.selectedGameCode;
	}



	public void setSelectedGameCode(String selectedGameCode) {
		this.selectedGameCode = selectedGameCode;
	}

	
	public Hashtable<Integer, Integer> getObservationPercentileMap() {
		ObservationsEntity obsen = new ObservationsEntity();
		
		String inparm = getInParam();
		
		if (inparm != null && inparm.length() > 0) { // Format gameCode:field
			
			observationPercentileMap = obsen.getObsPercentiles(inparm);
		}
			
		return observationPercentileMap;
	}



	public void setObservationPercentileMap(
			Hashtable<Integer, Integer> observationPercentileMap) {
		this.observationPercentileMap = observationPercentileMap;
	}

	public Hashtable<Integer, Hashtable<Integer, Integer>> getObservationPercentileMaps() {
		
		if (historySize == 0)
			setHistorySize(100);
		
		ObservationsEntity obsen = new ObservationsEntity();
		
		String inparm = getInParam();
		
		if (inparm != null && inparm.length() > 0) { // Format gameCode:field
			
			for (int i=getHistorySize(); i>0;i--)
				observationPercentileMaps.put(i, obsen.getObsPercentilesAsOfDaysBefore(inparm, i));
		}
		
		return observationPercentileMaps;
	}



	public void setObservationPercentileMaps(
			Hashtable<Integer, Hashtable<Integer, Integer>> observationPercentileMaps) {
		this.observationPercentileMaps = observationPercentileMaps;
	}




	public String getObsPerJSObject() {
		
		if (getObservationPercentileMaps() == null || getObservationPercentileMaps().size() ==0) {
			getObservationPercentileMaps();
		}
		
		 Set<Integer> keys = observationPercentileMaps.keySet();
		 String out = "";
		 
		 for (Integer key: keys) {
			 
			 Hashtable<Integer,Integer> innertable = observationPercentileMaps.get(key);
		  
			 Set<Integer> innerkeys = innertable.keySet();
			 
			 String thisset = "";
	        
			 thisset += "{";
			
			 for(Integer innerkey: innerkeys) {
	           // System.out.println("Value of "+key+" is: "+ observationPercentileMap.get(key));
	            
				 thisset += innerkey + ":" + innertable.get(innerkey) + ",";
	        }
	        
			 thisset = thisset.substring(0,thisset.length()-1) + "}," ;
	      
	        out += thisset;
		 }
		 
		 out = "[" + out.substring(0,out.length()-1) + "]";
		// System.out.println("Setting obsPerJSObject to: " + out);
		 this.obsPerJSObject = out;
	
		return obsPerJSObject;
	}



	public void setObsPerJSObject(String obsPerJSObject) {
		
		
	        this.obsPerJSObject = obsPerJSObject;
	}



	public int getHistorySize() {
		return historySize;
	}



	public void setHistorySize(int historySize) {
		this.historySize = historySize;
	}



	


}

