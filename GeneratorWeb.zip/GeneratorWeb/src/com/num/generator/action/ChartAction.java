package com.num.generator.action;

import java.util.Hashtable;

import com.num.generator.dataaccess.ResultHistoryEntity;
import com.opensymphony.xwork2.ActionSupport;

public class ChartAction extends ActionSupport {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String actionLineData;
	private String actionLineData2;
	private String bucketRemainderWaveData;
	private String chartTitle;
	private String buckremwavemode;
	private String inParam;
	private String historyLength;
	
	public String execute() throws Exception {
		
		return SUCCESS;
	}

	public String getActionLineData() {
		
		ResultHistoryEntity rhe = new ResultHistoryEntity();
		
		String inparm = getInParam();
		
		if (inparm.contains("brwave")) {
			setBuckremwavemode("Y");
			return getBucketRemainderWaveData();
		}
		
		if (inparm != null && inparm.length() > 0) { // Format gameCode:field
			
			rhe.setGameCode(inparm.substring(0,inparm.indexOf(":")));
			
			setChartTitle(inparm.substring(inparm.indexOf(":")+1,inparm.length()));
			
			int span = 50;
			if (getHistoryLength() != null && getHistoryLength().length() > 0) 
				span = Integer.parseInt(getHistoryLength());
				
			String rawData = rhe.getLastNForChart(getChartTitle(), span);
			
			if (getChartTitle().equalsIgnoreCase("FIRSTFIVESUM") || getChartTitle().endsWith("Freq")) {
				actionLineData = "[" + rawData + "],[" + get5MovingAvg(rawData) + "],[],[]";
			} else {
				actionLineData = "[" + rawData + "],[],[],[]";
			}
		}
		System.out.println("ChartAction: lineData " + actionLineData);
		return actionLineData;
	}

	public void setActionLineData(String lineData) {
		this.actionLineData = lineData;
	}
	
	private String get5MovingAvg(String inarr) {
		String out = "";
		String[] vals = inarr.split(",");
		
		for (int i=0; i< vals.length; i++) {
			if (i >= 4) {
				out += (Integer.parseInt(vals[i-4]) + 
						Integer.parseInt(vals[i-3]) + 
						Integer.parseInt(vals[i-2]) + 
						Integer.parseInt(vals[i-1]) + 
						Integer.parseInt(vals[i])) / 5 + ",";
			} else {
				out += Integer.parseInt(vals[i]) + ",";
			}
		}
		
		return out.substring(0, out.length()-1);
	}


	public String getInParam() {
		return inParam;
	}

	public void setInParam(String inParam) {
		this.inParam = inParam;
	}

	public String getChartTitle() {
		return chartTitle;
	}

	public void setChartTitle(String chartTitle) {
		this.chartTitle = chartTitle;
	}

	public String getHistoryLength() {
		return historyLength;
	}

	public void setHistoryLength(String historyLength) {
		this.historyLength = historyLength;
	}

	public String getBucketRemainderWaveData() {
		
		ResultHistoryEntity rhe = new ResultHistoryEntity();
		
		String inparm = getInParam();
		
		System.out.println("ChartAction.getBucketRemainderWaveData: inparm: '" + inparm + "'");
		
		if (inparm != null && inparm.length() > 0) { // Format gameCode:field
			
			rhe.setGameCode(inparm.split(":")[0]);
			int lastserial = Integer.parseInt(rhe.getValueForField("serialNumber", rhe.getGameCode(), 0));
			
			setChartTitle(inparm.split(":")[1]);
			String oedata = "";
			String oodata = "";
			String eedata = "";
			String eodata = "";
			
			int step = 10;
			
			for (int i=30; i>=0; i--) {
				
				//Data in blocks of steps
				//Hashtable<String, Integer> data = rhe.evenOddBucketRemainderInSelectedResults(getChartTitle(), 
				//									rhe.getGameCode(), (lastserial - (i+1)*step + 1), (lastserial - i*step));
				
				// Data in step of 1...
				Hashtable<String, Integer> data = rhe.evenOddBucketRemainderInSelectedResults(getChartTitle(), 
						rhe.getGameCode(), (lastserial - step - i + 1), (lastserial - i));
				
				oedata += ((data.get("OE")==null)?"0":data.get("OE")) + ",";
				oodata += ((data.get("OO")==null)?"0":data.get("OO")) + ",";
				eedata += ((data.get("EE")==null)?"0":data.get("EE")) + ",";
				eodata += ((data.get("EO")==null)?"0":data.get("EO")) + ",";
			}
						
			bucketRemainderWaveData = "[" + oedata.substring(0,oedata.length()-1) + "]" 
										+ ",["	+ oodata.substring(0,oodata.length()-1) + "]" 
										+ ",["	+ eedata.substring(0,eedata.length()-1) + "]" 
										+ ",["	+ eodata.substring(0,eodata.length()-1) + "]"
										;
			
			oedata = "";
			oodata = "";
			eedata = "";
			eodata = "";
			
			step = 30;
			for (int i=30; i>=0; i--) {
				//Data in blocks of steps
				//Hashtable<String, Integer> data = rhe.evenOddBucketRemainderInSelectedResults(getChartTitle(), 
				//									rhe.getGameCode(), (lastserial - (i+1)*step + 1), (lastserial - i*step));
				
				// Data in step of 1...
				Hashtable<String, Integer> data = rhe.evenOddBucketRemainderInSelectedResults(getChartTitle(), 
						rhe.getGameCode(), (lastserial - step - i + 1), (lastserial - i));
				
				oedata += ((data.get("OE")==null)?"0":data.get("OE")) + ",";
				oodata += ((data.get("OO")==null)?"0":data.get("OO")) + ",";
				eedata += ((data.get("EE")==null)?"0":data.get("EE")) + ",";
				eodata += ((data.get("EO")==null)?"0":data.get("EO")) + ",";
			}
						
			actionLineData2 = "[" + oedata.substring(0,oedata.length()-1) + "]" 
										+ ",["	+ oodata.substring(0,oodata.length()-1) + "]" 
										+ ",["	+ eedata.substring(0,eedata.length()-1) + "]" 
										+ ",["	+ eodata.substring(0,eodata.length()-1) + "]"
										;
			
		}
		System.out.println("ChartAction: lineData " + bucketRemainderWaveData);
		return bucketRemainderWaveData;
		
	}

	public void setBucketRemainderWaveData(String bucketRemainderWaveData) {
		this.bucketRemainderWaveData = bucketRemainderWaveData;
	}

	public String getBuckremwavemode() {
		return buckremwavemode;
	}

	public void setBuckremwavemode(String buckremwavemode) {
		this.buckremwavemode = buckremwavemode;
	}

	public String getActionLineData2() {
		return actionLineData2;
	}

	public void setActionLineData2(String actionLineData2) {
		this.actionLineData2 = actionLineData2;
	}

}
