package com.num.generator.action;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map.Entry;
import java.util.Set;

import com.num.generator.dataaccess.ObservationsEntity;
import com.num.generator.dataaccess.ResultHistoryEntity;
import com.num.generator.predic.ListUtils;
import com.opensymphony.xwork2.ActionSupport;

public class AttributeTemperatureMapAction extends ActionSupport {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String inParam;
	
	private String inAttribute;
	private String selectedGameCode;
	private String attributeValueForTemp;
	private String inputDistanceValues;
	
	private int turningPoint;
	
	private ArrayList<Integer> distanceValuesForAtt;
	private String attributeTempValueJSObj;
	
	private static Hashtable<String , String> attributeTempValueJSHash;
	
	
	public String execute() throws Exception {
		
		return SUCCESS;
	}

	
	public String getInParam() {
		return inParam;
	}


	public void setInParam(String inParam) {
		this.inParam = inParam;
	}


	public String getSelectedGameCode() {
		String inparm = getInParam();
		
		if (inparm != null && inparm.length() > 0) { // Format attribute:gameCode
			String[] splitStr = inparm.split(":");
			setSelectedGameCode(splitStr[1]);
			
			
		}
		return this.selectedGameCode;
	}

	public void setSelectedGameCode(String selectedGameCode) {
		this.selectedGameCode = selectedGameCode;
	}


	public String getInAttribute() {
		
		if (this.inAttribute == null) {
			String inparm = getInParam();
			
			System.out.println("AttributeTemperatureMapAction.getInAttribute: " + inparm);
			if (inparm != null && inparm.length() > 0) { // Format attribute:gameCode
				String[] splitStr = inparm.split(":");
				setInAttribute(splitStr[0]);
				
				
			}
		}
		return this.inAttribute;
	}


	public void setInAttribute(String inAttribute) {
		this.inAttribute = inAttribute;
	}


	public ArrayList<Integer> getDistanceValuesForAtt() {
		
		ArrayList<Integer> out = null;
		
		String inparm = getInParam();
		
		String inputdistanceVals = null; 
		
		if (inparm != null && inparm.length() > 0) { // Format attribute:gameCode:value:distancedata
			String[] splitStr = inparm.split(":");
			
			if (splitStr.length > 3) {
				inputdistanceVals = splitStr[3];
				
				ArrayList<Integer> indivvalslist = new ArrayList<Integer>();
				
				if (inputdistanceVals.startsWith("[")) {
					String removedbracks = inputdistanceVals.substring(1);
					inputdistanceVals = removedbracks.substring(0,removedbracks.length()-1);
				}
				String[] inputvals = inputdistanceVals.split(",");
				
				for (String val: inputvals) {
					if (val.length() > 0)
						indivvalslist.add(Integer.parseInt(val.trim()));
				}
				
				setDistanceValuesForAtt(indivvalslist);
			}
			
		}
		
		setInputDistanceValues(inputdistanceVals);
		
		if (inputdistanceVals == null) {
		
			out =null;
			
			ResultHistoryEntity rhe = new ResultHistoryEntity();
			
			if (getSelectedGameCode() == null)
				return out;
			else
				rhe.setGameCode(getSelectedGameCode());
			
			ArrayList<String> attributes = new ArrayList<String>();
			attributes.add(getInAttribute());
			
			Hashtable<String, Integer> distanceinput = new Hashtable<String, Integer>();
			
			distanceinput.put(getInAttribute(), Integer.parseInt(getAttributeValueForTemp()));
			
			
			LinkedHashMap<Integer, Integer> data = rhe.getDistancesDataForMultipleAttributeAndValue(distanceinput, 0);
			
			ArrayList<Integer> indivvalslist = new ArrayList<Integer>();
			
			for (Integer key : data.keySet()) {
				indivvalslist.add(data.get(key));
				
			}
			
			setDistanceValuesForAtt(indivvalslist);
			
		}
		
		
		return distanceValuesForAtt;
	}


	public void setDistanceValuesForAtt(ArrayList<Integer> attributeValues) {
		this.distanceValuesForAtt = attributeValues;
	}


	public String getAttributeTempValueJSObj() {
		
		if (attributeTempValueJSHash == null || attributeTempValueJSHash.get(getSelectedGameCode()+"|"+getInAttribute()+"|"+getAttributeValueForTemp()) == null) {
		
			ArrayList<Integer> vals= getDistanceValuesForAtt();
			
			setTurningPoint(ListUtils.computeTurningPointBasedOnMAs(vals));
			
			List<Integer> movavg3list = ListUtils.getMovingAverages(vals, 3);
			
			//System.out.println("3 MA" + movavg3list);
			
			List<Integer> movavg5list = ListUtils.getMovingAverages(vals, 5);
			
			//System.out.println("5 MA" + movavg5list);
			
			List<Integer> movavg8list = ListUtils.getMovingAverages(vals, 8);
			
			//System.out.println("8 MA" + movavg8list);
			
			 String out = "";
			 
			 int counter = 0;
				for (int entry : movavg8list) {
				     //System.out.println(entry.getKey() + "/" + entry.getValue());
					if (/*movavg8list.get(counter) > movavg5list.get(counter) && */movavg8list.get(counter) > movavg3list.get(counter))				
						out += "1" + ",";
					else if (/*movavg8list.get(counter) < movavg5list.get(counter) && */movavg8list.get(counter) < movavg3list.get(counter)) 
						out += "-1" + ",";
					else
						out += "0" + ",";
					
					counter++;
				}
			 
			 out = "[" + out.substring(0,out.length()-1) + "]";
			//System.out.println("Setting obsPerJSObject to: " + out);
			 this.attributeTempValueJSObj = out;
			 
			 attributeTempValueJSHash = new Hashtable<String, String>();
			 attributeTempValueJSHash.put(getSelectedGameCode()+"|"+getInAttribute()+"|"+getAttributeValueForTemp(), out);
			 
		} else {
			this.attributeTempValueJSObj = attributeTempValueJSHash.get(getSelectedGameCode()+"|"+getInAttribute()+"|"+getAttributeValueForTemp());
		}
	
		return attributeTempValueJSObj;
			
		
	}


	public void setAttributeTempValueJSObj(String attributeValueJSObj) {
		this.attributeTempValueJSObj = attributeValueJSObj;
	}


	public String getAttributeValueForTemp() {
		String inparm = getInParam();
		
		if (inparm != null && inparm.length() > 1) { // Format attribute:gameCode:value
			String[] splitStr = inparm.split(":");
			setAttributeValueForTemp(splitStr[2]);
			
		}
		return this.attributeValueForTemp;
	}


	public void setAttributeValueForTemp(String attributeValueForTemp) {
		this.attributeValueForTemp = attributeValueForTemp;
	}


	public int getTurningPoint() {
		return turningPoint;
	}


	public void setTurningPoint(int turningPoint) {
		this.turningPoint = turningPoint;
	}


	public String getInputDistanceValues() {
		return inputDistanceValues;
	}


	public void setInputDistanceValues(String inputDistanceValues) {
		this.inputDistanceValues = inputDistanceValues;
	}


	


}

