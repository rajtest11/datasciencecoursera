package com.num.generator.action;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map.Entry;
import java.util.Set;

import com.num.generator.dataaccess.GameTypesEntity;
import com.num.generator.dataaccess.ObservationsEntity;
import com.num.generator.dataaccess.ResultHistoryEntity;
import com.opensymphony.xwork2.ActionSupport;

public class AttributeFreqMapAction extends ActionSupport {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String inParam;
	
	private String inAttribute;
	private String selectedGameCode;
	
	private LinkedHashMap<Integer,ArrayList<Integer>> attributeValues;
	private String attributeValueJSObj;
	
	private static Hashtable<String , String> attributeValueJSHash;
	private static String lowDistanceValues; // Values of this attribute that have appeared recently - top 25% values
	
	private static String highDistanceValues; // Values of this attribute that have not appeared recently - bottom 25% values
	
	
	public String execute() throws Exception {
		
		return SUCCESS;
	}

	
	public String getInParam() {
		return inParam;
	}


	public void setInParam(String inParam) {
		this.inParam = inParam;
	}


	public String getSelectedGameCode() {
		String inparm = getInParam();
		
		if (inparm != null && inparm.length() > 0) { // Format attribute:gameCode
			String[] splitStr = inparm.split(":");
			setSelectedGameCode(splitStr[1]);
			
			
		}
		return this.selectedGameCode;
	}

	public void setSelectedGameCode(String selectedGameCode) {
		this.selectedGameCode = selectedGameCode;
	}


	public String getInAttribute() {
		String inparm = getInParam();
		
		if (inparm != null && inparm.length() > 0) { // Format attribute:gameCode
			String[] splitStr = inparm.split(":");
			setInAttribute(splitStr[0]);
			
			
		}
		return this.inAttribute;
	}


	public void setInAttribute(String inAttribute) {
		this.inAttribute = inAttribute;
	}


	public LinkedHashMap<Integer, ArrayList<Integer>> getAttributeValues() {
		LinkedHashMap<Integer, ArrayList<Integer>> out =null;
		
		ResultHistoryEntity rhe = new ResultHistoryEntity();
		
		if (getSelectedGameCode() == null)
			return out;
		else
			rhe.setGameCode(getSelectedGameCode());
		
		ArrayList<String> attributes = new ArrayList<String>();
		attributes.add(getInAttribute());
		
		out = rhe.getLastNForAttributes( attributes, 0, 0);
		
		
		
		setAttributeValues(out);
		return out;
	}


	public void setAttributeValues(
			LinkedHashMap<Integer, ArrayList<Integer>> attributeValues) {
		this.attributeValues = attributeValues;
	}


	public String getAttributeValueJSObj() {
		
		if (attributeValueJSHash == null || attributeValueJSHash.get(getSelectedGameCode()+"|"+getInAttribute()) == null) {
		
			LinkedHashMap<Integer,ArrayList<Integer>> vals=	getAttributeValues();
			
			
			 String out = "";
			 
				for (Entry<Integer, ArrayList<Integer>> entry : vals.entrySet()) {
				     //System.out.println(entry.getKey() + "/" + entry.getValue());
					out += entry.getValue().get(0) + ",";
				}
			 
			 out = "[" + out.substring(0,out.length()-1) + "]";
			// System.out.println("Setting obsPerJSObject to: " + out);
			 this.attributeValueJSObj = out;
			 
			 attributeValueJSHash = new Hashtable<String, String>();
			 attributeValueJSHash.put(getSelectedGameCode()+"|"+getInAttribute(), out);
			 
		} else {
			this.attributeValueJSObj = attributeValueJSHash.get(getSelectedGameCode()+"|"+getInAttribute());
		}
	
		return attributeValueJSObj;
			
		
	}


	public void setAttributeValueJSObj(String attributeValueJSObj) {
		this.attributeValueJSObj = attributeValueJSObj;
	}

	public  String getLowDistanceValues() {
		
		String out =null;
		
		ResultHistoryEntity rhe = new ResultHistoryEntity();
		
		if (getSelectedGameCode() == null)
			return out;
		else
			rhe.setGameCode(getSelectedGameCode());
		
		ArrayList<String> attributes = new ArrayList<String>();
		attributes.add(getInAttribute());
		
		ArrayList<String>  listOfValues = rhe.getAllValuesForAttributes(attributes, 0, false, null,null );
		
		int lastnSize = listOfValues.size()/4;
		
		if (getInAttribute().contains("megaValue")) {
			GameTypesEntity gte = new GameTypesEntity();
			gte.setGameCode(getSelectedGameCode());
			
			Collection game = gte.findRows();
			
			Iterator it = game.iterator();
					
			while (it.hasNext()) {
				GameTypesEntity thisent = (GameTypesEntity) it.next();
				lastnSize = Integer.parseInt(thisent.getMaxMegaValue())/4;
			}
		}
		out = "["+rhe.getLastNForAttribute(getInAttribute(), lastnSize, 0)+"]";
		
		//System.out.println("AttributeFreqMapAction.getLowDistanceValues: Setting lowdistanevalues: " + out);
		setLowDistanceValues(out);
		return lowDistanceValues;
	}


	public void setLowDistanceValues(String lowDistanceValues) {
		AttributeFreqMapAction.lowDistanceValues = lowDistanceValues;
	}


	public String getHighDistanceValues() {
		
		String out =null;
		
		ResultHistoryEntity rhe = new ResultHistoryEntity();
		
		if (getSelectedGameCode() == null)
			return out;
		else
			rhe.setGameCode(getSelectedGameCode());
		
		ArrayList<String> attributes = new ArrayList<String>();
		attributes.add(getInAttribute());
		
		ArrayList<String>  listOfValues = rhe.getAllValuesForAttributes(attributes, 0, false, null,null );
		
		int lastnSize = listOfValues.size()/4;
		
		if (getInAttribute().contains("megaValue")) {
			GameTypesEntity gte = new GameTypesEntity();
			gte.setGameCode(getSelectedGameCode());
			
			Collection game = gte.findRows();
			
			Iterator it = game.iterator();
					
			while (it.hasNext()) {
				GameTypesEntity thisent = (GameTypesEntity) it.next();
				lastnSize = Integer.parseInt(thisent.getMaxMegaValue())/4;
			}
		}
		out = "["+rhe.getHighDistanceValuesForAttribute(getInAttribute(), lastnSize, 0)+"]";
		
		//System.out.println("AttributeFreqMapAction.getLowDistanceValues: Setting lowdistanevalues: " + out);
		setHighDistanceValues(out);
		return highDistanceValues;
	}


	public static void setHighDistanceValues(String highDistanceValues) {
		AttributeFreqMapAction.highDistanceValues = highDistanceValues;
	}




}

