package com.num.generator.action;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Hashtable;
import java.util.LinkedHashMap;

import com.num.generator.dataaccess.ResultHistoryEntity;
import com.opensymphony.xwork2.ActionSupport;

public class AttributeCurrentDistanceIndivValueAction extends ActionSupport {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String selectedGameCode;
	private String  distanceAttributesList;
	private String  distanceAttributeValues;
	
	LinkedHashMap<Integer,Integer> curAttValGamedata;
	
	public String getSelectedGameCode() {
		//System.out.println("In AttributeCurrentDistanceIndivValueAction: selectedGameCode " + selectedGameCode);
		return selectedGameCode;
	}
	public void setSelectedGameCode(String selectedGameCode) {
		this.selectedGameCode = selectedGameCode;
	}
	public String getDistanceAttributesList() {
		return distanceAttributesList;
	}
	public void setDistanceAttributesList(String distanceAttributesList) {
		this.distanceAttributesList = distanceAttributesList;
	}
	
	public String execute() throws Exception {
		return SUCCESS;
	}
	public LinkedHashMap<Integer,Integer> getCurAttValGamedata() {
		
		ResultHistoryEntity rhe = new ResultHistoryEntity();
		rhe.setGameCode(getSelectedGameCode());
		
		String[] attriblist = distanceAttributesList.split(",");
		String[] vals = distanceAttributeValues.split(",");
		
		//System.out.println("In AttributeCurrentDistanceIndivValueAction: attributes " + Arrays.asList(attriblist));
		//System.out.println("In AttributeCurrentDistanceIndivValueAction: values " + Arrays.asList(vals));
		
		Hashtable<String,Integer> distanceinput = new Hashtable<String, Integer>();
		
		int p = 0;
		for (String att: attriblist) {
			distanceinput.put(att, Integer.parseInt(vals[p]));
			p++;
		}
		
		curAttValGamedata = rhe.getDistancesDataForMultipleAttributeAndValue(distanceinput, 0);
		
		return curAttValGamedata;
	}
	
	public void setCurAttValGamedata(
			LinkedHashMap<Integer,Integer> curgamedata) {
		this.curAttValGamedata = curgamedata;
	}
	public String getDistanceAttributeValues() {
		return distanceAttributeValues;
	}
	public void setDistanceAttributeValues(String distanceAttributeValues) {
		this.distanceAttributeValues = distanceAttributeValues;
	}

}
