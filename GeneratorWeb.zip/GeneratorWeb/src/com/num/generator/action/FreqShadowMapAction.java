package com.num.generator.action;

import java.util.Hashtable;

import com.num.generator.dataaccess.CurrentStateEntity;
import com.num.generator.dataaccess.GameTypesEntity;
import com.opensymphony.xwork2.ActionSupport;

public class FreqShadowMapAction extends ActionSupport {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String inParam;
	
	private String inAttribute;
	private String selectedGameCode;
	
	private String attributeValueJSObj;
	
	private static Hashtable<String , String> attributeValueJSHash;
	private  String freqShadow1list; // Numbers that are in 0-1 of the last results freqs
	
	private  String freqShadow3list; // Numbers that are in 2-3 of the last results freqs
	
	private  String maxNum; // Max number in this game
	
	
	public String execute() throws Exception {
		
		return SUCCESS;
	}

	
	public String getInParam() {
		return inParam;
	}


	public void setInParam(String inParam) {
		this.inParam = inParam;
	}


	public String getSelectedGameCode() {
		String inparm = getInParam();
		
		if (inparm != null && inparm.length() > 0) { // Format attribute:gameCode
			String[] splitStr = inparm.split(":");
			setSelectedGameCode(splitStr[1]);
			
			
		}
		return this.selectedGameCode;
	}

	public void setSelectedGameCode(String selectedGameCode) {
		this.selectedGameCode = selectedGameCode;
	}


	public String getMaxNum() {
		
		GameTypesEntity gte = new GameTypesEntity();
		gte.setGameCode(getSelectedGameCode());
		
		for (Object e: gte.findRows()) {
			setMaxNum(((GameTypesEntity)e).getMaximumValue());
		}
		return maxNum;
	}


	public void setMaxNum(String maxNum) {
		this.maxNum = maxNum;
	}


	public String getInAttribute() {
		String inparm = getInParam();
		
		if (inparm != null && inparm.length() > 0) { // Format attribute:gameCode
			String[] splitStr = inparm.split(":");
			setInAttribute(splitStr[0]);
			
			
		}
		return this.inAttribute;
	}


	public void setInAttribute(String inAttribute) {
		this.inAttribute = inAttribute;
	}

	public  String getFreqShadow1list() {
		
		CurrentStateEntity cs = new CurrentStateEntity();
		cs.setGameCode(getSelectedGameCode());
				
		return cs.getValuesInFreqShadow(getSelectedGameCode(), "FF", 1);
	}


	

	public  String getFreqShadow3list() {
		CurrentStateEntity cs = new CurrentStateEntity();
		cs.setGameCode(getSelectedGameCode());
		
		
		return cs.getValuesInFreqShadow(getSelectedGameCode(), "FF", 3);
	}


	

	public String getAttributeValueJSObj() {
		
		if (attributeValueJSHash == null || attributeValueJSHash.get(getSelectedGameCode()+"|"+getInAttribute()) == null) {
		 String out = "";
			 
				out += "{";
				
				out += "One:[";				
				out += getFreqShadow1list();				
				out += "],";
				
				out += "Three:[";				
				out += getFreqShadow3list();				
				out += "],";
				
				out += "MaxForGame:";				
				out += getMaxNum();				
				out += "";
				
				out += "}";
			 
			 System.out.println("Setting obsPerJSObject to: " + out);
			 this.attributeValueJSObj = out;
			 
			 attributeValueJSHash = new Hashtable<String, String>();
			 attributeValueJSHash.put(getSelectedGameCode()+"|"+getInAttribute(), out);
			 
		} else {
			System.out.println("Got obsPerJSObject from cache for : " + getSelectedGameCode()+"|"+getInAttribute());
			this.attributeValueJSObj = attributeValueJSHash.get(getSelectedGameCode()+"|"+getInAttribute());
		}
	
		return attributeValueJSObj;
			
		
	}


	public void setAttributeValueJSObj(String attributeValueJSObj) {
		this.attributeValueJSObj = attributeValueJSObj;
	}

	


}

