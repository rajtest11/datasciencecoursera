package com.num.generator.action;

import com.opensymphony.xwork2.ActionSupport;

public class LinkAction extends ActionSupport {

	private static final long serialVersionUID = -1L;
	
	public String welcome() {
		return "welcome";
	}

	public String first()
	{
		return "first";		
	}
	
	public String second()
	{
		return "second";		
	}
	
	public String third()
	{
		return "third";		
	}
	
	public String fourth()
	{
		return "fourth";		
	}
	
	public String fifth()
	{
		return "fifth";		
	}
	
	public String mega()
	{
		return "mega";		
	}
	public String aggregate()
	{
		return "aggregate";		
	}
	
	public String observation()
	{
		return "observation";		
	}
	
	public String criteriaResult()
	{
		return "criteriaResult";		
	}
	
	public String distance()
	{
		return "distance";		
	}
	
	
	
}