package com.num.generator.action;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.num.generator.LoadObservations;
import com.num.generator.dataaccess.CriteriaEntity;
import com.opensymphony.xwork2.ActionSupport;

public class AjaxActions extends ActionSupport{

    private String name;
    private String date;
    private String numbers;
    private String gameCode;
    
	private String dataFromForm;
    private List<String> countryList;
    private Map<String,Long> countryMap;

    public String sayHi(){
        
        dataFromForm="Date " +date + " Numbers " + numbers;
        
        //System.out.println(dataFromForm);
        if (numbers.length() > 0)
        	LoadObservations.loadData(date, numbers);
        
        countryList=new ArrayList();
        countryList.add("US");
        countryList.add("UK");
        countryList.add("Russia");

        countryMap= new HashMap();
        countryMap.put("US",1L);
        countryMap.put("UK",2L);
        countryMap.put("Russia",3L);

        return ActionSupport.SUCCESS;
    }
    
	public String clearCriteriaResults() {
		dataFromForm = "Clearing criteria and results for Date " + date
				+ " GameCode " + gameCode;

		System.out.println(dataFromForm);

		if (date != null && gameCode != null) {

			CriteriaEntity ce = new CriteriaEntity();
			ce.clearCriteria(gameCode, date);
		}

		System.out.println("Done.");
		return ActionSupport.SUCCESS;
	}

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    
    public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getNumbers() {
		return numbers;
	}

	public void setNumbers(String numbers) {
		this.numbers = numbers;
	}

    public String getGreeting() {
        return dataFromForm;
    }

    public void setGreeting(String greeting) {
        this.dataFromForm = greeting;
    }

    public List<String> getCountryList() {
        return countryList;
    }

    public void setCountryList(List<String> countryList) {
        this.countryList = countryList;
    }

    public Map<String, Long> getCountryMap() {
        return countryMap;
    }
    
    public String getGameCode() {
		return gameCode;
	}

	public void setGameCode(String gameCode) {
		this.gameCode = gameCode;
	}


}
