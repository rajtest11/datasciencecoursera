package com.num.generator.action;

import com.opensymphony.xwork2.ActionSupport;

public class MineResultsAction extends ActionSupport {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String inParam;
	
	private String selectedGameCode;
	private String selectedTargetDate;
	
	
	public String execute() throws Exception {
		
		return SUCCESS;
	}

	

	public String getInParam() {
		return inParam;
	}

	public void setInParam(String inParam) {
		this.inParam = inParam;
	}



	public String getSelectedGameCode() {
		String inparm = getInParam();
		
		if (inparm != null && inparm.length() > 0) { // Format gameCode:targetDate
			
			setSelectedGameCode(inparm.substring(0,inparm.indexOf(":")));
			
			
		}
		return this.selectedGameCode;
	}



	public void setSelectedGameCode(String selectedGameCode) {
		this.selectedGameCode = selectedGameCode;
	}



	public String getSelectedTargetDate() {
		String inparm = getInParam();
		
		if (inparm != null && inparm.length() > 0) { // Format gameCode:targetDate
	
			setSelectedTargetDate(inparm.substring(inparm.indexOf(":")+1,inparm.length()));
			
		}
		return this.selectedTargetDate;
	}



	public void setSelectedTargetDate(String selectedTargetDate) {
		this.selectedTargetDate = selectedTargetDate;
	}

	


}
