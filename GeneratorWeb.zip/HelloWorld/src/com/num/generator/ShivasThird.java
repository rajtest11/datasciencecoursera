package com.num.generator;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;
import java.util.Set;

import com.google.common.collect.Sets;
import com.google.common.collect.Sets.SetView;
import com.num.generator.dataaccess.AggregateRanksEntity;
import com.num.generator.dataaccess.CriteriaEntity;
import com.num.generator.dataaccess.GameBucketEntity;
import com.num.generator.dataaccess.GameTypesEntity;
import com.num.generator.dataaccess.MissingDigitsEntity;
import com.num.generator.dataaccess.ResultHistoryEntity;
import com.num.generator.predic.CreateDBPredicFile;
import com.num.generator.predic.ProcessIndivDBPredicFile;

public class ShivasThird {

	private static String forDate = "0610"; // Mandatory
	private static String gameType = "2"; // 1- MM, 2 - PB -- Mandatory
	private static int gStartSum = 90;
	private static int gEndSum = 190;

	private static Generator g = null;
	private static String gameCode = null;
	private static GameTypesEntity gte = null; 
	private static ResultHistoryEntity rhe = new ResultHistoryEntity();
	private static String fileName = null;
	static Properties DBpredicProp = new Properties();
	private static List attributes = null;
	private static List savedattributes;
	private static int iteration = 0;
	private static String obsCountRange = "";

	public static void main(String[] args) {

		long start = System.currentTimeMillis();

		if (gameCode == null) {
			gte = new GameTypesEntity();
			gte.setGameCode(gameType);

			Iterator itg = (gte.findRows()).iterator();

			if (itg.hasNext()) {
				gte = (GameTypesEntity) itg.next();
				gameCode = gte.getProgramCode();
			}
		}

		// CREATE GAME BUCKET RANKS
		/*
		 * GameBucketEntity gb = new GameBucketEntity();
		 * gb.populateGameBuckets(gameType);
		 * 
		 * // CREATE MISSING DIGITS MissingDigitsEntity mde = new
		 * MissingDigitsEntity(); //mde.populateMissingDigits(gameType); //
		 * CREATE OTHER AGGREGATE RANKS FIRST
		 * 
		 * AggregateRanksEntity agr = new AggregateRanksEntity();
		 * agr.populateMissingDigitRanks(gameType);
		 * agr.populateFollowerMapRanks(gameType);
		 * agr.populateMaxFactorRanks(gameType);
		 * //agr.populateSkipSumRanks(gameType);
		 */

		String userinput = null;
		System.out.println("Starting run for gamecode" + gameType
				+ " targetDate " + forDate);

		System.out.println(getSumLoops());
		System.out.println("Reuse existing configs? : y/n");

		try {
			BufferedReader bufferRead = new BufferedReader(
					new InputStreamReader(System.in));
			userinput = bufferRead.readLine();

		} catch (IOException e) {
			e.printStackTrace();
		}

		if (!userinput.toUpperCase().startsWith("N")
				&& !userinput.toUpperCase().startsWith("Y")) {
			System.out.println("Invalid command: " + userinput + " Exiting..");
			return;
		}

		if (userinput.toUpperCase().startsWith("N")) {

			// CREATE DB PREDICTIONS

			rhe.setGameCode(gameType);

			CreateDBPredicFile.setInGameCode(gameType);
			CreateDBPredicFile.setNextDate(forDate);
			CreateDBPredicFile.setUseSerial(Integer.parseInt(rhe.getLastNForAttribute(
					"serialNumber", 1, 0)));
			CreateDBPredicFile.setSuppressVerboseOut(true);

			System.out
					.println("Enter observation period if different from 10 days, else press enter ");

			try {
				BufferedReader bufferRead = new BufferedReader(
						new InputStreamReader(System.in));
				userinput = bufferRead.readLine();

			} catch (IOException e) {
				e.printStackTrace();
			}

			if (userinput.length() > 0)
				CreateDBPredicFile.setObsPeriod(Integer.parseInt(userinput));

			CreateDBPredicFile.main(null);

			System.out.println(" Clean DB predic files before proceeding");
			System.out.println("Enter Y to proceed : ");

			try {
				BufferedReader bufferRead = new BufferedReader(
						new InputStreamReader(System.in));
				userinput = bufferRead.readLine();

			} catch (IOException e) {
				e.printStackTrace();
			}

			if (!userinput.toUpperCase().startsWith("Y")) {
				System.out.println("Invalid command: " + userinput);
				return;
			}

			// PROCESS INDIV PREDICTIONS NOW AND CREATE POSSIBLE LISTS

			ProcessIndivDBPredicFile.setInGameCode(gameType);
			ProcessIndivDBPredicFile.setNextDate(forDate);
			ProcessIndivDBPredicFile.main(null);

			// WAIT FOR POSSIBLE LISTS TO BE CLEANED

			System.out
					.println(" Clean it before proceeding. Remove entries for Mega numbers.");
			System.out.println(" Set up props.properties.");
			System.out.println("Enter Y to proceed : ");

			try {
				BufferedReader bufferRead = new BufferedReader(
						new InputStreamReader(System.in));
				userinput = bufferRead.readLine();

			} catch (IOException e) {
				e.printStackTrace();
			}

			if (!userinput.toUpperCase().startsWith("Y")) {
				System.out.println("Invalid command: " + userinput
						+ " Exiting..");
				return;
			}

		}

		// // PROCESS AGGREGATE PREDICTIONS NOW
		if (fileName == null)
			fileName = "C:\\eclipse\\workspace\\first\\Pred\\PredFor" + forDate
					+ "-" + gameCode.toUpperCase();

		FileInputStream fis;

		try {
			fis = new FileInputStream(new File(fileName));
			// "C:\\eclipse\\workspace\\first\\Pred\\PredFor" + nextDate + "-"+
			// getInPrgCode().toUpperCase()
			DBpredicProp.load(fis);

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return;
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return;
		}

		Generator.setForDate(forDate);
		Generator.startSum = gStartSum;
		Generator.endSum = gStartSum + 20;

		Generator gen = new Generator(); // Needed to initialize statics

		if (attributes == null) {
			attributes = Arrays.asList(DBpredicProp.keySet().toArray());
		}

		// for (int i=0; i<3; i++) {
		String thisAttrib = "";

		Properties tempDBpredicProp = new Properties();
		Properties tempNOTDBpredicProp = new Properties();

		Iterator attIt = null;
		if (attributes.size() > 0)
			attIt = attributes.iterator();

		while (attIt.hasNext()) {

			String attName = ((String) attIt.next()).toUpperCase();
			String value = (DBpredicProp.getProperty(attName) == null) ? ""
					: DBpredicProp.getProperty(attName);
			// If we want to avoid an attribute being run with ON and OFF
			// scenario, we put an 'F' (Force)
			// in the end of the attribute e.g.
			// FIRSTFIVESUM=NOT[78,99,102,112]F
			if (!attName.startsWith("OBS") && !attName.startsWith("MATCH")
					&& value.length() > 0 && !value.endsWith("F")) {

				value = value.replace("NOT", "");

				tempDBpredicProp.setProperty(attName, value);

				value = "NOT" + value;

				tempNOTDBpredicProp.setProperty("NOT " + attName, value);

			}
		}

		savedattributes = attributes;
		// String[] tmpentryarr = tempDBpredicProp.toArray(new String[0]);
		// String[] tmpnotentryarr = tempNOTDBpredicProp.toArray(new String[0]);

		Set<Object> tmpNOTentries = tempNOTDBpredicProp.keySet();
		Set<Object> tmpentries = tempDBpredicProp.keySet();
		// Set<List<Object>> allpossibleChoices =
		// Sets.cartesianProduct(tmpNOTentries,tmpentries);
		// Set<List<List<Object>>> furtherCart =
		// Sets.cartesianProduct(allpossibleChoices, allpossibleChoices);

		if (tmpentries.size() == 0) {
			System.out.println("No attributes to iterate over -- terminating run.");
			return;
		}

		SetView<Object> union = Sets.union(tmpNOTentries, tmpentries);

		String[] entryUnionArray = union.toArray(new String[0]);
		// Set<String> availableEntries = ImmutableSet.of(tmpentryarr);
		Set<String> uniqueAttribs = new HashSet<String>();
		Set<String> uniqueAttribsForSizeMatch = new HashSet<String>();

		// Generate cartesian product of elements and NOT elements
		int choices = tmpentries.size();
		int[] comb = new int[choices];
		String[] comblocal = new String[choices];

		for (int j = 0; j < choices; j++) {

			comb[j] = j;
			comblocal[j] = entryUnionArray[comb[j]];
			uniqueAttribs.add(comblocal[j].replace("NOT ", ""));
			uniqueAttribsForSizeMatch.add(comblocal[j].replace("NOT ", "")
					.replace(thisAttrib, ""));
		}

		if (uniqueAttribsForSizeMatch.size() == choices) {

			int step = 0;
			int startSum = gStartSum;
			int endSum = gEndSum;

			while (startSum < endSum) {
				
				//System.out.println("Start = " + startSum + " end = " + (startSum + getNextStepSize(startSum)));
				Generator.startSum = startSum + 1;
				Generator.endSum = startSum + getNextStepSize(startSum);

				processThisUniqueListOfAttribs(uniqueAttribs, comblocal);
				startSum = startSum + getNextStepSize(startSum);

			}

		}

		int maxValue = entryUnionArray.length;
		while (next_comb(comb, choices, maxValue)) {
			uniqueAttribs = new HashSet<String>();
			uniqueAttribsForSizeMatch = new HashSet<String>();

			for (int j = 0; j < choices; j++) {

				// comb[i] = i;
				comblocal[j] = entryUnionArray[comb[j]];

				uniqueAttribs.add(comblocal[j].replace("NOT ", ""));
				uniqueAttribsForSizeMatch.add(comblocal[j].replace("NOT ", "")
						.replace(thisAttrib, ""));
			}

			if (uniqueAttribsForSizeMatch.size() == choices) {

				int step = 0;
				int startSum = gStartSum;
				int endSum = gEndSum;

				while (startSum < endSum) {
					
					// System.out.println("Start = " + startSum + " end = " +	 (startSum + getNextStepSize(startSum)));
					Generator.startSum = startSum + 1;
					Generator.endSum = startSum + getNextStepSize(startSum);

					processThisUniqueListOfAttribs(uniqueAttribs, comblocal);
					startSum = startSum + getNextStepSize(startSum);

				}
			}
			attributes = savedattributes;

		}

		System.out.println("Completed run for gamecode" + gameType
				+ " targetDate " + forDate);

	}

	private static void processThisUniqueListOfAttribs(
			Set<String> uniqueAttribs, String[] comblocal) {

		boolean untouched = true;
		// System.out.println(Arrays.toString(comblocal));

		String obslist = DBpredicProp.getProperty("OBSLIST");
		int maxObsCounter = 5; // Running up to 4 obscount
		int minObsCounter = 0;

		int[] obsCounters = null;

		if (obslist != null && obslist.length() > 0) {

			int startInd = obslist.indexOf("[") + 1;
			if (startInd > 0) {
				String val = obslist.substring(startInd, obslist.indexOf("]"));
				String[] valA = val.split("\\,");
				List lis = (List) Arrays.asList(valA);

				if (lis.size() < 5)
					maxObsCounter = lis.size() + 1;

				String obsinccount = DBpredicProp
						.getProperty("OBSINCLUDECOUNT");

				if (obsinccount.length() == 0) {
					/*
					 * if (lis.size() > 15) minObsCounter = 1;
					 * 
					 * if (lis.size() > 20) minObsCounter = 2;
					 * 
					 * if (lis.size() > 30) minObsCounter = 3;
					 * 
					 * if (lis.size() > 35) minObsCounter = 4;
					 */
				} else {
					if (obsinccount.indexOf(",") > 0) {
						String[] obs = obsinccount.split("\\,");
						obsCounters = new int[obs.length];

						for (int x = 0; x < obs.length; x++) {
							obsCounters[x] = Integer.parseInt(obs[x]);
						}

						if (obsCountRange.length() == 0)
							obsCountRange = obsinccount;

					} else {

						minObsCounter = Integer.parseInt(obsinccount);

					}
				}

			}

			if (obsCounters == null || obsCounters.length == 0) {
				obsCounters = new int[maxObsCounter - minObsCounter + 1];

				for (int x = 0; x < obsCounters.length; x++) {
					obsCounters[x] = minObsCounter + x;
				}
				obsCountRange = minObsCounter + "-" + (maxObsCounter);
			}
		}
		
		String[] gapsCounter = {"Y", "N"};
		String[] diffsCounter = {"Y", "N"};
		
		if (DBpredicProp.getProperty("MATCH3GAPS") != null &&  DBpredicProp.getProperty("MATCH3GAPS").endsWith("F")) {
			gapsCounter = new String[1];
			gapsCounter[0] = DBpredicProp.getProperty("MATCH3GAPS").replaceAll("F", "");
		}
		
		if ( DBpredicProp.getProperty("MATCH3DIFFS") != null && DBpredicProp.getProperty("MATCH3DIFFS").endsWith("F")) {
			diffsCounter = new String[1];
			diffsCounter[0] = DBpredicProp.getProperty("MATCH3DIFFS").replaceAll("F", "");
		}

		for (int match3gaps = 0; match3gaps < gapsCounter.length; match3gaps++) { // RUN
																// THIS
																// FOR Y
																// AND N
																// -- 0
																// Y, 1
																// N
			for (int match3diffs = 0; match3diffs < diffsCounter.length; match3diffs++) { // RUN
																		// THIS
																		// FOR Y
																		// AND N
																		// -- 0
																		// Y, 1
																		// N

				for (int q = 0; q < obsCounters.length; q++) { // RUN
																// THIS
																// FOR
																// OBSINCLUDE
																// 0
																// -
																// 5
																// or
																// the
																// size
																// of
																// obslist
																// if
																// less
																// than
																// 5

					int obs = obsCounters[q];

					DBpredicProp.setProperty("OBSINCLUDECOUNT",
							Integer.toString(obs));

					/*if (DBpredicProp.getProperty("MATCH3DIFFS").startsWith("Y")
							&& match3diffs == 1) {
						DBpredicProp.setProperty("MATCH3DIFFS", "N");
						untouched = false;
					}

					if (DBpredicProp.getProperty("MATCH3DIFFS").startsWith("N")
							&& match3diffs == 0) {
						DBpredicProp.setProperty("MATCH3DIFFS", "Y");
						untouched = false;
					}*/
					DBpredicProp.setProperty("MATCH3DIFFS", diffsCounter[match3diffs]);
					DBpredicProp.setProperty("MATCH3GAPS", gapsCounter[match3gaps]);

					for (int u = 0; u < comblocal.length; u++) {
						if (comblocal[u].startsWith("NOT")
								&& !DBpredicProp.getProperty(
										comblocal[u].replace("NOT ", ""))
										.contains("NOT")) {
							String oldvalue = DBpredicProp
									.getProperty(comblocal[u].replace("NOT ",
											""));

							DBpredicProp.setProperty(
									comblocal[u].replace("NOT ", ""), "NOT"
											+ oldvalue);
							untouched = false;

						}

						if (!comblocal[u].startsWith("NOT")
								&& DBpredicProp.getProperty(comblocal[u])
										.contains("NOT")) {
							String oldvalue = DBpredicProp
									.getProperty(comblocal[u]);

							DBpredicProp.setProperty(comblocal[u],
									oldvalue.replace("NOT", ""));
							untouched = false;

						}
					}

					attributes = new ArrayList(Arrays.asList(uniqueAttribs
							.toArray(new String[0])));

					System.out.println("Running iteration "
							+ (iteration + 1)
							+ " of "
							+ (Math.pow(2, comblocal.length) * diffsCounter.length * gapsCounter.length
									* (obsCounters.length) * (getSumLoops()))
							+ " -- " + Arrays.toString(comblocal)
							+ " Match3diffs "
							+ (DBpredicProp.getProperty("MATCH3DIFFS"))
							+ " Match3Gaps "
							+ (DBpredicProp.getProperty("MATCH3GAPS"))
							+ " -- OBSCOUNT " + (obs) + " of " + obsCountRange);
					// System.out.println(Generator.startSum + " " +
					// Generator.endSum);

					// / TODO: CALL GENERATOR HERE
					Generator.currentCriteria = new CriteriaEntity();
					Generator.setDBpredicProp(DBpredicProp);
					Generator.unlikelyBucketSpan = 500;
					Generator.main(new String[0]);

					iteration++;
					try {
						FileInputStream fis = new FileInputStream(new File(
								fileName));
						// "C:\\eclipse\\workspace\\first\\Pred\\PredFor" +
						// nextDate + "-"+
						// getInPrgCode().toUpperCase()
						DBpredicProp.load(fis);

					} catch (FileNotFoundException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			}
		}

	}

	static boolean next_comb(int comb[], int k, int n) {

		int i = k - 1;

		comb[i]++;

		while (i > 0 && (comb[i] >= n - k + 1 + i)) {
			i--;
			comb[i]++;
		}

		if (comb[0] > n - k) /* Combination (n-k, n-k+1, ..., n) reached */
			return false; /* No more combinations can be generated */

		/*
		 * comb now looks like (..., x, n, n, n, ..., n).
		 * 
		 * Turn it into (..., x, x + 1, x + 2, ...)
		 */

		for (i = i + 1; i < k && i > 0; i++)
			comb[i] = comb[i - 1] + 1;

		return true;

	}

	private static int getSumLoops() {
		int loops = 0;

		int startSum = gStartSum;
		int endSum = gEndSum;
		int step = 0;

		while (startSum < endSum) {
			
			// System.out.println("Start = " + startSum + " end = " +
			// (startSum+step));
			startSum = startSum + getNextStepSize(startSum);
			loops++;
		}

		return loops;

	}
	
	private static int getNextStepSize(int startSum) {
		
		int step = 0;
		
		if (startSum < 100)
			step = 20;
		if (startSum >= 100 && startSum <= 130)
			step = 10;
		if (startSum > 130 && startSum <= 170)
			step = 5;
		if (startSum > 170 && startSum <= 200)
			step = 10;
		if (startSum > 200)
			step = 30;
		if (startSum > 250)
			step = 50;

		return step;
	}

}
