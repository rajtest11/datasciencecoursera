package com.num.generator.dataaccess;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Hashtable;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;

public class ResultsWithinLastN extends Base {
	
	private String gameCode;
	private String serialNumber;
	private String withinLast;
	private String firstFiveSum;
	private String firstValue;
	private String  secondValue;
	private String thirdValue;
	private String fourthValue;
	private String fifthValue;
	private String megaValue;
	private String firstSkip;
	private String secondSkip;
	private String thirdSkip;
	private String  fourthSkip;
	private String fifthSkip;
	private String megaSkip;
	private String  firstRedux;
	private String secondRedux;
	private String thirdRedux;
	private String fourthRedux;
	private String fifthRedux;
	private String megaRedux;
	private String firstFiveSumRedux;
	private String firstBucket;
	private String secondBucket;
	private String  thirdBucket;
	private String fourthBucket;
	private String fifthBucket; 
	private String megaBucket;
	private String firstFiveSumBucket;
	private String firstPrime;
	private String secondPrime;
	private String thirdPrime;
	private String fourthPrime;
	private String fifthPrime;
	private String numPrimes;
	private String  megaPrime;
	private String firstFiveSumPrime;
	private String firstFollower;
	private String secondFollower;
	private String thirdFollower;
	private String fourthFollower;
	private String fifthFollower;
	private String megaFollower;

	public static ConcurrentHashMap withinNData = new ConcurrentHashMap();

	public String getFirstFiveSumBucket() {
		return firstFiveSumBucket;
	}

	public void setFirstFiveSumBucket(String firstFiveSumBucket) {
		this.firstFiveSumBucket = firstFiveSumBucket;
	}

	public String getGameCode() {
		return gameCode;
	}

	public void setGameCode(String gameCode) {
		this.gameCode = gameCode;
	}

	public String getSerialNumber() {
		return serialNumber;
	}

	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}

	public String getWithinLast() {
		return withinLast;
	}

	public void setWithinLast(String withinLast) {
		this.withinLast = withinLast;
	}

	public String getFirstFiveSum() {
		return firstFiveSum;
	}

	public void setFirstFiveSum(String firstFiveSum) {
		this.firstFiveSum = firstFiveSum;
	}

	public String getFirstValue() {
		return firstValue;
	}

	public void setFirstValue(String firstValue) {
		this.firstValue = firstValue;
	}

	public String getSecondValue() {
		return secondValue;
	}

	public void setSecondValue(String secondValue) {
		this.secondValue = secondValue;
	}

	public String getThirdValue() {
		return thirdValue;
	}

	public void setThirdValue(String thirdValue) {
		this.thirdValue = thirdValue;
	}

	public String getFourthValue() {
		return fourthValue;
	}

	public void setFourthValue(String fourthValue) {
		this.fourthValue = fourthValue;
	}

	public String getFifthValue() {
		return fifthValue;
	}

	public void setFifthValue(String fifthValue) {
		this.fifthValue = fifthValue;
	}

	public String getMegaValue() {
		return megaValue;
	}

	public void setMegaValue(String megaValue) {
		this.megaValue = megaValue;
	}

	public String getFirstSkip() {
		return firstSkip;
	}

	public void setFirstSkip(String firstSkip) {
		this.firstSkip = firstSkip;
	}

	public String getSecondSkip() {
		return secondSkip;
	}

	public void setSecondSkip(String secondSkip) {
		this.secondSkip = secondSkip;
	}

	public String getThirdSkip() {
		return thirdSkip;
	}

	public void setThirdSkip(String thirdSkip) {
		this.thirdSkip = thirdSkip;
	}

	public String getFourthSkip() {
		return fourthSkip;
	}

	public void setFourthSkip(String fourthSkip) {
		this.fourthSkip = fourthSkip;
	}

	public String getFifthSkip() {
		return fifthSkip;
	}

	public void setFifthSkip(String fifthSkip) {
		this.fifthSkip = fifthSkip;
	}

	public String getMegaSkip() {
		return megaSkip;
	}

	public void setMegaSkip(String megaSkip) {
		this.megaSkip = megaSkip;
	}

	public String getFirstRedux() {
		return firstRedux;
	}

	public void setFirstRedux(String firstRedux) {
		this.firstRedux = firstRedux;
	}

	public String getSecondRedux() {
		return secondRedux;
	}

	public void setSecondRedux(String secondRedux) {
		this.secondRedux = secondRedux;
	}

	public String getThirdRedux() {
		return thirdRedux;
	}

	public void setThirdRedux(String thirdRedux) {
		this.thirdRedux = thirdRedux;
	}

	public String getFourthRedux() {
		return fourthRedux;
	}

	public void setFourthRedux(String fourthRedux) {
		this.fourthRedux = fourthRedux;
	}

	public String getFifthRedux() {
		return fifthRedux;
	}

	public void setFifthRedux(String fifthRedux) {
		this.fifthRedux = fifthRedux;
	}

	public String getMegaRedux() {
		return megaRedux;
	}

	public void setMegaRedux(String megaRedux) {
		this.megaRedux = megaRedux;
	}

	public String getFirstFiveSumRedux() {
		return firstFiveSumRedux;
	}

	public void setFirstFiveSumRedux(String firstFiveSumRedux) {
		this.firstFiveSumRedux = firstFiveSumRedux;
	}

	public String getFirstBucket() {
		return firstBucket;
	}

	public void setFirstBucket(String firstBucket) {
		this.firstBucket = firstBucket;
	}

	public String getSecondBucket() {
		return secondBucket;
	}

	public void setSecondBucket(String secondBucket) {
		this.secondBucket = secondBucket;
	}

	public String getThirdBucket() {
		return thirdBucket;
	}

	public void setThirdBucket(String thirdBucket) {
		this.thirdBucket = thirdBucket;
	}

	public String getFourthBucket() {
		return fourthBucket;
	}

	public void setFourthBucket(String fourthBucket) {
		this.fourthBucket = fourthBucket;
	}

	public String getFifthBucket() {
		return fifthBucket;
	}

	public void setFifthBucket(String fifthBucket) {
		this.fifthBucket = fifthBucket;
	}

	public String getMegaBucket() {
		return megaBucket;
	}

	public void setMegaBucket(String megaBucket) {
		this.megaBucket = megaBucket;
	}

	public static ConcurrentHashMap getWithinNData() {
		return withinNData;
	}

	public static void setWithinNData(ConcurrentHashMap withinNData) {
		ResultsWithinLastN.withinNData = withinNData;
	}

	
	public String getFirstPrime() {
		return firstPrime;
	}

	public void setFirstPrime(String firstPrime) {
		this.firstPrime = firstPrime;
	}

	public String getSecondPrime() {
		return secondPrime;
	}

	public void setSecondPrime(String secondPrime) {
		this.secondPrime = secondPrime;
	}

	public String getThirdPrime() {
		return thirdPrime;
	}

	public void setThirdPrime(String thirdPrime) {
		this.thirdPrime = thirdPrime;
	}

	public String getFourthPrime() {
		return fourthPrime;
	}

	public void setFourthPrime(String fourthPrime) {
		this.fourthPrime = fourthPrime;
	}

	public String getFifthPrime() {
		return fifthPrime;
	}

	public void setFifthPrime(String fifthPrime) {
		this.fifthPrime = fifthPrime;
	}

	public String getNumPrimes() {
		return numPrimes;
	}

	public void setNumPrimes(String numPrimes) {
		this.numPrimes = numPrimes;
	}

	public String getMegaPrime() {
		return megaPrime;
	}

	public void setMegaPrime(String megaPrime) {
		this.megaPrime = megaPrime;
	}

	public String getFirstFiveSumPrime() {
		return firstFiveSumPrime;
	}

	public void setFirstFiveSumPrime(String firstFiveSumPrime) {
		this.firstFiveSumPrime = firstFiveSumPrime;
	}


	
	
	public String getFirstFollower() {
		return firstFollower;
	}

	public void setFirstFollower(String firstFollower) {
		this.firstFollower = firstFollower;
	}

	public String getSecondFollower() {
		return secondFollower;
	}

	public void setSecondFollower(String secondFollower) {
		this.secondFollower = secondFollower;
	}

	public String getThirdFollower() {
		return thirdFollower;
	}

	public void setThirdFollower(String thirdFollower) {
		this.thirdFollower = thirdFollower;
	}

	public String getFourthFollower() {
		return fourthFollower;
	}

	public void setFourthFollower(String fourthFollower) {
		this.fourthFollower = fourthFollower;
	}

	public String getFifthFollower() {
		return fifthFollower;
	}

	public void setFifthFollower(String fifthFollower) {
		this.fifthFollower = fifthFollower;
	}

	public String getMegaFollower() {
		return megaFollower;
	}

	public void setMegaFollower(String megaFollower) {
		this.megaFollower = megaFollower;
	}

	@Override
	public String getTableName() {
		return " results_within_lastN_history ";
	}

	
	public String getInsertSQL() {
		StringBuffer buff = new StringBuffer();
		
		StringBuffer internalBuffer = new StringBuffer();
		
		buff.append("Insert into " + getTableName() + "( ");
		
		if (getGameCode() != null)  {
			buff.append("gameCode,");
			internalBuffer.append("'" + getGameCode() + "',");
		}
		
		if (getSerialNumber() != null)  {
			buff.append("serialNumber,");
			internalBuffer.append("'" + getSerialNumber() + "',");
		}
		
		if (getWithinLast() != null)  {
			buff.append("withinLast,");
			internalBuffer.append("'" + getWithinLast() + "',");
		}
		
		if (getFirstValue() != null)  {
			buff.append("firstValue,");
			internalBuffer.append("'" + getFirstValue() + "',");
		}
		
		if (getSecondValue() != null)  {
			buff.append("secondValue,");
			internalBuffer.append("'" + getSecondValue() + "',");
		}
		
		if (getThirdValue() != null)  {
			buff.append("thirdValue,");
			internalBuffer.append("'" + getThirdValue() + "',");
		}
		
		if (getFourthValue() != null)  {
			buff.append("fourthValue,");
			internalBuffer.append("'" + getFourthValue() + "',");
		}
		
		if (getFifthValue() != null)  {
			buff.append("fifthValue,");
			internalBuffer.append("'" + getFifthValue() + "',");
		}
		
		if (getMegaValue() != null)  {
			buff.append("megaValue,");
			internalBuffer.append("'" + getMegaValue() + "',");
		}
		
		if (getFirstSkip() != null)  {
			buff.append("firstSkip,");
			internalBuffer.append("'" + getFirstSkip() + "',");
		}
		
		if (getSecondSkip() != null)  {
			buff.append("secondSkip,");
			internalBuffer.append("'" + getSecondSkip() + "',");
		}
		
		if (getThirdSkip() != null)  {
			buff.append("thirdSkip,");
			internalBuffer.append("'" + getThirdSkip() + "',");
		}
		
		if (getFourthSkip() != null)  {
			buff.append("fourthSkip,");
			internalBuffer.append("'" + getFourthSkip() + "',");
		}
		
		if (getFifthSkip() != null)  {
			buff.append("fifthSkip,");
			internalBuffer.append("'" + getFifthSkip() + "',");
		}
		
		if (getMegaSkip() != null)  {
			buff.append("megaSkip,");
			internalBuffer.append("'" + getMegaSkip() + "',");
		}
		
		if (getFirstRedux() != null)  {
			buff.append("firstRedux,");
			internalBuffer.append("'" + getFirstRedux() + "',");
		}
		
		if (getSecondRedux() != null)  {
			buff.append("secondRedux,");
			internalBuffer.append("'" + getSecondRedux() + "',");
		}
		
		if (getThirdRedux() != null)  {
			buff.append("thirdRedux,");
			internalBuffer.append("'" + getThirdRedux() + "',");
		}
		
		if (getFourthRedux() != null)  {
			buff.append("fourthRedux,");
			internalBuffer.append("'" + getFourthRedux() + "',");
		}
		
		if (getFifthRedux() != null)  {
			buff.append("fifthRedux,");
			internalBuffer.append("'" + getFifthRedux() + "',");
		}
		
		if (getMegaRedux() != null)  {
			buff.append("megaRedux,");
			internalBuffer.append("'" + getMegaRedux() + "',");
		}
		
		if (getFirstBucket() != null)  {
			buff.append("firstBucket,");
			internalBuffer.append("'" + getFirstBucket() + "',");
		}
		
		if (getSecondBucket() != null)  {
			buff.append("secondBucket,");
			internalBuffer.append("'" + getSecondBucket() + "',");
		}
		
		if (getThirdBucket() != null)  {
			buff.append("thirdBucket,");
			internalBuffer.append("'" + getThirdBucket() + "',");
		}
		
		if (getFourthBucket() != null)  {
			buff.append("fourthBucket,");
			internalBuffer.append("'" + getFourthBucket() + "',");
		}
		
		if (getFifthBucket() != null)  {
			buff.append("fifthBucket,");
			internalBuffer.append("'" + getFifthBucket() + "',");
		}
		
		if (getMegaBucket() != null)  {
			buff.append("megaBucket,");
			internalBuffer.append("'" + getMegaBucket() + "',");
		}
		
		if (getFirstFiveSumBucket() != null)  {
			buff.append("firstFiveSumBucket,");
			internalBuffer.append("'" + getFirstFiveSumBucket() + "',");
	}
	
		
		if (getFirstFiveSum() != null)  {
				buff.append("firstFiveSum,");
				internalBuffer.append("'" + getFirstFiveSum() + "',");
		}
			
		if (getFirstFiveSumRedux() != null)  {
				buff.append("firstFiveSumRedux,");
				internalBuffer.append("'" + getFirstFiveSumRedux() + "',");
		}
		
		
		if (getFirstPrime() != null)  {
			buff.append("firstPrime,");
			internalBuffer.append("'" + getFirstPrime() + "',");
		}
			
		if (getSecondPrime() != null)  {
			buff.append("secondPrime,");
			internalBuffer.append("'" + getSecondPrime() + "',");
		}
				
		if (getThirdPrime() != null)  {
			buff.append("thirdPrime,");
			internalBuffer.append("'" + getThirdPrime() + "',");
		}
		
		if (getFourthPrime() != null)  {
			buff.append("fourthPrime,");
			internalBuffer.append("'" + getFourthPrime() + "',");
		}
		
		if (getFifthPrime() != null)  {
			buff.append("fifthPrime,");
			internalBuffer.append("'" + getFifthPrime() + "',");
		}
		
		if (getMegaPrime() != null)  {
			buff.append("megaPrime,");
			internalBuffer.append("'" + getMegaPrime() + "',");
		}
		
		if (getNumPrimes() != null)  {
			buff.append("numPrimes,");
			internalBuffer.append("'" + getNumPrimes() + "',");
		}
		
		if (getFirstFiveSumPrime() != null)  {
			buff.append("firstFiveSumPrime,");
			internalBuffer.append("'" + getFirstFiveSumPrime() + "',");
		}
		
		if (getFirstFollower() != null)  {
			buff.append("firstFollower,");
			internalBuffer.append("'" + getFirstFollower() + "',");
		}
			
		if (getSecondFollower() != null)  {
			buff.append("secondFollower,");
			internalBuffer.append("'" + getSecondFollower() + "',");
		}
				
		if (getThirdFollower() != null)  {
			buff.append("thirdFollower,");
			internalBuffer.append("'" + getThirdFollower() + "',");
		}
		
		if (getFourthFollower() != null)  {
			buff.append("fourthFollower,");
			internalBuffer.append("'" + getFourthFollower() + "',");
		}
		
		if (getFifthFollower() != null)  {
			buff.append("fifthFollower,");
			internalBuffer.append("'" + getFifthFollower() + "',");
		}
		
		if (getMegaFollower() != null)  {
			buff.append("megaFollower,");
			internalBuffer.append("'" + getMegaFollower() + "',");
		}
		
	
		
		return buff.substring(0,buff.length()-1) + ") values ( "+ internalBuffer.substring(0,internalBuffer.length()-1) + ")" ;
	}
	
	public String getUpdateSQL() {
		StringBuffer buff = new StringBuffer();
		StringBuffer whereBuff = new StringBuffer();
		
		buff.append("Update " + getTableName() + " SET ");
		
		if (getGameCode() != null)  {
			whereBuff.append(" where gameCode = '" + getGameCode() + "' ");
		}
		
		if (getSerialNumber() != null)  {
			whereBuff.append("AND serialNumber = '" + getSerialNumber() + "' ");
			
		}
		
		if (getWithinLast() != null)  {
			whereBuff.append("AND withinLast = '" + getWithinLast() + "' ");
			
		}
		
		if (getFirstValue() != null)  {
			buff.append(" firstValue = '" + getFirstValue() + "',");
		}
		
		if (getSecondValue() != null)  {
			buff.append(" secondValue = '" + getSecondValue() + "',");
			
		}
		
		if (getThirdValue() != null)  {
			buff.append(" thirdValue = '" + getThirdValue() + "',");

		}
		
		if (getFourthValue() != null)  {
			buff.append(" fourthValue = '" + getFourthValue() + "',");

		}
		
		/*if (getFifthValue() != null)  {
			buff.append("fifthValue,");
			internalBuffer.append("'" + getFifthValue() + "',");
		}
		
		if (getMegaValue() != null)  {
			buff.append("megaValue,");
			internalBuffer.append("'" + getMegaValue() + "',");
		}
		
		if (getFirstSkip() != null)  {
			buff.append("firstSkip,");
			internalBuffer.append("'" + getFirstSkip() + "',");
		}
		
		if (getSecondSkip() != null)  {
			buff.append("secondSkip,");
			internalBuffer.append("'" + getSecondSkip() + "',");
		}
		
		if (getThirdSkip() != null)  {
			buff.append("thirdSkip,");
			internalBuffer.append("'" + getThirdSkip() + "',");
		}
		
		if (getFourthSkip() != null)  {
			buff.append("fourthSkip,");
			internalBuffer.append("'" + getFourthSkip() + "',");
		}
		
		if (getFifthSkip() != null)  {
			buff.append("fifthSkip,");
			internalBuffer.append("'" + getFifthSkip() + "',");
		}
		
		if (getMegaSkip() != null)  {
			buff.append("megaSkip,");
			internalBuffer.append("'" + getMegaSkip() + "',");
		}
		
		if (getFirstRedux() != null)  {
			buff.append("firstRedux,");
			internalBuffer.append("'" + getFirstRedux() + "',");
		}
		
		if (getSecondRedux() != null)  {
			buff.append("secondRedux,");
			internalBuffer.append("'" + getSecondRedux() + "',");
		}
		
		if (getThirdRedux() != null)  {
			buff.append("thirdRedux,");
			internalBuffer.append("'" + getThirdRedux() + "',");
		}
		
		if (getFourthRedux() != null)  {
			buff.append("fourthRedux,");
			internalBuffer.append("'" + getFourthRedux() + "',");
		}
		
		if (getFifthRedux() != null)  {
			buff.append("fifthRedux,");
			internalBuffer.append("'" + getFifthRedux() + "',");
		}
		
		if (getMegaRedux() != null)  {
			buff.append("megaRedux,");
			internalBuffer.append("'" + getMegaRedux() + "',");
		}
		
		if (getFirstBucket() != null)  {
			buff.append("firstBucket,");
			internalBuffer.append("'" + getFirstBucket() + "',");
		}
		
		if (getSecondBucket() != null)  {
			buff.append("secondBucket,");
			internalBuffer.append("'" + getSecondBucket() + "',");
		}
		
		if (getThirdBucket() != null)  {
			buff.append("thirdBucket,");
			internalBuffer.append("'" + getThirdBucket() + "',");
		}
		
		if (getFourthBucket() != null)  {
			buff.append("fourthBucket,");
			internalBuffer.append("'" + getFourthBucket() + "',");
		}
		
		if (getFifthBucket() != null)  {
			buff.append("fifthBucket,");
			internalBuffer.append("'" + getFifthBucket() + "',");
		}
		
		if (getMegaBucket() != null)  {
			buff.append("megaBucket,");
			internalBuffer.append("'" + getMegaBucket() + "',");
		}
		
		if (getFirstFiveSumBucket() != null)  {
			buff.append(" firstFiveSumBucket = '" + getFirstFiveSumBucket() + "',");
			
		}
	*/
		/*if (getFirstFiveSum() != null)  {
				buff.append("firstFiveSum,");
				internalBuffer.append("'" + getFirstFiveSum() + "',");
		}
			
		if (getFirstFiveSumRedux() != null)  {
				buff.append("firstFiveSumRedux,");
				internalBuffer.append("'" + getFirstFiveSumRedux() + "',");
		}
		
		
		if (getFirstPrime() != null)  {
			buff.append("firstPrime,");
			internalBuffer.append("'" + getFirstPrime() + "',");
		}
			
		if (getSecondPrime() != null)  {
			buff.append("secondPrime,");
			internalBuffer.append("'" + getSecondPrime() + "',");
		}
				
		if (getThirdPrime() != null)  {
			buff.append("thirdPrime,");
			internalBuffer.append("'" + getThirdPrime() + "',");
		}
		
		if (getFourthPrime() != null)  {
			buff.append("fourthPrime,");
			internalBuffer.append("'" + getFourthPrime() + "',");
		}
		
		if (getFifthPrime() != null)  {
			buff.append("fifthPrime,");
			internalBuffer.append("'" + getFifthPrime() + "',");
		}
		
		if (getMegaPrime() != null)  {
			buff.append("megaPrime,");
			internalBuffer.append("'" + getMegaPrime() + "',");
		}
		
		if (getNumPrimes() != null)  {
			buff.append("numPrimes,");
			internalBuffer.append("'" + getNumPrimes() + "',");
		}
		
		if (getFirstFiveSumPrime() != null)  {
			buff.append("firstFiveSumPrime,");
			internalBuffer.append("'" + getFirstFiveSumPrime() + "',");
		}*/
		
		if (getFirstFollower() != null)  {
			buff.append(" firstFollower = '" + getFirstFollower() + "',");
			
		}
		
		if (getSecondFollower() != null)  {
			buff.append(" SecondFollower = '" + getSecondFollower() + "',");
			
		}
		
		if (getThirdFollower() != null)  {
			buff.append(" ThirdFollower = '" + getThirdFollower() + "',");
			
		}
		
		if (getFourthFollower() != null)  {
			buff.append(" FourthFollower = '" + getFourthFollower() + "',");
			
		}
		
		if (getFifthFollower() != null)  {
			buff.append(" FifthFollower = '" + getFifthFollower() + "',");
			
		}
		
		if (getMegaFollower() != null)  {
			buff.append(" MegaFollower = '" + getMegaFollower() + "',");
			
		}
	
		
		return buff.toString().substring(0,buff.toString().length()-1) + whereBuff.toString();
	}

	@Override
	public Collection readAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Collection findRows() {
		// TODO Auto-generated method stub
		return null;
	}
	
	public ArrayList getMissingSerialsForGame (String gameCode) {
		ArrayList l = new ArrayList();
		Connection conn = null;
		
		String sql = "select distinct h.serialNumber from result_history h left outer join results_within_lastN_history d " +
		 				"on h.serialNumber = d.SerialNumber and h.gameCode = d.gameCode " +
		 				" where d.serialNumber is null " +
		 				" and h.gameCode = " + gameCode +
		 				" order by h.serialNumber desc LIMIT 150";
		
								/*sql = "select distinct h.serialNumber from result_history h left outer join results_within_lastN_history d " +
									"on h.serialNumber = d.SerialNumber and h.gameCode = d.gameCode " +
									" where d.firstFollower is null " +
									" and h.gameCode = " + gameCode +
									" order by h.serialNumber desc LIMIT 250";*/
		
		try {
			
			conn = getConnection();
			Statement stmt = conn.createStatement();
			
			ResultSet rs = stmt.executeQuery(sql);
			
			int previousSerial = 0;
			while (rs.next()) {
				int thisSerial = rs.getInt("serialNumber");
				
				if (previousSerial == 0) {
					l.add(thisSerial);
					previousSerial = thisSerial;
				} else {
					if (previousSerial - thisSerial > 1) {
						break;
					} else {
						l.add(thisSerial);
						previousSerial = thisSerial;
					}
				}
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			if (conn != null)
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		
		return l;
	}
	
	public void executeLastNProcsForSerial(int gameCode, int withinLast, int serial) {
		Connection conn = null;
		
		ResultHistoryEntity rhe = new ResultHistoryEntity();
		rhe.setGameCode(Integer.toString(gameCode));
		rhe.setSerialNumber(Integer.toString(serial));
		
		if (!rhe.exists()) {
			System.out.println("Invalid SerialNumber " + serial + " passed for for game " + gameCode + " To method ResultsWithinLastN.executeLastNProcsForSerial.");
			return;
		}
		
		ResultsWithinLastN result = new ResultsWithinLastN();
		result.setGameCode(Integer.toString(gameCode));
		result.setWithinLast(Integer.toString(withinLast));
		result.setSerialNumber(Integer.toString(serial));
		
		//System.out.print("Starting executeLastNProcsForSerial for game" + gameCode + " N " + withinLast);
		try {
			
			conn = getConnection();
			CallableStatement stmt = conn.prepareCall("{call percentResultsWithFiveSumBucketInLastN (?, ?, ?)}");
			
			stmt.setInt(1, gameCode);
			stmt.setInt(2, withinLast);
			stmt.setInt(3, serial);
			
			boolean hadresults = stmt.execute();
			
			if (hadresults) {
		        ResultSet rs = stmt.getResultSet();

		        if (rs.next()) {
		        	int perc = rs.getInt("percentage");
		        	int drawsSince = rs.getInt("drawsSince");
		        	result.setFirstFiveSumBucket(Integer.toString(perc*drawsSince));
		        	if (withinNData != null) {
		        		if (withinNData.containsKey("firstFiveSumBucket")) {
		        			Hashtable innerTable = (Hashtable) withinNData.get("firstFiveSumBucket");
		        			innerTable.put(withinLast, perc*drawsSince);
		        		} else {
		        			Hashtable innerTable = new Hashtable();
		        			innerTable.put(withinLast, perc*drawsSince);
		        			withinNData.put("firstFiveSumBucket", innerTable);
		        		}
		        	}
		        }

		        hadresults = stmt.getMoreResults();
		    }
			
			stmt = conn.prepareCall("{call percentResultsWithFirstValueInLastN(?, ?, ?)}");
			
			stmt.setInt(1, gameCode);
			stmt.setInt(2, withinLast);
			stmt.setInt(3, serial);
			
			hadresults = stmt.execute();
			
			if (hadresults) {
		        ResultSet rs = stmt.getResultSet();

		        if (rs.next()) {
		        	int perc = rs.getInt("percentage");
		        	int drawsSince = rs.getInt("drawsSince");
		        	result.setFirstValue(Integer.toString(perc*drawsSince));
		        	if (withinNData != null) {
		        		if (withinNData.containsKey("1")) {
		        			Hashtable innerTable = (Hashtable) withinNData.get("1");
		        			innerTable.put(withinLast, perc*drawsSince);
		        		} else {
		        			Hashtable innerTable = new Hashtable();
		        			innerTable.put(withinLast, perc*drawsSince);
		        			withinNData.put("1", innerTable);
		        		}
		        	}
		        }

		        hadresults = stmt.getMoreResults();
		    }
			
			stmt = conn.prepareCall("{call percentResultsWithSecondValueInLastN(?, ?, ?)}");
			stmt.setInt(1, gameCode);
			stmt.setInt(2, withinLast);
			stmt.setInt(3, serial);
			
			hadresults = stmt.execute();
			
			if (hadresults) {
		        ResultSet rs = stmt.getResultSet();

		        if (rs.next()) {
		        	int perc = rs.getInt("percentage");
		        	int drawsSince = rs.getInt("drawsSince");
		        	result.setSecondValue(Integer.toString(perc*drawsSince));
		        	if (withinNData != null) {
		        		if (withinNData.containsKey("2")) {
		        			Hashtable innerTable = (Hashtable) withinNData.get("2");
		        			innerTable.put(withinLast, perc*drawsSince);
		        		} else {
		        			Hashtable innerTable = new Hashtable();
		        			innerTable.put(withinLast, perc*drawsSince);
		        			withinNData.put("2", innerTable);
		        		}
		        	}
		        }

		        hadresults = stmt.getMoreResults();
		    }
			
			stmt = conn.prepareCall("{call percentResultsWithThirdValueInLastN(?, ?, ?)}");
			stmt.setInt(1, gameCode);
			stmt.setInt(2, withinLast);
			stmt.setInt(3, serial);
			
			hadresults = stmt.execute();
			
			if (hadresults) {
		        ResultSet rs = stmt.getResultSet();

		        if (rs.next()) {
		        	int perc = rs.getInt("percentage");
		        	int drawsSince = rs.getInt("drawsSince");
		        	result.setThirdValue(Integer.toString(perc*drawsSince));
		        	if (withinNData != null) {
		        		if (withinNData.containsKey("3")) {
		        			Hashtable innerTable = (Hashtable) withinNData.get("3");
		        			innerTable.put(withinLast, perc*drawsSince);
		        		} else {
		        			Hashtable innerTable = new Hashtable();
		        			innerTable.put(withinLast, perc*drawsSince);
		        			withinNData.put("3", innerTable);
		        		}
		        	}
		        }

		        hadresults = stmt.getMoreResults();
		    }
			
			stmt = conn.prepareCall("{call percentResultsWithFourthValueInLastN(?, ?, ?)}");
			stmt.setInt(1, gameCode);
			stmt.setInt(2, withinLast);
			stmt.setInt(3, serial);
			
			hadresults = stmt.execute();
			
			if (hadresults) {
		        ResultSet rs = stmt.getResultSet();

		        if (rs.next()) {
		        	int perc = rs.getInt("percentage");
		        	int drawsSince = rs.getInt("drawsSince");
		        	result.setFourthValue(Integer.toString(perc*drawsSince));
		        	if (withinNData != null) {
		        		if (withinNData.containsKey("4")) {
		        			Hashtable innerTable = (Hashtable) withinNData.get("4");
		        			innerTable.put(withinLast, perc*drawsSince);
		        		} else {
		        			Hashtable innerTable = new Hashtable();
		        			innerTable.put(withinLast, perc*drawsSince);
		        			withinNData.put("4", innerTable);
		        		}
		        	}
		        }

		        hadresults = stmt.getMoreResults();
		    }
			
			stmt = conn.prepareCall("{call percentResultsWithFifthValueInLastN(?, ?, ?)}");
			stmt.setInt(1, gameCode);
			stmt.setInt(2, withinLast);
			stmt.setInt(3, serial);
			
			hadresults = stmt.execute();
			
			if (hadresults) {
		        ResultSet rs = stmt.getResultSet();

		        if (rs.next()) {
		        	int perc = rs.getInt("percentage");
		        	int drawsSince = rs.getInt("drawsSince");
		        	result.setFifthValue(Integer.toString(perc*drawsSince));
		        	if (withinNData != null) {
		        		if (withinNData.containsKey("5")) {
		        			Hashtable innerTable = (Hashtable) withinNData.get("5");
		        			innerTable.put(withinLast, perc*drawsSince);
		        		} else {
		        			Hashtable innerTable = new Hashtable();
		        			innerTable.put(withinLast, perc*drawsSince);
		        			withinNData.put("5", innerTable);
		        		}
		        	}
		        }

		        hadresults = stmt.getMoreResults();
		    }
			
			stmt = conn.prepareCall("{call percentResultsWithMegaValueInLastN(?, ?, ?)}");
			stmt.setInt(1, gameCode);
			stmt.setInt(2, withinLast);
			stmt.setInt(3, serial);
			
			hadresults = stmt.execute();
			
			if (hadresults) {
		        ResultSet rs = stmt.getResultSet();

		        if (rs.next()) {
		        	int perc = rs.getInt("percentage");
		        	int drawsSince = rs.getInt("drawsSince");
		        	result.setMegaValue(Integer.toString(perc*drawsSince));
		        	if (withinNData != null) {
		        		if (withinNData.containsKey("M")) {
		        			Hashtable innerTable = (Hashtable) withinNData.get("M");
		        			innerTable.put(withinLast, perc*drawsSince);
		        		} else {
		        			Hashtable innerTable = new Hashtable();
		        			innerTable.put(withinLast, perc*drawsSince);
		        			withinNData.put("M", innerTable);
		        		}
		        	}
		        }

		        hadresults = stmt.getMoreResults();
		    }
			
			stmt = conn.prepareCall("{call percentResultsWithFiveSumInLastN(?, ?, ?)}");
			stmt.setInt(1, gameCode);
			stmt.setInt(2, withinLast);
			stmt.setInt(3, serial);
			
			hadresults = stmt.execute();
			
			if (hadresults) {
		        ResultSet rs = stmt.getResultSet();

		        if (rs.next()) {
		        	int perc = rs.getInt("percentage");
		        	int drawsSince = rs.getInt("drawsSince");
		        	result.setFirstFiveSum(Integer.toString(perc*drawsSince));
		        	if (withinNData != null) {
		        		if (withinNData.containsKey("S")) {
		        			Hashtable innerTable = (Hashtable) withinNData.get("S");
		        			innerTable.put(withinLast, perc*drawsSince);
		        		} else {
		        			Hashtable innerTable = new Hashtable();
		        			innerTable.put(withinLast, perc*drawsSince);
		        			withinNData.put("S", innerTable);
		        		}
		        	}
		        }

		        hadresults = stmt.getMoreResults();
		    }
			
			stmt = conn.prepareCall("{call percentResultsWithFiveSumReduxInLastN(?, ?, ?)}");
			stmt.setInt(1, gameCode);
			stmt.setInt(2, withinLast);
			stmt.setInt(3, serial);
			
			hadresults = stmt.execute();
			
			if (hadresults) {
		        ResultSet rs = stmt.getResultSet();

		        if (rs.next()) {
		        	int perc = rs.getInt("percentage");
		        	int drawsSince = rs.getInt("drawsSince");
		        	result.setFirstFiveSumRedux(Integer.toString(perc*drawsSince));
		        	if (withinNData != null) {
		        		if (withinNData.containsKey("SR")) {
		        			Hashtable innerTable = (Hashtable) withinNData.get("SR");
		        			innerTable.put(withinLast, perc*drawsSince);
		        		} else {
		        			Hashtable innerTable = new Hashtable();
		        			innerTable.put(withinLast, perc*drawsSince);
		        			withinNData.put("SR", innerTable);
		        		}
		        	}
		        }

		        hadresults = stmt.getMoreResults();
		    }
			
			stmt = conn.prepareCall("{call percentResultsWithFirstReduxInLastN(?, ?, ?)}");
			stmt.setInt(1, gameCode);
			stmt.setInt(2, withinLast);
			stmt.setInt(3, serial);
			
			hadresults = stmt.execute();
			
			if (hadresults) {
		        ResultSet rs = stmt.getResultSet();

		        if (rs.next()) {
		        	int perc = rs.getInt("percentage");
		        	int drawsSince = rs.getInt("drawsSince");
		        	result.setFirstRedux(Integer.toString(perc*drawsSince));
		        	if (withinNData != null) {
		        		if (withinNData.containsKey("FirstR")) {
		        			Hashtable innerTable = (Hashtable) withinNData.get("FirstR");
		        			innerTable.put(withinLast, perc*drawsSince);
		        		} else {
		        			Hashtable innerTable = new Hashtable();
		        			innerTable.put(withinLast, perc*drawsSince);
		        			withinNData.put("FirstR", innerTable);
		        		}
		        	}
		        }

		        hadresults = stmt.getMoreResults();
		    }
			
			stmt = conn.prepareCall("{call percentResultsWithSecondReduxInLastN(?, ?, ?)}");
			stmt.setInt(1, gameCode);
			stmt.setInt(2, withinLast);
			stmt.setInt(3, serial);
			
			hadresults = stmt.execute();
			
			if (hadresults) {
		        ResultSet rs = stmt.getResultSet();

		        if (rs.next()) {
		        	int perc = rs.getInt("percentage");
		        	int drawsSince = rs.getInt("drawsSince");
		        	result.setSecondRedux(Integer.toString(perc*drawsSince));
		        	if (withinNData != null) {
		        		if (withinNData.containsKey("SecondR")) {
		        			Hashtable innerTable = (Hashtable) withinNData.get("SecondR");
		        			innerTable.put(withinLast, perc*drawsSince);
		        		} else {
		        			Hashtable innerTable = new Hashtable();
		        			innerTable.put(withinLast, perc*drawsSince);
		        			withinNData.put("SecondR", innerTable);
		        		}
		        	}
		        }

		        hadresults = stmt.getMoreResults();
		    }
			
			stmt = conn.prepareCall("{call percentResultsWithThirdReduxInLastN(?, ?, ?)}");
			stmt.setInt(1, gameCode);
			stmt.setInt(2, withinLast);
			stmt.setInt(3, serial);
			
			hadresults = stmt.execute();
			
			if (hadresults) {
		        ResultSet rs = stmt.getResultSet();

		        if (rs.next()) {
		        	int perc = rs.getInt("percentage");
		        	int drawsSince = rs.getInt("drawsSince");
		        	result.setThirdRedux(Integer.toString(perc*drawsSince));
		        	if (withinNData != null) {
		        		if (withinNData.containsKey("ThirdR")) {
		        			Hashtable innerTable = (Hashtable) withinNData.get("ThirdR");
		        			innerTable.put(withinLast, perc*drawsSince);
		        		} else {
		        			Hashtable innerTable = new Hashtable();
		        			innerTable.put(withinLast, perc*drawsSince);
		        			withinNData.put("ThirdR", innerTable);
		        		}
		        	}
		        }

		        hadresults = stmt.getMoreResults();
		    }
			
			stmt = conn.prepareCall("{call percentResultsWithFourthReduxInLastN(?, ?, ?)}");
			stmt.setInt(1, gameCode);
			stmt.setInt(2, withinLast);
			stmt.setInt(3, serial);
			
			hadresults = stmt.execute();
			
			if (hadresults) {
		        ResultSet rs = stmt.getResultSet();

		        if (rs.next()) {
		        	int perc = rs.getInt("percentage");
		        	int drawsSince = rs.getInt("drawsSince");
		        	result.setFourthRedux(Integer.toString(perc*drawsSince));
		        	if (withinNData != null) {
		        		if (withinNData.containsKey("FourthR")) {
		        			Hashtable innerTable = (Hashtable) withinNData.get("FourthR");
		        			innerTable.put(withinLast, perc*drawsSince);
		        		} else {
		        			Hashtable innerTable = new Hashtable();
		        			innerTable.put(withinLast, perc*drawsSince);
		        			withinNData.put("FourthR", innerTable);
		        		}
		        	}
		        }

		        hadresults = stmt.getMoreResults();
		    }
			
			stmt = conn.prepareCall("{call percentResultsWithFifthReduxInLastN(?, ?, ?)}");
			stmt.setInt(1, gameCode);
			stmt.setInt(2, withinLast);
			stmt.setInt(3, serial);
			
			hadresults = stmt.execute();
			
			if (hadresults) {
		        ResultSet rs = stmt.getResultSet();

		        if (rs.next()) {
		        	int perc = rs.getInt("percentage");
		        	int drawsSince = rs.getInt("drawsSince");
		        	result.setFifthRedux(Integer.toString(perc*drawsSince));
		        	if (withinNData != null) {
		        		if (withinNData.containsKey("FifthR")) {
		        			Hashtable innerTable = (Hashtable) withinNData.get("FifthR");
		        			innerTable.put(withinLast, perc*drawsSince);
		        		} else {
		        			Hashtable innerTable = new Hashtable();
		        			innerTable.put(withinLast, perc*drawsSince);
		        			withinNData.put("FifthR", innerTable);
		        		}
		        	}
		        }

		        hadresults = stmt.getMoreResults();
		    }
			
			stmt = conn.prepareCall("{call percentResultsWithMegaReduxInLastN(?, ?, ?)}");
			stmt.setInt(1, gameCode);
			stmt.setInt(2, withinLast);
			stmt.setInt(3, serial);
			
			hadresults = stmt.execute();
			
			if (hadresults) {
		        ResultSet rs = stmt.getResultSet();

		        if (rs.next()) {
		        	int perc = rs.getInt("percentage");
		        	int drawsSince = rs.getInt("drawsSince");
		        	result.setMegaRedux(Integer.toString(perc*drawsSince));
		        	if (withinNData != null) {
		        		if (withinNData.containsKey("MegaR")) {
		        			Hashtable innerTable = (Hashtable) withinNData.get("MegaR");
		        			innerTable.put(withinLast, perc*drawsSince);
		        		} else {
		        			Hashtable innerTable = new Hashtable();
		        			innerTable.put(withinLast, perc*drawsSince);
		        			withinNData.put("MegaR", innerTable);
		        		}
		        	}
		        }

		        hadresults = stmt.getMoreResults();
		    }
			
			stmt = conn.prepareCall("{call percentResultsWithFirstSkipInLastN(?, ?, ?)}");
			stmt.setInt(1, gameCode);
			stmt.setInt(2, withinLast);
			stmt.setInt(3, serial);
			
			hadresults = stmt.execute();
			
			if (hadresults) {
		        ResultSet rs = stmt.getResultSet();

		        if (rs.next()) {
		        	int perc = rs.getInt("percentage");
		        	int drawsSince = rs.getInt("drawsSince");
		        	result.setFirstSkip(Integer.toString(perc*drawsSince));
		        	if (withinNData != null) {
		        		if (withinNData.containsKey("FirstSkip")) {
		        			Hashtable innerTable = (Hashtable) withinNData.get("FirstSkip");
		        			innerTable.put(withinLast, perc*drawsSince);
		        		} else {
		        			Hashtable innerTable = new Hashtable();
		        			innerTable.put(withinLast, perc*drawsSince);
		        			withinNData.put("FirstSkip", innerTable);
		        		}
		        	}
		        }

		        hadresults = stmt.getMoreResults();
		    }
			
			stmt = conn.prepareCall("{call percentResultsWithSecondSkipInLastN(?, ?, ?)}");
			stmt.setInt(1, gameCode);
			stmt.setInt(2, withinLast);
			stmt.setInt(3, serial);
			
			hadresults = stmt.execute();
			
			if (hadresults) {
		        ResultSet rs = stmt.getResultSet();

		        if (rs.next()) {
		        	int perc = rs.getInt("percentage");
		        	int drawsSince = rs.getInt("drawsSince");
		        	result.setSecondSkip(Integer.toString(perc*drawsSince));
		        	if (withinNData != null) {
		        		if (withinNData.containsKey("SecondSkip")) {
		        			Hashtable innerTable = (Hashtable) withinNData.get("SecondSkip");
		        			innerTable.put(withinLast, perc*drawsSince);
		        		} else {
		        			Hashtable innerTable = new Hashtable();
		        			innerTable.put(withinLast, perc*drawsSince);
		        			withinNData.put("SecondSkip", innerTable);
		        		}
		        	}
		        }

		        hadresults = stmt.getMoreResults();
		    }
			
			stmt = conn.prepareCall("{call percentResultsWithThirdSkipInLastN(?, ?, ?)}");
			stmt.setInt(1, gameCode);
			stmt.setInt(2, withinLast);
			stmt.setInt(3, serial);
			
			hadresults = stmt.execute();
			
			if (hadresults) {
		        ResultSet rs = stmt.getResultSet();

		        if (rs.next()) {
		        	int perc = rs.getInt("percentage");
		        	int drawsSince = rs.getInt("drawsSince");
		        	result.setThirdSkip(Integer.toString(perc*drawsSince));
		        	if (withinNData != null) {
		        		if (withinNData.containsKey("ThirdSkip")) {
		        			Hashtable innerTable = (Hashtable) withinNData.get("ThirdSkip");
		        			innerTable.put(withinLast, perc*drawsSince);
		        		} else {
		        			Hashtable innerTable = new Hashtable();
		        			innerTable.put(withinLast, perc*drawsSince);
		        			withinNData.put("ThirdSkip", innerTable);
		        		}
		        	}
		        }

		        hadresults = stmt.getMoreResults();
		    }
			
			stmt = conn.prepareCall("{call percentResultsWithFourthSkipInLastN(?, ?, ?)}");
			stmt.setInt(1, gameCode);
			stmt.setInt(2, withinLast);
			stmt.setInt(3, serial);
			
			hadresults = stmt.execute();
			
			if (hadresults) {
		        ResultSet rs = stmt.getResultSet();

		        if (rs.next()) {
		        	int perc = rs.getInt("percentage");
		        	int drawsSince = rs.getInt("drawsSince");
		        	result.setFourthSkip(Integer.toString(perc*drawsSince));
		        	if (withinNData != null) {
		        		if (withinNData.containsKey("FourthSkip")) {
		        			Hashtable innerTable = (Hashtable) withinNData.get("FourthSkip");
		        			innerTable.put(withinLast, perc*drawsSince);
		        		} else {
		        			Hashtable innerTable = new Hashtable();
		        			innerTable.put(withinLast, perc*drawsSince);
		        			withinNData.put("FourthSkip", innerTable);
		        		}
		        	}
		        }

		        hadresults = stmt.getMoreResults();
		    }
			
			stmt = conn.prepareCall("{call percentResultsWithFifthSkipInLastN(?, ?, ?)}");
			stmt.setInt(1, gameCode);
			stmt.setInt(2, withinLast);
			stmt.setInt(3, serial);
			
			hadresults = stmt.execute();
			
			if (hadresults) {
		        ResultSet rs = stmt.getResultSet();

		        if (rs.next()) {
		        	int perc = rs.getInt("percentage");
		        	int drawsSince = rs.getInt("drawsSince");
		        	result.setFifthSkip(Integer.toString(perc*drawsSince));
		        	if (withinNData != null) {
		        		if (withinNData.containsKey("FifthSkip")) {
		        			Hashtable innerTable = (Hashtable) withinNData.get("FifthSkip");
		        			innerTable.put(withinLast, perc*drawsSince);
		        		} else {
		        			Hashtable innerTable = new Hashtable();
		        			innerTable.put(withinLast, perc*drawsSince);
		        			withinNData.put("FifthSkip", innerTable);
		        		}
		        	}
		        }

		        hadresults = stmt.getMoreResults();
		    }
			
			stmt = conn.prepareCall("{call percentResultsWithMegaSkipInLastN(?, ?, ?)}");
			stmt.setInt(1, gameCode);
			stmt.setInt(2, withinLast);
			stmt.setInt(3, serial);
			
			hadresults = stmt.execute();
			
			if (hadresults) {
		        ResultSet rs = stmt.getResultSet();

		        if (rs.next()) {
		        	int perc = rs.getInt("percentage");
		        	int drawsSince = rs.getInt("drawsSince");
		        	result.setMegaSkip(Integer.toString(perc*drawsSince));
		        	if (withinNData != null) {
		        		if (withinNData.containsKey("MegaSkip")) {
		        			Hashtable innerTable = (Hashtable) withinNData.get("MegaSkip");
		        			innerTable.put(withinLast, perc*drawsSince);
		        		} else {
		        			Hashtable innerTable = new Hashtable();
		        			innerTable.put(withinLast, perc*drawsSince);
		        			withinNData.put("MegaSkip", innerTable);
		        		}
		        	}
		        }

		        hadresults = stmt.getMoreResults();
		    }
			
			stmt = conn.prepareCall("{call percentResultsWithFirstBucketInLastN(?, ?, ?)}");
			stmt.setInt(1, gameCode);
			stmt.setInt(2, withinLast);
			stmt.setInt(3, serial);
			
			hadresults = stmt.execute();
			
			if (hadresults) {
		        ResultSet rs = stmt.getResultSet();

		        if (rs.next()) {
		        	int perc = rs.getInt("percentage");
		        	int drawsSince = rs.getInt("drawsSince");
		        	result.setFirstBucket(Integer.toString(perc*drawsSince));
		        	if (withinNData != null) {
		        		if (withinNData.containsKey("FirstBucket")) {
		        			Hashtable innerTable = (Hashtable) withinNData.get("FirstBucket");
		        			innerTable.put(withinLast, perc*drawsSince);
		        		} else {
		        			Hashtable innerTable = new Hashtable();
		        			innerTable.put(withinLast, perc*drawsSince);
		        			withinNData.put("FirstBucket", innerTable);
		        		}
		        	}
		        }

		        hadresults = stmt.getMoreResults();
		    }
			
			stmt = conn.prepareCall("{call percentResultsWithSecondBucketInLastN(?, ?, ?)}");
			stmt.setInt(1, gameCode);
			stmt.setInt(2, withinLast);
			stmt.setInt(3, serial);
			
			hadresults = stmt.execute();
			
			if (hadresults) {
		        ResultSet rs = stmt.getResultSet();

		        if (rs.next()) {
		        	int perc = rs.getInt("percentage");
		        	int drawsSince = rs.getInt("drawsSince");
		        	result.setSecondBucket(Integer.toString(perc*drawsSince));
		        	if (withinNData != null) {
		        		if (withinNData.containsKey("SecondBucket")) {
		        			Hashtable innerTable = (Hashtable) withinNData.get("SecondBucket");
		        			innerTable.put(withinLast, perc*drawsSince);
		        		} else {
		        			Hashtable innerTable = new Hashtable();
		        			innerTable.put(withinLast, perc*drawsSince);
		        			withinNData.put("SecondBucket", innerTable);
		        		}
		        	}
		        }

		        hadresults = stmt.getMoreResults();
		    }
			
			stmt = conn.prepareCall("{call percentResultsWithThirdBucketInLastN(?, ?, ?)}");
			stmt.setInt(1, gameCode);
			stmt.setInt(2, withinLast);
			stmt.setInt(3, serial);
			
			hadresults = stmt.execute();
			
			if (hadresults) {
		        ResultSet rs = stmt.getResultSet();

		        if (rs.next()) {
		        	int perc = rs.getInt("percentage");
		        	int drawsSince = rs.getInt("drawsSince");
		        	result.setThirdBucket(Integer.toString(perc*drawsSince));
		        	if (withinNData != null) {
		        		if (withinNData.containsKey("ThirdBucket")) {
		        			Hashtable innerTable = (Hashtable) withinNData.get("ThirdBucket");
		        			innerTable.put(withinLast, perc*drawsSince);
		        		} else {
		        			Hashtable innerTable = new Hashtable();
		        			innerTable.put(withinLast, perc*drawsSince);
		        			withinNData.put("ThirdBucket", innerTable);
		        		}
		        	}
		        }

		        hadresults = stmt.getMoreResults();
		    }
			
			stmt = conn.prepareCall("{call percentResultsWithFourthBucketInLastN(?, ?, ?)}");
			stmt.setInt(1, gameCode);
			stmt.setInt(2, withinLast);
			stmt.setInt(3, serial);
			
			hadresults = stmt.execute();
			
			if (hadresults) {
		        ResultSet rs = stmt.getResultSet();

		        if (rs.next()) {
		        	int perc = rs.getInt("percentage");
		        	int drawsSince = rs.getInt("drawsSince");
		        	result.setFourthBucket(Integer.toString(perc*drawsSince));
		        	if (withinNData != null) {
		        		if (withinNData.containsKey("FourthBucket")) {
		        			Hashtable innerTable = (Hashtable) withinNData.get("FourthBucket");
		        			innerTable.put(withinLast, perc*drawsSince);
		        		} else {
		        			Hashtable innerTable = new Hashtable();
		        			innerTable.put(withinLast, perc*drawsSince);
		        			withinNData.put("FourthBucket", innerTable);
		        		}
		        	}
		        }

		        hadresults = stmt.getMoreResults();
		    }
			
			stmt = conn.prepareCall("{call percentResultsWithFifthBucketInLastN(?, ?, ?)}");
			stmt.setInt(1, gameCode);
			stmt.setInt(2, withinLast);
			stmt.setInt(3, serial);
			
			hadresults = stmt.execute();
			
			if (hadresults) {
		        ResultSet rs = stmt.getResultSet();

		        if (rs.next()) {
		        	int perc = rs.getInt("percentage");
		        	int drawsSince = rs.getInt("drawsSince");
		        	result.setFifthBucket(Integer.toString(perc*drawsSince));
		        	if (withinNData != null) {
		        		if (withinNData.containsKey("FifthBucket")) {
		        			Hashtable innerTable = (Hashtable) withinNData.get("FifthBucket");
		        			innerTable.put(withinLast, perc*drawsSince);
		        		} else {
		        			Hashtable innerTable = new Hashtable();
		        			innerTable.put(withinLast, perc*drawsSince);
		        			withinNData.put("FifthBucket", innerTable);
		        		}
		        	}
		        }

		        hadresults = stmt.getMoreResults();
		    }
			
			stmt = conn.prepareCall("{call percentResultsWithMegaBucketInLastN(?, ?, ?)}");
			stmt.setInt(1, gameCode);
			stmt.setInt(2, withinLast);
			stmt.setInt(3, serial);
			
			hadresults = stmt.execute();
			
			if (hadresults) {
		        ResultSet rs = stmt.getResultSet();

		        if (rs.next()) {
		        	int perc = rs.getInt("percentage");
		        	int drawsSince = rs.getInt("drawsSince");
		        	result.setMegaBucket(Integer.toString(perc*drawsSince));
		        	if (withinNData != null) {
		        		if (withinNData.containsKey("MegaBucket")) {
		        			Hashtable innerTable = (Hashtable) withinNData.get("MegaBucket");
		        			innerTable.put(withinLast, perc*drawsSince);
		        		} else {
		        			Hashtable innerTable = new Hashtable();
		        			innerTable.put(withinLast, perc*drawsSince);
		        			withinNData.put("MegaBucket", innerTable);
		        		}
		        	}
		        }

		        hadresults = stmt.getMoreResults();
		    }
			
			stmt = conn.prepareCall("{call percentResultsWithFirstPrime(?, ?,?)}");
			stmt.setInt(1, gameCode);
			//stmt.setInt(2, withinLast);
			stmt.setInt(2, serial);
			stmt.registerOutParameter(3, java.sql.Types.INTEGER);
			
			stmt.execute();
			
	       	int outval = stmt.getInt(3);
	        result.setFirstPrime(Integer.toString(outval));
	        	
	       
		       
		    
			
			stmt = conn.prepareCall("{call percentResultsWithsecondPrime(?, ?,?)}");
			stmt.setInt(1, gameCode);
			//stmt.setInt(2, withinLast);
			stmt.setInt(2, serial);
			stmt.registerOutParameter(3, java.sql.Types.INTEGER);
			
			stmt.execute();
			
	       	outval = stmt.getInt(3);
	        result.setSecondPrime(Integer.toString(outval));
			
			
			
			stmt = conn.prepareCall("{call percentResultsWiththirdPrime(?, ?,?)}");
			stmt.setInt(1, gameCode);
			//stmt.setInt(2, withinLast);
			stmt.setInt(2, serial);
			stmt.registerOutParameter(3, java.sql.Types.INTEGER);
			
			stmt.execute();
			
	       	outval = stmt.getInt(3);
	       	result.setThirdPrime(Integer.toString(outval));
			
			
			stmt = conn.prepareCall("{call percentResultsWithfourthPrime(?, ?,?)}");
			stmt.setInt(1, gameCode);
			//stmt.setInt(2, withinLast);
			stmt.setInt(2, serial);
			stmt.registerOutParameter(3, java.sql.Types.INTEGER);
			
			stmt.execute();
			
	       	outval = stmt.getInt(3);
	       	result.setFourthPrime(Integer.toString(outval));
			
			
			stmt = conn.prepareCall("{call percentResultsWithfifthPrime(?, ?,?)}");
			stmt.setInt(1, gameCode);
			//stmt.setInt(2, withinLast);
			stmt.setInt(2, serial);
			stmt.registerOutParameter(3, java.sql.Types.INTEGER);
			
			stmt.execute();
			
	       	outval = stmt.getInt(3);
	       	result.setFifthPrime(Integer.toString(outval));
			
			
			stmt = conn.prepareCall("{call percentResultsWithmegaPrime(?, ?,?)}");
			stmt.setInt(1, gameCode);
			//stmt.setInt(2, withinLast);
			stmt.setInt(2, serial);
			stmt.registerOutParameter(3, java.sql.Types.INTEGER);
			
			stmt.execute();
			
	       	outval = stmt.getInt(3);
	       	result.setMegaPrime(Integer.toString(outval));
			
			
			stmt = conn.prepareCall("{call percentResultsWithfirstFiveSumPrime(?, ?, ?)}");
			stmt.setInt(1, gameCode);
			//stmt.setInt(2, withinLast);
			stmt.setInt(2, serial);
			stmt.registerOutParameter(3, java.sql.Types.INTEGER);
			
			stmt.execute();
			
	       	outval = stmt.getInt(3);
	       	result.setFirstFiveSumPrime(Integer.toString(outval));
			
			
			stmt = conn.prepareCall("{call percentResultsWithnumPrimesInLastN(?,?, ?,?)}");
			stmt.setInt(1, gameCode);
			stmt.setInt(2, withinLast);
			stmt.setInt(3, serial);
			stmt.registerOutParameter(4, java.sql.Types.INTEGER);
			
			stmt.execute();
			
	       	outval = stmt.getInt(4);
	       	result.setNumPrimes(Integer.toString(outval));
			
			stmt = conn.prepareCall("{call percentResultsWithfirstFollower(?, ?,?)}");
			stmt.setInt(1, gameCode);
			//stmt.setInt(2, withinLast);
			stmt.setInt(2, serial);
			stmt.registerOutParameter(3, java.sql.Types.INTEGER);
			
			stmt.execute();
			
	       	outval = stmt.getInt(3);
	        result.setFirstFollower(Integer.toString(outval));
	        	
	       
		       
		    
			
			stmt = conn.prepareCall("{call percentResultsWithsecondFollower(?, ?,?)}");
			stmt.setInt(1, gameCode);
			//stmt.setInt(2, withinLast);
			stmt.setInt(2, serial);
			stmt.registerOutParameter(3, java.sql.Types.INTEGER);
			
			stmt.execute();
			
	       	outval = stmt.getInt(3);
	        result.setSecondFollower(Integer.toString(outval));
			
			
			
			stmt = conn.prepareCall("{call percentResultsWiththirdFollower(?, ?,?)}");
			stmt.setInt(1, gameCode);
			//stmt.setInt(2, withinLast);
			stmt.setInt(2, serial);
			stmt.registerOutParameter(3, java.sql.Types.INTEGER);
			
			stmt.execute();
			
	       	outval = stmt.getInt(3);
	       	result.setThirdFollower(Integer.toString(outval));
			
			
			stmt = conn.prepareCall("{call percentResultsWithfourthFollower(?, ?,?)}");
			stmt.setInt(1, gameCode);
			//stmt.setInt(2, withinLast);
			stmt.setInt(2, serial);
			stmt.registerOutParameter(3, java.sql.Types.INTEGER);
			
			stmt.execute();
			
	       	outval = stmt.getInt(3);
	       	result.setFourthFollower(Integer.toString(outval));
			
			
			stmt = conn.prepareCall("{call percentResultsWithfifthFollower(?, ?,?)}");
			stmt.setInt(1, gameCode);
			//stmt.setInt(2, withinLast);
			stmt.setInt(2, serial);
			stmt.registerOutParameter(3, java.sql.Types.INTEGER);
			
			stmt.execute();
			
	       	outval = stmt.getInt(3);
	       	result.setFifthFollower(Integer.toString(outval));
			
			
			stmt = conn.prepareCall("{call percentResultsWithmegaFollower(?, ?,?)}");
			stmt.setInt(1, gameCode);
			//stmt.setInt(2, withinLast);
			stmt.setInt(2, serial);
			stmt.registerOutParameter(3, java.sql.Types.INTEGER);
			
			stmt.execute();
			
	       	outval = stmt.getInt(3);
	       	result.setMegaFollower(Integer.toString(outval));
			
			
						
			stmt.close();	
			String searchSQL = "select * from " + getTableName() + " where gameCode = " + result.getGameCode() + " and serialNumber = " + result.getSerialNumber() + " and withinLast = " + result.getWithinLast();
			
			Statement qstmt = conn.createStatement();
			
			ResultSet rs = qstmt.executeQuery(searchSQL);
			
			if (rs.next()) {
				result.update();
			} else {
				if (!result.create())
					System.out.println("..... Could not insert serialNumber " +  serial + " Game " + gameCode + " withinLast " + withinLast);
			}
			//System.out.println("..... DONE serialNumber " +  serial);
			//System.out.println(withinNData);
				
		} catch (SQLException e) {
			// TODO Auto-generated catch block
		} finally {
			if (conn != null)
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
	}
	
	public int getWithinLastValuesForFieldBasedOnSTDEV(String fieldName, String gameCode, int serialNum) {
		int out = 0;
		String serialClause = "";
		
		if (serialNum > 0)
			serialClause = " and serialNumber <= " + serialNum;
		
		String sql = "select withinLast, stdev from ( select withinLast, count(*) as coun, stddev(" + fieldName + 
						") as stdev ,avg(" + fieldName + ") as average " +
						" from results_within_lastN_history where gameCode = " + gameCode + serialClause + 
						" group by withinLast having count(*) > 15  and average > 25) as temp order by stdev asc LIMIT 1";
		
		
		Connection conn = null;
		try {
			
			conn = getConnection();
			Statement stmt = conn.createStatement();
			
			ResultSet rs = stmt.executeQuery(sql);
			
			int withinLastValue = 0;
			
			if (rs.next()) {
				out = rs.getInt("withinLast");
				
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			if (conn != null)
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		
		return out;
	}
	
	public String getValuesForFieldBasedOnWithinLast(String fieldName, String gameCode, int serialNum, int withinLast) {
		String out = "";
		
		ResultHistoryEntity rhe = new ResultHistoryEntity();
		rhe.setGameCode(gameCode);
		
		/*out = "WithinLast:" + withinLast + " LastN:" + 
							getLastNValueFor(fieldName, gameCode, serialNum, withinLast) + "/" +
							getMaxLastNValueFor(fieldName, gameCode, serialNum, withinLast) + ":"
							+ rhe.getLastN(fieldName, withinLast, serialNum);*/
		
		out = rhe.getLastNForWithinLast(fieldName, withinLast, serialNum);
		
		return out;
	}
	
	public int getWithinLastValuesForFieldBasedOnCountJump(String fieldName, String gameCode, int serialNum) {
		int out = 0;
		String serialClause = "";
		
		if (serialNum > 0)
			serialClause = " and b.serialNumber <= " + serialNum;
		
		
		String sql = "select withinLast,  count(*) from (	select b." + fieldName + 
						" as preceder, b.withinLast  from results_within_lastN_history a, results_within_lastN_history b where " +
						" a.gameCode = b.gameCode and a.withinLast = b.withinLast and a.gameCode = " + gameCode + serialClause + " and a.serialNumber = b.serialNumber +1 " +
						" and a." + fieldName + " = 0) as temp " + 
						" group by withinLast	order by count(*) desc";
		
		
		Connection conn = null;
		try {
			
			conn = getConnection();
			Statement stmt = conn.createStatement();
			
			ResultSet rs = stmt.executeQuery(sql);
			
			int withinLastValue = 0;
			int prevWithinLast = 0;
			
			while (rs.next()) {
				withinLastValue = rs.getInt("withinLast");
				
				if (prevWithinLast == 0) {
					prevWithinLast = withinLastValue;
				} else {
					/*if ((withinLastValue / 10) != (prevWithinLast /10)) {
						int min = (withinLastValue < prevWithinLast)?withinLastValue:prevWithinLast;
						out = Integer.toString(min);
						break;
					} */
					
					if (((withinLastValue / 10 > 0) && (prevWithinLast /10 == 0)) || 
							((withinLastValue / 10 == 0) && (prevWithinLast /10 > 0)) ) {
						int min = (withinLastValue < prevWithinLast)?withinLastValue:prevWithinLast;
						out = min;
						break;
					}
					prevWithinLast = withinLastValue;
				}
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			if (conn != null)
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		
		return out;
	}
	
	public int getWithinLastValuesForFieldBasedOnMaxFieldValue(String fieldName, String gameCode, int serialNum) {
		int out = 0;
		String serialClause = "";
		
		if (serialNum > 0)
			serialClause = " and serialNumber <= " + serialNum;
		
		
		
		String sql = "select serialNumber, withinLast, " + fieldName + " from results_within_lastN_history"  +
						" where gameCode = " + gameCode + serialClause + 
						" order by serialNumber desc, " + fieldName + " desc, withinLast asc limit 1";
		
		
		Connection conn = null;
		try {
			
			conn = getConnection();
			Statement stmt = conn.createStatement();
			
			ResultSet rs = stmt.executeQuery(sql);
			
			
			if (rs.next()) {
				out = rs.getInt("withinLast");
			
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			if (conn != null)
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		
		return out;
	}
	
	public int getWithinLastValuesForFieldBasedOnMinFieldValue(String fieldName, String gameCode, int serialNum) {
		int out = 0;
		String serialClause = "";
		
		if (serialNum > 0)
			serialClause = " and serialNumber <= " + serialNum;
		
		
		
		String sql = "select serialNumber, withinLast, " + fieldName + " from results_within_lastN_history"  +
						" where gameCode = " + gameCode + serialClause + 
						" order by serialNumber desc, " + fieldName + " asc, withinLast asc limit 1";
		
		
		Connection conn = null;
		try {
			
			conn = getConnection();
			Statement stmt = conn.createStatement();
			
			ResultSet rs = stmt.executeQuery(sql);
			
			
			if (rs.next()) {
				out = rs.getInt("withinLast");
			
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			if (conn != null)
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		
		return out;
	}
	
	public int getLastNValueFor(String fieldName, String gameCode, int serialNum, int withinLast) {
		int out = 0;
		String serialClause = "";
		String withinClause = "";
		if (serialNum > 0)
			serialClause = " and serialNumber = " + serialNum;
		else
			serialClause = " order by serialNumber desc LIMIT 1 " ;
		
		if (withinLast > 0)
			withinClause = " and withinLast = " + withinLast;
		
		String sql = "select " + fieldName + " from results_within_lastN_history where gameCode = " + gameCode + withinClause + serialClause ;
		
		
		Connection conn = null;
		try {
			
			conn = getConnection();
			Statement stmt = conn.createStatement();
			
			ResultSet rs = stmt.executeQuery(sql);
			
			int value = 0;
			
			if (rs.next()) {
				return (rs.getInt(fieldName));
			
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			if (conn != null)
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		
		return out;
	}
	
	
	public int predictLastNValueFor(String fieldName, String gameCode, int serialNum, int withinLast) {
		int out = -1;
		String serialClause = "";
		String withinClause = "";
		
		int currentNValue = -1;
		if (serialNum > 0)
			serialClause = " and serialNumber = " + serialNum;
		else
			serialClause = " order by serialNumber desc LIMIT 1 " ;
		
		if (withinLast > 0)
			withinClause = " and withinLast = " + withinLast;
		
		String sql = "select " + fieldName + " from results_within_lastN_history where gameCode = " + gameCode + withinClause + serialClause ;
		
		String predictSQL = "select withinLast, follower, count(*) from (select a." + fieldName + " as follower, b.withinLast  from results_within_lastN_history a, results_within_lastN_history b " +
								"where a.gameCode = " + gameCode + " and a.gameCode = b.gameCode and a.withinLast = b.withinLast and a.serialNumber = b.serialNumber +1 " +
								" and b." + fieldName + " = ? ) as temp group by withinLast, follower order by withinLast, count(*) desc LIMIT 1";
		
		
		Connection conn = null;
		try {
			
			conn = getConnection();
			Statement stmt = conn.createStatement();
			
			ResultSet rs = stmt.executeQuery(sql);
			
			int value = 0;
			
			if (rs.next()) {
				currentNValue = (rs.getInt(fieldName));
				PreparedStatement pstmt = conn.prepareStatement(predictSQL);
				pstmt.setInt(1, currentNValue);
				ResultSet rsPred = pstmt.executeQuery();
				
				if (rsPred.next()) {
					out = rsPred.getInt("follower");
				}
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			if (conn != null)
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		
		return out;
	}
	
	public int predictLastNValueBasedOnLast2For(String fieldName, String gameCode, int serialNum, int withinLast) {
		int out = -1;
		String serialClause = "";
		String withinClause = "";
		
		int currentNValue = -1;
		int currentNMinus1Value = -1;
		if (serialNum > 0)
			serialClause = " and serialNumber <= " + serialNum + " order by serialNumber desc LIMIT 2 ";
		else
			serialClause = " order by serialNumber desc LIMIT 2 " ;
		
		if (withinLast > 0)
			withinClause = " and withinLast = " + withinLast;
		
		String sql = "select " + fieldName + " from results_within_lastN_history where gameCode = " + gameCode + withinClause + serialClause ;
		
		String predictSQL = "select withinLast, follower, count(*) from (select a." + fieldName + 
							" as follower, b.withinLast  from results_within_lastN_history a, results_within_lastN_history b , results_within_lastN_history c " +
								"where a.gameCode = " + gameCode + 
								" and a.gameCode = b.gameCode and b.gameCode = c.gameCode and a.withinLast = b.withinLast " + 
								" and b.withinLast = c.withinLast and a.serialNumber = b.serialNumber +1 and a.serialNumber = c.serialNumber + 2 " +
								" and b." + fieldName + " = ? and c." + fieldName + " = ?) as temp group by withinLast, follower order by withinLast, count(*) desc LIMIT 1";
		
		
		Connection conn = null;
		try {
			
			conn = getConnection();
			Statement stmt = conn.createStatement();
			
			ResultSet rs = stmt.executeQuery(sql);
			
			int value = 0;
			int counter = 0;
			while (rs.next()) {
				
				if (counter == 0)
					currentNValue = (rs.getInt(fieldName));
				else
					currentNMinus1Value = (rs.getInt(fieldName));
				
				counter++;
			}
			
			PreparedStatement pstmt = conn.prepareStatement(predictSQL);
			pstmt.setInt(1, currentNValue);
			pstmt.setInt(2, currentNMinus1Value);
			ResultSet rsPred = pstmt.executeQuery();
			
			if (rsPred.next()) {
				out = rsPred.getInt("follower");
			}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			if (conn != null)
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		
		return out;
	}
	
	
	public int getMaxLastNValueFor(String fieldName, String gameCode, int serialNum, int withinLast) {
		int out = 0;
		String serialClause = "";
		String withinClause = "";
		if (serialNum > 0)
			serialClause = " and serialNumber <= " + serialNum;
		
		if (withinLast > 0)
			withinClause = " and withinLast = " + withinLast;
		
		String sql = "select max(" + fieldName + ") as maxm from results_within_lastN_history where gameCode = " + gameCode + serialClause + withinClause ;
		
		
		Connection conn = null;
		try {
			
			conn = getConnection();
			Statement stmt = conn.createStatement();
			
			ResultSet rs = stmt.executeQuery(sql);
			
			int value = 0;
			
			if (rs.next()) {
				return (rs.getInt("maxm"));
			
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			if (conn != null)
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		
		return out;
	}
	
	public List getColumnNames() {
		ArrayList l = new ArrayList();
		Connection conn = null;
		
		String sql = "show columns from " + getTableName();
		
		try {
			
			conn = getConnection();
			Statement stmt = conn.createStatement();
			
			ResultSet rs = stmt.executeQuery(sql);
			
			int previousSerial = 0;
			while (rs.next()) {
				String thisField = rs.getString("field");
				
				if (!(thisField.equals("gameCode") || thisField.equals("serialNumber") || thisField.equals("withinLast")))
					l.add(thisField);
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			if (conn != null)
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		
		return l;
	}

}
