package com.num.generator.dataaccess;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;

public class CriteriaResultEntity extends Base {
	
	
	private String criteriaResultID;
	private String 	criteriaID;
	private String firstFiveSum;
	private String firstValue;
	private String  secondValue;
	private String thirdValue;
	private String fourthValue;
	private String fifthValue;
	private String megaValue;
	
	private String firstFreq;
	private String secondFreq;
	private String thirdFreq;
	private String fourthFreq ;
	private String fifthFreq;
	private String megaFreq ;
    
	private String firstSkip;
	private String secondSkip;
	private String thirdSkip;
	private String  fourthSkip;
	private String fifthSkip;
	private String megaSkip;
	private String skipSum;
	private String  firstRedux;
	private String secondRedux;
	private String thirdRedux;
	private String fourthRedux;
	private String fifthRedux;
	private String megaRedux;
	private String firstFiveSumRedux;
	private String firstBucket;
	private String secondBucket;
	private String  thirdBucket;
	private String fourthBucket;
	private String fifthBucket; 
	private String megaBucket;
	private String firstFiveSumBucket;
	private String firstPrime;
	private String secondPrime;
	private String thirdPrime;
	private String fourthPrime;
	private String fifthPrime;
	private String numPrimes;
	private String  megaPrime;
	private String firstFiveSumPrime;
	
	private String match3Diff;
	private String miss3Diff;
	private String  diff1 ;
	private String diff2 ;
	private String diff3 ;
	private String diff4 ;
	private String frequencyMap;
	private String starCount;
	
	private String similarResults;
	
	private String missingDigits;
	private String followerMap;
	private String maxFactor;
	private String maxFactorCount;
	
	private ArrayList<CriteriaResultEntity> listOfCriteriaResults = new ArrayList<CriteriaResultEntity>();

	
	public ArrayList<CriteriaResultEntity> getListOfCriteriaResults() {
		return listOfCriteriaResults;
	}

	public void setListOfCriteriaResults(
			ArrayList<CriteriaResultEntity> listOfCriteriaResults) {
		this.listOfCriteriaResults = listOfCriteriaResults;
	}

	
	public String getCriteriaResultID() {
		return criteriaResultID;
	}

	public void setCriteriaResultID(String criteriaResultID) {
		this.criteriaResultID = criteriaResultID;
	}

	public String getCriteriaID() {
		return criteriaID;
	}

	public void setCriteriaID(String criteriaID) {
		this.criteriaID = criteriaID;
	}

	public String getFirstFiveSum() {
		return firstFiveSum;
	}

	public void setFirstFiveSum(String firstFiveSum) {
		this.firstFiveSum = firstFiveSum;
	}

	public String getFirstValue() {
		return firstValue;
	}

	public void setFirstValue(String firstValue) {
		this.firstValue = firstValue;
	}

	public String getSecondValue() {
		return secondValue;
	}

	public void setSecondValue(String secondValue) {
		this.secondValue = secondValue;
	}

	public String getThirdValue() {
		return thirdValue;
	}

	public void setThirdValue(String thirdValue) {
		this.thirdValue = thirdValue;
	}

	public String getFourthValue() {
		return fourthValue;
	}

	public void setFourthValue(String fourthValue) {
		this.fourthValue = fourthValue;
	}

	public String getFifthValue() {
		return fifthValue;
	}

	public void setFifthValue(String fifthValue) {
		this.fifthValue = fifthValue;
	}

	public String getMegaValue() {
		return megaValue;
	}

	public void setMegaValue(String megaValue) {
		this.megaValue = megaValue;
	}

	public String getFirstSkip() {
		return firstSkip;
	}

	public void setFirstSkip(String firstSkip) {
		this.firstSkip = firstSkip;
	}

	public String getSecondSkip() {
		return secondSkip;
	}

	public void setSecondSkip(String secondSkip) {
		this.secondSkip = secondSkip;
	}

	public String getThirdSkip() {
		return thirdSkip;
	}

	public void setThirdSkip(String thirdSkip) {
		this.thirdSkip = thirdSkip;
	}

	public String getFourthSkip() {
		return fourthSkip;
	}

	public void setFourthSkip(String fourthSkip) {
		this.fourthSkip = fourthSkip;
	}

	public String getFifthSkip() {
		return fifthSkip;
	}

	public void setFifthSkip(String fifthSkip) {
		this.fifthSkip = fifthSkip;
	}

	public String getMegaSkip() {
		return megaSkip;
	}

	public void setMegaSkip(String megaSkip) {
		this.megaSkip = megaSkip;
	}

	public String getSkipSum() {
		return skipSum;
	}

	public void setSkipSum(String skipSum) {
		this.skipSum = skipSum;
	}

	public String getFirstRedux() {
		return firstRedux;
	}

	public void setFirstRedux(String firstRedux) {
		this.firstRedux = firstRedux;
	}

	public String getSecondRedux() {
		return secondRedux;
	}

	public void setSecondRedux(String secondRedux) {
		this.secondRedux = secondRedux;
	}

	public String getThirdRedux() {
		return thirdRedux;
	}

	public void setThirdRedux(String thirdRedux) {
		this.thirdRedux = thirdRedux;
	}

	public String getFourthRedux() {
		return fourthRedux;
	}

	public void setFourthRedux(String fourthRedux) {
		this.fourthRedux = fourthRedux;
	}

	public String getFifthRedux() {
		return fifthRedux;
	}

	public void setFifthRedux(String fifthRedux) {
		this.fifthRedux = fifthRedux;
	}

	public String getMegaRedux() {
		return megaRedux;
	}

	public void setMegaRedux(String megaRedux) {
		this.megaRedux = megaRedux;
	}

	public String getFirstFiveSumRedux() {
		return firstFiveSumRedux;
	}

	public void setFirstFiveSumRedux(String firstFiveSumRedux) {
		this.firstFiveSumRedux = firstFiveSumRedux;
	}

	public String getFirstBucket() {
		return firstBucket;
	}

	public void setFirstBucket(String firstBucket) {
		this.firstBucket = firstBucket;
	}

	public String getSecondBucket() {
		return secondBucket;
	}

	public void setSecondBucket(String secondBucket) {
		this.secondBucket = secondBucket;
	}

	public String getThirdBucket() {
		return thirdBucket;
	}

	public void setThirdBucket(String thirdBucket) {
		this.thirdBucket = thirdBucket;
	}

	public String getFourthBucket() {
		return fourthBucket;
	}

	public void setFourthBucket(String fourthBucket) {
		this.fourthBucket = fourthBucket;
	}

	public String getFifthBucket() {
		return fifthBucket;
	}

	public void setFifthBucket(String fifthBucket) {
		this.fifthBucket = fifthBucket;
	}

	public String getMegaBucket() {
		return megaBucket;
	}

	public void setMegaBucket(String megaBucket) {
		this.megaBucket = megaBucket;
	}

	public String getFirstFiveSumBucket() {
		return firstFiveSumBucket;
	}

	public void setFirstFiveSumBucket(String firstFiveSumBucket) {
		this.firstFiveSumBucket = firstFiveSumBucket;
	}

	public String getFirstPrime() {
		return firstPrime;
	}

	public void setFirstPrime(String firstPrime) {
		this.firstPrime = firstPrime;
	}

	public String getSecondPrime() {
		return secondPrime;
	}

	public void setSecondPrime(String secondPrime) {
		this.secondPrime = secondPrime;
	}

	public String getThirdPrime() {
		return thirdPrime;
	}

	public void setThirdPrime(String thirdPrime) {
		this.thirdPrime = thirdPrime;
	}

	public String getFourthPrime() {
		return fourthPrime;
	}

	public void setFourthPrime(String fourthPrime) {
		this.fourthPrime = fourthPrime;
	}

	public String getFifthPrime() {
		return fifthPrime;
	}

	public void setFifthPrime(String fifthPrime) {
		this.fifthPrime = fifthPrime;
	}

	public String getNumPrimes() {
		return numPrimes;
	}

	public void setNumPrimes(String numPrimes) {
		this.numPrimes = numPrimes;
	}

	public String getMegaPrime() {
		return megaPrime;
	}

	public void setMegaPrime(String megaPrime) {
		this.megaPrime = megaPrime;
	}

	public String getFirstFiveSumPrime() {
		return firstFiveSumPrime;
	}

	public void setFirstFiveSumPrime(String firstFiveSumPrime) {
		this.firstFiveSumPrime = firstFiveSumPrime;
	}

	public String getMatch3Diff() {
		return match3Diff;
	}

	public void setMatch3Diff(String match3Diff) {
		this.match3Diff = match3Diff;
	}

	public String getMiss3Diff() {
		return miss3Diff;
	}

	public void setMiss3Diff(String miss3Diff) {
		this.miss3Diff = miss3Diff;
	}

	public String getDiff1() {
		return diff1;
	}

	public void setDiff1(String diff1) {
		this.diff1 = diff1;
	}

	public String getDiff2() {
		return diff2;
	}

	public void setDiff2(String diff2) {
		this.diff2 = diff2;
	}

	public String getDiff3() {
		return diff3;
	}

	public void setDiff3(String diff3) {
		this.diff3 = diff3;
	}

	public String getDiff4() {
		return diff4;
	}

	public void setDiff4(String diff4) {
		this.diff4 = diff4;
	}

	public String getFrequencyMap() {
		return frequencyMap;
	}

	public void setFrequencyMap(String frequencyMap) {
		this.frequencyMap = frequencyMap;
	}

	public String getFirstFreq() {
		return firstFreq;
	}

	public void setFirstFreq(String firstFreq) {
		this.firstFreq = firstFreq;
	}

	public String getSecondFreq() {
		return secondFreq;
	}

	public void setSecondFreq(String secondFreq) {
		this.secondFreq = secondFreq;
	}

	public String getThirdFreq() {
		return thirdFreq;
	}

	public void setThirdFreq(String thirdFreq) {
		this.thirdFreq = thirdFreq;
	}

	public String getFourthFreq() {
		return fourthFreq;
	}

	public void setFourthFreq(String fourthFreq) {
		this.fourthFreq = fourthFreq;
	}

	public String getFifthFreq() {
		return fifthFreq;
	}

	public void setFifthFreq(String fifthFreq) {
		this.fifthFreq = fifthFreq;
	}

	public String getMegaFreq() {
		return megaFreq;
	}

	public void setMegaFreq(String megaFreq) {
		this.megaFreq = megaFreq;
	}

	public String getStarCount() {
		return starCount;
	}

	public void setStarCount(String starCount) {
		this.starCount = starCount;
	}

	public String getSimilarResults() {
		return similarResults;
	}

	public void setSimilarResults(String similarResults) {
		this.similarResults = similarResults;
	}

	public String getMissingDigits() {
		return missingDigits;
	}

	public void setMissingDigits(String missingDigits) {
		this.missingDigits = missingDigits;
	}

	public String getFollowerMap() {
		return followerMap;
	}

	public String getMaxFactor() {
		return maxFactor;
	}

	public void setMaxFactor(String maxFactor) {
		this.maxFactor = maxFactor;
	}

	public String getMaxFactorCount() {
		return maxFactorCount;
	}

	public void setMaxFactorCount(String maxFactorCount) {
		this.maxFactorCount = maxFactorCount;
	}

	public void setFollowerMap(String followerMap) {
		this.followerMap = followerMap;
	}

	@Override
	public String getTableName() {
		return " criteria_result ";
	}

	@Override
	public String getInsertSQL() {
		
		
		if (listOfCriteriaResults != null && listOfCriteriaResults.size() > 0)
			return getMultipleInsertSQL();
		
		StringBuffer buff = new StringBuffer();
		
		StringBuffer internalBuffer = new StringBuffer();
		
		buff.append("Insert into " + getTableName() + "( ");
		
		if (getCriteriaResultID() != null)  {
			buff.append("criteriaResultID,");
			internalBuffer.append("'" + getCriteriaResultID() + "',");
		}
		
		if (getCriteriaID() != null)  {
			buff.append("criteriaID,");
			internalBuffer.append("'" + getCriteriaID() + "',");
		}
		
		if (getFirstValue() != null)  {
			buff.append("firstValue,");
			internalBuffer.append("'" + getFirstValue() + "',");
		}
		
		if (getSecondValue() != null)  {
			buff.append("secondValue,");
			internalBuffer.append("'" + getSecondValue() + "',");
		}
		
		if (getThirdValue() != null)  {
			buff.append("thirdValue,");
			internalBuffer.append("'" + getThirdValue() + "',");
		}
		
		if (getFourthValue() != null)  {
			buff.append("fourthValue,");
			internalBuffer.append("'" + getFourthValue() + "',");
		}
		
		if (getFifthValue() != null)  {
			buff.append("fifthValue,");
			internalBuffer.append("'" + getFifthValue() + "',");
		}
		
		if (getMegaValue() != null)  {
			buff.append("megaValue,");
			internalBuffer.append("'" + getMegaValue() + "',");
		}
		
		if (getStarCount() != null)  {
			buff.append("starCount,");
			internalBuffer.append("'" + getStarCount() + "',");
		}
		
		
		
		if (getSimilarResults() != null)  {
			buff.append("similarResults,");
			internalBuffer.append("'" + getSimilarResults() + "',");
		}
		
		if (getMissingDigits() != null)  {
			buff.append("missingDigits,");
			internalBuffer.append("'" + getMissingDigits() + "',");
		}
		
		if (getFollowerMap() != null)  {
			buff.append("followerMap,");
			internalBuffer.append("'" + getFollowerMap() + "',");
		}
		
		
		if (getFirstFreq() != null)  {
			buff.append("firstFreq,");
			internalBuffer.append("'" + getFirstFreq() + "',");
		}
		
		if (getSecondFreq() != null)  {
			buff.append("secondFreq,");
			internalBuffer.append("'" + getSecondFreq() + "',");
		}
		
		if (getThirdFreq() != null)  {
			buff.append("thirdFreq,");
			internalBuffer.append("'" + getThirdFreq() + "',");
		}
		
		if (getFourthFreq() != null)  {
			buff.append("fourthFreq,");
			internalBuffer.append("'" + getFourthFreq() + "',");
		}
		
		if (getFifthFreq() != null)  {
			buff.append("fifthFreq,");
			internalBuffer.append("'" + getFifthFreq() + "',");
		}
		
		if (getMegaFreq() != null)  {
			buff.append("megaFreq,");
			internalBuffer.append("'" + getMegaFreq() + "',");
		}
		
		
		
		
		if (getFirstSkip() != null)  {
			buff.append("firstSkip,");
			internalBuffer.append("'" + getFirstSkip() + "',");
		}
		
		if (getSecondSkip() != null)  {
			buff.append("secondSkip,");
			internalBuffer.append("'" + getSecondSkip() + "',");
		}
		
		if (getThirdSkip() != null)  {
			buff.append("thirdSkip,");
			internalBuffer.append("'" + getThirdSkip() + "',");
		}
		
		if (getFourthSkip() != null)  {
			buff.append("fourthSkip,");
			internalBuffer.append("'" + getFourthSkip() + "',");
		}
		
		if (getFifthSkip() != null)  {
			buff.append("fifthSkip,");
			internalBuffer.append("'" + getFifthSkip() + "',");
		}
		
		if (getMegaSkip() != null)  {
			buff.append("megaSkip,");
			internalBuffer.append("'" + getMegaSkip() + "',");
		}
		
		if (getSkipSum() != null)  {
			buff.append("skipSum,");
			internalBuffer.append("'" + getSkipSum() + "',");
		}
		
		if (getFirstRedux() != null)  {
			buff.append("firstRedux,");
			internalBuffer.append("'" + getFirstRedux() + "',");
		}
		
		if (getSecondRedux() != null)  {
			buff.append("secondRedux,");
			internalBuffer.append("'" + getSecondRedux() + "',");
		}
		
		if (getThirdRedux() != null)  {
			buff.append("thirdRedux,");
			internalBuffer.append("'" + getThirdRedux() + "',");
		}
		
		if (getFourthRedux() != null)  {
			buff.append("fourthRedux,");
			internalBuffer.append("'" + getFourthRedux() + "',");
		}
		
		if (getFifthRedux() != null)  {
			buff.append("fifthRedux,");
			internalBuffer.append("'" + getFifthRedux() + "',");
		}
		
		if (getMegaRedux() != null)  {
			buff.append("megaRedux,");
			internalBuffer.append("'" + getMegaRedux() + "',");
		}
		
		if (getFirstBucket() != null)  {
			buff.append("firstBucket,");
			internalBuffer.append("'" + getFirstBucket() + "',");
		}
		
		if (getSecondBucket() != null)  {
			buff.append("secondBucket,");
			internalBuffer.append("'" + getSecondBucket() + "',");
		}
		
		if (getThirdBucket() != null)  {
			buff.append("thirdBucket,");
			internalBuffer.append("'" + getThirdBucket() + "',");
		}
		
		if (getFourthBucket() != null)  {
			buff.append("fourthBucket,");
			internalBuffer.append("'" + getFourthBucket() + "',");
		}
		
		if (getFifthBucket() != null)  {
			buff.append("fifthBucket,");
			internalBuffer.append("'" + getFifthBucket() + "',");
		}
		
		if (getMegaBucket() != null)  {
			buff.append("megaBucket,");
			internalBuffer.append("'" + getMegaBucket() + "',");
		}
		
		if (getFirstFiveSumBucket() != null)  {
			buff.append("firstFiveSumBucket,");
			internalBuffer.append("'" + getFirstFiveSumBucket() + "',");
	}
	
		
		if (getFirstFiveSum() != null)  {
				buff.append("firstFiveSum,");
				internalBuffer.append("'" + getFirstFiveSum() + "',");
		}
			
		if (getFirstFiveSumRedux() != null)  {
				buff.append("firstFiveSumRedux,");
				internalBuffer.append("'" + getFirstFiveSumRedux() + "',");
		}
		
		
		if (getFirstPrime() != null)  {
			buff.append("firstPrime,");
			internalBuffer.append("'" + getFirstPrime() + "',");
		}
			
		if (getSecondPrime() != null)  {
			buff.append("secondPrime,");
			internalBuffer.append("'" + getSecondPrime() + "',");
		}
				
		if (getThirdPrime() != null)  {
			buff.append("thirdPrime,");
			internalBuffer.append("'" + getThirdPrime() + "',");
		}
		
		if (getFourthPrime() != null)  {
			buff.append("fourthPrime,");
			internalBuffer.append("'" + getFourthPrime() + "',");
		}
		
		if (getFifthPrime() != null)  {
			buff.append("fifthPrime,");
			internalBuffer.append("'" + getFifthPrime() + "',");
		}
		
		if (getMegaPrime() != null)  {
			buff.append("megaPrime,");
			internalBuffer.append("'" + getMegaPrime() + "',");
		}
		
		if (getNumPrimes() != null)  {
			buff.append("numPrimes,");
			internalBuffer.append("'" + getNumPrimes() + "',");
		}
		
		if (getFirstFiveSumPrime() != null)  {
			buff.append("firstFiveSumPrime,");
			internalBuffer.append("'" + getFirstFiveSumPrime() + "',");
		}
		
		
		if (getMatch3Diff() != null)  {
			buff.append("match3Diff,");
			internalBuffer.append("'" + getMatch3Diff() + "',");
		}
			
		if (getMiss3Diff() != null)  {
			buff.append("miss3Diff,");
			internalBuffer.append("'" + getMiss3Diff() + "',");
		}
				
		if (getDiff1() != null)  {
			buff.append("diff1,");
			internalBuffer.append("'" + getDiff1() + "',");
		}
		
		if (getDiff2() != null)  {
			buff.append("diff2,");
			internalBuffer.append("'" + getDiff2() + "',");
		}
		
		if (getDiff3() != null)  {
			buff.append("diff3,");
			internalBuffer.append("'" + getDiff3() + "',");
		}
		
		if (getDiff4() != null)  {
			buff.append("diff4,");
			internalBuffer.append("'" + getDiff4() + "',");
		}
		
		if (getFrequencyMap() != null)  {
			buff.append("frequencyMap,");
			internalBuffer.append("'" + getFrequencyMap() + "',");
		}
		
		if (getMaxFactor() != null)  {
			buff.append("maxFactor,");
			internalBuffer.append("'" + getMaxFactor() + "',");
		}
		
		if (getMaxFactorCount() != null)  {
			buff.append("maxFactorCount,");
			internalBuffer.append("'" + getMaxFactorCount() + "',");
		}
		
		return buff.substring(0,buff.length()-1) + ") values ( "+ internalBuffer.substring(0,internalBuffer.length()-1) + ")" ;
	}
	
	
	
	
	
	
	private String getMultipleInsertSQL() {
		StringBuffer buff = new StringBuffer();
		
		StringBuffer internalBuffer = new StringBuffer();
		
		buff.append("Insert into " + getTableName() + "( ");
		
		Iterator it = listOfCriteriaResults.iterator();
		
		int counter = 0;
		
		while(it.hasNext()) {
			
			
				CriteriaResultEntity gb = (CriteriaResultEntity) it.next();
				
				
				
				if (counter == 0) {
					
					
					if (gb.getCriteriaResultID() != null)  {
						buff.append("criteriaResultID,");
						internalBuffer.append("'" + gb.getCriteriaResultID() + "',");
					}
					
					if (gb.getCriteriaID() != null)  {
						buff.append("criteriaID,");
						internalBuffer.append("'" + gb.getCriteriaID() + "',");
					}
					
					if (gb.getFirstValue() != null)  {
						buff.append("firstValue,");
						internalBuffer.append("'" + gb.getFirstValue() + "',");
					}
					
					if (gb.getSecondValue() != null)  {
						buff.append("secondValue,");
						internalBuffer.append("'" + gb.getSecondValue() + "',");
					}
					
					if (gb.getThirdValue() != null)  {
						buff.append("thirdValue,");
						internalBuffer.append("'" + gb.getThirdValue() + "',");
					}
					
					if (gb.getFourthValue() != null)  {
						buff.append("fourthValue,");
						internalBuffer.append("'" + gb.getFourthValue() + "',");
					}
					
					if (gb.getFifthValue() != null)  {
						buff.append("fifthValue,");
						internalBuffer.append("'" + gb.getFifthValue() + "',");
					}
					
					if (gb.getMegaValue() != null)  {
						buff.append("megaValue,");
						internalBuffer.append("'" + gb.getMegaValue() + "',");
					}
					
					if (gb.getStarCount() != null)  {
						buff.append("starCount,");
						internalBuffer.append("'" + gb.getStarCount() + "',");
					}
					
					if (gb.getSimilarResults() != null)  {
						buff.append("similarResults,");
						internalBuffer.append("'" + gb.getSimilarResults() + "',");
					}
					
					
					if (gb.getMissingDigits() != null)  {
						buff.append("missingDigits,");
						internalBuffer.append("'" + gb.getMissingDigits() + "',");
					}
					
					if (gb.getFollowerMap() != null)  {
						buff.append("followerMap,");
						internalBuffer.append("'" + gb.getFollowerMap() + "',");
					}
					
					
					if (gb.getFirstFreq() != null)  {
						buff.append("firstFreq,");
						internalBuffer.append("'" + gb.getFirstFreq() + "',");
					}
					
					if (gb.getSecondFreq() != null)  {
						buff.append("secondFreq,");
						internalBuffer.append("'" + gb.getSecondFreq() + "',");
					}
					
					if (gb.getThirdFreq() != null)  {
						buff.append("thirdFreq,");
						internalBuffer.append("'" + gb.getThirdFreq() + "',");
					}
					
					if (gb.getFourthFreq() != null)  {
						buff.append("fourthFreq,");
						internalBuffer.append("'" + gb.getFourthFreq() + "',");
					}
					
					if (gb.getFifthFreq() != null)  {
						buff.append("fifthFreq,");
						internalBuffer.append("'" + gb.getFifthFreq() + "',");
					}
					
					if (gb.getMegaFreq() != null)  {
						buff.append("megaFreq,");
						internalBuffer.append("'" + gb.getMegaFreq() + "',");
					}
					
					if (gb.getFirstSkip() != null)  {
						buff.append("firstSkip,");
						internalBuffer.append("'" + gb.getFirstSkip() + "',");
					}
					
					if (gb.getSecondSkip() != null)  {
						buff.append("secondSkip,");
						internalBuffer.append("'" + gb.getSecondSkip() + "',");
					}
					
					if (gb.getThirdSkip() != null)  {
						buff.append("thirdSkip,");
						internalBuffer.append("'" + gb.getThirdSkip() + "',");
					}
					
					if (gb.getFourthSkip() != null)  {
						buff.append("fourthSkip,");
						internalBuffer.append("'" + gb.getFourthSkip() + "',");
					}
					
					if (gb.getFifthSkip() != null)  {
						buff.append("fifthSkip,");
						internalBuffer.append("'" + gb.getFifthSkip() + "',");
					}
					
					if (gb.getMegaSkip() != null)  {
						buff.append("megaSkip,");
						internalBuffer.append("'" + gb.getMegaSkip() + "',");
					}
					
					if (gb.getSkipSum() != null)  {
						buff.append("skipSum,");
						internalBuffer.append("'" + gb.getSkipSum() + "',");
					}
					
					if (gb.getFirstRedux() != null)  {
						buff.append("firstRedux,");
						internalBuffer.append("'" + gb.getFirstRedux() + "',");
					}
					
					if (gb.getSecondRedux() != null)  {
						buff.append("secondRedux,");
						internalBuffer.append("'" + gb.getSecondRedux() + "',");
					}
					
					if (gb.getThirdRedux() != null)  {
						buff.append("thirdRedux,");
						internalBuffer.append("'" + gb.getThirdRedux() + "',");
					}
					
					if (gb.getFourthRedux() != null)  {
						buff.append("fourthRedux,");
						internalBuffer.append("'" + gb.getFourthRedux() + "',");
					}
					
					if (gb.getFifthRedux() != null)  {
						buff.append("fifthRedux,");
						internalBuffer.append("'" + gb.getFifthRedux() + "',");
					}
					
					if (gb.getMegaRedux() != null)  {
						buff.append("megaRedux,");
						internalBuffer.append("'" + gb.getMegaRedux() + "',");
					}
					
					if (gb.getFirstBucket() != null)  {
						buff.append("firstBucket,");
						internalBuffer.append("'" + gb.getFirstBucket() + "',");
					}
					
					if (gb.getSecondBucket() != null)  {
						buff.append("secondBucket,");
						internalBuffer.append("'" + gb.getSecondBucket() + "',");
					}
					
					if (gb.getThirdBucket() != null)  {
						buff.append("thirdBucket,");
						internalBuffer.append("'" + gb.getThirdBucket() + "',");
					}
					
					if (gb.getFourthBucket() != null)  {
						buff.append("fourthBucket,");
						internalBuffer.append("'" + gb.getFourthBucket() + "',");
					}
					
					if (gb.getFifthBucket() != null)  {
						buff.append("fifthBucket,");
						internalBuffer.append("'" + gb.getFifthBucket() + "',");
					}
					
					if (gb.getMegaBucket() != null)  {
						buff.append("megaBucket,");
						internalBuffer.append("'" + gb.getMegaBucket() + "',");
					}
					
					if (gb.getFirstFiveSumBucket() != null)  {
						buff.append("firstFiveSumBucket,");
						internalBuffer.append("'" + gb.getFirstFiveSumBucket() + "',");
					}
				
					
					if (gb.getFirstFiveSum() != null)  {
							buff.append("firstFiveSum,");
							internalBuffer.append("'" + gb.getFirstFiveSum() + "',");
					}
						
					if (gb.getFirstFiveSumRedux() != null)  {
							buff.append("firstFiveSumRedux,");
							internalBuffer.append("'" + gb.getFirstFiveSumRedux() + "',");
					}
					
					
					if (gb.getFirstPrime() != null)  {
						buff.append("firstPrime,");
						internalBuffer.append("'" + gb.getFirstPrime() + "',");
					}
						
					if (gb.getSecondPrime() != null)  {
						buff.append("secondPrime,");
						internalBuffer.append("'" + gb.getSecondPrime() + "',");
					}
							
					if (gb.getThirdPrime() != null)  {
						buff.append("thirdPrime,");
						internalBuffer.append("'" + gb.getThirdPrime() + "',");
					}
					
					if (gb.getFourthPrime() != null)  {
						buff.append("fourthPrime,");
						internalBuffer.append("'" + gb.getFourthPrime() + "',");
					}
					
					if (gb.getFifthPrime() != null)  {
						buff.append("fifthPrime,");
						internalBuffer.append("'" + gb.getFifthPrime() + "',");
					}
					
					if (gb.getMegaPrime() != null)  {
						buff.append("megaPrime,");
						internalBuffer.append("'" + gb.getMegaPrime() + "',");
					}
					
					if (gb.getNumPrimes() != null)  {
						buff.append("numPrimes,");
						internalBuffer.append("'" + gb.getNumPrimes() + "',");
					}
					
					if (gb.getFirstFiveSumPrime() != null)  {
						buff.append("firstFiveSumPrime,");
						internalBuffer.append("'" + gb.getFirstFiveSumPrime() + "',");
					}
					
					
					if (gb.getMatch3Diff() != null)  {
						buff.append("match3Diff,");
						internalBuffer.append("'" + gb.getMatch3Diff() + "',");
					}
						
					if (gb.getMiss3Diff() != null)  {
						buff.append("miss3Diff,");
						internalBuffer.append("'" + gb.getMiss3Diff() + "',");
					}
							
					if (gb.getDiff1() != null)  {
						buff.append("diff1,");
						internalBuffer.append("'" + gb.getDiff1() + "',");
					}
					
					if (gb.getDiff2() != null)  {
						buff.append("diff2,");
						internalBuffer.append("'" + gb.getDiff2() + "',");
					}
					
					if (gb.getDiff3() != null)  {
						buff.append("diff3,");
						internalBuffer.append("'" + gb.getDiff3() + "',");
					}
					
					if (gb.getDiff4() != null)  {
						buff.append("diff4,");
						internalBuffer.append("'" + gb.getDiff4() + "',");
					}
					
					if (gb.getFrequencyMap() != null)  {
						buff.append("frequencyMap,");
						internalBuffer.append("'" + gb.getFrequencyMap() + "',");
					}
					
					if (gb.getMaxFactor() != null)  {
						buff.append("maxFactor,");
						internalBuffer.append("'" + gb.getMaxFactor() + "',");
					}
					
					if (gb.getMaxFactorCount() != null)  {
						buff.append("maxFactorCount,");
						internalBuffer.append("'" + gb.getMaxFactorCount() + "',");
					}
					
					
					
					internalBuffer.deleteCharAt(internalBuffer.length()-1);
					internalBuffer.append(")");
					
				} else {
					internalBuffer.append(",(");
					
					if (gb.getCriteriaResultID() != null)  {
						internalBuffer.append("'" + gb.getCriteriaResultID() + "',");
					}
					
					if (gb.getCriteriaID() != null)  {
						internalBuffer.append("'" + gb.getCriteriaID() + "',");
					}
					
					if (gb.getFirstValue() != null)  {
						internalBuffer.append("'" + gb.getFirstValue() + "',");
					}
					
					if (gb.getSecondValue() != null)  {
						internalBuffer.append("'" + gb.getSecondValue() + "',");
					}
					
					if (gb.getThirdValue() != null)  {
						internalBuffer.append("'" + gb.getThirdValue() + "',");
					}
					
					if (gb.getFourthValue() != null)  {
						internalBuffer.append("'" + gb.getFourthValue() + "',");
					}
					
					if (gb.getFifthValue() != null)  {
						internalBuffer.append("'" + gb.getFifthValue() + "',");
					}
					
					if (gb.getMegaValue() != null)  {
						internalBuffer.append("'" + gb.getMegaValue() + "',");
					}
					
					if (gb.getStarCount() != null)  {
						internalBuffer.append("'" + gb.getStarCount() + "',");
					}
					
					if (gb.getSimilarResults() != null)  {
						internalBuffer.append("'" + gb.getSimilarResults() + "',");
					}
					
					
					
					if (gb.getMissingDigits() != null)  {
						internalBuffer.append("'" + gb.getMissingDigits() + "',");
					}
					
					if (gb.getFollowerMap() != null)  {
						internalBuffer.append("'" + gb.getFollowerMap() + "',");
					}
					
					
					if (gb.getFirstFreq() != null)  {
						internalBuffer.append("'" + gb.getFirstFreq() + "',");
					}
					
					if (gb.getSecondFreq() != null)  {
						internalBuffer.append("'" + gb.getSecondFreq() + "',");
					}
					
					if (gb.getThirdFreq() != null)  {
						internalBuffer.append("'" + gb.getThirdFreq() + "',");
					}
					
					if (gb.getFourthFreq() != null)  {
						internalBuffer.append("'" + gb.getFourthFreq() + "',");
					}
					
					if (gb.getFifthFreq() != null)  {
						internalBuffer.append("'" + gb.getFifthFreq() + "',");
					}
					
					if (gb.getMegaFreq() != null)  {
						internalBuffer.append("'" + gb.getMegaFreq() + "',");
					}
					
					
					
					
					if (gb.getFirstSkip() != null)  {
						internalBuffer.append("'" + gb.getFirstSkip() + "',");
					}
					
					if (gb.getSecondSkip() != null)  {
						internalBuffer.append("'" + gb.getSecondSkip() + "',");
					}
					
					if (gb.getThirdSkip() != null)  {
						internalBuffer.append("'" + gb.getThirdSkip() + "',");
					}
					
					if (gb.getFourthSkip() != null)  {
						internalBuffer.append("'" + gb.getFourthSkip() + "',");
					}
					
					if (gb.getFifthSkip() != null)  {
						internalBuffer.append("'" + gb.getFifthSkip() + "',");
					}
					
					if (gb.getMegaSkip() != null)  {
						internalBuffer.append("'" + gb.getMegaSkip() + "',");
					}
					
					if (gb.getSkipSum() != null)  {
						internalBuffer.append("'" + gb.getSkipSum() + "',");
					}
					
					if (gb.getFirstRedux() != null)  {
						internalBuffer.append("'" + gb.getFirstRedux() + "',");
					}
					
					if (gb.getSecondRedux() != null)  {
						internalBuffer.append("'" + gb.getSecondRedux() + "',");
					}
					
					if (gb.getThirdRedux() != null)  {
						internalBuffer.append("'" + gb.getThirdRedux() + "',");
					}
					
					if (gb.getFourthRedux() != null)  {
						internalBuffer.append("'" + gb.getFourthRedux() + "',");
					}
					
					if (gb.getFifthRedux() != null)  {
						internalBuffer.append("'" + gb.getFifthRedux() + "',");
					}
					
					if (gb.getMegaRedux() != null)  {
						internalBuffer.append("'" + gb.getMegaRedux() + "',");
					}
					
					if (gb.getFirstBucket() != null)  {
						internalBuffer.append("'" + gb.getFirstBucket() + "',");
					}
					
					if (gb.getSecondBucket() != null)  {
						internalBuffer.append("'" + gb.getSecondBucket() + "',");
					}
					
					if (gb.getThirdBucket() != null)  {
						internalBuffer.append("'" + gb.getThirdBucket() + "',");
					}
					
					if (gb.getFourthBucket() != null)  {
						internalBuffer.append("'" + gb.getFourthBucket() + "',");
					}
					
					if (gb.getFifthBucket() != null)  {
						internalBuffer.append("'" + gb.getFifthBucket() + "',");
					}
					
					if (gb.getMegaBucket() != null)  {
						internalBuffer.append("'" + gb.getMegaBucket() + "',");
					}
					
					if (gb.getFirstFiveSumBucket() != null)  {
						internalBuffer.append("'" + gb.getFirstFiveSumBucket() + "',");
				}
				
					
					if (gb.getFirstFiveSum() != null)  {
							internalBuffer.append("'" + gb.getFirstFiveSum() + "',");
					}
						
					if (gb.getFirstFiveSumRedux() != null)  {
							internalBuffer.append("'" + gb.getFirstFiveSumRedux() + "',");
					}
					
					
					if (gb.getFirstPrime() != null)  {
						internalBuffer.append("'" + gb.getFirstPrime() + "',");
					}
						
					if (gb.getSecondPrime() != null)  {
						internalBuffer.append("'" + gb.getSecondPrime() + "',");
					}
							
					if (gb.getThirdPrime() != null)  {
						internalBuffer.append("'" + gb.getThirdPrime() + "',");
					}
					
					if (gb.getFourthPrime() != null)  {
						internalBuffer.append("'" + gb.getFourthPrime() + "',");
					}
					
					if (gb.getFifthPrime() != null)  {
						internalBuffer.append("'" + gb.getFifthPrime() + "',");
					}
					
					if (gb.getMegaPrime() != null)  {
						internalBuffer.append("'" + gb.getMegaPrime() + "',");
					}
					
					if (gb.getNumPrimes() != null)  {
						internalBuffer.append("'" + gb.getNumPrimes() + "',");
					}
					
					if (gb.getFirstFiveSumPrime() != null)  {
						internalBuffer.append("'" + gb.getFirstFiveSumPrime() + "',");
					}
					
					
					if (gb.getMatch3Diff() != null)  {
						internalBuffer.append("'" + gb.getMatch3Diff() + "',");
					}
						
					if (gb.getMiss3Diff() != null)  {
						internalBuffer.append("'" + gb.getMiss3Diff() + "',");
					}
							
					if (gb.getDiff1() != null)  {
						internalBuffer.append("'" + gb.getDiff1() + "',");
					}
					
					if (gb.getDiff2() != null)  {
						internalBuffer.append("'" + gb.getDiff2() + "',");
					}
					
					if (gb.getDiff3() != null)  {
						internalBuffer.append("'" + gb.getDiff3() + "',");
					}
					
					if (gb.getDiff4() != null)  {
						internalBuffer.append("'" + gb.getDiff4() + "',");
					}
					
					if (gb.getFrequencyMap() != null)  {
						internalBuffer.append("'" + gb.getFrequencyMap() + "',");
					}
					
					if (gb.getMaxFactor() != null)  {
						internalBuffer.append("'" + gb.getMaxFactor() + "',");
					}
					
					if (gb.getMaxFactorCount() != null)  {
						internalBuffer.append("'" + gb.getMaxFactorCount() + "',");
					}
					
					
									
					internalBuffer.deleteCharAt(internalBuffer.length()-1);
					internalBuffer.append(")");
				}
			
				counter++;
		
		}
		
		
		return buff.substring(0,buff.length()-1) + ") values ( "+ internalBuffer.toString() ;
	}

	@Override
	public String getUpdateSQL() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Collection readAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Collection findRows() {
		// TODO Auto-generated method stub
		return null;
	}

}
