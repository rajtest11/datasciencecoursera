package com.num.generator.dataaccess;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Hashtable;
import java.util.Iterator;

public class AggregateRanksEntity extends Base {
	
	private static final String MISSING_DIGITS_PARAM_TYPE = "MIS";
	private static final String FOLLOWER_MAP_PARAM_TYPE = "FOL";
	private static final String SKIP_SUM_PARAM_TYPE = "SKP";
	private static final String MAX_FACTOR_PARAM_TYPE = "MXF";
	private static final String BUCKET_GAP_MAP_PARAM_TYPE = "BGM";
	
	private String gameCode;
	private String 	paramType; 
	private String	paramValue ;
	private String	paramRank;
	private String instances;
	
	private ArrayList<AggregateRanksEntity> listOfparams = new ArrayList<AggregateRanksEntity>();

	public static void main(String[] args) {
		AggregateRanksEntity e = new AggregateRanksEntity();
		System.out.println("Creating AggregateRanks ");
		
		e.populateBucketGapMapRanks("1");
		e.populateMaxFactorRanks("1");
		e.populateFollowerMapRanks("1");
		e.populateMissingDigitRanks("1");
		
		
	}
	
	public String getGameCode() {
		return gameCode;
	}

	public void setGameCode(String gameCode) {
		this.gameCode = gameCode;
	}

	public String getParamType() {
		return paramType;
	}

	public void setParamType(String paramType) {
		this.paramType = paramType;
	}

	public String getParamValue() {
		return paramValue;
	}

	public void setParamValue(String paramValue) {
		this.paramValue = paramValue;
	}

	public String getParamRank() {
		return paramRank;
	}

	public void setParamRank(String paramRank) {
		this.paramRank = paramRank;
	}

	
	public String getInstances() {
		return instances;
	}

	public void setInstances(String instances) {
		this.instances = instances;
	}

	public String getTableName() {
		return " aggregate_ranks " ;
	}

	
	public String getInsertSQL() {
		if (listOfparams != null && listOfparams.size() > 0)
			return getMultipleInsertSQL();
		
		StringBuffer buff = new StringBuffer();
		
		StringBuffer internalBuffer = new StringBuffer();
		
		buff.append("Insert into " + getTableName() + "( ");
		
		if (getGameCode() != null)  {
			buff.append("gameCode,");
			internalBuffer.append("'" + getGameCode() + "',");
		}
		
		if (getParamType() != null)  {
			buff.append("paramType,");
			internalBuffer.append("'" + getParamType() + "',");
		}
		
		if (getParamValue() != null)  {
			buff.append("paramValue,");
			internalBuffer.append("'" + getParamValue() + "',");
		}
		
		if (getParamRank() != null)  {
			buff.append("paramRank,");
			internalBuffer.append("'" + getParamRank() + "',");
		}
		
		if (getInstances() != null)  {
			buff.append("instances,");
			internalBuffer.append("'" + getInstances() + "',");
		}
			
		return buff.substring(0,buff.length()-1) + ") values ( "+ internalBuffer.substring(0,internalBuffer.length()-1) + ")" ;
	}

	private String getMultipleInsertSQL() {
		StringBuffer buff = new StringBuffer();
		
		StringBuffer internalBuffer = new StringBuffer();
		
		buff.append("Insert into " + getTableName() + "( ");
		
		Iterator it = listOfparams.iterator();
		
		int counter = 0;
		
		while(it.hasNext()) {
			
			
				AggregateRanksEntity gb = (AggregateRanksEntity) it.next();
				
				
				if (counter == 0) {
					if (gb.getGameCode() != null)  {
						buff.append("gameCode,");
						internalBuffer.append("'" + gb.getGameCode() + "',");
					}
					
					if (gb.getParamType() != null)  {
						buff.append("paramType,");
						internalBuffer.append("'" + gb.getParamType()+ "',");
					}
					
					if (gb.getParamValue() != null)  {
						buff.append("paramValue,");
						internalBuffer.append("'" + gb.getParamValue() + "',");
					}
					
					if (gb.getInstances() != null)  {
						buff.append("instances,");
						internalBuffer.append("'" + gb.getInstances() + "',");
					}
					
					if (gb.getParamRank() != null)  {
						buff.append("paramRank,");
						internalBuffer.append("'" + gb.getParamRank() + "',");
					}
					
					internalBuffer.deleteCharAt(internalBuffer.length()-1);
					internalBuffer.append(")");
					
				} else {
					internalBuffer.append(",(");
					if (gb.getGameCode() != null)  {
						internalBuffer.append("'" + gb.getGameCode() + "',");
					}
					
					if (gb.getParamType() != null)  {
						internalBuffer.append("'" + gb.getParamType()+ "',");
					}
					
					if (gb.getParamValue() != null)  {
						internalBuffer.append("'" + gb.getParamValue() + "',");
					}
					
					if (gb.getInstances() != null)  {
						internalBuffer.append("'" + gb.getInstances() + "',");
					}
					
					if (gb.getParamRank() != null)  {
						internalBuffer.append("'" + gb.getParamRank() + "',");
					}
									
					internalBuffer.deleteCharAt(internalBuffer.length()-1);
					internalBuffer.append(")");
				}
			
			counter++;
		
		}
		
		
		return buff.substring(0,buff.length()-1) + ") values ( "+ internalBuffer.toString() ;
	}
	
	public int populateMissingDigitRanks(String gameCode) {
		
		listOfparams = new ArrayList<AggregateRanksEntity>();
		return populateParams(gameCode, MISSING_DIGITS_PARAM_TYPE);
		
	}
	
	public int populateBucketGapMapRanks(String gameCode) {
		
		listOfparams = new ArrayList<AggregateRanksEntity>();
		return populateParams(gameCode, BUCKET_GAP_MAP_PARAM_TYPE);
		
	}
	
	public int populateFollowerMapRanks(String gameCode) {
		listOfparams = new ArrayList<AggregateRanksEntity>();
		return populateParams(gameCode, FOLLOWER_MAP_PARAM_TYPE);
		
	}
	
	public int populateSkipSumRanks(String gameCode) {
		listOfparams = new ArrayList<AggregateRanksEntity>();
		return populateParams(gameCode, SKIP_SUM_PARAM_TYPE);
		
	}
	
	public int populateMaxFactorRanks(String gameCode) {
		listOfparams = new ArrayList<AggregateRanksEntity>();
		return populateParams(gameCode, MAX_FACTOR_PARAM_TYPE);
		
	}
	
	
	private int populateParams(String gameCode, String forParamType) {
		int updatedCount = 0;
		
		// FIRST find if missing_digits for this gameCode need to be populated
		
		if (gameCode == null)  {
			System.out.println("Pass a valid gameCode ");
			return -1;
		}
		
		String sql1 = "select sum(instances) as totals from " + getTableName() + " where gameCode =  " + gameCode + " and paramType = '" + forParamType + "'";

		Connection conn = null;
		boolean doInsert = false;
		try {
			
			conn = getConnection();
			Statement stmt = conn.createStatement();
			
			ResultSet rs = stmt.executeQuery(sql1);
			
			int instances = 0;
			
			if (rs.next()) {
				instances = rs.getInt("totals");
				
				rs.close();
				
				if (instances > 0) {
					String sql2 = "select count(*) as records from jointView where gameCode = " + gameCode ;
					rs = stmt.executeQuery(sql2);
					
					if (rs.next()) {
						if ((rs.getInt("records") - instances) != 0) doInsert = true;
						rs.close();
					}
					
				} else {
					doInsert = true;
				}
			}
			
			if (doInsert) {
				if (instances > 0) {// DELETE all first
					int outInt = stmt.executeUpdate("delete from " + getTableName() + "  where gameCode = "  + gameCode + " and paramType = '" + forParamType + "'");
					
					if (outInt > 0)
						doInsert = true;
				}
				
				if (doInsert) {
					
					String sql3 = "";
					
					if (forParamType.equals("MIS")) {
					
						sql3 = "select missingDigits as paramValue, count(*) as instances from missing_digits where gameCode = " + gameCode +  
										" group by paramValue  order by  count(*) desc";
					}
					
					if (forParamType.equals("FOL")) {
						
						sql3 = "select CONCAT(firstValue,secondValue, thirdValue, fourthValue, fifthValue) as paramValue, count(*) as instances  from  follower_patterns where gameCode = " + gameCode +  
										" group by paramValue  order by  count(*) desc  " ;
					}
					
					if (forParamType.equals("SKP")) {
						
					sql3 = "select ifnull(firstSkip,0) + ifnull(secondSkip,0)+ ifnull(thirdSkip,0)+ ifnull(fourthSkip,0)+ ifnull(fifthSkip,0) as paramValue, count(*) as instances " +
									" from jointView where gameCode = "  + gameCode +
									" group by paramValue " +
									" order by count(*) desc";
					}
					
					if (forParamType.equals("MXF")) {
						
						sql3 = "select ifnull(maxFactor,0)  as paramValue, count(*) as instances " +
										" from jointView where gameCode = "  + gameCode +
										" group by paramValue " +
										" order by count(*) desc";
					}
					
					
					if (forParamType.equals("BGM")) {
						
						sql3 = "select concat(" +
									"(secondValue DIV 10) - (firstValue div 10) , " +
									"(thirdValue DIV 10) - (secondValue div 10) , " +
									"(fourthValue DIV 10) - (thirdValue div 10) , " +
									"(fifthValue DIV 10) - (fourthValue div 10) " +
									") as paramValue, count(*) as instances " +
										" from jointView where gameCode = "  + gameCode +
										" group by paramValue " +
										" order by count(*) desc";
					}					
					
					if (sql3.length() > 0) {
						rs = stmt.executeQuery(sql3);
						int counter = 1;
						while (rs.next()) {
							AggregateRanksEntity gb = new AggregateRanksEntity();
							gb.setGameCode(gameCode);
							gb.setParamType(forParamType);
							gb.setParamValue(rs.getString("paramValue"));
							gb.setInstances(rs.getString("instances"));
							gb.setParamRank(Integer.toString(counter));
							
							listOfparams.add(gb);
							counter++;
						}
						
						if (this.create()) System.out.println(" Entries for paramType " + forParamType + " created in " + getTableName());
					}
				}
				
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			if (conn != null)
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
				
				
		return updatedCount;
		
	}
	
	
	public Hashtable<String, Integer> getFollowerRanksForGame(String gameCode) {
		Hashtable<String, Integer> out = new Hashtable<String, Integer>();
				
		Connection conn = getConnection();
		
		Statement stmt;
		try {
			stmt = conn.createStatement();
			
			ResultSet rs = stmt.executeQuery("select paramValue as value, paramRank as rank from aggregate_ranks agr where agr.gameCode = " + gameCode + " and agr.paramType = 'FOL'");
		  	
		  	while (rs.next()) {
		  		out.put(rs.getString("value"), rs.getInt("rank"));
		  	}
		  	
		 	  		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				if (conn != null)
					conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		return out;
	}
	
	public Hashtable<String, Integer> getMissingDigitsForGame(String gameCode) {
		Hashtable<String, Integer> out = new Hashtable<String, Integer>();
				
		Connection conn = getConnection();
		
		Statement stmt;
		try {
			stmt = conn.createStatement();
			
			ResultSet rs = stmt.executeQuery("select paramValue as value, paramRank as rank from aggregate_ranks agr where agr.gameCode = " + gameCode + " and agr.paramType = 'MIS'");
		  	
		  	while (rs.next()) {
		  		out.put(rs.getString("value"), rs.getInt("rank"));
		  	}
		  	
		 	  		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				if (conn != null)
					conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		return out;
	}


	@Override
	public String getUpdateSQL() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Collection readAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Collection findRows() {
		// TODO Auto-generated method stub
		return null;
	}

}
