package com.num.generator.dataaccess;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.apache.commons.lang3.StringUtils;

import com.num.generator.predic.PredictionScenarioAnalysis;

public class GamePredictionStateEntity extends Base {
	
	private String gameCode;
	private String serialNumber;
	private String inputDrawDate;
	private String firstPredicFinalState;
	private String firstPredicRate;
	private String firstPredicAvgTotalScore;
	private String secondPredicFinalState;
	private String secondPredicRate;
	private String secondPredicAvgTotalScore;
	private String thirdPredicFinalState;
	private String thirdPredicRate;
	private String thirdPredicAvgTotalScore ;
	private String fourthPredicFinalState;
	private String fourthPredicRate;
	private String fourthPredicAvgTotalScore;
	private String fifthPredicFinalState;
	private String fifthPredicRate;
	private String fifthPredicAvgTotalScore;
	private String megaPredicFinalState;
	private String megaPredicRate;
	private String megaPredicAvgTotalScore;
	private String firstFiveSumBucketPredicFinalState;
	private String firstFiveSumBucketPredicRate;
	private String firstFiveSumBucketPredicAvgTotalScore;
	  		

	public static void main(String[] args) {
		GamePredictionStateEntity e = new GamePredictionStateEntity();
		System.out.println("Creating GamePredictionStateEntity ");
		
		e.popultateGamePredictionStateHistory("2");
	}
	
	public String getGameCode() {
		return gameCode;
	}

	public void setGameCode(String gameCode) {
		this.gameCode = gameCode;
	}

	public String getSerialNumber() {
		return serialNumber;
	}

	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}

	public String getInputDrawDate() {
		return inputDrawDate;
	}

	public void setInputDrawDate(String inputDrawDate) {
		this.inputDrawDate = inputDrawDate;
	}

	public String getFirstPredicFinalState() {
		return firstPredicFinalState;
	}

	public void setFirstPredicFinalState(String firstPredicFinalState) {
		this.firstPredicFinalState = firstPredicFinalState;
	}

	public String getFirstPredicRate() {
		return firstPredicRate;
	}

	public void setFirstPredicRate(String firstPredicRate) {
		this.firstPredicRate = firstPredicRate;
	}

	public String getFirstPredicAvgTotalScore() {
		return firstPredicAvgTotalScore;
	}

	public void setFirstPredicAvgTotalScore(String firstPredicAvgTotalScore) {
		this.firstPredicAvgTotalScore = firstPredicAvgTotalScore;
	}

	public String getSecondPredicFinalState() {
		return secondPredicFinalState;
	}

	public void setSecondPredicFinalState(String secondPredicFinalState) {
		this.secondPredicFinalState = secondPredicFinalState;
	}

	public String getSecondPredicRate() {
		return secondPredicRate;
	}

	public void setSecondPredicRate(String secondPredicRate) {
		this.secondPredicRate = secondPredicRate;
	}

	public String getSecondPredicAvgTotalScore() {
		return secondPredicAvgTotalScore;
	}

	public void setSecondPredicAvgTotalScore(String secondPredicAvgTotalScore) {
		this.secondPredicAvgTotalScore = secondPredicAvgTotalScore;
	}

	public String getThirdPredicFinalState() {
		return thirdPredicFinalState;
	}

	public void setThirdPredicFinalState(String thirdPredicFinalState) {
		this.thirdPredicFinalState = thirdPredicFinalState;
	}

	public String getThirdPredicRate() {
		return thirdPredicRate;
	}

	public void setThirdPredicRate(String thirdPredicRate) {
		this.thirdPredicRate = thirdPredicRate;
	}

	public String getThirdPredicAvgTotalScore() {
		return thirdPredicAvgTotalScore;
	}

	public void setThirdPredicAvgTotalScore(String thirdPredicAvgTotalScore) {
		this.thirdPredicAvgTotalScore = thirdPredicAvgTotalScore;
	}

	public String getFourthPredicFinalState() {
		return fourthPredicFinalState;
	}

	public void setFourthPredicFinalState(String fourthPredicFinalState) {
		this.fourthPredicFinalState = fourthPredicFinalState;
	}

	public String getFourthPredicRate() {
		return fourthPredicRate;
	}

	public void setFourthPredicRate(String fourthPredicRate) {
		this.fourthPredicRate = fourthPredicRate;
	}

	public String getFourthPredicAvgTotalScore() {
		return fourthPredicAvgTotalScore;
	}

	public void setFourthPredicAvgTotalScore(String fourthPredicAvgTotalScore) {
		this.fourthPredicAvgTotalScore = fourthPredicAvgTotalScore;
	}

	public String getFifthPredicFinalState() {
		return fifthPredicFinalState;
	}

	public void setFifthPredicFinalState(String fifthPredicFinalState) {
		this.fifthPredicFinalState = fifthPredicFinalState;
	}

	public String getFifthPredicRate() {
		return fifthPredicRate;
	}

	public void setFifthPredicRate(String fifthPredicRate) {
		this.fifthPredicRate = fifthPredicRate;
	}

	public String getFifthPredicAvgTotalScore() {
		return fifthPredicAvgTotalScore;
	}

	public void setFifthPredicAvgTotalScore(String fifthPredicAvgTotalScore) {
		this.fifthPredicAvgTotalScore = fifthPredicAvgTotalScore;
	}

	public String getMegaPredicFinalState() {
		return megaPredicFinalState;
	}

	public void setMegaPredicFinalState(String megaPredicFinalState) {
		this.megaPredicFinalState = megaPredicFinalState;
	}

	public String getMegaPredicRate() {
		return megaPredicRate;
	}

	public void setMegaPredicRate(String megaPredicRate) {
		this.megaPredicRate = megaPredicRate;
	}

	public String getMegaPredicAvgTotalScore() {
		return megaPredicAvgTotalScore;
	}

	public void setMegaPredicAvgTotalScore(String megaPredicAvgTotalScore) {
		this.megaPredicAvgTotalScore = megaPredicAvgTotalScore;
	}

	public String getFirstFiveSumBucketPredicFinalState() {
		return firstFiveSumBucketPredicFinalState;
	}

	public void setFirstFiveSumBucketPredicFinalState(
			String firstFiveSumBucketPredicFinalState) {
		this.firstFiveSumBucketPredicFinalState = firstFiveSumBucketPredicFinalState;
	}

	public String getFirstFiveSumBucketPredicRate() {
		return firstFiveSumBucketPredicRate;
	}

	public void setFirstFiveSumBucketPredicRate(String firstFiveSumBucketPredicRate) {
		this.firstFiveSumBucketPredicRate = firstFiveSumBucketPredicRate;
	}

	public String getFirstFiveSumBucketPredicAvgTotalScore() {
		return firstFiveSumBucketPredicAvgTotalScore;
	}

	public void setFirstFiveSumBucketPredicAvgTotalScore(
			String firstFiveSumBucketPredicAvgTotalScore) {
		this.firstFiveSumBucketPredicAvgTotalScore = firstFiveSumBucketPredicAvgTotalScore;
	}

	@Override
	public String getTableName() {
		// TODO Auto-generated method stub
		return "game_prediction_state";
	}

	@Override
	public String getInsertSQL() {
		StringBuffer buff = new StringBuffer();
		
		StringBuffer internalBuffer = new StringBuffer();
		
		buff.append("Insert into " + getTableName() + "( ");
		
		if (getGameCode() != null)  {
			buff.append("gameCode,");
			internalBuffer.append("'" + getGameCode() + "',");
		} else {
			return null;
		}
		
		
		if (getSerialNumber() != null )  {
			buff.append("serialNumber,");
			internalBuffer.append("'" + getSerialNumber() + "',");
		} else {
			return null;
		}
		
		if (getInputDrawDate() != null)  {
			buff.append("inputDrawDate,");
			internalBuffer.append("'" + getInputDrawDate() + "',");
		}
		
		if (getFirstPredicFinalState() != null)  {
			buff.append("firstPredicFinalState,");
			internalBuffer.append("'" + getFirstPredicFinalState() + "',");
		}
		
		if (getFirstPredicRate() != null)  {
			buff.append("firstPredicRate,");
			internalBuffer.append("" + getFirstPredicRate() + ",");
		}
		
		if (getFirstPredicAvgTotalScore() != null)  {
			buff.append("firstPredicAvgTotalScore,");
			internalBuffer.append("'" + getFirstPredicAvgTotalScore() + "',");
		}
		
		if (getSecondPredicFinalState() != null)  {
			buff.append("secondPredicFinalState,");
			internalBuffer.append("'" + getSecondPredicFinalState() + "',");
		}
		
		if (getSecondPredicRate() != null)  {
			buff.append("secondPredicRate,");
			internalBuffer.append("" + getSecondPredicRate() + ",");
		}
		
		if (getSecondPredicAvgTotalScore() != null)  {
			buff.append("secondPredicAvgTotalScore,");
			internalBuffer.append("'" + getSecondPredicAvgTotalScore() + "',");
		}
		
		if (getThirdPredicFinalState() != null)  {
			buff.append("thirdPredicFinalState,");
			internalBuffer.append("'" + getThirdPredicFinalState() + "',");
		}
		
		if (getThirdPredicRate() != null)  {
			buff.append("thirdPredicRate,");
			internalBuffer.append("" + getThirdPredicRate() + ",");
		}
		
		if (getThirdPredicAvgTotalScore() != null)  {
			buff.append("thirdPredicAvgTotalScore,");
			internalBuffer.append("'" + getThirdPredicAvgTotalScore() + "',");
		}
		
		if (getFourthPredicFinalState() != null)  {
			buff.append("fourthPredicFinalState,");
			internalBuffer.append("'" + getFourthPredicFinalState() + "',");
		}
		
		if (getFourthPredicRate() != null)  {
			buff.append("fourthPredicRate,");
			internalBuffer.append("" + getFourthPredicRate() + ",");
		}
		
		if (getFourthPredicAvgTotalScore() != null)  {
			buff.append("fourthPredicAvgTotalScore,");
			internalBuffer.append("'" + getFourthPredicAvgTotalScore() + "',");
		}
		
		if (getFifthPredicFinalState() != null)  {
			buff.append("fifthPredicFinalState,");
			internalBuffer.append("'" + getFifthPredicFinalState() + "',");
		}
		
		if (getFifthPredicRate() != null)  {
			buff.append("fifthPredicRate,");
			internalBuffer.append("" + getFifthPredicRate() + ",");
		}
		
		if (getFifthPredicAvgTotalScore() != null)  {
			buff.append("fifthPredicAvgTotalScore,");
			internalBuffer.append("'" + getFifthPredicAvgTotalScore() + "',");
		}
		
		if (getMegaPredicFinalState() != null)  {
			buff.append("megaPredicFinalState,");
			internalBuffer.append("'" + getMegaPredicFinalState() + "',");
		}
		
		if (getMegaPredicRate() != null)  {
			buff.append("megaPredicRate,");
			internalBuffer.append("" + getMegaPredicRate() + ",");
		}
		
		if (getMegaPredicAvgTotalScore() != null)  {
			buff.append("megaPredicAvgTotalScore,");
			internalBuffer.append("'" + getMegaPredicAvgTotalScore() + "',");
		}
		
		if (getFirstFiveSumBucketPredicFinalState() != null)  {
			buff.append("firstFiveSumBucketPredicFinalState,");
			internalBuffer.append("'" + getFirstFiveSumBucketPredicFinalState() + "',");
		}
		
		if (getFirstFiveSumBucketPredicRate() != null)  {
			buff.append("firstFiveSumBucketPredicRate,");
			internalBuffer.append("" + getFirstFiveSumBucketPredicRate() + ",");
		}
		
		if (getFirstFiveSumBucketPredicAvgTotalScore() != null)  {
			buff.append("firstFiveSumBucketPredicAvgTotalScore,");
			internalBuffer.append("'" + getFirstFiveSumBucketPredicAvgTotalScore() + "',");
		}
		
		
		return buff.substring(0,buff.length()-1) + ") values ( "+ internalBuffer.substring(0,internalBuffer.length()-1) + ")" ;

	}

	@Override
	public String getUpdateSQL() {
		StringBuffer buff = new StringBuffer();
		StringBuffer whereBuff = new StringBuffer();
		
		if (getGameCode() == null || getSerialNumber() == null) {
			System.out.println("GamePredictionStateEntity: update attempted without gamecode or serialnumber.");
			return null;
		}
		buff.append("Update " + getTableName() + " SET ");
			
		if (getGameCode() != null && getSerialNumber() != null)  {
			whereBuff.append(" where gameCode = '" + getGameCode() + "' and serialNumber = " + getSerialNumber());
			
		}
		if (getInputDrawDate() != null)  {
			buff.append(" inputDrawDate = '" + getInputDrawDate() + "',");
		}
		
		if (getFirstPredicFinalState() != null)  {
			buff.append(" firstPredicFinalState = '" + getFirstPredicFinalState() + "',");
		}
		
		if (getFirstPredicRate() != null)  {
			buff.append(" firstPredicRate = '" + getFirstPredicRate() + "',");
			
		}
		
		if (getFirstPredicAvgTotalScore() != null)  {
			buff.append(" firstPredicAvgTotalScore = '" + getFirstPredicAvgTotalScore() + "',");
			
		}
		
		if (getSecondPredicFinalState() != null)  {
			buff.append(" secondPredicFinalState = '" + getSecondPredicFinalState() + "',");
			
		}
		
		if (getSecondPredicRate() != null)  {
			buff.append(" secondPredicRate = '" + getSecondPredicRate() + "',");
			
		}
		
		if (getSecondPredicAvgTotalScore() != null)  {
			buff.append(" secondPredicAvgTotalScore = '" + getSecondPredicAvgTotalScore() + "',");
			
		}
		
		if (getThirdPredicFinalState() != null)  {
			buff.append(" thirdPredicFinalState = '" + getThirdPredicFinalState() + "',");
			
		}
		
		if (getThirdPredicRate() != null)  {
			buff.append(" thirdPredicRate = '" + getThirdPredicRate() + "',");
			
		}
		
		if (getThirdPredicAvgTotalScore() != null)  {
			buff.append(" thirdPredicAvgTotalScore = '" + getThirdPredicAvgTotalScore() + "',");
			
		}
		
		if (getFourthPredicFinalState() != null)  {
			buff.append(" fourthPredicFinalState = '" + getFourthPredicFinalState() + "',");
			
		}
		
		if (getFourthPredicRate() != null)  {
			buff.append(" fourthPredicRate = '" + getFourthPredicRate() + "',");
			
		}
		
		if (getFourthPredicAvgTotalScore() != null)  {
			buff.append(" fourthPredicAvgTotalScore = '" + getFourthPredicAvgTotalScore() + "',");
			
		}
		
		if (getFifthPredicFinalState() != null)  {
			buff.append(" fifthPredicFinalState = '" + getFifthPredicFinalState() + "',");
			
		}
		
		if (getFifthPredicRate() != null)  {
			buff.append(" fifthPredicRate = '" + getFifthPredicRate() + "',");
			
		}
		
		if (getFifthPredicAvgTotalScore() != null)  {
			buff.append(" fifthPredicAvgTotalScore = '" + getFifthPredicAvgTotalScore() + "',");
			
		}
		
		if (getMegaPredicFinalState() != null)  {
			buff.append(" megaPredicFinalState = '" + getMegaPredicFinalState() + "',");
			
		}
		
		if (getMegaPredicRate() != null)  {
			buff.append(" megaPredicRate = '" + getMegaPredicRate() + "',");
			
		}
		
		if (getMegaPredicAvgTotalScore() != null)  {
			buff.append(" megaPredicAvgTotalScore = '" + getMegaPredicAvgTotalScore() + "',");
			
		}
		
		if (getFirstFiveSumBucketPredicFinalState() != null)  {
			buff.append(" firstFiveSumBucketPredicFinalState = '" + getFirstFiveSumBucketPredicFinalState() + "',");
			
		}
		
		if (getFirstFiveSumBucketPredicRate() != null)  {
			buff.append(" firstFiveSumBucketPredicRate = '" + getFirstFiveSumBucketPredicRate() + "',");
			
		}
		
		if (getFirstFiveSumBucketPredicAvgTotalScore() != null)  {
			buff.append(" firstFiveSumBucketPredicAvgTotalScore = '" + getFirstFiveSumBucketPredicAvgTotalScore() + "',");
			
		}
		
		
		return buff.toString().substring(0,buff.length()-1) + whereBuff.toString();
	}

	@Override
	public Collection readAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Collection findRows() {
		Collection out = new ArrayList();
		Connection conn = getConnection();
		
		Statement stmt;
		try {
			stmt = conn.createStatement();
			StringBuffer buff = new StringBuffer();
			StringBuffer whereclause = new StringBuffer();
			
			buff.append ("Select * from " + getTableName() + " where ");
				
			if (getGameCode() != null)  {
				whereclause.append("gameCode = '" + getGameCode() + "'");
			}
			
			if (getSerialNumber() != null)  {
				if (whereclause.length() > 0)
					whereclause.append(" AND serialNumber = " + getSerialNumber() + "");
				else
					whereclause.append(" serialNumber = " + getSerialNumber() + "");
			}
			
		  	ResultSet rs = stmt.executeQuery(buff.toString() + whereclause.toString());
		  	
		  	while (rs.next()) {
		  		GamePredictionStateEntity gte = new GamePredictionStateEntity();
		  		gte.setGameCode(rs.getString("gameCode"));
		  		gte.setSerialNumber(rs.getString("serialNumber"));
		  		
		  		gte.setInputDrawDate(rs.getString("inputDrawDate"));
		  		gte.setFirstPredicFinalState(rs.getString("firstPredicFinalState"));
		  		gte.setFirstPredicRate(rs.getString("firstPredicRate"));
		  		gte.setFirstPredicAvgTotalScore(rs.getString("firstPredicAvgTotalScore"));
		  		gte.setSecondPredicFinalState(rs.getString("secondPredicFinalState"));
		  		gte.setSecondPredicRate(rs.getString("secondPredicRate"));
		  		gte.setSecondPredicAvgTotalScore(rs.getString("secondPredicAvgTotalScore"));
		  		gte.setThirdPredicFinalState(rs.getString("thirdPredicFinalState"));
		  		gte.setThirdPredicRate(rs.getString("thirdPredicRate"));
		  		gte.setThirdPredicAvgTotalScore(rs.getString("thirdPredicAvgTotalScore"));
		  		gte.setFourthPredicFinalState(rs.getString("fourthPredicFinalState"));
		  		gte.setFourthPredicRate(rs.getString("fourthPredicRate"));
		  		gte.setFourthPredicAvgTotalScore(rs.getString("fourthPredicAvgTotalScore"));
		  		gte.setFifthPredicFinalState(rs.getString("fifthPredicFinalState"));
		  		gte.setFifthPredicRate(rs.getString("fifthPredicRate"));
		  		gte.setFifthPredicAvgTotalScore(rs.getString("fifthPredicAvgTotalScore")); ;
		  		gte.setMegaPredicFinalState(rs.getString("megaPredicFinalState"));
		  		gte.setMegaPredicRate(rs.getString("megaPredicRate"));
		  		gte.setMegaPredicAvgTotalScore(rs.getString("megaPredicAvgTotalScore"));
		  		gte.setFirstFiveSumBucketPredicFinalState(rs.getString("firstFiveSumBucketPredicFinalState"));
		  		gte.setFirstFiveSumBucketPredicRate(rs.getString("firstFiveSumBucketPredicRate"));
		  		gte.setFirstFiveSumBucketPredicAvgTotalScore(rs.getString("firstFiveSumBucketPredicAvgTotalScore"));
		  		
		  		out.add(gte);
		  	}
	  	
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				if (conn != null)
					conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return out;
	}
	
	
	public void popultateGamePredictionStateHistory(String gameCode) {
		if (getGameCode() == null)
			setGameCode(gameCode);
		
		if (getGameCode() == null) {
			System.out.println("GamePredictionStateEntity: popultateGamePredictionStateHistory ... null gamecode");
			return;
		}
		
		popultateGamePredictionStateHistoryForOneAttrib(gameCode, "first");
		popultateGamePredictionStateHistoryForOneAttrib(gameCode, "second");
		popultateGamePredictionStateHistoryForOneAttrib(gameCode, "third");
		popultateGamePredictionStateHistoryForOneAttrib(gameCode, "fourth");
		popultateGamePredictionStateHistoryForOneAttrib(gameCode, "fifth");
		popultateGamePredictionStateHistoryForOneAttrib(gameCode, "mega");
		popultateGamePredictionStateHistoryForOneAttrib(gameCode, "firstFiveSumBucket");
	}
	
	private void popultateGamePredictionStateHistoryForOneAttrib(String gameCode, String attrib) {
		if (getGameCode() == null)
			setGameCode(gameCode);
		
		if (getGameCode() == null) {
			System.out.println("GamePredictionStateEntity: popultateGamePredictionStateHistory ... null gamecode");
			return;
		}
		
		ResultHistoryEntity rhe =  new ResultHistoryEntity();
		rhe.setGameCode(gameCode);
		
		String lastdates = "";
		
		if (findRows().size() == 0)
			lastdates = rhe.getLastNForAttribute("dateOfDraw", 100, 0);
		else 
			lastdates = rhe.getLastNForAttribute("dateOfDraw", 2, 0);
		
		String [] datesarr = lastdates.split(","); 
		
		String lastserial = rhe.getLastNForAttribute("serialNumber", 1, 0);
		
		for (int i=1; i<datesarr.length; i++) {
			int serial = Integer.parseInt(lastserial) - i;
			
			setSerialNumber(Integer.toString(serial));
			
			String predperformance = "";
			int avgtotalscore = 0;
			rhe.setDateOfDraw(datesarr[i-1]);
			Collection<ResultHistoryEntity> nextres = rhe.findRows();
			
			PredictionScenarioAnalysis.setAttribute(attrib);
			PredictionScenarioAnalysis.setGameCode(gameCode);
			
			if (nextres.size() == 1) {
				List<InclusionExclusionEntity> prevpreds = PredictionScenarioAnalysis.getPredictionsAsonDate(4,datesarr[i]);				
				
				for (InclusionExclusionEntity oneprevpred: prevpreds) {
					String attributeval = rhe.getLastNForAttribute(oneprevpred.getAttribute(), 1, Integer.parseInt(nextres.iterator().next().getSerialNumber()));
					
					String performance = PredictionScenarioAnalysis.getPredictionPerformanceForSubAttribute(oneprevpred, Integer.parseInt(attributeval));
					
					predperformance += performance;
					
					avgtotalscore += Math.abs(Integer.parseInt(oneprevpred.getTotalScore()));
				}
				
			}
			if (predperformance.length() > 0) {
				
				Collection<GamePredictionStateEntity> rows = findRows();
				if (rows.size() > 0) {
					GamePredictionStateEntity gpe = rows.iterator().next();
					if (attrib.equalsIgnoreCase("first")) {
						gpe.setFirstPredicFinalState(predperformance);
						//gpe.setFirstPredicRate(Integer.toString(StringUtils.countMatches(predperformance, "T")*100/predperformance.length()));
						gpe.setFirstPredicRate(Integer.toString(StringUtils.countMatches(predperformance, "T")));
						gpe.setFirstPredicAvgTotalScore(Integer.toString(avgtotalscore/4));
					}
					
					if (attrib.equalsIgnoreCase("second")) {
						gpe.setSecondPredicFinalState(predperformance);
						//gpe.setSecondPredicRate(Integer.toString(StringUtils.countMatches(predperformance, "T")*100/predperformance.length()));
						gpe.setSecondPredicRate(Integer.toString(StringUtils.countMatches(predperformance, "T")));
						gpe.setSecondPredicAvgTotalScore(Integer.toString(avgtotalscore/4));
					}
					
					if (attrib.equalsIgnoreCase("third")) {
						gpe.setThirdPredicFinalState(predperformance);
						//gpe.setThirdPredicRate(Integer.toString(StringUtils.countMatches(predperformance, "T")*100/predperformance.length()));
						gpe.setThirdPredicRate(Integer.toString(StringUtils.countMatches(predperformance, "T")));
						gpe.setThirdPredicAvgTotalScore(Integer.toString(avgtotalscore/4));
					}
					
					if (attrib.equalsIgnoreCase("fourth")) {
						gpe.setFourthPredicFinalState(predperformance);
						//gpe.setFourthPredicRate(Integer.toString(StringUtils.countMatches(predperformance, "T")*100/predperformance.length()));
						gpe.setFourthPredicRate(Integer.toString(StringUtils.countMatches(predperformance, "T")));
						gpe.setFourthPredicAvgTotalScore(Integer.toString(avgtotalscore/4));
					}
					
					if (attrib.equalsIgnoreCase("fifth")) {
						gpe.setFifthPredicFinalState(predperformance);
						//gpe.setFifthPredicRate(Integer.toString(StringUtils.countMatches(predperformance, "T")*100/predperformance.length()));
						gpe.setFifthPredicRate(Integer.toString(StringUtils.countMatches(predperformance, "T")));
						gpe.setFifthPredicAvgTotalScore(Integer.toString(avgtotalscore/4));
					}
					
					if (attrib.equalsIgnoreCase("mega")) {
						gpe.setMegaPredicFinalState(predperformance);
						//gpe.setMegaPredicRate(Integer.toString(StringUtils.countMatches(predperformance, "T")*100/predperformance.length()));
						gpe.setMegaPredicRate(Integer.toString(StringUtils.countMatches(predperformance, "T")));
						gpe.setMegaPredicAvgTotalScore(Integer.toString(avgtotalscore/4));
					}
					
					if (attrib.equalsIgnoreCase("firstFiveSumBucket")) {
						gpe.setFirstFiveSumBucketPredicFinalState(predperformance);
						//gpe.setFirstFiveSumBucketPredicRate(Integer.toString(StringUtils.countMatches(predperformance, "T")*100/predperformance.length()));
						gpe.setFirstFiveSumBucketPredicRate(Integer.toString(StringUtils.countMatches(predperformance, "T")));
						gpe.setFirstFiveSumBucketPredicAvgTotalScore(Integer.toString(avgtotalscore/4));
					}
					
					gpe.update();
					//System.out.println(datesarr[i] + " | " + predperformance + " | " + (StringUtils.countMatches(predperformance, "T")*100/predperformance.length()) + " Entity updated.");
					
					
				} else {
					GamePredictionStateEntity gpe = new GamePredictionStateEntity();
					gpe.setGameCode(gameCode);
					gpe.setInputDrawDate(datesarr[i]);
					gpe.setSerialNumber(Integer.toString(serial));
					
					if (attrib.equalsIgnoreCase("first")) {
						gpe.setFirstPredicFinalState(predperformance);
						//gpe.setFirstPredicRate(Integer.toString(StringUtils.countMatches(predperformance, "T")*100/predperformance.length()));
						gpe.setFirstPredicRate(Integer.toString(StringUtils.countMatches(predperformance, "T")));
						gpe.setFirstPredicAvgTotalScore(Integer.toString(avgtotalscore/4));
					}
					
					if (attrib.equalsIgnoreCase("second")) {
						gpe.setSecondPredicFinalState(predperformance);
						//gpe.setSecondPredicRate(Integer.toString(StringUtils.countMatches(predperformance, "T")*100/predperformance.length()));
						gpe.setSecondPredicRate(Integer.toString(StringUtils.countMatches(predperformance, "T")));
						gpe.setSecondPredicAvgTotalScore(Integer.toString(avgtotalscore/4));
					}
					
					if (attrib.equalsIgnoreCase("third")) {
						gpe.setThirdPredicFinalState(predperformance);
						//gpe.setThirdPredicRate(Integer.toString(StringUtils.countMatches(predperformance, "T")*100/predperformance.length()));
						gpe.setThirdPredicRate(Integer.toString(StringUtils.countMatches(predperformance, "T")));
						gpe.setThirdPredicAvgTotalScore(Integer.toString(avgtotalscore/4));
					}
					
					if (attrib.equalsIgnoreCase("fourth")) {
						gpe.setFourthPredicFinalState(predperformance);
						//gpe.setFourthPredicRate(Integer.toString(StringUtils.countMatches(predperformance, "T")*100/predperformance.length()));
						gpe.setFourthPredicRate(Integer.toString(StringUtils.countMatches(predperformance, "T")));
						gpe.setFourthPredicAvgTotalScore(Integer.toString(avgtotalscore/4));
					}
					
					if (attrib.equalsIgnoreCase("fifth")) {
						gpe.setFifthPredicFinalState(predperformance);
						//gpe.setFifthPredicRate(Integer.toString(StringUtils.countMatches(predperformance, "T")*100/predperformance.length()));
						gpe.setFifthPredicRate(Integer.toString(StringUtils.countMatches(predperformance, "T")));
						gpe.setFifthPredicAvgTotalScore(Integer.toString(avgtotalscore/4));
					}
					
					if (attrib.equalsIgnoreCase("mega")) {
						gpe.setMegaPredicFinalState(predperformance);
						//gpe.setMegaPredicRate(Integer.toString(StringUtils.countMatches(predperformance, "T")*100/predperformance.length()));
						gpe.setMegaPredicRate(Integer.toString(StringUtils.countMatches(predperformance, "T")));
						gpe.setMegaPredicAvgTotalScore(Integer.toString(avgtotalscore/4));
					}
					
					if (attrib.equalsIgnoreCase("firstFiveSumBucket")) {
						gpe.setFirstFiveSumBucketPredicFinalState(predperformance);
						//gpe.setFirstFiveSumBucketPredicRate(Integer.toString(StringUtils.countMatches(predperformance, "T")*100/predperformance.length()));
						gpe.setFirstFiveSumBucketPredicRate(Integer.toString(StringUtils.countMatches(predperformance, "T")));
						gpe.setFirstFiveSumBucketPredicAvgTotalScore(Integer.toString(avgtotalscore/4));
					}
					
					gpe.create();
					//System.out.println(datesarr[i] + " | " + predperformance + " | " + (StringUtils.countMatches(predperformance, "T")*100/predperformance.length()) + " Entity created.");
					
				}
			} else
				System.out.println("No predictions..");
			
		}
		
	}

}
