package com.num.generator.dataaccess;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Hashtable;

public class GameTypesEntity extends Base {

	private String gameName = null;
	private String programCode = null;
	private static Hashtable codes = new Hashtable();
	
	public String getProgramCode() {
		return programCode;
	}


	public void setProgramCode(String programCode) {
		this.programCode = programCode;
	}


	public String getGameName() {
		return gameName;
	}


	public void setGameName(String gameName) {
		this.gameName = gameName;
	}


	public String getGameCode() {
		return gameCode;
	}


	public void setGameCode(String gameCode) {
		this.gameCode = gameCode;
	}


	public String getMaximumValue() {
		return maximumValue;
	}


	public void setMaximumValue(String maximumValue) {
		this.maximumValue = maximumValue;
	}


	public String getMaxMegaValue() {
		return maxMegaValue;
	}


	public void setMaxMegaValue(String maxMegaValue) {
		this.maxMegaValue = maxMegaValue;
	}


	private String gameCode = null;
	private String maximumValue = null;
	private String maxMegaValue = null;


	public String getInsertSQL() {
		// TODO Auto-generated method stub
		return null;
	}

	
	public String getTableName() {
		return " game_types ";
	}


	
	public Collection readAll() {
		Collection out = new ArrayList();
		Connection conn = getConnection();
		
		Statement stmt;
		try {
			stmt = conn.createStatement();
			  
		  	ResultSet rs = stmt.executeQuery("Select * from " + getTableName());
		  	
		  	while (rs.next()) {
		  		GameTypesEntity gte = new GameTypesEntity();
		  		gte.setGameCode(rs.getString("gameCode"));
		  		gte.setProgramCode(rs.getString("programCode"));
		  		gte.setGameName(rs.getString("gameName"));
		  		gte.setMaximumValue(rs.getString("maximumValue"));
		  		gte.setMaxMegaValue(rs.getString("maxMegaValue"));
		  		
		  		out.add(gte);
		  	}
	  	
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				if (conn != null)
					conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return out;
	}


	@Override
	public Collection findRows() {
		Collection out = new ArrayList();
		Connection conn = getConnection();
		
		Statement stmt;
		try {
			stmt = conn.createStatement();
			StringBuffer buff = new StringBuffer();
			StringBuffer whereclause = new StringBuffer();
			
			buff.append ("Select * from " + getTableName() + " where ");
				
			if (getGameCode() != null)  {
				whereclause.append("gameCode = '" + getGameCode() + "'");
			}
			
			if (getProgramCode() != null)  {
				if (whereclause.length() > 0)
					whereclause.append(" AND programCode = '" + getProgramCode() + "'");
				else
					whereclause.append(" programCode = '" + getProgramCode() + "'");
			}
			
		  	ResultSet rs = stmt.executeQuery(buff.toString() + whereclause.toString());
		  	
		  	while (rs.next()) {
		  		GameTypesEntity gte = new GameTypesEntity();
		  		gte.setGameCode(rs.getString("gameCode"));
		  		gte.setProgramCode(rs.getString("programCode"));
		  		gte.setGameName(rs.getString("gameName"));
		  		gte.setMaximumValue(rs.getString("maximumValue"));
		  		gte.setMaxMegaValue(rs.getString("maxMegaValue"));
		  		
		  		out.add(gte);
		  	}
	  	
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				if (conn != null)
					conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return out;
	}
	
	
	
	public String findGameCodeByProgramCode(String programCode) {
		
		if (codes.containsKey(programCode.toUpperCase()))
			return (String) codes.get(programCode.toUpperCase());
		else {
			Connection conn = getConnection();
			String gameCodeOut = null;
			Statement stmt;
			try {
				stmt = conn.createStatement();
				StringBuffer buff = new StringBuffer();
				StringBuffer whereclause = new StringBuffer();
				
				buff.append ("Select * from " + getTableName() + " where ");
				
				whereclause.append(" programCode = '" + programCode.toUpperCase() + "'");
							
			  	ResultSet rs = stmt.executeQuery(buff.toString() + whereclause.toString());
			  	
			  	while (rs.next()) {
			  		gameCodeOut = rs.getString("gameCode");
	
			  	}
		  	
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} finally {
				try {
					if (conn != null)
						conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			codes.put(programCode.toUpperCase(), gameCodeOut);
			return gameCodeOut;
		}
	}


	@Override
	public String getUpdateSQL() {
		// TODO Auto-generated method stub
		return null;
	}

}
