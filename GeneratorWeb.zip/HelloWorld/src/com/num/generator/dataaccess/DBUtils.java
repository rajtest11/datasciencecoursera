package com.num.generator.dataaccess;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collection;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Random;
import java.util.Set;
import java.util.StringTokenizer;
import java.util.TreeSet;

import org.apache.commons.math3.stat.regression.SimpleRegression;

import com.num.generator.Generator;
import com.num.generator.Numbers;
import com.num.generator.predic.PredictAscDescBasedOnPatterns;
import com.num.generator.predic.PredictEvenOddBasedOnPatterns;
import com.num.generator.predic.PredictPrimeNonprimeBasedOnPatterns;
import com.num.generator.predic.PredictValueBasedOnDistanceAndFreq;

public class DBUtils extends Base {
	
	private boolean testMode = true;
	private static String globalattribute = null;
	
	public static void main(String[] args) {
		DBUtils dbu = new DBUtils();
			String inputtoisseq = "8,12, 44, 46";
			String gameCode = "2";
			String attribute="fourthRedux";
			//System.out.println("isSequence " + inputtoisseq + " output " + isSequence(inputtoisseq, 5));
			//System.out.println("isAllEvenOrOdd " + inputtoisseq + " output " + isAllEvenOrOdd(inputtoisseq, 5));
	//	dbu.findAllSequencesForAttribute(gameCode, "fifthFreq",0);
		//dbu.findAllEvenOddsForAttribute("2", "secondFreq", 0);
		
		//System.out.println(dbu.getCurrentSequenceLengthForAttribute("2g", "secondFreq"));
			//dbu.getCurrentFreqAndSkipForAttribute(gameCode,attribute,0,0, true);
			//analyzeFreqForGame(gameCode);
			//dbu.findNextValueForSeriesThroughRegression("165,154,87,162,166,159g,162,153,159,27,159,154,155,159,165,160,31,165,141,31,157,164,155,157,169,35,24,164,155,36,157,156,142,162,161,22,161,162,19,157,160,160,30,75,147,164,166,92,161,154,170,159,33,163,151,14,39,170,170,88,165,159,167,168,156,163,167,95,169,90,166,166,23,171,28,160,9,165,15,169,166,165,70,160,163,166,174,161,164,148,154,160,149,29,150,37,19,168,160,164,109,166,171,163,165,107,154,169");
		/***********************************************************/
		//dbu.getCurrentSequenceLengthForAllAttributes("2", true);
		//dbu.testAttributeForSequenceLength(gameCode,attribute);
		dbu.testAttributeForEvenOddLength(gameCode, attribute);
		//dbu.testAttributeForMARegression(gameCode, attribute);
		/*System.out.println();*/
		//dbu.getCurrentEvenOddLengthsForAllAttributes("1", true);
		
			//dbu.testAttributeForExclusions(gameCode, attribute);
			//dbu.testAttributeForSequenceOfRedux(gameCode, attribute);
			//dbu.testAttributeForInclusion(gameCode, attribute);
	//	dbu.testFirstFiveSumBasedOnBucketsAndFreqSkipForInclusion(gameCode);
	//		dbu.testFirstFiveSumBasedOnBucketsAndPercentileForInclusion(gameCode);
			
			// SET global attribute to run it only for 1 attribute
		globalattribute = attribute;
		//dbu.getCurrentInclusionAndExclusionsForAllAttributes(gameCode);
		
		//dbu.testAttributeForDistanceInHistory(gameCode,attribute);
		
			long start = System.currentTimeMillis();
		//dbu.testWhetherAllNumsAppearedInObsOnADay("1");
			
			
			//getNextDateForGameAndSerial("2", 1066);
			System.out.println("Time taken :" + (System.currentTimeMillis()-start));
		} 
	
	public static String getNextDateForGameAndSerial(String gameCode, int serialNumber) {
		
		String out = "";
		
		ResultHistoryEntity rhe = new ResultHistoryEntity();
		rhe.setGameCode(gameCode);
		rhe.setSerialNumber(Integer.toString(serialNumber));
		
		ArrayList<ResultHistoryEntity> lastrow = (ArrayList<ResultHistoryEntity>) rhe.findRows();

		if (lastrow.size() == 0)
			return out;
		
		String lastDateOfDraw = lastrow.get(0).getDateOfDraw();
		String dayofweek = lastrow.get(0).getDayOfTheWeek().replaceAll("\"", "");
		
		//System.out.println(lastDateOfDraw + " " + lastDateOfDraw.substring(0, 4)+ " " + lastDateOfDraw.substring(4,6)+ " " + lastDateOfDraw.substring(6,8)+ " " + dayofweek);
		
		Calendar nextDateCal = Calendar.getInstance();
		
		nextDateCal.set(Calendar.YEAR,Integer.parseInt(lastDateOfDraw.substring(0, 4)));
		nextDateCal.set(Calendar.MONTH,Integer.parseInt(lastDateOfDraw.substring(4, 6))-1);
		nextDateCal.set(Calendar.DATE,Integer.parseInt(lastDateOfDraw.substring(6, 8)));
		
		if (dayofweek.equals("6") || dayofweek.equals("7"))
			nextDateCal.add(Calendar.DAY_OF_YEAR, 4);
		else
			nextDateCal.add(Calendar.DAY_OF_YEAR, 3);
		
		int imon = nextDateCal.get(Calendar.MONTH)+1;
		String smon = ((imon < 10) ? "0" : "") + (Integer.toString(imon));
		int iday = nextDateCal.get(Calendar.DAY_OF_MONTH);
		String sday = ((iday < 10) ? "0" : "") + (Integer.toString(iday));
		int iyear = nextDateCal.get(Calendar.YEAR);
		String syear = Integer.toString(iyear);
		
		//System.out.println(syear+smon+sday);
		
		return syear+smon+sday;
	}
	
	private void testWhetherAllNumsAppearedInObsOnADay(String gameCode) {
		ArrayList<String> listOfAttributes = new ArrayList<String>();
		ResultHistoryEntity rhe = new ResultHistoryEntity();
		rhe.setGameCode(gameCode);
		
		
		listOfAttributes.add("firstValue");
		listOfAttributes.add("secondValue");
		listOfAttributes.add("thirdValue");
		listOfAttributes.add("fourthValue");
		listOfAttributes.add("fifthValue");
		
		ArrayList<String>  listOfValues = rhe.getAllValuesForAttributes(listOfAttributes, 0, false, "val", null);
		ObservationsEntity obse = new ObservationsEntity();
		Generator.obsData = obse.loadObsData(gameCode);
		
		
		for (String valset: listOfValues) {
			String[] vals = valset.split(",");
			int[] vali = new int[vals.length];
			
			for (int i=0; i< vali.length; i++) {
				vali[i] = Integer.parseInt(vals[i]);
			}
			
			if (!Generator.sameObsDate(vali))
				System.out.println(Arrays.toString(vali));
		}
		
	}

	private void testAttributeForDistanceInHistory(String gameCode, String attribute) { // Predicting based on distance of reoccurence
		
		System.out.println("Distance for: " + attribute + " Game: " + gameCode);
		ResultHistoryEntity rhe = new ResultHistoryEntity();
		rhe.setGameCode(gameCode);
		
		ArrayList<String> listOfAttributes = new ArrayList<String>();
		
		listOfAttributes.add(attribute);
		listOfAttributes.add("firstFiveSumBucket");
		ArrayList<String>  listOfValues = rhe.getAllValuesForAttributes(listOfAttributes, 0, false, null, null);
		
		int latestSerial = Integer.parseInt(rhe.getLastNForAttribute("serialNumber", 1, 0));
		
		LinkedHashMap<String, ArrayList<Integer>> gamedata = new LinkedHashMap<String, ArrayList<Integer>>();
		
		ArrayList<Integer> last25distances =  new ArrayList<Integer>();
		
		System.out.println("Possible values: " + listOfValues);
		
		for (String valset: listOfValues) {
			
			String[] vals = valset.split(",");
			Hashtable<String, Integer> distanceinput = new Hashtable<String, Integer>();
			int p=0;
			for (String att: listOfAttributes) {
				distanceinput.put(att, Integer.parseInt(vals[p]));
				p++;
			}
			
			LinkedHashMap<Integer, Integer> data = rhe.getDistancesDataForMultipleAttributeAndValue(distanceinput, 0);
			
			ArrayList<Integer> distancelist = new ArrayList<Integer>();
			
			int j = 0;
			for (Integer key : data.keySet()) {
				if (j == 0) distancelist.add(latestSerial + 1 - key);
				distancelist.add(data.get(key));
				j++;
			}

			gamedata.put(valset, distancelist);
			
		}
		
		
		for (String key : gamedata.keySet()) {
		          System.out.println(key + ":\t" + (gamedata.get(key).size()-1) + ":\t" + gamedata.get(key));
		}

		
	}

	public int isSequence(int[] vals) {
		int out = 0;
		
		String valsString = "";
		
		if (vals.length == 0) return out;
		
		for (int i=0; i<vals.length; i++) {
			valsString += vals[i];
			
			if (i < vals.length-1)
				valsString += ",";
		}
		
		String sequenceSQL = "SELECT isSequence(CONCAT_WS(','," + valsString + ")) AS test";
		
		Connection conn = getConnection();
		
		Statement stmt;
		try {
			stmt = conn.createStatement();
			  
		  	ResultSet rs = stmt.executeQuery(sequenceSQL);
		  	
		  	if (rs.next()) {
		  		
		  		out = rs.getInt("test");
		  	}
	  	
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				if (conn != null)
					conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return out;
	}
	
	
	public static int isSequence(String vals, int length) {
		int out = 0;
		
		String[] values = vals.split(",");
		int prevVal = 0;
		
		if (length > values.length)
			length = values.length;
		
		for (int k = 0; k < length; k++) {
			if (prevVal == 0) {
				prevVal = Integer.parseInt(values[k].trim());
			} else {
				if (Integer.parseInt(values[k].trim()) == prevVal) {
					out = out + 0;
					prevVal = Integer.parseInt(values[k].trim());
					return 0;
				} else {
					if (Integer.parseInt(values[k].trim()) > prevVal) {
						out = out + 1;
						prevVal = Integer.parseInt(values[k].trim());
					} else {
						out = out - 1;
						prevVal = Integer.parseInt(values[k].trim());
					}
				}

			}
		}
		
		 if ( out == length -1 ) return -1;
		
			    
		 if ( out == 0-length+1)  return 1;
		out = 0;
		
		return out;
	}
	
	
	public static int isAllEvenOrOdd(String vals, int length) {
		int out = 0;
		
		String[] values = vals.split(",");
		
		if (length > values.length)
			length = values.length;
		
		for (int k = 0; k < length; k++) {
			if ( Integer.parseInt(values[k].trim()) % 2 == 0 ) 
				out = out + 1;
			else  		
		      	out = out -1;

		}
		
		 if ( out == length ) return 1;
		
			    
		 if ( out == 0-length)  return 2;
		out = 0;
		
		return out;
	}
	
	public Hashtable<Integer,ArrayList<Integer>> findAllSequencesForAttribute(String gameCode, String attribute, int serialNumber, int seqLength) { //prints ascending and descending sequence counts for attribute
																// Sequence Length - Total Ascending - Total Descending  - ASc Skip - Desc Skip - Ratio
		int latestSerial = 0;
		
		//System.out.println("Sequence data for gameCode " + gameCode + " attribute " + attribute );
		Hashtable<Integer,ArrayList<Integer>> sequenceHash = new Hashtable<Integer,ArrayList<Integer>>();
		Hashtable<Integer,ArrayList<Integer>> serialData = new Hashtable<Integer,ArrayList<Integer>>();
		ResultHistoryEntity rhe = new ResultHistoryEntity();
		rhe.setGameCode(gameCode);
		
		if (serialNumber == 0)
			latestSerial = Integer.parseInt(rhe.getLastNForAttribute("serialNumber", 1, 0));
		else
			latestSerial = serialNumber;
		
		int startSequencelength = 3;
		int endSequenceLength =  8;
		
		if (seqLength > 0) {
			startSequencelength = seqLength;
			//endSequenceLength =  seqLength+1;
		}
		
		int depth = 300;
			
		//System.out.print("Processing seq length ");
		for (int j=latestSerial; j>latestSerial-depth; j--) {
			String maxVals = rhe.getLastNForSequenceFromCache(attribute, endSequenceLength, j);
			//if (j==latestSerial)
				//System.out.println(" doing " + depth + " iterations");
			for (int i=startSequencelength; i<endSequenceLength; i++) {
				
				//System.out.print("  " + i + " " + j);
				int isSeq = isSequence(maxVals,i);
				if ( isSeq != 0) { // sequence of length i found
					
					if (isSeq == 1) {
						if (serialData.get(j) != null) {
							 serialData.get(j).add(i);
						} else {
							ArrayList<Integer> al = new ArrayList<Integer>();
							al.add(i);
							serialData.put(j, al);
						}
					}
					
					if (isSeq == -1) {
						if (serialData.get(j) != null) {
							 serialData.get(j).add(0-i);
						} else {
							ArrayList<Integer> al = new ArrayList<Integer>();
							al.add(0-i);
							serialData.put(j, al);
						}
					}
					
				}
			}
			
		}
		//System.out.println();
		
		for (int j=latestSerial; j>latestSerial-depth; j--) {
			if (serialData.get(j) != null) {
				int longestSeq = serialData.get(j).get(serialData.get(j).size()-1);
				
				if (sequenceHash.get(Math.abs(longestSeq)) != null) {
					if (longestSeq > 0) { 
						sequenceHash.get(Math.abs(longestSeq)).set(0,
								sequenceHash.get(Math.abs(longestSeq)).get(0) + 1);
	
						if (sequenceHash.get(Math.abs(longestSeq)).get(2) == 0)
							sequenceHash.get(Math.abs(longestSeq)).set(2, latestSerial - j);
					}
					
					if (longestSeq < 0) {
						sequenceHash.get(Math.abs(longestSeq)).set(1,
								sequenceHash.get(Math.abs(longestSeq)).get(1) + 1);
	
						if (sequenceHash.get(Math.abs(longestSeq)).get(3) == 0)
							sequenceHash.get(Math.abs(longestSeq)).set(3, latestSerial - j);
					}
					
				} else {
					ArrayList<Integer> al = new ArrayList<Integer>();
					
					if (longestSeq > 0) {
						al.add(0, 1);
						al.add(1, 0);
						al.add(2, latestSerial - j);
						al.add(3, 0);
						al.add(4, 0);
					} 
					
					if (longestSeq < 0) {
						al.add(0, 0);
						al.add(1, 1);
						al.add(2, 0);
						al.add(3, latestSerial - j);
						al.add(4, 0);
					}
					
					sequenceHash.put(Math.abs(longestSeq), al);
				}
			}
		}
		
		Collection<ArrayList<Integer>> enu = sequenceHash.values();
		
		Iterator it = enu.iterator();
		
		while (it.hasNext()) {
			ArrayList<Integer> thislist =  (ArrayList<Integer>) it.next();
			
			thislist.set(4, depth/(thislist.get(0)+thislist.get(1)));
		}
		
		//System.out.println(" Total records processed " + totalProcessed);
		/*if (seqLength > 0)
			System.out.print(seqLength + " " +sequenceHash.get(seqLength));
		else*/
			//System.out.print(sequenceHash);
		
		return sequenceHash;
		
	}
	
	
	public Hashtable<Integer,ArrayList<Integer>> findAllEvenOddsForAttribute(String gameCode, String attribute, int serialNum,
			int seqLength) { // prints even and odd sequence counts for attribute
		// Sequence Length - Odd - Even - Odd Skip - Even Skip - Ratio
		int latestSerial = 0;
		
		//System.out.println("Even Odd Sequence data for gameCode " + gameCode +	 " attribute " + attribute );
		Hashtable<Integer, ArrayList<Integer>> serialData = new Hashtable<Integer, ArrayList<Integer>>();
		Hashtable<Integer, ArrayList<Integer>> sequenceHash = new Hashtable<Integer, ArrayList<Integer>>();
		ResultHistoryEntity rhe = new ResultHistoryEntity();
		rhe.setGameCode(gameCode);

		if (serialNum == 0)
			latestSerial = Integer.parseInt(rhe.getLastNForAttribute("serialNumber", 1, 0));
		else
			latestSerial = serialNum;
		
		int maxSerial = Integer.parseInt(rhe.getLastNForAttribute("serialNumber", 1, 0));

		int startSequencelength = 2;
		int endSequenceLength = 8;

		if (seqLength > 0) {
			startSequencelength = seqLength;
			// endSequenceLength = seqLength+1;
		}

		int depth = 300;

		
		//System.out.print("Processing seq length ");
				for (int j=latestSerial; j>latestSerial-depth; j--) {
					String maxVals = rhe.getLastNForSequenceFromCache(attribute, endSequenceLength, j);
					//System.out.print("  " + i);
					for (int i=startSequencelength; i<endSequenceLength; i++) {
						
						//System.out.print("  " + i + " " + j);
						int isSeq = isAllEvenOrOdd(maxVals,i);
						if ( isSeq != 0) { // sequence of evens of odds  found
							
							if (isSeq == 1) {
								if (serialData.get(j) != null) {
									 serialData.get(j).add(i);
								} else {
									ArrayList<Integer> al = new ArrayList<Integer>();
									al.add(i);
									serialData.put(j, al);
								}
							}
							
							if (isSeq == 2) {
								if (serialData.get(j) != null) {
									 serialData.get(j).add(0-i);
								} else {
									ArrayList<Integer> al = new ArrayList<Integer>();
									al.add(0-i);
									serialData.put(j, al);
								}
							}
							
						}
					}
					
				}
				//System.out.println();
				
				for (int j=latestSerial; j>latestSerial-depth; j--) {
					if (serialData.get(j) != null) {
						int longestSeq = serialData.get(j).get(serialData.get(j).size()-1);
						
						if (sequenceHash.get(Math.abs(longestSeq)) != null) {
							if (longestSeq < 0) { 
								sequenceHash.get(Math.abs(longestSeq)).set(0,
										sequenceHash.get(Math.abs(longestSeq)).get(0) + 1);
			
								if (sequenceHash.get(Math.abs(longestSeq)).get(2) == 0)
									sequenceHash.get(Math.abs(longestSeq)).set(2, latestSerial - j);
							}
							
							if (longestSeq > 0) {
								sequenceHash.get(Math.abs(longestSeq)).set(1,
										sequenceHash.get(Math.abs(longestSeq)).get(1) + 1);
			
								if (sequenceHash.get(Math.abs(longestSeq)).get(3) == 0)
									sequenceHash.get(Math.abs(longestSeq)).set(3, latestSerial - j);
							}
							
						} else {
							ArrayList<Integer> al = new ArrayList<Integer>();
							
							if (longestSeq > 0) {
								al.add(0, 1);
								al.add(1, 0);
								al.add(2, maxSerial - j);
								al.add(3, 0);
								al.add(4, 0);
							} 
							
							if (longestSeq < 0) {
								al.add(0, 0);
								al.add(1, 1);
								al.add(2, 0);
								al.add(3, maxSerial - j);
								al.add(4, 0);
							}
							
							sequenceHash.put(Math.abs(longestSeq), al);
						}
					}
				}
		
		Collection<ArrayList<Integer>> enu = sequenceHash.values();

		Iterator it = enu.iterator();

		while (it.hasNext()) {
			ArrayList<Integer> thislist = (ArrayList<Integer>) it.next();

			thislist.set(4, depth	/ (thislist.get(0) + thislist.get(1)));
		}

		
		//System.out.print(sequenceHash);
		
		return sequenceHash;

	}
	
	public void getCurrentSequenceLengthForAllAttributes(String gameCode, boolean printSequenceMap) {
		System.out.println("Detecting sequence lengths asc(+ve) and desc(-ve) for gameCode " + gameCode);
		ResultHistoryEntity rhe = new ResultHistoryEntity();
		rhe.setGameCode(gameCode);
		
		ResultsWithinLastN lastN = new ResultsWithinLastN();
		List l = lastN.getColumnNames();
		l.add("firstFreq");
		l.add("secondFreq");
		l.add("thirdFreq");
		l.add("fourthFreq");
		l.add("fifthFreq");
		l.add("megaFreq");
		
		l.add("firstDigitDiff");
		l.add("secondDigitDiff");
		l.add("thirdDigitDiff");
		l.add("fourthDigitDiff");
		l.add("fifthDigitDiff");
		l.add("megaDigitDiff");
		
		Iterator it = l.iterator();
		
		while (it.hasNext()) {
			String fieldName = (String) it.next();
			
			if (!fieldName.endsWith("Follower") && !fieldName.endsWith("Prime") ) {
				int seqlen = getCurrentSequenceLengthForAttribute(gameCode,fieldName,0);
				
				int latestValueForAttrib = Integer.parseInt(rhe.getValueForField(fieldName, gameCode, 0));
				
				if (Math.abs(seqlen) >  2) {
					System.out.print(fieldName + "  " + seqlen + " Last Value " + latestValueForAttrib + " ");
					if (printSequenceMap) findAllSequencesForAttribute(gameCode, fieldName, 0, Math.abs(seqlen));
					System.out.println();
				}
			} 
			
		}
		
	}
	
	
	public void testAttributeForSequenceLength(String gameCode, String attribute) {
		
		
		ResultHistoryEntity rhe = new ResultHistoryEntity();
    	rhe.setGameCode(gameCode);
    	ArrayList<String> failures = new ArrayList<String>();
    	ArrayList<String> successes = new ArrayList<String>();
    	int lastserial = 0;
    	int passed = 0;
    	int samplesize = 200;
    	int printsize = 10;	
    	
    	int latestsuccessserial = 0;//(successes.size() > 0)?Integer.parseInt(successes.get(0).substring(0, successes.get(0).indexOf("-"))):0;
		int latestfailureserial = 0;//(failures.size() > 0)?Integer.parseInt(failures.get(0).substring(0, failures.get(0).indexOf("-"))):0;
		
    	int seqlargerthantwo = 0;
    	
    	try {
    	 	
    	if (lastserial == 0)
    		lastserial = Integer.parseInt(rhe.getValueForField("serialNumber", gameCode, 0));
    	
    	for (int i=0; i<samplesize; i++) {
    		Hashtable<Integer,ArrayList<Integer>> seqmap = null;
    		String value = rhe.getValueForFieldFromCache(attribute, gameCode, (lastserial-i));
    		
    		if (!attribute.endsWith("Follower") && !attribute.endsWith("Prime") ) {
    			
//    			if (i== 153)
//    				System.out.print("Here");
				int seqlen = getCurrentSequenceLengthForAttribute(gameCode,attribute, (lastserial-i-1));
				
				String scurrval = rhe.getValueForFieldFromCache(attribute, gameCode, (lastserial-i));
				String sprevval = rhe.getValueForFieldFromCache(attribute, gameCode, (lastserial-i-1));
				int currentValueForAttrib = Integer.parseInt((scurrval == null)?"0":scurrval);
				int prevValueForAttrib = Integer.parseInt((sprevval==null)?"0":sprevval);
				
				if (Math.abs(seqlen) >  2) {
					seqlargerthantwo++;
					//System.out.print(i);
					seqmap = findAllSequencesForAttribute(gameCode, attribute, (lastserial-i-1), Math.abs(seqlen));
					//System.out.println();
				
					 
					int useSkip = 0;
					if (seqlen > 0) {
						if (seqmap.get(Math.abs(seqlen)+1) != null)
							useSkip = seqmap.get(Math.abs(seqlen)+1).get(2);
					} else {
						if (seqmap.get(Math.abs(seqlen)+1) != null)
							useSkip = seqmap.get(Math.abs(seqlen)+1).get(3);
					}
					
					// If higher sequence is overdue, target move in the same direction otherwise reverse
					boolean contSameDirection = false;
					
					if (seqmap.get(Math.abs(seqlen)+1) != null && useSkip > seqmap.get(Math.abs(seqlen)+1).get(4))
						contSameDirection = true;
				
					if (seqlen > 0) { // increasing values
						
						if (contSameDirection) {
							if (currentValueForAttrib > prevValueForAttrib)  {
								passed++;
								if (successes.size() < printsize)
									successes.add((lastserial-i)+"-"+prevValueForAttrib);
								if (latestsuccessserial == 0) latestsuccessserial = seqlargerthantwo;
								
							} else {
				    			if (failures.size() < printsize)
				    				failures.add((lastserial-i)+"-"+prevValueForAttrib);
				    			
				    			if (latestfailureserial == 0) latestfailureserial = seqlargerthantwo;
				    		}
						} else {
							if (currentValueForAttrib < prevValueForAttrib)  {
								passed++;
								if (successes.size() < printsize)
									successes.add((lastserial-i)+"-"+prevValueForAttrib);
								
								if (latestsuccessserial == 0) latestsuccessserial = seqlargerthantwo;
							} else {
				    			if (failures.size() < printsize)
				    				failures.add((lastserial-i)+"-"+prevValueForAttrib);
				    			
				    			if (latestfailureserial == 0) latestfailureserial = seqlargerthantwo;
				    		}
						}
						
					} else {
						
						if (contSameDirection) {
							if (currentValueForAttrib < prevValueForAttrib) {
								passed++;
								if (successes.size() < printsize)
									successes.add((lastserial-i)+"-"+prevValueForAttrib);
								
								if (latestsuccessserial == 0) latestsuccessserial = seqlargerthantwo;
							} else {
				    			if (failures.size() < printsize)
				    				failures.add((lastserial-i)+"-"+prevValueForAttrib);
				    			
				    			if (latestfailureserial == 0) latestfailureserial = seqlargerthantwo;
				    		}
						} else {
							if (currentValueForAttrib > prevValueForAttrib) {
								passed++;
								if (successes.size() < printsize)
									successes.add((lastserial-i)+"-"+prevValueForAttrib);
								
								if (latestsuccessserial == 0) latestsuccessserial = seqlargerthantwo;
							} else {
				    			if (failures.size() < printsize)
				    				failures.add((lastserial-i)+"-"+prevValueForAttrib);
				    			
				    			if (latestfailureserial == 0) latestfailureserial = seqlargerthantwo;
				    		}
						}
						
					}
		    		
				}
    			
    		} 
    		if (i == 0) {
    			//System.out.println("Exclusions : " + + list.size() +"["  + excl + "] next value: " + value + " --- " + ((list.size() > 0 && !list.contains(Integer.parseInt(value)))?" passed ":" failed "));
    		}
    		
    	}
    	
    	//System.out.println("Passed " + (passed*100/samplesize) + " pc " + successes.toString());
    	//System.out.println (" Failed serials " + failures.toString());
    	
    
		
		//Collections.sort(list);
		
		rhe.setGameCode(gameCode);
		InclusionExclusionEntity ince = new InclusionExclusionEntity();
		ince.setAlgorithmType(InclusionExclusionEntity.ALGORITHM_TYPE_SEQUENCE);
		ince.setAttribute(attribute);
		ince.setGameCode(gameCode);
		ince.setInputDrawDate(rhe.getLastNForAttribute("dateOfDraw", 1, 0));
		ince.setIsInclusionInd("false");
		
		//ince.setPercent(Integer.toString((passed*100/samplesize)));;
		//ince.setTotalScore(Integer.toString(((lastserial - latestsuccessserial) * ((passed*100/samplesize)))));;
		
		
		int currseqlen = getCurrentSequenceLengthForAttribute(gameCode,attribute, lastserial);
		Hashtable<Integer,ArrayList<Integer>> currseqmap = findAllSequencesForAttribute(gameCode, attribute, 0, Math.abs(currseqlen));
		System.out.println(currseqmap);
	
		
		int useSkip = 0;
		if (currseqlen > 0) {
			if (currseqmap.get(Math.abs(currseqlen)+1) != null)
				useSkip = currseqmap.get(Math.abs(currseqlen)+1).get(2);
		} else {
			if (currseqmap.get(Math.abs(currseqlen)+1) != null)
				useSkip = currseqmap.get(Math.abs(currseqlen)+1).get(3);
		}
		
		// If higher sequence is overdue, target move in the same direction otherwise reverse
		boolean contSameDirection = false;
		 
		if (currseqmap.get(Math.abs(currseqlen)+1) != null) {
			if (useSkip > currseqmap.get(Math.abs(currseqlen)+1).get(4))
				contSameDirection = true;
		}
	
		
		
		int lastVal = Integer.parseInt(rhe.getValueForFieldFromCache(attribute, gameCode, lastserial));
		
		if (currseqlen > 0) {
			if (!contSameDirection)
				lastVal = 0- lastVal;
		} else {
			if (contSameDirection)
				lastVal = 0- lastVal;
		}
	 	
		
		
		if (Math.abs(currseqlen) > 2) {
			
			if (latestfailureserial > 1 && (latestfailureserial-1) * (100-(passed*100/seqlargerthantwo)) > 100) {
				ince.setPercent(Integer.toString((100-(passed*100/seqlargerthantwo))));
				ince.setTotalScore(Integer.toString((latestfailureserial-1) * (100-(passed*100/seqlargerthantwo))));
				
				lastVal = 0- lastVal;
				contSameDirection = !contSameDirection;
			}
			
			if (latestsuccessserial > 1 && (latestsuccessserial-1) * (passed*100/seqlargerthantwo) > 100) {
				ince.setPercent(Integer.toString((passed*100/seqlargerthantwo)));
				ince.setTotalScore(Integer.toString((latestsuccessserial-1) * (passed*100/seqlargerthantwo)));
			}
		}
		
		if (contSameDirection) {
			ince.setIsInclusionInd("true");
			
		} else {
			ince.setIsInclusionInd("false");
		}
		
		ArrayList<Integer> inarg = new ArrayList();
		inarg.add(lastVal);
		ince.setData(inarg);
		
		
		
		/*if (latestsuccessserial == lastserial) {
			
			if (((lastserial - latestfailureserial) * (100-(passed*100/seqlargerthantwo))) > 100) {
				
				if (contSameDirection)
					ince.setIsInclusionInd("true");
				ince.setPercent(Integer.toString((100-(passed*100/seqlargerthantwo))));;
    			ince.setTotalScore(Integer.toString((lastserial - latestfailureserial) * (100-(passed*100/seqlargerthantwo))));
    			
    			
				System.out.print (attribute + " Target FAIL"  + "[" + (100-(passed*100/seqlargerthantwo)) + "-" + (lastserial - latestfailureserial) * (100-(passed*100/seqlargerthantwo)) + "]");
				System.out.println (" Current exclusions for " + attribute + " " + list.size() + " " + list.toString() );
			}
			
		} else {
			
			if (((lastserial - latestsuccessserial) * ((passed*100/seqlargerthantwo))) > 100) {
				
				if (!contSameDirection)
					ince.setIsInclusionInd("false");
				
				ince.setPercent(Integer.toString((passed*100/seqlargerthantwo)));;
    			ince.setTotalScore(Integer.toString(((lastserial - latestsuccessserial) * ((passed*100/seqlargerthantwo)))));;
    			
				System.out.print (attribute + " Target SUCCESS"  + "[" + ((passed*100/seqlargerthantwo)) + "-" + (lastserial - latestsuccessserial) * ((passed*100/seqlargerthantwo)) + "]");
				System.out.println (" Current exclusions for " + attribute + " " + list.size() + " " + list.toString() );
			}
			 
		}*/
		
		if (!testMode)ince.addInclusionExclusionResult();
		
		
		System.out.println("Sequence length " + ince.getAttribute() + " "+ ince.getIsInclusionInd() + " " + ince.getPercent() + " " + ince.getTotalScore() + " " + ince.getData().get(0) + " ");
    	} catch (Exception e) {
    		System.out.println("DBUTils.testAttributeForSequenceLength: Exception while processing gamecode " + gameCode + " attribute " + attribute );
    	}
		
		
		
	}
	
	private String getNMovingAvg(String inarr, int n) {  //assumes that series starts with the oldest and ends with the most recent
		String out = "";
		String[] vals = inarr.split(",");
		
		for (int i=0; i< vals.length; i++) {
			if (i >= n-1) {
				int sum = 0;
				// Sum last n
				for (int k=0; k<n; k++)
					sum += Integer.parseInt(vals[i-k]);
				
				out += sum / n + ",";
			} else {
				out += Integer.parseInt(vals[i]) + ",";
			}
		}
		
		return out.substring(0, out.length()-1);
	}

	
public void testAttributeForMARegression(String gameCode, String attribute) { // Valid for Freq and FirstFiveSum
		
		if (!(attribute.endsWith("Sum") || attribute.endsWith("Freq")) )
			return;
		
		ResultHistoryEntity rhe = new ResultHistoryEntity();
    	rhe.setGameCode(gameCode);
    	ArrayList<String> failures = new ArrayList<String>();
    	ArrayList<String> successes = new ArrayList<String>();
    	int lastserial = 0;
    	int passed = 0;
    	int samplesize = 200;
    	int printsize = 10;	
    	
    	int latestsuccessserial = 0;//(successes.size() > 0)?Integer.parseInt(successes.get(0).substring(0, successes.get(0).indexOf("-"))):0;
		int latestfailureserial = 0;//(failures.size() > 0)?Integer.parseInt(failures.get(0).substring(0, failures.get(0).indexOf("-"))):0;
		
		try {
    	if (lastserial == 0)
    		lastserial = Integer.parseInt(rhe.getValueForField("serialNumber", gameCode, 0));
    	
    	for (int i=0; i<samplesize; i++) {
    		
    		if (!attribute.endsWith("Follower") && !attribute.endsWith("Prime") ) {
    			
//    			if (i== 153)
//    				System.out.print("Here");
				
				String scurrval = rhe.getValueForFieldFromCache(attribute, gameCode, (lastserial-i));
				String sprevval = rhe.getValueForFieldFromCache(attribute, gameCode, (lastserial-i-1));
				int currentValueForAttrib = Integer.parseInt((scurrval == null)?"0":scurrval);
				int prevValueForAttrib = Integer.parseInt((sprevval==null)?"0":sprevval);
				
				
				int[] nextVals = findNextValueForAttributeThroughRegression(gameCode, attribute, (lastserial-i-1));
					
				if ((currentValueForAttrib >= nextVals[0] && currentValueForAttrib <= nextVals[1] ) ||
						(currentValueForAttrib >= nextVals[2] && currentValueForAttrib <= nextVals[3] )	)  {
					passed++;
					if (successes.size() < printsize)
						successes.add((lastserial-i)+"-"+prevValueForAttrib);
					
					
				} else {
	    			if (failures.size() < printsize)
	    				failures.add((lastserial-i)+"-"+prevValueForAttrib);
	    			
	    			
	    		}
    			
    		} 
    		if (i == 0) {
    			//System.out.println("Exclusions : " + + list.size() +"["  + excl + "] next value: " + value + " --- " + ((list.size() > 0 && !list.contains(Integer.parseInt(value)))?" passed ":" failed "));
    		}
    		
    	}
    	 latestsuccessserial = Integer.parseInt(successes.get(0).substring(0, successes.get(0).indexOf("-")));
		 latestfailureserial = Integer.parseInt(failures.get(0).substring(0, failures.get(0).indexOf("-")));		
    		
		rhe.setGameCode(gameCode);
		InclusionExclusionEntity ince = new InclusionExclusionEntity();
		ince.setAlgorithmType(InclusionExclusionEntity.ALGORITHM_TYPE_REGRESSION);
		ince.setAttribute(attribute);
		ince.setGameCode(gameCode);
		ince.setInputDrawDate(rhe.getLastNForAttribute("dateOfDraw", 1, 0));
		ince.setIsInclusionInd("false");
		ince.setPercent(Integer.toString((passed*100/samplesize)));;
		
		int[] nextVals = findNextValueForAttributeThroughRegression(gameCode, attribute,0);
				
		if (latestsuccessserial == lastserial) {
			
			if (((lastserial - latestfailureserial) * (100-(passed*100/samplesize))) > 100) {
				ince.setIsInclusionInd("false");
				
				if (ince.getPercent() == null) {
					ince.setPercent(Integer.toString((100-(passed*100/samplesize))));;
					
				}
				ince.setTotalScore(Integer.toString((lastserial - latestfailureserial) * (100-Integer.parseInt(ince.getPercent()))));
    			
				System.out.print (attribute + "-MA REGRESSION Target FAIL" + "[" + ince.getPercent() + " : " + (lastserial - latestfailureserial) * (100-Integer.parseInt(ince.getPercent())) + "]");
				System.out.println (" Current predicted ranges for " + attribute + " " + nextVals[0] + "-" + nextVals[1] + " and " + nextVals[2] + "-" + nextVals[3] );
			}
			
		} else {
			
			if (((lastserial - latestsuccessserial) * ((passed*100/samplesize))) > 100) {
				ince.setIsInclusionInd("true");
				
				if (ince.getPercent() == null) {
					ince.setPercent(Integer.toString((passed*100/samplesize)));;
					
				}
				
				ince.setTotalScore(Integer.toString(((lastserial - latestsuccessserial) * Integer.parseInt(ince.getPercent()))));
    			
				System.out.print (attribute + "-MA REGRESSION Target SUCCESS" + "[" + ince.getPercent() + " : " + (lastserial - latestsuccessserial) * Integer.parseInt(ince.getPercent()) + "]");
				System.out.println (" Current predicted ranges for " + attribute + " " + nextVals[0] + "-" + nextVals[1] + " and " + nextVals[2] + "-" + nextVals[3] );
			}
			 
		}
		
		
		ArrayList<Integer> inarg = new ArrayList();
			
		inarg.add(nextVals[0]);		
		inarg.add(nextVals[1]);
		inarg.add(nextVals[2]);		
		inarg.add(nextVals[3]);		
		
		ince.setData(inarg);

		
		if (!testMode) ince.addInclusionExclusionResult();
		System.out.println("Regression Length " + ince.getAttribute() + " "+ ince.getIsInclusionInd() + " " + ince.getPercent() + " " + ince.getTotalScore() + " " + ince.getData().get(0) + "-" + ince.getData().get(1) + " "+ ince.getData().get(2) + "-"+ ince.getData().get(3));
		} catch (Exception e) {
    		System.out.println("DBUTils.testAttributeForMARegression: Exception while processing gamecode " + gameCode + " attribute " + attribute );
    	}
		
		
	}

static private void analyzeFreqForGame(String gameCode) {
	
	Hashtable<Integer,Integer> distrib = new Hashtable<Integer, Integer>();
	ResultHistoryEntity rhe = new ResultHistoryEntity();
	rhe.setGameCode(gameCode);
	ArrayList<String> failures = new ArrayList<String>();
	ArrayList<String> successes = new ArrayList<String>();
	int lastserial = 0;
	
	int samplesize = 200;
	 	
	if (lastserial == 0)
		lastserial = Integer.parseInt(rhe.getValueForField("serialNumber", gameCode, 0));
	
	for (int i=0; i<samplesize; i++) {
		
			int numsAtleast2Away = 0;
					
//			if (i== 153)
//				System.out.print("Here");
			String freqs = rhe.getFreqsForGameAndSerial(gameCode, (lastserial-i));
			String[] indFreqs = freqs.split(",");
			
			for (int j= 0; j < indFreqs.length-1; j++) {
				int thisFreq = Integer.parseInt(indFreqs[j]);
				
				String prevfreqs = rhe.getFreqsForGameAndSerial(gameCode, (lastserial-i-1));
				String[] previndFreqs = prevfreqs.split(",");
				
				int prevminDistance = 0;
				for (int k= 0; k < previndFreqs.length-1; k++) {
					
					int minDistance = Math.abs(thisFreq - Integer.parseInt(previndFreqs[k]));
					
					if (prevminDistance == 0) {
						prevminDistance = minDistance;
					} else {
						if (minDistance < prevminDistance) prevminDistance = minDistance;
					}
					
				}
				
				if (prevminDistance > 2) numsAtleast2Away++;
			}
			
			if (numsAtleast2Away < 2)
				System.out.println (numsAtleast2Away + " " + (lastserial-i) + " Freqs " + freqs);
			
				if (distrib.get(new Integer(numsAtleast2Away)) != null) {
					distrib.put(numsAtleast2Away, distrib.get(numsAtleast2Away)+1);
				} else {
					distrib.put(numsAtleast2Away, 1);
				}
	    		
			}
			
		System.out.println(distrib);
		
	}
	
	
	




private int[] findNextValueForAttributeThroughRegression(String gameCode,
		String attribute, int serialNum) {
	// TODO Auto-generated method stub
	
	ResultHistoryEntity rhe = new ResultHistoryEntity();
	rhe.setGameCode(gameCode);
	
	String lastnvalues = rhe.getLastNForRegressionFromCache(attribute, 200, serialNum);
	
	int masize = 5;
	
	String mavalues = getNMovingAvg(lastnvalues, masize);
	
	ArrayList<Double> distanceFromMAlist =  new ArrayList<Double>();
	ArrayList<Double> fieldValuejumplist =  new ArrayList<Double>();
	
	String[] lastnvaluesSplit = lastnvalues.split(",");
	String[] mavaluessplit = mavalues.split(",");
	
	
	for (int i=0; i< lastnvaluesSplit.length; i++) {
		double val = Double.parseDouble(lastnvaluesSplit[i]) - Double.parseDouble(mavaluessplit[i]);
		
		if (val < 0)
			val = 0- val;
		
		distanceFromMAlist.add(val);
		
	}
	
	for (int i=0; i< masize-1; i++)
		distanceFromMAlist.remove(0);
	
	String currfieldVal = rhe.getLastNForRegressionFromCache(attribute, 1, serialNum);
	
	int currMA = 0;
	
	for (int i=0; i< masize; i++)
		currMA += Integer.parseInt(lastnvaluesSplit[lastnvaluesSplit.length-1-i]);
	
	currMA = currMA/masize;
	
	
	double currDistanceFromMA =  Integer.parseInt(currfieldVal) - currMA;
	
	if (currDistanceFromMA < 0) currDistanceFromMA = 0- currDistanceFromMA;
	
	distanceFromMAlist.remove(distanceFromMAlist.size()-1);
	
	Double[] distanceFromMA = new Double[distanceFromMAlist.size()];
	
	distanceFromMAlist.toArray(distanceFromMA);
	
	for (int i=masize-1; i< lastnvaluesSplit.length-1; i++) {
		double val = Double.parseDouble(lastnvaluesSplit[i+1]) - Double.parseDouble(lastnvaluesSplit[i]);
		
		if (val < 0)
			val = 0- val;
		
		fieldValuejumplist.add(val);
	}
	
	// Add the last jump value we need the next value for this
	//currfieldVal = rhe.getLastNForRegressionFromCache(attribute, 1, serialNum+1);
	
/*	int lastjumpval = Integer.parseInt(currfieldVal) - Integer.parseInt(lastnvaluesSplit[lastnvaluesSplit.length-1]);
	
	if (lastjumpval < 0) lastjumpval = 0- lastjumpval;
	
	fieldValuejumplist.add((double)lastjumpval);*/
	
	
	Double[] fieldValuejump = new Double[fieldValuejumplist.size()];
	fieldValuejumplist.toArray(fieldValuejump);
	
	SimpleRegression regr = new SimpleRegression();
	
	for (int i=0; i<distanceFromMA.length; i++) {
		regr.addData(distanceFromMA[i], fieldValuejump[i]);
	}
	

	double estimatedJump = regr.predict(currDistanceFromMA);
	
	
	int[] out = new int[4];
	int band = 0;
	
	if (attribute.endsWith("Freq"))
		band = 5;
	
	if (attribute.equalsIgnoreCase("FIRSTFIVESUM"))
		band = 20;
		
	out[0] = Integer.parseInt(currfieldVal) - (int)estimatedJump - band;
	out[1] = Integer.parseInt(currfieldVal) - (int)estimatedJump + band;
	out[2] = Integer.parseInt(currfieldVal) + (int)estimatedJump - band;
	out[3] = Integer.parseInt(currfieldVal) + (int)estimatedJump + band;
	
	return out;
}

private int[] findNextValueForSeriesThroughRegression(String lastnvalues) {
	// TODO Auto-generated method stub
	
	
	int masize = 5;
	
	String mavalues = getNMovingAvg(lastnvalues, masize);
	
	ArrayList<Double> distanceFromMAlist =  new ArrayList<Double>();
	ArrayList<Double> fieldValuejumplist =  new ArrayList<Double>();
	
	String[] lastnvaluesSplit = lastnvalues.split(",");
	String[] mavaluessplit = mavalues.split(",");
	
	
	for (int i=0; i< lastnvaluesSplit.length; i++) {
		double val = Double.parseDouble(lastnvaluesSplit[i]) - Double.parseDouble(mavaluessplit[i]);
		
		if (val < 0)
			val = 0- val;
		
		distanceFromMAlist.add(val);
		
	}
	
	for (int i=0; i< masize-1; i++)
		distanceFromMAlist.remove(0);
	
	String currfieldVal = lastnvaluesSplit[lastnvaluesSplit.length-1];
	
	int currMA = 0;
	
	for (int i=0; i< masize; i++)
		currMA += Integer.parseInt(lastnvaluesSplit[lastnvaluesSplit.length-1-i]);
	
	currMA = currMA/masize;
	
	
	double currDistanceFromMA =  Integer.parseInt(currfieldVal) - currMA;
	
	if (currDistanceFromMA < 0) currDistanceFromMA = 0- currDistanceFromMA;
	
	distanceFromMAlist.remove(distanceFromMAlist.size()-1);
	
	Double[] distanceFromMA = new Double[distanceFromMAlist.size()];
	
	distanceFromMAlist.toArray(distanceFromMA);
	
	for (int i=masize-1; i< lastnvaluesSplit.length-1; i++) {
		double val = Double.parseDouble(lastnvaluesSplit[i+1]) - Double.parseDouble(lastnvaluesSplit[i]);
		
		if (val < 0)
			val = 0- val;
		
		fieldValuejumplist.add(val);
	}
	
	// Add the last jump value we need the next value for this
	//currfieldVal = rhe.getLastNForRegressionFromCache(attribute, 1, serialNum+1);
	
/*	int lastjumpval = Integer.parseInt(currfieldVal) - Integer.parseInt(lastnvaluesSplit[lastnvaluesSplit.length-1]);
	
	if (lastjumpval < 0) lastjumpval = 0- lastjumpval;
	
	fieldValuejumplist.add((double)lastjumpval);*/
	
	
	Double[] fieldValuejump = new Double[fieldValuejumplist.size()];
	fieldValuejumplist.toArray(fieldValuejump);
	
	SimpleRegression regr = new SimpleRegression();
	
	for (int i=0; i<distanceFromMA.length; i++) {
		regr.addData(distanceFromMA[i], fieldValuejump[i]);
	}
	

	double estimatedJump = regr.predict(currDistanceFromMA);
	
	
	int[] out = new int[4];
	int band = 5;
		
	out[0] = Integer.parseInt(currfieldVal) - (int)estimatedJump - band;
	out[1] = Integer.parseInt(currfieldVal) - (int)estimatedJump + band;
	out[2] = Integer.parseInt(currfieldVal) + (int)estimatedJump - band;
	out[3] = Integer.parseInt(currfieldVal) + (int)estimatedJump + band;
	
	return out;
}

public void testAttributeForEvenOddLength(String gameCode, String attribute) {
	
	
	ResultHistoryEntity rhe = new ResultHistoryEntity();
	rhe.setGameCode(gameCode);
	ArrayList<String> failures = new ArrayList<String>();
	ArrayList<String> successes = new ArrayList<String>();
	int lastserial = 0;
	int passed = 0;
	int samplesize = 200;
	int printsize = 10;	
	
	int latestsuccessserial = 0;//(successes.size() > 0)?Integer.parseInt(successes.get(0).substring(0, successes.get(0).indexOf("-"))):0;
	int latestfailureserial = 0;//(failures.size() > 0)?Integer.parseInt(failures.get(0).substring(0, failures.get(0).indexOf("-"))):0;
	
	int seqlargerthantwo = 0;
	 	
	try {
	if (lastserial == 0)
		lastserial = Integer.parseInt(rhe.getValueForField("serialNumber", gameCode, 0));
	
	for (int i=0; i<samplesize; i++) {
		Hashtable<Integer,ArrayList<Integer>> seqmap = null;
		String value = rhe.getValueForFieldFromCache(attribute, gameCode, (lastserial-i));
		
		if (!attribute.endsWith("Follower") && !attribute.endsWith("Prime") ) {
			
//			if (i== 153)
//				System.out.print("Here");
			int seqlen = getCurrentEvenOddLengthForAttribute(gameCode,attribute, (lastserial-i-1));
			
			String scurrval = rhe.getValueForFieldFromCache(attribute, gameCode, (lastserial-i));
			String sprevval = rhe.getValueForFieldFromCache(attribute, gameCode, (lastserial-i-1));
			int currentValueForAttrib = Integer.parseInt((scurrval == null)?"0":scurrval);
			int prevValueForAttrib = Integer.parseInt((sprevval==null)?"0":sprevval);
			
			if (Math.abs(seqlen) >  2) {
				seqlargerthantwo++;
				//System.out.print(i);
				seqmap = findAllEvenOddsForAttribute(gameCode, attribute, (lastserial-i-1), Math.abs(seqlen));
				//System.out.println();
			
				 
				int useSkip = 0;
				if (seqlen > 0) {
					if (seqmap.get(Math.abs(seqlen)+1) != null)
						useSkip = seqmap.get(Math.abs(seqlen)+1).get(2);
				} else {
					if (seqmap.get(Math.abs(seqlen)+1) != null)
						useSkip = seqmap.get(Math.abs(seqlen)+1).get(3);
				}
				
				// If higher sequence is overdue, target move in the same direction otherwise reverse
				boolean contSameDirection = false;
				
				if (seqmap.get(Math.abs(seqlen)+1) != null && useSkip > seqmap.get(Math.abs(seqlen)+1).get(4))
					contSameDirection = true;
			
				//if (seqlen > 0) { // EVEN values
					
					if (contSameDirection) {
						if (currentValueForAttrib % 2 == prevValueForAttrib % 2)  {
							passed++;
							if (successes.size() < printsize)
								successes.add((lastserial-i)+"-"+prevValueForAttrib);
							if (latestsuccessserial == 0) latestsuccessserial = seqlargerthantwo;
							
						} else {
			    			if (failures.size() < printsize)
			    				failures.add((lastserial-i)+"-"+prevValueForAttrib);
			    			
			    			if (latestfailureserial == 0) latestfailureserial = seqlargerthantwo;
			    		}
					} else {
						if (currentValueForAttrib % 2 != prevValueForAttrib % 2)  {
							passed++;
							if (successes.size() < printsize)
								successes.add((lastserial-i)+"-"+prevValueForAttrib);
							
							if (latestsuccessserial == 0) latestsuccessserial = seqlargerthantwo;
						} else {
			    			if (failures.size() < printsize)
			    				failures.add((lastserial-i)+"-"+prevValueForAttrib);
			    			
			    			if (latestfailureserial == 0) latestfailureserial = seqlargerthantwo;
			    		}
					}
					
				//} 
	    		
			}
			
		} 
		if (i == 0) {
			//System.out.println("Exclusions : " + + list.size() +"["  + excl + "] next value: " + value + " --- " + ((list.size() > 0 && !list.contains(Integer.parseInt(value)))?" passed ":" failed "));
		}
		
	}
	
	//System.out.println("Passed " + (passed*100/samplesize) + " pc " + successes.toString());
	//System.out.println (" Failed serials " + failures.toString());
	

	
	//Collections.sort(list);
	
	rhe.setGameCode(gameCode);
	InclusionExclusionEntity ince = new InclusionExclusionEntity();
	ince.setAlgorithmType(InclusionExclusionEntity.ALGORITHM_TYPE_EVENODD);
	ince.setAttribute(attribute);
	ince.setGameCode(gameCode);
	ince.setInputDrawDate(rhe.getLastNForAttribute("dateOfDraw", 1, 0));
	ince.setIsInclusionInd("false");
	
	//ince.setPercent(Integer.toString((passed*100/samplesize)));;
	//ince.setTotalScore(Integer.toString(((lastserial - latestsuccessserial) * ((passed*100/samplesize)))));;
	
	
	int currseqlen = getCurrentEvenOddLengthForAttribute(gameCode,attribute, lastserial);
	Hashtable<Integer,ArrayList<Integer>> currseqmap = findAllEvenOddsForAttribute(gameCode, attribute, 0, Math.abs(currseqlen));
	System.out.println(currseqmap);

	
	int useSkip = 0;
	if (currseqlen > 0) {
		if (currseqmap.get(Math.abs(currseqlen)+1) != null)
			useSkip = currseqmap.get(Math.abs(currseqlen)+1).get(2);
	} else {
		if (currseqmap.get(Math.abs(currseqlen)+1) != null)
			useSkip = currseqmap.get(Math.abs(currseqlen)+1).get(3);
	}
	
	// If higher sequence is overdue, target move in the same direction otherwise reverse
	boolean contSameDirection = false;
	 
	if (currseqmap.get(Math.abs(currseqlen)+1) != null) {
		if (useSkip > currseqmap.get(Math.abs(currseqlen)+1).get(4))
			contSameDirection = true;
	}

	
	
	int lastVal = Integer.parseInt(rhe.getValueForFieldFromCache(attribute, gameCode, lastserial));
	
	if (currseqlen > 0) {
		if (!contSameDirection)
			lastVal = 0- lastVal;
	} else {
		if (contSameDirection)
			lastVal = 0- lastVal;
	}
	
	
	
	if (Math.abs(currseqlen) > 2) {
		
		if (latestfailureserial > 1 && (latestfailureserial-1) * (100-(passed*100/seqlargerthantwo)) > 100) {
			ince.setPercent(Integer.toString((100-(passed*100/seqlargerthantwo))));
			ince.setTotalScore(Integer.toString((latestfailureserial-1) * (100-(passed*100/seqlargerthantwo))));
			
			lastVal = 0- lastVal;
			contSameDirection = !contSameDirection;
		}
		
		if (latestsuccessserial > 1 && (latestsuccessserial-1) * (passed*100/seqlargerthantwo) > 100) {
			ince.setPercent(Integer.toString((passed*100/seqlargerthantwo)));
			ince.setTotalScore(Integer.toString((latestsuccessserial-1) * (passed*100/seqlargerthantwo)));
		}
	}
	
	if (contSameDirection) {
		ince.setIsInclusionInd("true");
		
	} else {
		ince.setIsInclusionInd("false");
	}
	
	ArrayList<Integer> inarg = new ArrayList();
	
	if (lastVal > 0)
		inarg.add(1*Math.abs(currseqlen));
	else
		inarg.add(-1*Math.abs(currseqlen));
	
	ince.setData(inarg);
	
	
	
	/*if (latestsuccessserial == lastserial) {
		
		if (((lastserial - latestfailureserial) * (100-(passed*100/seqlargerthantwo))) > 100) {
			
			if (contSameDirection)
				ince.setIsInclusionInd("true");
			ince.setPercent(Integer.toString((100-(passed*100/seqlargerthantwo))));;
			ince.setTotalScore(Integer.toString((lastserial - latestfailureserial) * (100-(passed*100/seqlargerthantwo))));
			
			
			System.out.print (attribute + " Target FAIL"  + "[" + (100-(passed*100/seqlargerthantwo)) + "-" + (lastserial - latestfailureserial) * (100-(passed*100/seqlargerthantwo)) + "]");
			System.out.println (" Current exclusions for " + attribute + " " + list.size() + " " + list.toString() );
		}
		
	} else {
		
		if (((lastserial - latestsuccessserial) * ((passed*100/seqlargerthantwo))) > 100) {
			
			if (!contSameDirection)
				ince.setIsInclusionInd("false");
			
			ince.setPercent(Integer.toString((passed*100/seqlargerthantwo)));;
			ince.setTotalScore(Integer.toString(((lastserial - latestsuccessserial) * ((passed*100/seqlargerthantwo)))));;
			
			System.out.print (attribute + " Target SUCCESS"  + "[" + ((passed*100/seqlargerthantwo)) + "-" + (lastserial - latestsuccessserial) * ((passed*100/seqlargerthantwo)) + "]");
			System.out.println (" Current exclusions for " + attribute + " " + list.size() + " " + list.toString() );
		}
		 
	}*/
	
	if (!testMode) ince.addInclusionExclusionResult();
	System.out.println("EvenOdd Length " + ince.getAttribute() + " "+ ince.getIsInclusionInd() + " " + ince.getPercent() + " " + ince.getTotalScore() + " " + ince.getData().get(0) + " ");
	} catch (Exception e) {
		System.out.println("DBUTils.testAttributeForEvenOddLength: Exception while processing gamecode " + gameCode + " attribute " + attribute );
	}
	
	
	
}
	
	public void getCurrentInclusionAndExclusionsForAllAttributes(String gameCode) {
		
		System.out.println("Detecting Inclusions and Exclusions for gameCode " + gameCode);
		ResultHistoryEntity rhe = new ResultHistoryEntity();
		rhe.setGameCode(gameCode); 
		
		ResultsWithinLastN lastN = new ResultsWithinLastN();
		List l = lastN.getColumnNames();
		
		l.add("firstDigitDiff");
		l.add("secondDigitDiff");
		l.add("thirdDigitDiff");
		l.add("fourthDigitDiff");
		l.add("fifthDigitDiff");
		l.add("megaDigitDiff");
		
		l.add("firstFreq");
		l.add("secondFreq");
		l.add("thirdFreq");
		l.add("fourthFreq");
		l.add("fifthFreq");
		l.add("megaFreq");
		
		l.add("firstFreqShadow");
		l.add("secondFreqShadow");
		l.add("thirdFreqShadow");
		l.add("fourthFreqShadow");
		l.add("fifthFreqShadow");
		l.add("megaFreqShadow");
		
		l.add("firstFiveSumBucketRedux");
		l.add("firstFiveSumBucketDigitDiff");
		
		l.add("maxFactor");
		l.add("skipSum");
		l.add("diff1");
		l.add("diff2");
		l.add("diff3");
		l.add("diff4");		
		
		
		if (globalattribute != null && globalattribute.length() > 0) {
			l.removeAll(l);
			l.add(globalattribute);
		}
		Iterator it = l.iterator();
		
		while (it.hasNext()) {
			String fieldName = (String) it.next();
			
			if (!fieldName.endsWith("Follower") && !fieldName.endsWith("Prime") ) {
				System.out.println(fieldName + "-----------------------");
				/*testAttributeForInclusion(gameCode, fieldName);
				testAttributeForExclusions(gameCode, fieldName);
				
				testAttributeForSequenceLength(gameCode, fieldName);
				testAttributeForEvenOddLength(gameCode, fieldName);
				
				testAttributeForMARegression(gameCode, fieldName);
				
				testAttributeForSequenceOfRedux(gameCode, fieldName);*/
				PredictValueBasedOnDistanceAndFreq strat = new PredictValueBasedOnDistanceAndFreq();
				strat.saveResult(Integer.parseInt(gameCode), fieldName);
				strat.getLastThreePerformanceAndUpdatePrediction(Integer.parseInt(gameCode), fieldName);
				
				PredictAscDescBasedOnPatterns strat2 =  new PredictAscDescBasedOnPatterns();
				strat2.saveResult(Integer.parseInt(gameCode), fieldName);
				strat2.getLastThreePerformanceAndUpdatePrediction(Integer.parseInt(gameCode), fieldName);
				
				PredictEvenOddBasedOnPatterns strat3 =  new PredictEvenOddBasedOnPatterns();
				strat3.saveResult(Integer.parseInt(gameCode), fieldName);
				strat3.getLastThreePerformanceAndUpdatePrediction(Integer.parseInt(gameCode), fieldName);
				
				PredictPrimeNonprimeBasedOnPatterns strat4 =  new PredictPrimeNonprimeBasedOnPatterns();
				strat4.saveResult(Integer.parseInt(gameCode), fieldName);
				strat4.getLastThreePerformanceAndUpdatePrediction(Integer.parseInt(gameCode), fieldName);
			} 
			
		}
		
		//testFirstFiveSumBasedOnBucketsAndPercentileForInclusion(gameCode);
		
	}
	
	public void getCurrentEvenOddLengthsForAllAttributes(String gameCode, boolean printSequenceMap) {
		System.out.println("Detecting even(+ve) odd(-ve) lengths for gameCode " + gameCode);
		ResultHistoryEntity rhe = new ResultHistoryEntity();
		rhe.setGameCode(gameCode);
		
		ResultsWithinLastN lastN = new ResultsWithinLastN();
		List l = lastN.getColumnNames();
		l.add("firstFreq");
		l.add("secondFreq");
		l.add("thirdFreq");
		l.add("fourthFreq");
		l.add("fifthFreq");
		l.add("megaFreq");
		
		l.add("firstDigitDiff");
		l.add("secondDigitDiff");
		l.add("thirdDigitDiff");
		l.add("fourthDigitDiff");
		l.add("fifthDigitDiff");
		l.add("megaDigitDiff");
		
		
		Iterator it = l.iterator();
		
		while (it.hasNext()) {
			String fieldName = (String) it.next();
			
			if (!fieldName.endsWith("Follower") && !fieldName.endsWith("Prime") ) {
				int seqlen = getCurrentEvenOddLengthForAttribute(gameCode,fieldName,0);
				
				int latestValueForAttrib = Integer.parseInt(rhe.getValueForField(fieldName, gameCode, 0));
				
				if (Math.abs(seqlen) >  2) {
					System.out.print(fieldName + "  " + seqlen + " Last Value " + latestValueForAttrib + " ");
					if (printSequenceMap) findAllEvenOddsForAttribute(gameCode, fieldName, 0, Math.abs(seqlen));
					System.out.println();
				}
			} 
			
		}
		
	}
	
	public int getCurrentSequenceLengthForAttribute(String gameCode, String attribute, int serialNum) {
		
		int totalProcessed = 0;
		
		ResultHistoryEntity rhe = new ResultHistoryEntity();
		rhe.setGameCode(gameCode);
		
		int startSequencelength = 2;
		int currentMaxLen = 0;
		//System.out.print("Processing seq length ");
		for (int i=startSequencelength; i<9; i++) {
			//System.out.print("  " + i);
			
				int isSeq = isSequence(rhe.getLastNForSequenceFromCache(attribute, i, serialNum),i);
				if ( isSeq != 0) { // sequence of length i found
					
						if (isSeq == 1) {
							currentMaxLen = isSeq*i;
						}
											
						if (isSeq == -1) {
							currentMaxLen = isSeq*i;
						}
						
				} else {
					break;
				}
			
			
		}
		
		//System.out.println();		
		//System.out.println("Current seq length for gameCode " + gameCode + " attribute " + attribute + " ---- " + currentMaxLen);
		
		return currentMaxLen;
	}
	
public int getCurrentEvenOddLengthForAttribute(String gameCode, String attribute, int serialNum) {
		
		int totalProcessed = 0;
		
		ResultHistoryEntity rhe = new ResultHistoryEntity();
		rhe.setGameCode(gameCode);
		
		int startSequencelength = 2;
		int currentMaxLen = 0;
		//System.out.print("Processing seq length ");
		for (int i=startSequencelength; i<9; i++) {
			//System.out.print("  " + i);
			
				int isSeq = isAllEvenOrOdd(rhe.getLastNForSequenceFromCache(attribute, i, serialNum),i);
				if ( isSeq != 0) { // sequence of length i found
					
						if (isSeq == 1) {
							currentMaxLen = i;
						}
											
						if (isSeq == 2) {
							currentMaxLen = 0-i;
						}
						
				} else {
					break;
				}
			
			
		}
		
		//System.out.println();		
		//System.out.println("Current seq length for gameCode " + gameCode + " attribute " + attribute + " ---- " + currentMaxLen);
		
		return currentMaxLen;
	}

	public Hashtable<Integer, ArrayList<Integer>> getCurrentFreqAndSkipForAttribute(String gameCode, String attribute, int serialNumber, int historyinclude, boolean doPrint) {
		
		Hashtable<Integer, ArrayList<Integer>> out = new Hashtable<Integer, ArrayList<Integer>>(); // Number - Freq, CurrentSkip, LastSkip
		Connection conn = null;
		
		int countofvals = 0;
		
		String countofvalssql = "select count(distinct " + attribute + ") as total from (select " + attribute + " from jointView where gameCode = " + gameCode 
				+ ((serialNumber>0)?" and serialNumber <=" + serialNumber:"") 
				 + " order by serialNumber desc " + ((historyinclude>0)?" LIMIT " + historyinclude:"") + ") as temp ";
		
		String serialClause = "";
		if (serialNumber > 0) serialClause = " and a.serialNumber <= " + serialNumber;
		
		StringBuffer buff = new StringBuffer(); 
		
		String limitClause = "";
		if (historyinclude > 0)
			limitClause = " LIMIT " + historyinclude;
		
		buff.append("select a." + attribute + " as val, a.serialNumber as aser, max(b.serialNumber) as maxb from jointView a, jointView b where a.gameCode =  " + gameCode + serialClause 
				+ " and a.gameCode = b.gameCode	and b.serialNumber < a.serialNumber	and a." + attribute + " = b." + attribute
				+ " group by val, a.serialNumber"
				+ " order by a.serialNumber desc"	+ limitClause);		
		
		String sql = buff.toString();
		
		try {
			
			conn = getConnection();
			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(countofvalssql);
			
			if (rs.next())
				countofvals = rs.getInt("total");
			
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sql);
			int currentSkip = 0;
			
			while (rs.next()) {
				int thisval  = rs.getInt("val");
				int lastSkip = 	rs.getInt("aser") - rs.getInt("maxb");
				
					if (out.get(thisval) == null) {
						ArrayList<Integer> a = new ArrayList<Integer>();
						a.add(0,0); 
						a.add(1, currentSkip+1);
						a.add(2, lastSkip);
						out.put(thisval, a);	
					} 
					currentSkip++;
					
					if (countofvals > 0 && out.size() == countofvals)
						break;
			}
			
			// Get the current freqs
			
					
			buff = new StringBuffer();
			buff.append("select ifnull(" + attribute + ",0) , count(*) as freq	from (select serialNumber, ifnull(" + attribute
								+ ",0) as "+ attribute + " from jointView a where  gameCode = " + gameCode  + serialClause
						+ " order by serialNumber desc " + limitClause + " ) as temp group by " + attribute + "	order by count(*) desc");
			
			
			sql = buff.toString();
			stmt = conn.createStatement();
			
			rs = stmt.executeQuery(sql);
			while (rs.next()) {
				int thisval = rs.getInt(1);
				int thisFreq = rs.getInt(2);
				
				if (out.get(thisval) != null) {
					out.get(thisval).set(0,thisFreq);
				}
				
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			if (conn != null)
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
	
		Enumeration<Integer> it = out.keys();

		while (it.hasMoreElements()) {
			int str = (int) it.nextElement();
			if (doPrint)
				System.out.println(str + ": " + out.get(str));

		}
		return out;
	}
	
	
public Hashtable<Integer, ArrayList<Integer>> getCurrentFreqAndSkipForFirstFiveSumsBasedOnBucket(String gameCode, int thisFirstFiveSumBucket, int serialNumber, int historyinclude, boolean doPrint) {
		
		Hashtable<Integer, ArrayList<Integer>> out = new Hashtable<Integer, ArrayList<Integer>>(); // Number - Freq, CurrentSkip, LastSkip
		
		StringBuffer buff = new StringBuffer();
		
		String serialClause = "";
		if (serialNumber > 0) serialClause = " and a.serialNumber <= " + serialNumber;
		
		String limitClause = "";
		if (historyinclude > 0)
			limitClause = " LIMIT " + historyinclude;
		
		buff.append("select ifnull(a.firstFiveSum,0) as val, (a.serialNumber- max(b.serialNumber)) as lastskip from jointView a, jointView b where a.gameCode =  " + 
					gameCode + serialClause 
				+ " and a.gameCode = b.gameCode	and a.firstFiveSumBucket = b.firstFiveSumBucket and a.firstFiveSumBucket = " + thisFirstFiveSumBucket + 
				" and b.serialNumber < a.serialNumber	and ifnull(a.firstFiveSum,0) = ifnull(b.firstFiveSum,0) group by val, a.serialNumber"
				+ " order by a.serialNumber desc"	+ limitClause);		
		
		String sql = buff.toString();
		Connection conn = null;
		try {
			
			conn = getConnection();
			Statement stmt = conn.createStatement();
			
			ResultSet rs = stmt.executeQuery(sql);
			int currentSkip = 0;
			
			while (rs.next()) {
				int thisval  = rs.getInt("val");
				int lastSkip = 	rs.getInt("lastskip");
				
					if (out.get(thisval) == null) {
						ArrayList<Integer> a = new ArrayList<Integer>();
						a.add(0,0);
						a.add(1, currentSkip+1);
						a.add(2, lastSkip);
						out.put(thisval, a);	
					} 
					currentSkip++;
			}
			
			// Get the current freqs
			
					
			buff = new StringBuffer();
			buff.append("select ifnull(firstFiveSum,0) , count(*) as freq	from (select serialNumber, ifnull(firstFiveSum,0) as firstFiveSum from jointView a where  gameCode = " + 
						gameCode  + serialClause + "  and a.firstFiveSumBucket = " + thisFirstFiveSumBucket + 
						 " order by serialNumber desc " + limitClause + " ) as temp group by firstFiveSum	order by count(*) desc");
			
			
			sql = buff.toString();
			stmt = conn.createStatement();
			
			rs = stmt.executeQuery(sql);
			while (rs.next()) {
				int thisval = rs.getInt(1);
				int thisFreq = rs.getInt(2);
				
				if (out.get(thisval) != null) {
					out.get(thisval).set(0,thisFreq);
				}
				
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			if (conn != null)
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
	
		Enumeration<Integer> it = out.keys();

		while (it.hasMoreElements()) {
			int str = (int) it.nextElement();
			if (doPrint)
				System.out.println(str + ": " + out.get(str));

		}
		return out;
	}
	
	public ArrayList<Integer> includeAttributeValuesBasedOnFreqAndSkip(String gameCode, String attribute, int serialNumber, int historysize) {
		ArrayList<Integer> out = new ArrayList<Integer>();
		Hashtable<Integer, ArrayList<Integer>> attributeData = getCurrentFreqAndSkipForAttribute(gameCode, attribute, serialNumber, historysize, false); //Number - Freq, CurrentSkip, LastSkip
		
		ResultHistoryEntity rhe = new ResultHistoryEntity();
		rhe.setGameCode(gameCode);

		if (historysize == 0) {
			historysize = Integer.parseInt(rhe.getLastNForAttribute("serialNumber", 1, serialNumber));
		}
		Enumeration<Integer> it = attributeData.keys();

		while (it.hasMoreElements()) {
			int str = (int) it.nextElement();
			//System.out.print(str);
			
			if (attributeData.get(str).get(0) > 0) {
				//if (historysize/attributeData.get(str).get(0) <= 2*attributeData.get(str).get(1))
				if (historysize/attributeData.get(str).get(0) <= attributeData.get(str).get(1))
					out.add(str);
			}

		}
		//System.out.println(out);
		return out;
	}
	
	private ArrayList<Integer> includeFirstFiveSumValuesBasedOnBucketsAndFreqAndSkip(String gameCode, int serialNumber, int historysize) {
		ArrayList<Integer> out = new ArrayList<Integer>();
		ArrayList<Integer> bucks = includeAttributeValuesBasedOnFreqAndSkip(gameCode, "firstFiveSumBucket",serialNumber,500);
		
		Iterator<Integer> it = bucks.iterator();
		
		while (it.hasNext()) {
			int bucket = it.next();
			Hashtable<Integer, ArrayList<Integer>> attributeData = getCurrentFreqAndSkipForFirstFiveSumsBasedOnBucket(gameCode, bucket, serialNumber, historysize, false);
			
			ResultHistoryEntity rhe = new ResultHistoryEntity();
			rhe.setGameCode(gameCode);

			if (historysize == 0) {
				historysize = Integer.parseInt(rhe.getLastNForAttribute("serialNumber", 1, serialNumber));
			}
			
			historysize = getTotalInstancesWithThisFirstFiveSumBucket(gameCode, bucket, serialNumber);
			Enumeration<Integer> at = attributeData.keys();

			while (at.hasMoreElements()) {
				int str = (int) at.nextElement();
				//System.out.print(str);
				
				if (attributeData.get(str).get(0) > 0) {
					//if (historysize/attributeData.get(str).get(0) <= 2*attributeData.get(str).get(1))
					if (historysize/attributeData.get(str).get(0) <= attributeData.get(str).get(1))
						out.add(str);
				}

			}
			
		}
		
		
		//System.out.println(out);
		return out;
	}
	
	private int getTotalInstancesWithThisFirstFiveSumBucket(String gameCode,
			int bucket, int serialNumber) {
		// TODO Auto-generated method stub
		Connection conn = null;
		int out = 0;
		String serialClause = "";
		if (serialNumber > 0)
			serialClause = " and serialNumber <= " + serialNumber;

		StringBuffer buff = new StringBuffer();
		buff.append("select count(*) from jointView where gameCode = "
				+ gameCode + serialClause + "  and firstFiveSumBucket = "
				+ bucket);

		String sql = buff.toString();
		try {
			conn = getConnection();
			Statement stmt = conn.createStatement();

			ResultSet rs = stmt.executeQuery(sql);
			while (rs.next()) {
				out = rs.getInt(1); 

			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			if (conn != null)
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}

		return 0;
	}

	public void testAttributeForInclusion(String gameCode, String attribute) {
		
		if ((attribute.endsWith("Freq") || attribute.endsWith("Skip") || attribute.endsWith("Shadow")) )
			return;
		
		
		ResultHistoryEntity rhe = new ResultHistoryEntity();
    	rhe.setGameCode(gameCode);
    	ArrayList<String> failures = new ArrayList<String>();
    	ArrayList<String> successes = new ArrayList<String>();
    	int lastserial = 0;
    	int passed = 0;
    	int samplesize = 100;
    	int printsize = 10;
    	
    	Random r = new Random();
    	int randomdraw = r.nextInt((100 - 1) + 1) + 1;
    	
    	int historysize = 500;
    	
    	try {
    	
    	if (lastserial == 0)
    		lastserial = Integer.parseInt(rhe.getValueForField("serialNumber", gameCode, 0));
    	
    	InclusionExclusionEntity ince = new InclusionExclusionEntity();
		ince.setAlgorithmType(InclusionExclusionEntity.ALGORITHM_TYPE_INCLUSIVE);
		ince.setAttribute(attribute);
		ince.setGameCode(gameCode);
		ince.setInputDrawDate(rhe.getLastNForAttribute("dateOfDraw", 1, 0));
		ince.setIsInclusionInd("true");
		
		ince.setPercent(Integer.toString(ince.getLastPassingPercent()));
		
    	
    	for (int i=0; i<samplesize; i++) {
    		
    		if (successes.size() == 0 || failures.size() ==0 || randomdraw >= 66 || Integer.parseInt(ince.getPercent()) == 0) {
    			
    			if (randomdraw >= 66)
    				ince.setPercent(null);
    			
	    		//System.out.print(i);
	    		String value = rhe.getValueForFieldFromCache(attribute, gameCode, (lastserial-i));
	    		
	    		//Set<Integer> list = new TreeSet<Integer>();
	    		
	    		ArrayList<Integer> list = includeAttributeValuesBasedOnFreqAndSkip(gameCode, attribute,  (lastserial-i-1), historysize);
	    		
	    		if (value == null)
	    			value = "0";
	    		
	    		if (list.size() > 0 && list.contains(Integer.parseInt(value))) {
	    			passed++;
	    			if (successes.size() < printsize)
	    				successes.add((lastserial-i)+"-"+rhe.getValueForFieldFromCache(attribute, gameCode, (lastserial-i-1)));
	    		} else {
	    			if (failures.size() < printsize)
	    				failures.add((lastserial-i)+"-"+rhe.getValueForFieldFromCache(attribute, gameCode, (lastserial-i-1)));
	    		}
	    			
	    		
	    		if (i == 0) {
	    			//System.out.println("Inclusions : " + + list.size() +"["  + list + "] next value: " + value + " --- " + ((list.size() > 0 && !list.contains(Integer.parseInt(value)))?" failed ":" passed "));
	    		}
    		} else {
    			if (randomdraw < 66 && Integer.parseInt(ince.getPercent()) > 0)
    				break;
    			
    		}
    		
    	}
    	
    	//System.out.println("Passed " + (passed*100/samplesize) + " pc " + successes.toString());
    	//System.out.println (" Failed serials " + failures.toString());
    	
    	
    	ArrayList<Integer> list = includeAttributeValuesBasedOnFreqAndSkip(gameCode, attribute, 0, historysize);
    	
    	
		//Collections.sort(list);
    	
    	//Collections.sort(list);
    			int latestsuccessserial = Integer.parseInt(successes.get(0).substring(0, successes.get(0).indexOf("-")));
    			int latestfailureserial = Integer.parseInt(failures.get(0).substring(0, failures.get(0).indexOf("-")));
    			
    			rhe.setGameCode(gameCode);
    			
				//ince.setPercent(Integer.toString((passed*100/samplesize)));;
    			//ince.setTotalScore(Integer.toString(((lastserial - latestsuccessserial) * ((passed*100/samplesize)))));;
    			
    			ince.setData(list);
    			
    			if (ince.getPercent() != null && !ince.getPercent().equals("0"))
    				passed = Integer.parseInt(ince.getPercent());
    			else
    				ince.setPercent(Integer.toString((passed*100/samplesize)));;
    			
    			if (latestsuccessserial == lastserial) {
    				
    				if (((lastserial - latestfailureserial) * (100-(passed*100/samplesize))) > 100) {
    					ince.setIsInclusionInd("false");
    					
    					if (ince.getPercent() == null) {
    						ince.setPercent(Integer.toString((100-(passed*100/samplesize))));;
    						
    					}
    					ince.setTotalScore(Integer.toString((lastserial - latestfailureserial) * (100-Integer.parseInt(ince.getPercent()))));
    	    			
    					System.out.print (attribute + "-INCLUSIONS Target FAIL" + "[" + ince.getPercent() + " : " + (lastserial - latestfailureserial) * (100-Integer.parseInt(ince.getPercent())) + "]");
    					System.out.println (" Current inclusions for " + attribute + " " + list.size() + " " + list.toString() );
    				}
    				
    			} else {
    				
    				if (((lastserial - latestsuccessserial) * ((passed*100/samplesize))) > 100) {
    					ince.setIsInclusionInd("true");
    					
    					if (ince.getPercent() == null) {
    						ince.setPercent(Integer.toString((passed*100/samplesize)));;
    						
    					}
    					
    					ince.setTotalScore(Integer.toString(((lastserial - latestsuccessserial) * Integer.parseInt(ince.getPercent()))));
    	    			
    					System.out.print (attribute + "-INCLUSIONS Target SUCCESS" + "[" + ince.getPercent() + " : " + (lastserial - latestsuccessserial) * Integer.parseInt(ince.getPercent()) + "]");
    					System.out.println (" Current inclusions for " + attribute + " " + list.size() + " " + list.toString() );
    				}
    				 
    			}
		
    	if (!testMode) ince.addInclusionExclusionResult();
    	
    	} catch (Exception e) {
    		System.out.println("DBUTils.testAttributeForInclusion: Exception while processing gamecode " + gameCode + " attribute " + attribute );
    	}
    	
	}
	
	
	public void testFirstFiveSumBasedOnBucketsAndFreqSkipForInclusion(String gameCode) {
		ResultHistoryEntity rhe = new ResultHistoryEntity();
    	
    	ArrayList<String> failures = new ArrayList<String>();
    	ArrayList<String> successes = new ArrayList<String>();
    	int lastserial = 0;
    	int passed = 0;
    	int samplesize = 100;
    	int printsize = 10;
    	int passedlistsize = 0;
    	int failedlistsize = 0;
    	
    	int historysize = 500;
    	
    	if (lastserial == 0)
    		lastserial = Integer.parseInt(rhe.getValueForField("serialNumber", gameCode, 0));
    	
    	for (int i=0; i<samplesize; i++) {
    		//System.out.print(i);
    		String value = rhe.getValueForField("firstFiveSum", gameCode, (lastserial-i));
    		
    		//Set<Integer> list = new TreeSet<Integer>();
    		
    		ArrayList<Integer> list = includeFirstFiveSumValuesBasedOnBucketsAndFreqAndSkip(gameCode, (lastserial-i-1), historysize);
    		
    		if (value == null)
    			value = "0";
    		
    		if (list.size() > 0 ) {
	    		if (list.contains(Integer.parseInt(value))) {
	    			passed++; 
	    			passedlistsize += list.size();
	    			if (successes.size() < printsize)
	    				successes.add((lastserial-i)+"-"+rhe.getValueForField("firstFiveSum", gameCode, (lastserial-i-1))+ "-"+ list.size());
	    		} else {
	    			failedlistsize += list.size();
	    			if (failures.size() < printsize)
	    				failures.add((lastserial-i)+"-"+rhe.getValueForField("firstFiveSum", gameCode, (lastserial-i-1))+ "-"+ list.size());
	    		}
    		}
    			
    		
    		if (i == 0) {
    			//System.out.println("Inclusions : " + + list.size() +"["  + list + "] next value: " + value + " --- " + ((list.size() > 0 && !list.contains(Integer.parseInt(value)))?" failed ":" passed "));
    		}
    		
    	}
    	
    	//System.out.println("Passed " + (passed*100/samplesize) + " pc " + successes.toString());
    	//System.out.println (" Failed serials " + failures.toString());
    	
    	
    	ArrayList<Integer> list = includeFirstFiveSumValuesBasedOnBucketsAndFreqAndSkip(gameCode,  0, historysize);
    	
    	
		//Collections.sort(list);
    	
    	//Collections.sort(list);
    			int latestsuccessserial = Integer.parseInt(successes.get(0).substring(0, successes.get(0).indexOf("-")));
    			int latestfailureserial = Integer.parseInt(failures.get(0).substring(0, failures.get(0).indexOf("-")));
    			
    			rhe.setGameCode(gameCode);
    			InclusionExclusionEntity ince = new InclusionExclusionEntity();
    			ince.setAlgorithmType(InclusionExclusionEntity.ALGORITHM_TYPE_FFSUM_BUCKET);
    			ince.setAttribute("firstFiveSum");
    			ince.setGameCode(gameCode);
    			ince.setInputDrawDate(rhe.getLastNForAttribute("dateOfDraw", 1, 0));
    			ince.setIsInclusionInd("true");
				
				ince.setPercent(Integer.toString((passed*100/samplesize)));;
    			ince.setTotalScore(Integer.toString(((lastserial - latestsuccessserial) * ((passed*100/samplesize)))));;
    			
    			ince.setData(list);
    			
    			System.out.println (" BUCKET and SKIP passed " + (passed*100/samplesize) + " pass size " + passedlistsize/passed + " fail size " + failedlistsize/(samplesize-passed) +
						"Current inclusions for " + "firstFiveSum" + " " + list.size() + " " + list.toString() );
	
    			if (latestsuccessserial == lastserial) {
    				
    				if (((lastserial - latestfailureserial) * (100-(passed*100/samplesize))) > 100) {
    					ince.setIsInclusionInd("false");
    					ince.setPercent(Integer.toString((100-(passed*100/samplesize))));;
    	    			ince.setTotalScore(Integer.toString((lastserial - latestfailureserial) * (100-(passed*100/samplesize))));
    	    			
    					System.out.print ("firstFiveSum" + " Target FAIL" + "[" + (100-(passed*100/samplesize)) + " : " + (lastserial - latestfailureserial) * (100-(passed*100/samplesize)) + "]");
    					System.out.println (" Current inclusions for " + "firstFiveSum" + " " + list.size() + " " + list.toString() );
    				}
    				
    			} else {
    				
    				if (((lastserial - latestsuccessserial) * ((passed*100/samplesize))) > 100) {
    					ince.setIsInclusionInd("true");
    					
    					ince.setPercent(Integer.toString((passed*100/samplesize)));;
    	    			ince.setTotalScore(Integer.toString(((lastserial - latestsuccessserial) * ((passed*100/samplesize)))));;
    	    			
    					System.out.print ("firstFiveSum" + " Target SUCCESS" + "[" + (passed*100/samplesize) + " : " + (lastserial - latestsuccessserial) * ((passed*100/samplesize)) + "]");
    					System.out.println (" Current inclusions for " + "firstFiveSum" + " " + list.size() + " " + list.toString() );
    				}
    				 
    			}
		
    	 ince.addInclusionExclusionResult();
    	
 	}
	
	public void testFirstFiveSumBasedOnBucketsAndPercentileForInclusion(String gameCode) {
		ResultHistoryEntity rhe = new ResultHistoryEntity();
    	rhe.setGameCode(gameCode);
    	ArrayList<String> failures = new ArrayList<String>();
    	ArrayList<String> successes = new ArrayList<String>();
    	int lastserial = 0;
    	int passed = 0;
    	int samplesize = 100;
    	int printsize = 10;
    	int passedlistsize=0;
    	int failedlistsize=0;
    	
    	int historysize = 500;
    	
    	try {
    	if (lastserial == 0)
    		lastserial = Integer.parseInt(rhe.getValueForField("serialNumber", gameCode, 0));
    	
    	for (int i=0; i<samplesize; i++) {
    		//System.out.print(i);
    		String value = rhe.getValueForFieldFromCache("firstFiveSum", gameCode, (lastserial-i));
    		
    		//Set<Integer> list = new TreeSet<Integer>();
    		
    		ArrayList<Integer> list = includeFirstFiveSumValuesBasedOnBucketsAndPercentile(gameCode, (lastserial-i-1), historysize);
    		
    		if (value == null)
    			value = "0";
    		
    		if (list.size() > 0 ) {
	    		if (list.contains(Integer.parseInt(value))) {
	    			passed++; 
	    			passedlistsize += list.size();
	    			if (successes.size() < printsize)
	    				successes.add((lastserial-i)+"-"+rhe.getValueForFieldFromCache("firstFiveSum", gameCode, (lastserial-i-1))+ "-"+ list.size());
	    		} else {
	    			failedlistsize += list.size();
	    			if (failures.size() < printsize)
	    				failures.add((lastserial-i)+"-"+rhe.getValueForFieldFromCache("firstFiveSum", gameCode, (lastserial-i-1))+ "-"+ list.size());
	    		}
    		}
    			
    		
    		if (i == 0) {
    			//System.out.println("Inclusions : " + + list.size() +"["  + list + "] next value: " + value + " --- " + ((list.size() > 0 && !list.contains(Integer.parseInt(value)))?" failed ":" passed "));
    		}
    		
    	}
    	
    	//System.out.println("Passed " + (passed*100/samplesize) + " pc " + successes.toString());
    	//System.out.println (" Failed serials " + failures.toString());
    	
    	
    	ArrayList<Integer> list = includeFirstFiveSumValuesBasedOnBucketsAndPercentile(gameCode,  0, historysize);
    	
    	
		//Collections.sort(list);
    	
    	//Collections.sort(list);
    			int latestsuccessserial = Integer.parseInt(successes.get(0).substring(0, successes.get(0).indexOf("-")));
    			int latestfailureserial = Integer.parseInt(failures.get(0).substring(0, failures.get(0).indexOf("-")));
    			
    			rhe.setGameCode(gameCode);
    			InclusionExclusionEntity ince = new InclusionExclusionEntity();
    			ince.setAlgorithmType(InclusionExclusionEntity.ALGORITHM_TYPE_FFSUM_BUCKET_INCLUDE);
    			ince.setAttribute("firstFiveSum");
    			ince.setGameCode(gameCode);
    			ince.setInputDrawDate(rhe.getLastNForAttribute("dateOfDraw", 1, 0));
    			ince.setIsInclusionInd("true");
				
				//ince.setPercent(Integer.toString((passed*100/samplesize)));;
    			//ince.setTotalScore(Integer.toString(((lastserial - latestsuccessserial) * ((passed*100/samplesize)))));;
    			
    			ince.setData(list);
    			
    			System.out.println (" BUCKET and PERCENTILE passed " + (passed*100/samplesize) + " pass size " + passedlistsize/passed + " fail size " + failedlistsize/(samplesize-passed) +
    								"Current inclusions for " + "firstFiveSum" + " " + list.size() + " " + list.toString() );
    			
    			
    			if (latestsuccessserial == lastserial) {
    				
    				if (((lastserial - latestfailureserial) * (100-(passed*100/samplesize))) > 100) {
    					ince.setIsInclusionInd("false");
    					ince.setPercent(Integer.toString((100-(passed*100/samplesize))));;
    	    			ince.setTotalScore(Integer.toString((lastserial - latestfailureserial) * (100-(passed*100/samplesize))));
    	    			
    					System.out.print ("firstFiveSum" + " Target FAIL" + "[" + (100-(passed*100/samplesize)) + " : " + (lastserial - latestfailureserial) * (100-(passed*100/samplesize)) + "]");
    					System.out.println (" Current inclusions for " + "firstFiveSum" + " " + list.size() + " " + list.toString() );
    				}
    				
    			} else {
    				
    				if (((lastserial - latestsuccessserial) * ((passed*100/samplesize))) > 100) {
    					ince.setIsInclusionInd("true");
    					
    					ince.setPercent(Integer.toString((passed*100/samplesize)));;
    	    			ince.setTotalScore(Integer.toString(((lastserial - latestsuccessserial) * ((passed*100/samplesize)))));;
    	    			
    					System.out.print ("firstFiveSum" + " Target SUCCESS" + "[" + (passed*100/samplesize) + " : " + (lastserial - latestsuccessserial) * ((passed*100/samplesize)) + "]");
    					System.out.println (" Current inclusions for " + "firstFiveSum" + " " + list.size() + " " + list.toString() );
    				}
    				 
    			}
		//UNCOMMENT
    	if (!testMode) ince.addInclusionExclusionResult();
    	} catch (Exception e) {
    		System.out.println("DBUTils.testFirstFiveSumBasedOnBucketsAndPercentileForInclusion: Exception while processing gamecode " + gameCode + " attribute firstFiveSum"  );
    	}
    	
 	}
	
	private ArrayList<Integer> includeFirstFiveSumValuesBasedOnBucketsAndPercentile(
			String gameCode, int serialNum, int historysize) {
		ArrayList<Integer> out = new ArrayList<Integer>();
		ResultHistoryEntity rhe = new ResultHistoryEntity();
		ArrayList<Integer> bucks = includeAttributeValuesBasedOnFreqAndSkip(gameCode, "firstFiveSumBucket",serialNum,500);
		
		// Trying buckets based on excludes (because that is 75 %
		/*bucks = new ArrayList<Integer>(); 
		
		String excl = rhe.getExclusionsForField("firstFiveSumBucket", gameCode,  serialNum, 65, 25);
		StringTokenizer excltok = new StringTokenizer(excl,",");
		
		while (excltok.hasMoreTokens()) {
			bucks.add(Integer.parseInt(excltok.nextToken()));
		}
		
		ArrayList<Integer> inclbucks = new ArrayList<Integer>();
		
		for (int b=5;b<30;b++) {
			if (!bucks.contains(b)) {
				inclbucks.add(b);
			}
		}
		
		bucks = inclbucks;*/
		// END TRYING
		
		Iterator<Integer> it = bucks.iterator();
		
		while (it.hasNext()) {
			int bucket = it.next();

			out.addAll(rhe.getFirstFiveSumIncludesBasedOnBucketAndPercentile(gameCode, serialNum, bucket, 0));
			
		}
		
		
		//System.out.println(out);
		return out;
	}

	public void testAttributeForExclusions(String gameCode, String attribute) {
		
		if ((attribute.endsWith("Freq") || attribute.endsWith("Skip") || attribute.endsWith("Shadow")) )
			return;
				
		ResultHistoryEntity rhe = new ResultHistoryEntity();
    	rhe.setGameCode(gameCode);
    	ArrayList<String> failures = new ArrayList<String>();
    	ArrayList<String> successes = new ArrayList<String>();
    	int lastserial = 0;
    	int passed = 0;
    	int samplesize = 300;
    	int printsize = 10;
    	
    	int percentilecutoff = 70;
    	int historyspan = 50;
    	
    	try {
    		
    	
    	if (attribute.equals("firstFiveSum")) {
    		percentilecutoff = 25;
    		historyspan = 50;
    	}
    	
    	if (attribute.equals("firstFiveSumBucket")) {
    		percentilecutoff = 65;
    		historyspan = 25;
    	}
    	
    	if (lastserial == 0)
    		lastserial = Integer.parseInt(rhe.getValueForField("serialNumber", gameCode, 0));
    	
    	for (int i=0; i<samplesize; i++) {
    		 
    		String value = rhe.getValueForFieldFromCache(attribute, gameCode, (lastserial-i));
    		
    		if (value == null) value = "0";
    		
    		Set<Integer> list = new TreeSet<Integer>();
    		
    		String excl = rhe.getExclusionsForField(attribute, gameCode,  (lastserial-i-1), percentilecutoff, historyspan);
    		StringTokenizer excltok = new StringTokenizer(excl,",");
    		
    		while (excltok.hasMoreTokens()) {
    			list.add(Integer.parseInt(excltok.nextToken()));
    		}
    		
    		if (attribute.equals("firstFiveSum")) {
	    		ArrayList<Integer> excl2 = rhe.getFirstFiveSumExcludesBasedOnMultiplesHistory(gameCode, (lastserial-i-1), historyspan);
	    		
	    		Iterator<Integer> exclIt = excl2.iterator();
	    		
	    		while (exclIt.hasNext()) {
	    			list.add(exclIt.next());
	    		}
    		}
    		
    		if (list.size() > 0 && !list.contains(Integer.parseInt(value))) {
    			passed++;
    			if (successes.size() < printsize)
    				successes.add((lastserial-i)+"-"+rhe.getValueForFieldFromCache(attribute, gameCode, (lastserial-i-1)));
    		} else {
    			if (failures.size() < printsize)
    				failures.add((lastserial-i)+"-"+rhe.getValueForFieldFromCache(attribute, gameCode, (lastserial-i-1)));
    		}
    			
    		
    		if (i == 0) {
    			//System.out.println("Exclusions : " + + list.size() +"["  + excl + "] next value: " + value + " --- " + ((list.size() > 0 && !list.contains(Integer.parseInt(value)))?" passed ":" failed "));
    		}
    		
    	}
    	
    	//System.out.println("Passed " + (passed*100/samplesize) + " pc " + successes.toString());
    	//System.out.println (" Failed serials " + failures.toString());
    	
    	Set<Integer> list = new TreeSet<Integer>();
    	
    	String excl = rhe.getExclusionsForField(attribute, gameCode,  0, percentilecutoff, historyspan);
    	
    	StringTokenizer excltok = new StringTokenizer(excl,",");
    	
		while (excltok.hasMoreTokens()) {
			String tem =  excltok.nextToken();
			if (!list.contains(Integer.parseInt(tem)))
				list.add(Integer.parseInt(tem));
		}
    	
		if (attribute.equals("firstFiveSum")) {
	    	ArrayList<Integer> excl2 = rhe.getFirstFiveSumExcludesBasedOnMultiplesHistory(gameCode, 0, historyspan);
			
			Iterator<Integer> exclIt = excl2.iterator();
			
			while (exclIt.hasNext()) {
				list.add(exclIt.next());
			}
		}
		
		//Collections.sort(list);
		int latestsuccessserial = (successes.size() > 0)?Integer.parseInt(successes.get(0).substring(0, successes.get(0).indexOf("-"))):0;
		int latestfailureserial = (failures.size() > 0)?Integer.parseInt(failures.get(0).substring(0, failures.get(0).indexOf("-"))):0;
		
		rhe.setGameCode(gameCode);
		InclusionExclusionEntity ince = new InclusionExclusionEntity();
		ince.setAlgorithmType(InclusionExclusionEntity.ALGORITHM_TYPE_EXCLUSIVE);
		ince.setAttribute(attribute);
		ince.setGameCode(gameCode);
		ince.setInputDrawDate(rhe.getLastNForAttribute("dateOfDraw", 1, 0));
		ince.setIsInclusionInd("false");
		
		ince.setPercent(Integer.toString((passed*100/samplesize)));;
		
		//ince.setPercent(Integer.toString((passed*100/samplesize)));;
		//ince.setTotalScore(Integer.toString(((lastserial - latestsuccessserial) * ((passed*100/samplesize)))));;
		
		ArrayList<Integer> inarg = new ArrayList();
		inarg.addAll(list);
		ince.setData(inarg);
		
		
		if (latestsuccessserial == lastserial) {
			
			if (((lastserial - latestfailureserial) * (100-(passed*100/samplesize))) > 100) {
				
				ince.setIsInclusionInd("true");
				ince.setPercent(Integer.toString((100-(passed*100/samplesize))));;
    			ince.setTotalScore(Integer.toString((lastserial - latestfailureserial) * (100-(passed*100/samplesize))));
    			
    			
				System.out.print (attribute + "-EXCLUSIONS Target FAIL"  + "[" + (100-(passed*100/samplesize)) + "-" + (lastserial - latestfailureserial) * (100-(passed*100/samplesize)) + "]");
				System.out.println (" Current exclusions for " + attribute + " " + list.size() + " " + list.toString() );
			}
			
		} else {
			
			if (((lastserial - latestsuccessserial) * ((passed*100/samplesize))) > 100) {
				
				ince.setIsInclusionInd("false");
				
				ince.setPercent(Integer.toString((passed*100/samplesize)));;
    			ince.setTotalScore(Integer.toString(((lastserial - latestsuccessserial) * ((passed*100/samplesize)))));;
    			
				System.out.print (attribute + "-EXCLUSIONS Target SUCCESS"  + "[" + ((passed*100/samplesize)) + "-" + (lastserial - latestsuccessserial) * ((passed*100/samplesize)) + "]");
				System.out.println (" Current exclusions for " + attribute + " " + list.size() + " " + list.toString() );
			}
			 
		}
		
		if (!testMode) ince.addInclusionExclusionResult();
		
    	} catch (Exception e) {
    		System.out.println("DBUTils.testAttributeForExclusion: Exception while processing gamecode " + gameCode + " attribute " + attribute );
    	}
    	
	}
	
	public void testAttributeForSequenceOfRedux(String gameCode, String attribute) { /// testing whether reduxes follow the NineDigitSequenceOutcome
		
		if (( attribute.endsWith("Redux") ) )
			return;
				
		ResultHistoryEntity rhe = new ResultHistoryEntity();
    	rhe.setGameCode(gameCode);
    	ArrayList<String> failures = new ArrayList<String>();
    	ArrayList<String> successes = new ArrayList<String>();
    	int lastserial = 0;
    	int passed = 0;
    	int samplesize = 300;
    	int printsize = 10;
    	
    	try {
    		
    	
    	if (lastserial == 0)
    		lastserial = Integer.parseInt(rhe.getValueForField("serialNumber", gameCode, 0));
    	
    	for (int i=0; i<samplesize; i++) {
    		 
    		String last10values = rhe.getLastNForSequenceFromCache(attribute, 10, (lastserial-i));
      		
    		String[] indivVals = last10values.split(",");
    		int[] last10redux = new int[indivVals.length];
    		
    		for (int k=0; k<indivVals.length; k++) {
    			last10redux[last10redux.length - k - 1] = Integer.parseInt(Numbers.getRedux(indivVals[k]));
    		}
    		
    		if (NineDigitSequenceOutcome.isConsistentOutcome(last10redux)) {
    			passed++;
    			if (successes.size() < printsize)
    				successes.add((lastserial-i)+"-"+rhe.getValueForFieldFromCache(attribute, gameCode, (lastserial-i-1)));
    		} else {
    			if (failures.size() < printsize)
    				failures.add((lastserial-i)+"-"+rhe.getValueForFieldFromCache(attribute, gameCode, (lastserial-i-1)));
    		}
    			
    		
    		if (i == 0) {
    			//System.out.println("Exclusions : " + + list.size() +"["  + excl + "] next value: " + value + " --- " + ((list.size() > 0 && !list.contains(Integer.parseInt(value)))?" passed ":" failed "));
    		}
    		
    	}
    	
    	//System.out.println("Passed " + (passed*100/samplesize) + " pc " + successes.toString());
    	//System.out.println (" Failed serials " + failures.toString());
    	
    	Set<Integer> list = new TreeSet<Integer>();
    	
    	String currentvals = rhe.getLastNForSequenceFromCache(attribute, 9, lastserial);
    	
    	StringTokenizer excltok = new StringTokenizer(currentvals,",");
    	
		while (excltok.hasMoreTokens()) {
			String tem =  excltok.nextToken();
			if (!list.contains(Integer.parseInt(Numbers.getRedux(tem))))
				list.add(Integer.parseInt(Numbers.getRedux(tem)));
		}
		
		String[] indivVals = currentvals.split(",");
		int[] last9redux = new int[indivVals.length];
		
		for (int k=0; k<indivVals.length; k++) {
			last9redux[last9redux.length - k - 1] = Integer.parseInt(Numbers.getRedux(indivVals[k]));
		}
		
		String sseries = "";
		String currentpattern = "";
		
		for (int j=0; j<last9redux.length; j++) sseries += Integer.toString(last9redux[j]);
		
		for (int i=last9redux.length-3;i<last9redux.length;i++) {
			if (sseries.substring(0, i).contains(Integer.toString(last9redux[i])))
				currentpattern += "O";
			else
				currentpattern += "N";
			
		}
		
		String target = NineDigitSequenceOutcome.getData().get(currentpattern);
    			
		//Collections.sort(list);
		int latestsuccessserial = (successes.size() > 0)?Integer.parseInt(successes.get(0).substring(0, successes.get(0).indexOf("-"))):0;
		int latestfailureserial = (failures.size() > 0)?Integer.parseInt(failures.get(0).substring(0, failures.get(0).indexOf("-"))):0;
		
		rhe.setGameCode(gameCode);
		InclusionExclusionEntity ince = new InclusionExclusionEntity();
		ince.setAlgorithmType(InclusionExclusionEntity.ALGORITHM_TYPE_REDUX_SEQUENCE);
		ince.setAttribute(attribute);
		ince.setGameCode(gameCode);
		ince.setInputDrawDate(rhe.getLastNForAttribute("dateOfDraw", 1, 0));
		ince.setIsInclusionInd("false");
		
		ince.setPercent(Integer.toString((passed*100/samplesize)));;
		
			//ince.setPercent(Integer.toString((passed*100/samplesize)));;
			//ince.setTotalScore(Integer.toString(((lastserial - latestsuccessserial) * ((passed*100/samplesize)))));;
		
		ArrayList<Integer> inarg = new ArrayList();
		inarg.addAll(list);
		ince.setData(inarg);
		
		
		if (latestsuccessserial == lastserial) {
			
			if (((lastserial - latestfailureserial) * (100-(passed*100/samplesize))) > 100) {
				
				ince.setIsInclusionInd((target.equals("N")?"true":"false"));
				ince.setPercent(Integer.toString((100-(passed*100/samplesize))));;
    			ince.setTotalScore(Integer.toString((lastserial - latestfailureserial) * (100-(passed*100/samplesize))));
    			
    			
				System.out.print (attribute + " Target FAIL"  + "[" + (100-(passed*100/samplesize)) + "-" + (lastserial - latestfailureserial) * (100-(passed*100/samplesize)) + "] - Predicted redux : " + target);
				System.out.println (" Current Redux " + (target.equals("N")?"inclusions":"exclusions") + " for " + attribute + " " + list.size() + " " + list.toString() );
			}
			
		} else {
			
			if (((lastserial - latestsuccessserial) * ((passed*100/samplesize))) > 100) {
				
				ince.setIsInclusionInd((target.equals("O")?"true":"false"));
				
				ince.setPercent(Integer.toString((passed*100/samplesize)));;
    			ince.setTotalScore(Integer.toString(((lastserial - latestsuccessserial) * ((passed*100/samplesize)))));;
    			
				System.out.print (attribute + " Target SUCCESS"  + "[" + ((passed*100/samplesize)) + "-" + (lastserial - latestsuccessserial) * ((passed*100/samplesize)) + "] - Predicted redux : " + target);
				System.out.println (" Current Redux " + (target.equals("O")?"inclusions":"exclusions") + " for " + attribute + " " + list.size() + " " + list.toString() );
			}
			 
		}
		
		if (!testMode) ince.addInclusionExclusionResult();
		
    	} catch (Exception e) {
    		System.out.println("DBUTils.testAttributeForSequenceOfRedux: Exception while processing gamecode " + gameCode + " attribute " + attribute );
    	}
    	
	}
	
	@Override
	public String getTableName() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getInsertSQL() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getUpdateSQL() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Collection readAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Collection findRows() {
		// TODO Auto-generated method stub
		return null;
	}

	public boolean isTestMode() {
		return testMode;
	}

	public void setTestMode(boolean testMode) {
		this.testMode = testMode;
	}

}
