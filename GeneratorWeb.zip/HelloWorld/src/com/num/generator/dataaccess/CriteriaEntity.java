package com.num.generator.dataaccess;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collection;

public class CriteriaEntity extends Base {
	
	private String criteriaID;
	private String 	firstFiveSumStart;
	private String 	firstFiveSumEnd;
	private String 	firstFiveSumAvgStart ;
	private String 	firstFiveSumAvgEnd;
	private String 	firstFiveSumPrimeInd;
	private String 	firstFiveSumEvenInd ;
	private String 	firstFiveSumOddInd ;
	private String 	firstFiveSumExcludeBucketList;
	private String 	firstFiveSumIncludeBucketList;
	private String 	match3DiffInd;
	private String 	miss3Diff;
	private String 	match3GapInd;
	private String 	miss3Gap;
	private String 	obsIncludeCount;
	private String 	targetDrawDate;
	private String 	targetGameCode;
	private String 	executeFlag;
	private String 	numberOfPassedCombinations;

	public String getCriteriaID() {
		return criteriaID;
	}

	public void setCriteriaID(String criteriaID) {
		this.criteriaID = criteriaID;
	}

	public String getFirstFiveSumStart() {
		return firstFiveSumStart;
	}

	public void setFirstFiveSumStart(String firstFiveSumStart) {
		this.firstFiveSumStart = firstFiveSumStart;
	}

	public String getFirstFiveSumEnd() {
		return firstFiveSumEnd;
	}

	public void setFirstFiveSumEnd(String firstFiveSumEnd) {
		this.firstFiveSumEnd = firstFiveSumEnd;
	}

	public String getFirstFiveSumAvgStart() {
		return firstFiveSumAvgStart;
	}

	public void setFirstFiveSumAvgStart(String firstFiveSumAvgStart) {
		this.firstFiveSumAvgStart = firstFiveSumAvgStart;
	}

	public String getFirstFiveSumAvgEnd() {
		return firstFiveSumAvgEnd;
	}

	public void setFirstFiveSumAvgEnd(String firstFiveSumAvgEnd) {
		this.firstFiveSumAvgEnd = firstFiveSumAvgEnd;
	}

	public String getFirstFiveSumPrimeInd() {
		return firstFiveSumPrimeInd;
	}

	public void setFirstFiveSumPrimeInd(String firstFiveSumPrimeInd) {
		this.firstFiveSumPrimeInd = firstFiveSumPrimeInd;
	}

	public String getFirstFiveSumEvenInd() {
		return firstFiveSumEvenInd;
	}

	public void setFirstFiveSumEvenInd(String firstFiveSumEvenInd) {
		this.firstFiveSumEvenInd = firstFiveSumEvenInd;
	}

	public String getFirstFiveSumExcludeBucketList() {
		return firstFiveSumExcludeBucketList;
	}

	public void setFirstFiveSumExcludeBucketList(
			String firstFiveSumExcludeBucketList) {
		this.firstFiveSumExcludeBucketList = firstFiveSumExcludeBucketList;
	}

	public String getFirstFiveSumIncludeBucketList() {
		return firstFiveSumIncludeBucketList;
	}

	public void setFirstFiveSumIncludeBucketList(
			String firstFiveSumIncludeBucketList) {
		this.firstFiveSumIncludeBucketList = firstFiveSumIncludeBucketList;
	}

	public String getMatch3DiffInd() {
		return match3DiffInd;
	}

	public void setMatch3DiffInd(String match3DiffInd) {
		this.match3DiffInd = match3DiffInd;
	}

	public String getMiss3Diff() {
		return miss3Diff;
	}

	public void setMiss3Diff(String miss3Diff) {
		this.miss3Diff = miss3Diff;
	}

	public String getMatch3GapInd() {
		return match3GapInd;
	}

	public void setMatch3GapInd(String match3GapInd) {
		this.match3GapInd = match3GapInd;
	}

	public String getMiss3Gap() {
		return miss3Gap;
	}

	public void setMiss3Gap(String miss3Gap) {
		this.miss3Gap = miss3Gap;
	}

	public String getObsIncludeCount() {
		return obsIncludeCount;
	}

	public void setObsIncludeCount(String obsIncludeCount) {
		this.obsIncludeCount = obsIncludeCount;
	}

	public String getTargetDrawDate() {
		return targetDrawDate;
	}

	public void setTargetDrawDate(String targetDrawDate) {
		this.targetDrawDate = targetDrawDate;
	}

	public String getTargetGameCode() {
		return targetGameCode;
	}

	public void setTargetGameCode(String targetGameCode) {
		this.targetGameCode = targetGameCode;
	}

	public String getExecuteFlag() {
		return executeFlag;
	}

	public void setExecuteFlag(String executeFlag) {
		this.executeFlag = executeFlag;
	}

	public String getFirstFiveSumOddInd() {
		return firstFiveSumOddInd;
	}

	public void setFirstFiveSumOddInd(String firstFiveSumOddInd) {
		this.firstFiveSumOddInd = firstFiveSumOddInd;
	}

	public String getNumberOfPassedCombinations() {
		return numberOfPassedCombinations;
	}

	public void setNumberOfPassedCombinations(String numberOfPassedCombinations) {
		this.numberOfPassedCombinations = numberOfPassedCombinations;
	}

	@Override
	public String getTableName() {
		// TODO Auto-generated method stub
		return " criteria ";
	}

	@Override
	public String getInsertSQL() {
		StringBuffer buff = new StringBuffer();
		
		StringBuffer internalBuffer = new StringBuffer();
		
		buff.append("Insert into " + getTableName() + "( ");
		
		
		if (getCriteriaID() != null && Integer.parseInt(getCriteriaID()) > 0)  {
			buff.append("criteriaID,");
			internalBuffer.append("'" + getCriteriaID() + "',");
		}
		
		if (getFirstFiveSumStart() != null)  {
			buff.append("firstFiveSumStart,");
			internalBuffer.append("'" + getFirstFiveSumStart() + "',");
		}
		
		if (getFirstFiveSumEnd() != null)  {
			buff.append("firstFiveSumEnd,");
			internalBuffer.append("'" + getFirstFiveSumEnd() + "',");
		}
		
		
		if (getNumberOfPassedCombinations() != null)  {
			buff.append("numberOfPassedCombinations,");
			internalBuffer.append("'" + getNumberOfPassedCombinations() + "',");
		}
		
		if (getFirstFiveSumAvgStart() != null)  {
			buff.append("firstFiveSumAvgStart,");
			internalBuffer.append("'" + getFirstFiveSumAvgStart() + "',");
		}
		
		if (getFirstFiveSumAvgEnd() != null)  {
			buff.append("firstFiveSumAvgEnd,");
			internalBuffer.append("'" + getFirstFiveSumAvgEnd() + "',");
		}
		
		if (getFirstFiveSumPrimeInd() != null)  {
			buff.append("firstFiveSumPrimeInd,");
			internalBuffer.append("" + (getFirstFiveSumPrimeInd().equalsIgnoreCase("true")?"true":"false") + ",");
		}
		
		if (getFirstFiveSumEvenInd() != null)  {
			buff.append("firstFiveSumEvenInd,");
			internalBuffer.append("" + (getFirstFiveSumEvenInd().equalsIgnoreCase("true")?"true":"false") + ",");
		}
		
		if (getFirstFiveSumOddInd() != null)  {
			buff.append("firstFiveSumOddInd,");
			internalBuffer.append("" + (getFirstFiveSumOddInd().equalsIgnoreCase("true")?"true":"false") + ",");
		} 
		
		if (getFirstFiveSumExcludeBucketList() != null)  {
			buff.append("firstFiveSumExcludeBucketList,");
			internalBuffer.append("'" + getFirstFiveSumExcludeBucketList() + "',");
		}
		
		
		if (getFirstFiveSumIncludeBucketList() != null)  {
			buff.append("firstFiveSumIncludeBucketList,");
			internalBuffer.append("'" + getFirstFiveSumIncludeBucketList() + "',");
		}
		
		if (getMatch3DiffInd() != null)  {
			buff.append("match3DiffInd,");
			internalBuffer.append("" + (getMatch3DiffInd().equalsIgnoreCase("true")?"true":"false") + ",");
		}
		
		if (getMiss3Diff() != null)  {
			buff.append("miss3Diff,");
			internalBuffer.append("'" + getMiss3Diff() + "',");
		}
		
		if (getMatch3GapInd() != null)  {
			buff.append("match3GapInd,");
			internalBuffer.append("" + (getMatch3GapInd().equalsIgnoreCase("true")?"true":"false") + ",");
		}
		
		if (getMiss3Gap() != null)  {
			buff.append("miss3Gap,");
			internalBuffer.append("'" + getMiss3Gap() + "',");
		}
		
		if (getObsIncludeCount() != null)  {
			buff.append("obsIncludeCount,");
			internalBuffer.append("'" + getObsIncludeCount() + "',");
		}
		
		if (getTargetDrawDate() != null)  {
			buff.append("targetDrawDate,");
			internalBuffer.append("'" + getTargetDrawDate() + "',");
		}
		
		if (getTargetGameCode() != null)  {
			buff.append("targetGameCode,");
			internalBuffer.append("'" + getTargetGameCode() + "',");
		}
		
		if (getExecuteFlag() != null)  {
			buff.append("executeFlag,");
			internalBuffer.append("" + (getExecuteFlag().equalsIgnoreCase("true")?"true":"false") + ",");
		}
		
		
		return buff.substring(0,buff.length()-1) + ") values ( "+ internalBuffer.substring(0,internalBuffer.length()-1) + ")" ;
	}

	@Override
	public String getUpdateSQL() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Collection readAll() {
		StringBuffer whereClause = new StringBuffer();
		if (getTargetGameCode() == null || getTargetGameCode() == null) 
			return null;
		
		if (getFirstFiveSumStart() != null)  {
			
			if (whereClause.length() > 0) whereClause.append(" and ");
			whereClause.append("firstFiveSumStart = ");
			whereClause.append("'" + getFirstFiveSumStart() + "' ");
		}
		
		if (getFirstFiveSumEnd() != null)  {
			if (whereClause.length() > 0) whereClause.append(" and ");
			whereClause.append("firstFiveSumEnd = ");
			whereClause.append("'" + getFirstFiveSumEnd() + "' ");
		}
		
		if (getFirstFiveSumAvgStart() != null)  {
			if (whereClause.length() > 0) whereClause.append(" and ");
			whereClause.append("firstFiveSumAvgStart = ");
			whereClause.append("'" + getFirstFiveSumAvgStart() + "' ");
		}
		
		if (getFirstFiveSumAvgEnd() != null)  {
			if (whereClause.length() > 0) whereClause.append(" and ");
			whereClause.append("firstFiveSumAvgEnd = ");
			whereClause.append("'" + getFirstFiveSumAvgEnd() + "' ");
		}
		
		if (getFirstFiveSumPrimeInd() != null)  {
			if (whereClause.length() > 0) whereClause.append(" and ");
			whereClause.append("firstFiveSumPrimeInd = ");
			whereClause.append("'" + getFirstFiveSumPrimeInd() + "' ");
		}
		
		if (getFirstFiveSumEvenInd() != null)  {
			if (whereClause.length() > 0) whereClause.append(" and ");
			whereClause.append("firstFiveSumEvenInd = ");
			whereClause.append("'" + getFirstFiveSumEvenInd() + "' ");
		}
		
		if (getFirstFiveSumOddInd() != null)  {
			if (whereClause.length() > 0) whereClause.append(" and ");
			whereClause.append("firstFiveSumOddInd = ");
			whereClause.append("'" + getFirstFiveSumOddInd() + "' ");
		}
		
		
		if (getFirstFiveSumExcludeBucketList() != null)  {
			if (whereClause.length() > 0) whereClause.append(" and ");
			whereClause.append("firstFiveSumExcludeBucketList = ");
			whereClause.append("'" + getFirstFiveSumExcludeBucketList() + "' ");
		}
		
		
		if (getFirstFiveSumIncludeBucketList() != null)  {
			if (whereClause.length() > 0) whereClause.append(" and ");
			whereClause.append("firstFiveSumIncludeBucketList = ");
			whereClause.append("'" + getFirstFiveSumIncludeBucketList() + "' ");
		}
		
		if (getMatch3DiffInd() != null)  {
			if (whereClause.length() > 0) whereClause.append(" and ");
			whereClause.append("match3DiffInd = ");
			whereClause.append("'" + getMatch3DiffInd() + "' ");
		}
		
		if (getMiss3Diff() != null)  {
			if (whereClause.length() > 0) whereClause.append(" and ");
			whereClause.append("miss3Diff = ");
			whereClause.append("'" + getMiss3Diff() + "' ");
		}
		
		if (getMatch3GapInd() != null)  {
			if (whereClause.length() > 0) whereClause.append(" and ");
			whereClause.append("match3GapInd = ");
			whereClause.append("'" + getMatch3GapInd() + "' ");
		}
		
		if (getMiss3Gap() != null)  {
			if (whereClause.length() > 0) whereClause.append(" and ");
			whereClause.append("miss3Gap = ");
			whereClause.append("'" + getMiss3Gap() + "' ");
		}
		
		
		if (getObsIncludeCount() != null)  {
			if (whereClause.length() > 0) whereClause.append(" and ");
			whereClause.append("obsIncludeCount = ");
			whereClause.append("'" + getObsIncludeCount() + "' ");
		}
		
		if (getTargetDrawDate() != null)  {
			if (whereClause.length() > 0) whereClause.append(" and ");
			whereClause.append("targetDrawDate = ");
			whereClause.append("'" + getTargetDrawDate() + "' ");
		}
		
		if (getExecuteFlag() != null)  {
			if (whereClause.length() > 0) whereClause.append(" and ");
			whereClause.append("executeFlag = ");
			whereClause.append("'" + getExecuteFlag() + "' ");
		}
		
		
		
		if (getNumberOfPassedCombinations() != null)  {
			if (whereClause.length() > 0) whereClause.append(" and ");
			whereClause.append("numberOfPassedCombinations = ");
			whereClause.append("'" + getNumberOfPassedCombinations() + "' ");
		}
		
		
		Collection out = new ArrayList();
		Connection conn = getConnection();
		
		Statement stmt;
		try {
			stmt = conn.createStatement();
			  
		  	ResultSet rs = stmt.executeQuery("Select * from " + getTableName() + " where targetGameCode = " + getTargetGameCode() + " and " + whereClause.toString());
		  	
		  	while (rs.next()) {
		  		CriteriaEntity gte = new CriteriaEntity();
		  		gte.setCriteriaID(rs.getString("criteriaID"));
		  		gte.setFirstFiveSumStart(rs.getString("firstFiveSumStart"));
		  		gte.setFirstFiveSumEnd(rs.getString("firstFiveSumEnd"));
		  		gte.setFirstFiveSumAvgStart(rs.getString("firstFiveSumAvgStart"));
		  		gte.setFirstFiveSumAvgEnd(rs.getString("firstFiveSumAvgEnd"));
		  		
		  		
		  		gte.setFirstFiveSumPrimeInd(rs.getString("firstFiveSumPrimeInd"));
		  		gte.setFirstFiveSumEvenInd(rs.getString("firstFiveSumEvenInd"));
		  		gte.setFirstFiveSumOddInd(rs.getString("firstFiveSumOddInd"));
		  		gte.setFirstFiveSumExcludeBucketList(rs.getString("firstFiveSumExcludeBucketList"));
		  		gte.setFirstFiveSumIncludeBucketList(rs.getString("firstFiveSumIncludeBucketList"));
		  		gte.setMatch3DiffInd(rs.getString("match3DiffInd"));
		  		
		  		
		  		gte.setMiss3Diff(rs.getString("miss3Diff"));
		  		
		  		gte.setMatch3GapInd(rs.getString("match3GapInd"));
		  		
		  		
		  		gte.setMiss3Gap(rs.getString("miss3Gap"));
		  		
		  		gte.setObsIncludeCount(rs.getString("obsIncludeCount"));
		  		gte.setTargetDrawDate(rs.getString("targetDrawDate"));
		  		gte.setTargetGameCode(rs.getString("targetGameCode"));
		  		gte.setExecuteFlag(rs.getString("executeFlag"));
		  		
		  		gte.setNumberOfPassedCombinations(rs.getString("numberOfPassedCombinations"));
		  		
		  		out.add(gte);
		  	}
	  	
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				if (conn != null)
					conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return out;
	}

	@Override
	public Collection findRows() {
		// TODO Auto-generated method stub
		return null;
	}
	
	public static void main(String[] args) {
		CriteriaEntity ce = new CriteriaEntity();
		
		ce.setFirstFiveSumAvgStart("200");
		
		System.out.println(ce.createWithAutoIncrement());
	}

	public void clearCriteria (String gameCode, String date) {
		
		String deleteresultSQL = "delete from criteria_result where criteriaID in (select criteriaID from criteria where targetDrawDate = '" + 
								date  + "' and targetGameCode = " + gameCode + ")";
		
		String deletecriteriaSQL = "delete from criteria where targetDrawDate = '" + 
								date  + "' and targetGameCode = " + gameCode;
		
		String optimizeCriteriaResult = "optimize table criteria_result";
		/*String optimizemissingdigits = "optimize table missing_digits";
		String optimizelastNresults = "optimize table results_within_lastN_history";
		String optimizederivedresults = "optimize table derived_result_history";
		String optimizeresults = "optimize table result_history";*/
		
		Connection conn = getConnection();
		
		Statement stmt;
		try {
			stmt = conn.createStatement();
			
			stmt.executeUpdate(deleteresultSQL);
			stmt.executeUpdate(deletecriteriaSQL);
			
			//stmt.executeUpdate(truncateCriteriaResult);
			//stmt.executeUpdate(optimizeCriteriaResult);
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				if (conn != null)
					conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
	}
}
