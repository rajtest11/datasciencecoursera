package com.num.generator.dataaccess;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.StringTokenizer;

public class InclusionExclusionEntity extends Base {
	private String rowID;
	private String inputDrawDate;
	private String 	gameCode;
	private String 	attribute;
	private String  algorithmType;
	private String 	isInclusionInd; // 0 - false   1 - true
	private String 	percent;
	private String 	totalScore;
	
	private String 	firstPerformance;
	private String 	secondPerformance;
	private String 	thirdPerformance;
	
	public final static String ALGORITHM_TYPE_INCLUSIVE = "INCLUSION_BY_FREQ_SKIP";
	public final static String ALGORITHM_TYPE_FFSUM_BUCKET = "BUCKET_DEPENDENT_SUM_INCLUSION_BY_FREQ_SKIP";
	public final static String ALGORITHM_TYPE_FFSUM_BUCKET_INCLUDE = "BUCKET_DEPENDENT_SUM_INCLUSION_BY_PERCENTILE";
	public final static String ALGORITHM_TYPE_EXCLUSIVE = "EXCLUSION_BY_SAFE_PERCENTILE";
	public final static String ALGORITHM_TYPE_SEQUENCE = "SEQUENCE_BY_HISTORY";
	public final static String ALGORITHM_TYPE_EVENODD = "EVENODD_BY_HISTORY";
	public final static String ALGORITHM_TYPE_REGRESSION = "REGRESSION_BY_MA";
	public final static String ALGORITHM_TYPE_REDUX_SEQUENCE = "REDUX_SEQUENCE";
	public final static String ALGORITHM_TYPE_DIST_FREQ_SAME_DIFF = "DIST_FREQ_SAME_DIFF_EVEN_ODD";
	public final static String ALGORITHM_TYPE_ASC_DESC_PATTERNS = "ASC_DESC_BY_PATTERNS";
	public final static String ALGORITHM_TYPE_EVEN_ODD_PATTERNS = "EVEN_ODD_BY_PATTERNS";
	public final static String ALGORITHM_TYPE_PRIME_NONPRIME_PATTERNS = "PRIME_NONPRIME_BY_PATTERNS";

	private ArrayList<Integer> data = new ArrayList<Integer>();;
	
	public String getRowID() {
		return rowID;
	}

	public void setRowID(String rowID) {
		this.rowID = rowID;
	}
	
	public String getInputDrawDate() {
		return inputDrawDate;
	}

	public void setInputDrawDate(String inputDrawDate) {
		this.inputDrawDate = inputDrawDate;
	}

	public String getGameCode() {
		return gameCode;
	}

	public void setGameCode(String gameCode) {
		this.gameCode = gameCode;
	}

	public String getAttribute() {
		return attribute;
	}

	public void setAttribute(String attribute) {
		this.attribute = attribute;
	}

	public String getAlgorithmType() {
		return algorithmType;
	}

	public void setAlgorithmType(String algorithmType) {
		this.algorithmType = algorithmType;
	}

	public String getIsInclusionInd() {
		return isInclusionInd;
	}

	public void setIsInclusionInd(String isInclusionInd) {
		this.isInclusionInd = isInclusionInd;
	}

	public String getPercent() {
		return percent;
	}

	public void setPercent(String percent) {
		this.percent = percent;
	}

	public String getTotalScore() {
		return totalScore;
	}

	public void setTotalScore(String totalScore) {
		this.totalScore = totalScore;
	}

	public ArrayList<Integer> getData() {
		return data;
	}

	public void setData(ArrayList<Integer> data) {
		this.data = data;
	}
	
	public String getFirstPerformance() {
		return firstPerformance;
	}

	public void setFirstPerformance(String firstPerformance) {
		this.firstPerformance = firstPerformance;
	}

	public String getSecondPerformance() {
		return secondPerformance;
	}

	public void setSecondPerformance(String secondPerformance) {
		this.secondPerformance = secondPerformance;
	}

	public String getThirdPerformance() {
		return thirdPerformance;
	}

	public void setThirdPerformance(String thirdPerformance) {
		this.thirdPerformance = thirdPerformance;
	}

	public static void main(String[] args) {

		InclusionExclusionEntity ie = new InclusionExclusionEntity();
		
		ie.setGameCode("1");
		ie.setAttribute("firstValue");
		
		System.out.println(ie.findRows());
	}

	@Override
	public String getTableName() {
		return "inc_exc";
		
	}

	@Override
	public String getInsertSQL() {
		StringBuffer buff = new StringBuffer();
		
		StringBuffer internalBuffer = new StringBuffer();
		
		buff.append("Insert into " + getTableName() + "( ");
		
		if (getGameCode() != null)  {
			buff.append("gameCode,");
			internalBuffer.append("'" + getGameCode() + "',");
		}
		
		if (getAlgorithmType() != null 
				//&& (getAlgorithmType().equals(ALGORITHM_TYPE_EXCLUSIVE) || getAlgorithmType().equals(ALGORITHM_TYPE_INCLUSIVE))
				)  {
			buff.append("algorithmType,");
			internalBuffer.append("'" + getAlgorithmType() + "',");
		} else {
			return null;
		}
		
		if (getInputDrawDate() != null)  {
			buff.append("inputDrawDate,");
			internalBuffer.append("'" + getInputDrawDate() + "',");
		}
		
		if (getAttribute() != null)  {
			buff.append("attribute,");
			internalBuffer.append("'" + getAttribute() + "',");
		}
		
		if (getIsInclusionInd() != null)  {
			buff.append("isInclusionInd,");
			internalBuffer.append("" + getIsInclusionInd() + ",");
		}
		
		if (getPercent() != null)  {
			buff.append("percent,");
			internalBuffer.append("'" + getPercent() + "',");
		}
		
		if (getTotalScore() != null)  {
			buff.append("totalScore,");
			internalBuffer.append("'" + getTotalScore() + "',");
		}
		
		if (getSecondPerformance() != null)  {
			buff.append("secondPerformance,");
			internalBuffer.append("'" + getSecondPerformance() + "',");
		}
		
		if (getThirdPerformance() != null)  {
			buff.append("thirdPerformance,");
			internalBuffer.append("'" + getThirdPerformance() + "',");
		}
		
		if (getFirstPerformance() != null)  {
			buff.append("firstPerformance,");
			internalBuffer.append("'" + getFirstPerformance() + "',");
		}
		
		return buff.substring(0,buff.length()-1) + ") values ( "+ internalBuffer.substring(0,internalBuffer.length()-1) + ")" ;
	}

	@Override
	public String getUpdateSQL() {
		StringBuffer buff = new StringBuffer();
		StringBuffer whereBuff = new StringBuffer();
		
		if (getRowID() == null) {
			System.out.println("InclusionExclusionEntity: update attempted without rowID.");
			return null;
		}
		buff.append("Update " + getTableName() + " SET ");
			
		if (getRowID() != null)  {
			whereBuff.append(" where rowID = '" + getRowID() + "' ");
			
		}
		
		
		if (getFirstPerformance() != null)  {
			buff.append(" firstPerformance = " + getFirstPerformance() + ",");
		}
		
		if (getSecondPerformance() != null)  {
			buff.append(" secondPerformance = " + getSecondPerformance() + ",");
		}
		
		
		if (getThirdPerformance() != null)  {
			buff.append(" thirdPerformance = " + getThirdPerformance() + ",");
		}
		
		return buff.toString().substring(0,buff.length()-1) + whereBuff.toString();
	}

	@Override
	public Collection readAll() {
		
		return null;
	}

	@Override
	public Collection<InclusionExclusionEntity> findRows() {
		Collection<InclusionExclusionEntity> out = null;
		
		StringBuffer buff = new StringBuffer();
		if (getGameCode() == null) {
			System.out.println("InclusionExclusionEntity.findRows: Set gameCode first.");
			return out;
		}
		
		if (getInputDrawDate() == null && getAttribute() == null) {
			System.out.println("InclusionExclusionEntity.findRows: Both, inputDrawDate and attribute can not be null.");
			return out;
		}
		
		if (getInputDrawDate() != null)  {
			buff.append(" and inputDrawDate = ");
			buff.append("'" + getInputDrawDate() + "'");
		}
		
		if (getAttribute() != null)  {
			buff.append(" and attribute = ");
			buff.append("'" + getAttribute() + "' ");
		}
		
		if (getAlgorithmType() != null)  {
			buff.append(" and algorithmType = ");
			buff.append("'" + getAlgorithmType() + "' ");
		}
		
		String sql = "select a.*, group_concat(distinct b.rowValue order by b.rowValue desc separator ', ') as valueList from " + 
						getTableName() + " a join inc_exc_data b on a.rowID = b.rowID "
								+ " where gameCode = " + getGameCode() + buff.toString()  + " group by a.rowID order by rowId desc limit 100";
		
		Connection conn = null;
		try {
			
			conn = getConnection();
			Statement stmt = conn.createStatement();
			
			ResultSet rs = stmt.executeQuery(sql);
			out = new ArrayList<InclusionExclusionEntity>();
			
			while (rs.next()) {
				InclusionExclusionEntity ent = new InclusionExclusionEntity();
				
				String dataStr = rs.getString("valueList");
				
				StringTokenizer datatok = new StringTokenizer(dataStr, ",");
				ArrayList<Integer> datalist =  new ArrayList<Integer>();
				while (datatok.hasMoreTokens()) {
					String thistoken = datatok.nextToken().trim();
					if (thistoken.length() > 0)
						datalist.add(Integer.parseInt(thistoken));
				}
				
				ent.setAlgorithmType(rs.getString("algorithmType"));
				ent.setAttribute(rs.getString("attribute"));
				ent.setData(datalist);
				ent.setRowID(rs.getString("rowID"));
				ent.setFirstPerformance(rs.getString("firstPerformance"));
				ent.setGameCode(rs.getString("gameCode"));
				ent.setInputDrawDate(rs.getString("inputDrawDate"));
				ent.setIsInclusionInd(rs.getString("isInclusionInd"));
				ent.setPercent(rs.getString("percent"));
				ent.setSecondPerformance(rs.getString("secondPerformance"));
				ent.setThirdPerformance(rs.getString("thirdPerformance"));
				ent.setTotalScore(rs.getString("totalScore"));
				
				out.add(ent);
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			if (conn != null)
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		
		return out;
	}
	
	public int addInclusionExclusionResult() {
		int out = -10;
		InclusionExclusionEntity iee = this;
		
		if (this.getGameCode() == null) {
			System.out.println("Null GameCode ");
			return -1;
		}
		
		if (this.getInputDrawDate() == null) {
			System.out.println("Null inputDrawDate ");
			return -2;
		}
		
		clearSameRowsForAnAttributeAndAlgorithm(gameCode, attribute, algorithmType, inputDrawDate);
		out = this.createWithAutoIncrement();
		
		if (out < 0) {
			System.out.println("Could not create inc_exc entry ");
			return -3;
		} else { // now insert data
			if (data.size() > 0) {
				StringBuffer buff = new StringBuffer();
				
				StringBuffer internalBuffer = new StringBuffer();
				
				buff.append("Insert into inc_exc_data ( ");
				
				Iterator<Integer> it = data.iterator();
				
				int counter = 0;
				
				while(it.hasNext()) {
					
					int thisValue =  it.next();
							
						if (counter == 0) {
					
							buff.append("rowID,");
							internalBuffer.append("'" + out + "',");
						
							buff.append("rowValue,");
							internalBuffer.append("'" + thisValue + "',");
							
							internalBuffer.deleteCharAt(internalBuffer.length()-1);
							internalBuffer.append(")");
							
						} else {
							internalBuffer.append(",(");
							
							internalBuffer.append("'" + out + "',");
							
							internalBuffer.append("'" + thisValue + "',");
													
							internalBuffer.deleteCharAt(internalBuffer.length()-1);
							internalBuffer.append(")");
						}
					
						counter++;
				}
				
				String dataInsertSQL = buff.substring(0,buff.length()-1) + ") values ( "+ internalBuffer.toString() ;
				Connection conn = getConnection();
				Statement stmt;
				try {
					stmt = conn.createStatement();
					out = stmt.executeUpdate(dataInsertSQL);
					
					if (conn != null) conn.close();
					
				} catch (SQLException e) {
					System.out.println("SQL Exception while inserting a row: SQLSTATE: " + e.getSQLState() + " CAUSE: " + e.getCause());
					//System.out.println(getInsertSQL());
				}
			}
		}
		
		return out;
	}
	
	public int getLastPassingPercent () {
		if (this.getGameCode() == null) {
			System.out.println("Null GameCode ");
			return -1;
		}
		
		if (this.getAttribute() == null) {
			System.out.println("Null Attribute ");
			return -2;
		}
		
		if (this.getAlgorithmType() == null) {
			System.out.println("Null AlgorithmType ");
			return -3;
		}
		
		String sql = "select * from inc_exc where gameCode = " + this.getGameCode() +
				" and attribute = '" + this.getAttribute() + "' and algorithmType = '" + this.getAlgorithmType() + "' " +
				" and percent > 0  order by inputDrawDate desc LIMIT 1";
		
		Connection conn = getConnection();
		
		Statement stmt;
		try {
			stmt = conn.createStatement();
			  
		  	ResultSet rs = stmt.executeQuery(sql);
		  	
		  	if (rs.next()) {
		  		if (rs.getBoolean("isInclusionInd") == true)
		  			return rs.getInt("percent");
		  		else
		  			return 100 - rs.getInt("percent");
		  	}
		  		
		  	else
		  		return 0;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				if (conn != null)
					conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		 return 0;
		 
	}
	
	public List<InclusionExclusionEntity> getLatestPredictionsForAttribute (int countofpredictions) {
		if (this.getGameCode() == null) {
			System.out.println("Null GameCode ");
			return null;
		}
		
		if (this.getAttribute() == null) {
			System.out.println("Null Attribute ");
			return null;
		}
		
		String excludeFirstFiveSumClause = "";
		
		if (this.getAttribute().equals("first")) {
			excludeFirstFiveSumClause = " and attribute not like 'firstFive%' and attribute not like '%FreqShadow' ";
		} else {
			excludeFirstFiveSumClause = " and attribute not like '%FreqShadow' ";
		}
		
		String limitclause = "";
		
		if (countofpredictions > 0)
			limitclause = " LIMIT " + countofpredictions;
		
		List<InclusionExclusionEntity> out = new ArrayList<InclusionExclusionEntity>();
		
		String sql = "select * from inc_exc where gameCode = " + this.getGameCode() +
				" and attribute like '" + this.getAttribute() + "%' " +  excludeFirstFiveSumClause +
				" and abs(totalScore) > 100  order by inputDrawDate desc, abs(totalScore) desc " + limitclause;
		
		Connection conn = getConnection();
		
		Statement stmt;
		try {
			stmt = conn.createStatement();
			  
			//System.out.println(sql);
		  	ResultSet rs = stmt.executeQuery(sql);
		  	
		  	while (rs.next()) {
		  		InclusionExclusionEntity thisent = new InclusionExclusionEntity();
		  		thisent.setAlgorithmType(rs.getString("algorithmType"));
		  		thisent.setTotalScore(rs.getString("totalScore"));
		  		thisent.setIsInclusionInd(Boolean.toString(rs.getBoolean("isInclusionInd")));
		  		thisent.setAttribute(rs.getString("attribute"));
		  		thisent.setRowID(rs.getString("rowID"));
		  		thisent.setInputDrawDate(rs.getString("inputDrawDate"));
		  		thisent.setGameCode(rs.getString("gameCode"));
		  		thisent.setData(getDataFromRowID(thisent.getRowID()));
		  		
		  		if (thisent.getData() != null && thisent.getData().size() > 0 )
		  			out.add(thisent);
		  	}
		  		
		  	
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				if (conn != null)
					conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		 return out;
		 
	}
	
	public List<InclusionExclusionEntity> getPredictionsForAttributeAsOnDate (int countofpredictions, String inputDrawDate) {
		if (this.getGameCode() == null) {
			System.out.println("Null GameCode ");
			return null;
		}
		
		if (this.getAttribute() == null) {
			System.out.println("Null Attribute ");
			return null;
		}
		
		String excludeFirstFiveSumClause = "";
		
		String limitclause = "";
				
		if (countofpredictions > 0)
			limitclause = " LIMIT " + countofpredictions;
		
		if (this.getAttribute().equals("first")) {
			excludeFirstFiveSumClause = " and attribute not like 'firstFive%' and attribute not like '%FreqShadow' ";
		} else {
			excludeFirstFiveSumClause = " and attribute not like '%FreqShadow' ";
		}
		
		List<InclusionExclusionEntity> out = new ArrayList<InclusionExclusionEntity>();
		
		String sql = "select * from inc_exc where gameCode = " + this.getGameCode() +
				" and inputDrawDate = '" + inputDrawDate + "' " +
				" and attribute like '" + this.getAttribute() + "%' " +  excludeFirstFiveSumClause +
				" and abs(totalScore) > 100  order by inputDrawDate desc, abs(totalScore) desc " + limitclause;
		
		Connection conn = getConnection();
		
		Statement stmt;
		try {
			stmt = conn.createStatement();
			  
		  	ResultSet rs = stmt.executeQuery(sql);
		  	
		  	while (rs.next()) {
		  		InclusionExclusionEntity thisent = new InclusionExclusionEntity();
		  		thisent.setAlgorithmType(rs.getString("algorithmType"));
		  		thisent.setTotalScore(rs.getString("totalScore"));
		  		thisent.setIsInclusionInd(Boolean.toString(rs.getBoolean("isInclusionInd")));
		  		thisent.setAttribute(rs.getString("attribute"));
		  		thisent.setRowID(rs.getString("rowID"));
		  		thisent.setInputDrawDate(rs.getString("inputDrawDate"));
		  		thisent.setGameCode(rs.getString("gameCode"));
		  		thisent.setData(getDataFromRowID(thisent.getRowID()));
		  		
		  		if (thisent.getData() != null && thisent.getData().size() > 0 )
		  			out.add(thisent);
		  	}
		  		
		  	
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				if (conn != null)
					conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		 return out;
		 
	}
	
	private ArrayList<Integer> getDataFromRowID(String rowID2) {
		ArrayList<Integer> out = new ArrayList<Integer>();
		
		String sql = "select * from inc_exc_data where rowID = " + rowID2;
		
		Connection conn = getConnection();
		
		Statement stmt;
		try {
			stmt = conn.createStatement();
			  
		  	ResultSet rs = stmt.executeQuery(sql);
		  	
		  	while (rs.next()) {
		  		
		  		out.add(rs.getInt("rowValue"));
		  	}
		  		
		  	
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				if (conn != null)
					conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		 return out;
		
	}

	public int clearOldRows(int allowdays, String gameCode) {
		int out = 0;
		Connection conn = null;
		try {
			
			conn = getConnection();
			Statement stmt = conn.createStatement();
		
			int dataInt = stmt.executeUpdate("delete from inc_exc_data where rowID in (" + 
							"select rowID from inc_exc where datediff(curdate(), inputDrawDate) > " + allowdays + " and gameCode = " + gameCode + ")");
			
			if (dataInt > 0) {
				out = stmt.executeUpdate("delete from inc_exc where datediff(curdate(), inputDrawDate) > " + allowdays + " and gameCode = " + gameCode );
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			if (conn != null)
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		
		System.out.println("InclusionExclusionEntity:clearOldRows -- Removed " + out + " rows since they are more than " + allowdays + " old.");
		return out;
	}
	
	public int clearSameRowsForAnAttributeAndAlgorithm( String gameCode, String attribute, String algorithm, String inputdrawdate) {
		int out = 0;
		Connection conn = null;
		try {
			
			conn = getConnection();
			Statement stmt = conn.createStatement();
		
			int dataInt = stmt.executeUpdate("delete from inc_exc_data where rowID in (" + 
							"select rowID from inc_exc where inputDrawDate= '" + inputdrawdate + "' and gameCode = " + gameCode + " and algorithmType ='" + algorithm + "' and attribute ='" + attribute + "')");
			
			if (dataInt > 0) {
				out = stmt.executeUpdate("delete from inc_exc where inputDrawDate= '" + inputdrawdate + "' and gameCode = " + gameCode + " and algorithmType ='" + algorithm + "' and attribute ='" + attribute + "'");
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			if (conn != null)
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		if (out > 0)
			System.out.println("InclusionExclusionEntity:clearSameRowsForAnAttributeAndAlgorithm -- Removed " + out + " rows for " + attribute + " , " + algorithm + " since they are duplicates.");
		return out;
	}


}
