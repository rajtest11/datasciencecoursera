package com.num.generator.dataaccess;

public final class ConnectionParams {
	private static String databaseURL = "jdbc:mysql://localhost/mysql?user=root&password=priyanka";
	private static String user = "root";
	private static String password = "priyanka";
	
	public static String getDatabaseURL() {
		return databaseURL;
	}
	public static String getUser() {
		return user;
	}
	public static String getPassword() {
		return password;
	}
	
}
