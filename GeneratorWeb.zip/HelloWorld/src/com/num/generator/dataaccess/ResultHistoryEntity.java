package com.num.generator.dataaccess;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Enumeration;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Set;
import java.util.StringTokenizer;
import java.util.TreeSet;

import com.num.generator.Factors;
import com.num.generator.Numbers;
import com.rj.lott.Result;

public class ResultHistoryEntity extends Base {

	private String resultID = null;
	
	private static Hashtable<Integer,HashSet<String>> diffsForGame = null;
	private static Hashtable<Integer,HashSet<String>> gapsForGame = null;
	
	private static ArrayList reduxesForGame = null;
	private static ArrayList VDiffsForGame = null;
	private static ArrayList unlikelyFreqShadowReduxesForGame = null; // FreqShadow is the minimum distance of each frequency from the all last frequencies
	private static ArrayList freqReduxesForGame = null;
	private static ArrayList digitDiffsForGame = null;
	private static Hashtable<String,Hashtable<Integer,Integer>> attValuesForSeq = null;
	private static int maxSerialForGame = 0;
	private static Hashtable<String,Hashtable<Integer,Integer>> attValuesForRegression = null;
	
	
	public static ArrayList getFreqReduxesForGame() {
		return freqReduxesForGame;
	}

	public static void setFreqReduxesForGame(ArrayList freqReduxesForGame) {
		ResultHistoryEntity.freqReduxesForGame = freqReduxesForGame;
	}

	public static Hashtable<Integer, HashSet<String>> getGapsForGame() {
		return gapsForGame;
	}

	public static void setGapsForGame(Hashtable<Integer, HashSet<String>> gapsForGame) {
		ResultHistoryEntity.gapsForGame = gapsForGame;
	}

	
	public static Hashtable<Integer,HashSet<String>> getDiffsForGame() {
		return diffsForGame;
	}

	public static void setDiffsForGame(Hashtable<Integer,HashSet<String>> diffsForGame) {
		ResultHistoryEntity.diffsForGame = diffsForGame;
	}
	
	public String getResultID() {
		return resultID;
	}

	public void setResultID(String resultID) {
		this.resultID = resultID;
	}

	public String getGameCode() {
		return gameCode;
	}

	public void setGameCode(String gameCode) {
		this.gameCode = gameCode;
	}

	public String getSerialNumber() {
		return serialNumber;
	}

	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}

	public String getDayOfTheWeek() {
		return dayOfTheWeek;
	}

	public void setDayOfTheWeek(String dayOfTheWeek) {
		this.dayOfTheWeek = dayOfTheWeek;
	}

	public String getFirstValue() {
		return firstValue;
	}

	public void setFirstValue(String firstValue) {
		this.firstValue = firstValue;
	}

	public String getSecondValue() {
		return secondValue;
	}

	public void setSecondValue(String secondValue) {
		this.secondValue = secondValue;
	}

	public String getThirdValue() {
		return thirdValue;
	}

	public void setThirdValue(String thirdValue) {
		this.thirdValue = thirdValue;
	}

	public String getFourthValue() {
		return fourthValue;
	}

	public void setFourthValue(String fourthValue) {
		this.fourthValue = fourthValue;
	}

	public String getFifthValue() {
		return fifthValue;
	}

	public void setFifthValue(String fifthValue) {
		this.fifthValue = fifthValue;
	}

	public String getMegaValue() {
		return megaValue;
	}

	public void setMegaValue(String megaValue) {
		this.megaValue = megaValue;
	}

	private String gameCode = null;
	private String serialNumber = null;
	private String dateOfDraw = null;
	private String dayOfTheWeek = null;
	private String firstValue = null;
	private String secondValue = null;
	private String  thirdValue = null;
	private String fourthValue = null;
	private String fifthValue = null;
	private String  megaValue = null;
    
    public static void main(String[] args) {
    	ResultHistoryEntity rhe = new ResultHistoryEntity();
    	
    	//rhe.insertResultsWithinLastNHistory("1");
    	
    	rhe.updateMaxFactorForDerivedRecords("2","982");
    	
    	/*ArrayList<String> failures = new ArrayList<String>();
    	ArrayList<String> successes = new ArrayList<String>();
    	int lastserial = 0;
    	String gameCode = "2";
    	int passed = 0;
    	int samplesize = 300;
    	String attribute = "firstFiveSum";
    	
    	int percentilecutoff = 25;
    	int historyspan = 50;
    	
    	if (attribute.equals("firstFiveSum")) {
    		percentilecutoff = 25;
    		historyspan = 50;
    	}
    	
    	if (lastserial == 0)
    		lastserial = Integer.parseInt(rhe.getValueForField("serialNumber", gameCode, 0));
    	
    	for (int i=0; i<samplesize; i++) {
    		
    		String value = rhe.getValueForField(attribute, gameCode, (lastserial-i));
    		
    		if (value == null) value = "0";
    		
    		Set<Integer> list = new TreeSet<Integer>();
    		
    		String excl = rhe.getExclusionsForField(attribute, gameCode,  (lastserial-i-1), percentilecutoff, historyspan);
    		StringTokenizer excltok = new StringTokenizer(excl,",");
    		
    		while (excltok.hasMoreTokens()) {
    			list.add(Integer.parseInt(excltok.nextToken()));
    		}
    		
    		if (attribute.equals("firstFiveSum")) {
	    		ArrayList<Integer> excl2 = rhe.getFirstFiveSumExcludesBasedOnMultiplesHistory(gameCode, (lastserial-i-1), historyspan);
	    		
	    		Iterator<Integer> exclIt = excl2.iterator();
	    		
	    		while (exclIt.hasNext()) {
	    			list.add(exclIt.next());
	    		}
    		}
    		
    		if (list.size() > 0 && !list.contains(Integer.parseInt(value))) {
    			passed++;
    			successes.add((lastserial-i)+"-"+rhe.getValueForField(attribute, gameCode, (lastserial-i-1)));
    		} else 
    			failures.add((lastserial-i)+"-"+rhe.getValueForField(attribute, gameCode, (lastserial-i-1)));
    			
    		
    		if (i == 0) {
    			System.out.println("Exclusions : " + + list.size() +"["  + excl + "] next value: " + value + " --- " + ((list.size() > 0 && !list.contains(Integer.parseInt(value)))?" passed ":" failed "));
    		}
    		
    	}
    	
    	System.out.println("Passed " + (passed*100/samplesize) + " pc " + successes.toString());
    	System.out.println (" Failed serials " + failures.toString());
    	
    	Set<Integer> list = new TreeSet<Integer>();
    	
    	String excl = rhe.getExclusionsForField(attribute, gameCode,  0, percentilecutoff, historyspan);
    	
    	StringTokenizer excltok = new StringTokenizer(excl,",");
    	
		while (excltok.hasMoreTokens()) {
			String tem =  excltok.nextToken();
			if (!list.contains(Integer.parseInt(tem)))
				list.add(Integer.parseInt(tem));
		}
    	
		if (attribute.equals("firstFiveSum")) {
	    	ArrayList<Integer> excl2 = rhe.getFirstFiveSumExcludesBasedOnMultiplesHistory(gameCode, 0, historyspan);
			
			Iterator<Integer> exclIt = excl2.iterator();
			
			while (exclIt.hasNext()) {
				list.add(exclIt.next());
			}
		}
		
		//Collections.sort(list);
		
    	
    	System.out.println (" Current exclusions for " + attribute + " " + list.size() + " " + list.toString() );*/
    }
    
	public String getTableName() {
		// TODO Auto-generated method stub
		return " result_history ";
	}
	
	public String toString() {
        return "GameCode.:" + this.gameCode + ",, "
                + "SerialNumber.:" + this.serialNumber + ",, " 
        		+ "[" + this.firstValue + ", " 
        		+  this.secondValue + ", " 
        		+  this.thirdValue + ", " 
        		+  this.fourthValue + ", " 
        		+  this.fifthValue + ",, " 
                +  this.megaValue + "]";
    }

	@Override
	public String getInsertSQL() {
		StringBuffer buff = new StringBuffer();
		
		StringBuffer internalBuffer = new StringBuffer();
		
		buff.append("Insert into " + getTableName() + "( ");
		
		if (getGameCode() != null)  {
			buff.append("gameCode,");
			internalBuffer.append("'" + getGameCode() + "',");
		}
		
		if (getSerialNumber() != null)  {
			buff.append("serialNumber,");
			internalBuffer.append("'" + getSerialNumber() + "',");
		}
		
		if (getDayOfTheWeek() != null)  {
			buff.append("dayOfTheWeek,");
			internalBuffer.append("'" + getDayOfTheWeek() + "',");
		}
		
		if (getFirstValue() != null)  {
			buff.append("firstValue,");
			internalBuffer.append("'" + getFirstValue() + "',");
		}
		
		if (getSecondValue() != null)  {
			buff.append("secondValue,");
			internalBuffer.append("'" + getSecondValue() + "',");
		}
		
		if (getThirdValue() != null)  {
			buff.append("thirdValue,");
			internalBuffer.append("'" + getThirdValue() + "',");
		}
		
		if (getFourthValue() != null)  {
			buff.append("fourthValue,");
			internalBuffer.append("'" + getFourthValue() + "',");
		}
		
		if (getFifthValue() != null)  {
			buff.append("fifthValue,");
			internalBuffer.append("'" + getFifthValue() + "',");
		}
		
		if (getMegaValue() != null)  {
			buff.append("megaValue,");
			internalBuffer.append("'" + getMegaValue() + "',");
		}
		
		if (getDateOfDraw() != null)  {
			buff.append("dateOfDraw,");
			internalBuffer.append("'" + getDateOfDraw() + "',");
		}
		
		
		return buff.substring(0,buff.length()-1) + ") values ( "+ internalBuffer.substring(0,internalBuffer.length()-1) + ")" ;
	}

	@Override
	public Collection readAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Collection<ResultHistoryEntity> findRows() {
		ArrayList<ResultHistoryEntity> out = new ArrayList<ResultHistoryEntity>();
		StringBuffer buff = new StringBuffer();
		
		StringBuffer internalBuffer = new StringBuffer();
		
		buff.append("select * from jointView where ");
		
		if (getGameCode() != null)  {
			internalBuffer.append("gameCode = ");
			internalBuffer.append("'" + getGameCode() + "'");
		}
		
		if (getSerialNumber() != null)  {
			if (internalBuffer.length() > 0)
				internalBuffer.append(" AND serialNumber = ");
			else
				internalBuffer.append(" serialNumber = ");
			internalBuffer.append("'" + getSerialNumber() + "'");
		}
		
		if (getDayOfTheWeek() != null)  {
			if (internalBuffer.length() > 0)
				internalBuffer.append(" AND dayOfTheWeek = ");
			else
				internalBuffer.append(" dayOfTheWeek = ");
			
			internalBuffer.append("'" + getDayOfTheWeek() + "'");
		}
		
		if (getFirstValue() != null)  {
			if (internalBuffer.length() > 0)
				internalBuffer.append(" AND firstValue = ");
			else
				internalBuffer.append(" firstValue = ");
			
			internalBuffer.append("'" + getFirstValue() + "'");
		}
		
		if (getSecondValue() != null)  {
			if (internalBuffer.length() > 0)
				internalBuffer.append(" AND secondValue = ");
			else
				internalBuffer.append(" secondValue = ");
			
			internalBuffer.append("'" + getSecondValue() + "'");
		}
		
		if (getThirdValue() != null)  {
			if (internalBuffer.length() > 0)
				internalBuffer.append(" AND thirdValue = ");
			else
				internalBuffer.append(" thirdValue = ");
			
			internalBuffer.append("'" + getThirdValue() + "'");
		}
		
		if (getFourthValue() != null)  {
			if (internalBuffer.length() > 0)
				internalBuffer.append(" AND fourthValue = ");
			else
				internalBuffer.append(" fourthValue = ");
			
			internalBuffer.append("'" + getFourthValue() + "'");
		}
		
		if (getFifthValue() != null)  {
			if (internalBuffer.length() > 0)
				internalBuffer.append(" AND fifthValue = ");
			else
				internalBuffer.append(" fifthValue = ");
			
			internalBuffer.append("'" + getFifthValue() + "'");
		}
		
		if (getMegaValue() != null)  {
			if (internalBuffer.length() > 0)
				internalBuffer.append(" AND megaValue = ");
			else
				internalBuffer.append(" megaValue = ");
			
			internalBuffer.append("'" + getMegaValue() + "'");
		}
		
		if (getDateOfDraw() != null)  {
			if (internalBuffer.length() > 0)
				internalBuffer.append(" AND dateOfDraw = ");
			else
				internalBuffer.append(" dateOfDraw = ");
			
			internalBuffer.append("'" + getDateOfDraw() + "'");
		}
		
		String sql = buff.toString() + internalBuffer.toString();
		Connection conn = null;
		try {
			
			conn = getConnection();
			Statement stmt = conn.createStatement();
			
			ResultSet rs = stmt.executeQuery(sql);
			
			while (rs.next()) {
				ResultHistoryEntity oneent = new ResultHistoryEntity();
				oneent.setDateOfDraw(rs.getString("dateOfDraw"));
				oneent.setGameCode(rs.getString("gameCode"));
				oneent.setSerialNumber(rs.getString("serialNumber"));
				oneent.setFirstValue(rs.getString("firstValue"));
				oneent.setSecondValue(rs.getString("secondValue"));
				oneent.setThirdValue(rs.getString("thirdValue"));
				oneent.setFourthValue(rs.getString("fourthValue"));
				oneent.setFifthValue(rs.getString("fifthValue"));
				oneent.setMegaValue(rs.getString("megaValue"));
				oneent.setDayOfTheWeek(rs.getString("dayOfTheWeek"));
				
				out.add(oneent);
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			if (conn != null)
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		
		
		
		return out;
	}

	public void setDateOfDraw(String dateOfDraw) {
		this.dateOfDraw = dateOfDraw;
	}

	public String getDateOfDraw() {
		return dateOfDraw;
	}

	public boolean exists() {
		boolean out = false;
		StringBuffer buff = new StringBuffer();
		
		StringBuffer internalBuffer = new StringBuffer();
		
		buff.append("select * from " + getTableName() + " where ");
		
		if (getGameCode() != null)  {
			internalBuffer.append("gameCode = ");
			internalBuffer.append("'" + getGameCode() + "'");
		}
		
		if (getSerialNumber() != null)  {
			if (internalBuffer.length() > 0)
				internalBuffer.append(" AND serialNumber = ");
			else
				internalBuffer.append(" serialNumber = ");
			internalBuffer.append("'" + getSerialNumber() + "'");
		}
		
		if (getDayOfTheWeek() != null)  {
			if (internalBuffer.length() > 0)
				internalBuffer.append(" AND dayOfTheWeek = ");
			else
				internalBuffer.append(" dayOfTheWeek = ");
			
			internalBuffer.append("'" + getDayOfTheWeek() + "'");
		}
		
		if (getFirstValue() != null)  {
			if (internalBuffer.length() > 0)
				internalBuffer.append(" AND firstValue = ");
			else
				internalBuffer.append(" firstValue = ");
			
			internalBuffer.append("'" + getFirstValue() + "'");
		}
		
		if (getSecondValue() != null)  {
			if (internalBuffer.length() > 0)
				internalBuffer.append(" AND secondValue = ");
			else
				internalBuffer.append(" secondValue = ");
			
			internalBuffer.append("'" + getSecondValue() + "'");
		}
		
		if (getThirdValue() != null)  {
			if (internalBuffer.length() > 0)
				internalBuffer.append(" AND thirdValue = ");
			else
				internalBuffer.append(" thirdValue = ");
			
			internalBuffer.append("'" + getThirdValue() + "'");
		}
		
		if (getFourthValue() != null)  {
			if (internalBuffer.length() > 0)
				internalBuffer.append(" AND fourthValue = ");
			else
				internalBuffer.append(" fourthValue = ");
			
			internalBuffer.append("'" + getFourthValue() + "'");
		}
		
		if (getFifthValue() != null)  {
			if (internalBuffer.length() > 0)
				internalBuffer.append(" AND fifthValue = ");
			else
				internalBuffer.append(" fifthValue = ");
			
			internalBuffer.append("'" + getFifthValue() + "'");
		}
		
		if (getMegaValue() != null)  {
			if (internalBuffer.length() > 0)
				internalBuffer.append(" AND megaValue = ");
			else
				internalBuffer.append(" megaValue = ");
			
			internalBuffer.append("'" + getMegaValue() + "'");
		}
		
		if (getDateOfDraw() != null)  {
			if (internalBuffer.length() > 0)
				internalBuffer.append(" AND dateOfDraw = ");
			else
				internalBuffer.append(" dateOfDraw = ");
			
			internalBuffer.append("'" + getDateOfDraw() + "'");
		}
		
		String sql = buff.toString() + internalBuffer.toString();
		Connection conn = null;
		try {
			
			conn = getConnection();
			Statement stmt = conn.createStatement();
			
			ResultSet rs = stmt.executeQuery(sql);
			
			if (rs.next())
				out = true;
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			if (conn != null)
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		
		
		
		return out;
	}
	
	public void createDerivedRecords() {
		Connection conn = null;
		try {
			
			conn = getConnection();
			CallableStatement stmt = conn.prepareCall("{call insert_derived_result}");
			
			boolean rs = stmt.execute();
			
						
		} catch (SQLException e) {
			// TODO Auto-generated catch block
		} finally {
			if (conn != null)
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
	}
	
	public void updateMaxFactorForDerivedRecords(String gameCode, String serialNumber) {
		
		if (gameCode == null)  {
			System.out.println("ResultHistoryEntity.updateMaxFactorForDerivedRecords : Pass a valid gameCode ");
			return ;
		}
		
		if (serialNumber == null)  {
			System.out.println("ResultHistoryEntity.updateMaxFactorForDerivedRecords : Pass a valid serialNumber ");
			return ;
		}
		
		
		String sql1 = "select firstValue, secondValue, thirdValue, fourthValue, fifthValue from " + getTableName() + " where gameCode =  " + gameCode +
						" and serialNumber = " + serialNumber;

		Connection conn = null;
		boolean doInsert = false;
		try {
			
			conn = getConnection();
			Statement stmt = conn.createStatement();
			
			ResultSet rs = stmt.executeQuery(sql1);
			
			int instances = 0;
			
			if (rs.next()) {
				
				int [] vals = {rs.getInt("firstValue"), rs.getInt("secondValue"),rs.getInt("thirdValue"),rs.getInt("fourthValue"),rs.getInt("fifthValue")};
				
				rs.close();
				
				Factors fac = new Factors();
				
				String maxFactorAndCount = Factors.getMaxFactorAndCountForComb(vals);
				
				if (maxFactorAndCount.length() > 0) {
					String[] ar = maxFactorAndCount.split(" ");
				
					String sql2 = "update result_history a, derived_result_history b set maxFactor = " + ar[0] +" , maxFactorCount = " + ar[1] + 
									" where a.resultID = b.resultID and gameCode = " + gameCode + " and serialNumber = " + serialNumber ;
 
					int out = stmt.executeUpdate(sql2);
					
					if (out > 0) 
						System.out.println("ResultHistoryEntity.updateMaxFactorForDerivedRecords : Record updated for serial " + serialNumber + " gamecode " +  gameCode);
				} else {
					System.out.println("ResultHistoryEntity.updateMaxFactorForDerivedRecords : Nothing to update for serial " + serialNumber + " gamecode " +  gameCode);
				}
					
					stmt.close();
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			if (conn != null)
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
				
	}
	
	public void createEvidenceOfFollowers(String gameCode) {
		Connection conn = null;
		try {
			
			conn = getConnection();
			CallableStatement stmt = conn.prepareCall("{call evidenceOfFollowerPatterns(?)}");
			stmt.setInt(1, Integer.parseInt(gameCode));
			
			boolean rs = stmt.execute();
							
		} catch (SQLException e) {
			// TODO Auto-generated catch block
		} finally {
			if (conn != null)
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
	}
	
	public void insertResultsWithinLastNHistory(String gameCode) {
		
		ResultsWithinLastN lastN = new ResultsWithinLastN();
		
		ArrayList l = lastN.getMissingSerialsForGame(gameCode);
		
		Iterator it = l.iterator();
		
		while (it.hasNext()) {
			Integer ser = (Integer)it.next();
			
			lastN = new ResultsWithinLastN();
			for (int i=3; i< 15; i++) {
				System.out.println("Serial " + ser + " withinlast " + i);
				lastN.executeLastNProcsForSerial(Integer.parseInt(gameCode), i, ser);
			}
			
		}
		
	}
	
	public boolean matches3Diffs (int serialNumber, int gameCode, int[] comb) {
		boolean out = false;
		String serialClause = "";
		int matchCount = 0;
		
		if (diffsForGame == null) {
			populateDiffsHash(gameCode, serialNumber);
		}
		
		int diff1 = comb[1]-comb[0];
		int diff2 = comb[2]-comb[0];
		int diff3 = comb[3]-comb[0];
		int diff4 = comb[4]-comb[0];
		
		if (diffsForGame.get(5).contains(diff1+"-"+diff2+"-"+diff3+"-"+diff4)) return false;
		
		if (diffsForGame.get(1).contains(diff2+"-"+diff3+"-"+diff4)) return true;
		if (diffsForGame.get(2).contains(diff1+"-"+diff3+"-"+diff4)) return true;
		if (diffsForGame.get(3).contains(diff1+"-"+diff2+"-"+diff4)) return true;
		if (diffsForGame.get(4).contains(diff1+"-"+diff2+"-"+diff3)) return true;
		
		
		return out;
	}
	
	public boolean matches3Gaps (int serialNumber, int gameCode, int[] comb) {
		boolean out = false;
		String serialClause = "";
		int matchCount = 0;
		
		if (gapsForGame == null) {
			populateGapsHash(gameCode, serialNumber);
		}
		
		int diff1 = comb[1]-comb[0];
		int diff2 = comb[2]-comb[1];
		int diff3 = comb[3]-comb[2];
		int diff4 = comb[4]-comb[3];
		
		if (gapsForGame.get(5).contains(diff1+"-"+diff2+"-"+diff3+"-"+diff4)) return false;
		
		if (gapsForGame.get(1).contains(diff2+"-"+diff3+"-"+diff4)) return true;
		if (gapsForGame.get(2).contains(diff1+"-"+diff3+"-"+diff4)) return true;
		if (gapsForGame.get(3).contains(diff1+"-"+diff2+"-"+diff4)) return true;
		if (gapsForGame.get(4).contains(diff1+"-"+diff2+"-"+diff3)) return true;
		
		
		return out;
	}
	
	private void populateDiffsHash(int gameCode, int serialNumber) {
		
			StringBuffer buff = new StringBuffer();
			
			diffsForGame = new Hashtable<Integer, HashSet<String>>();
			
			String serialClause = "";
			if (serialNumber > 0) serialClause = " and a.serialNumber < " + serialNumber;
		  
			buff.append("select a.serialNumber, a.diff1, a.diff2, a.diff3, a.diff4 from jointView a where a.gameCode = " + gameCode + serialClause + " order by serialNumber desc"	);		
			
			String sql = buff.toString();
			Connection conn = null;
			try {
				
				conn = getConnection();
				Statement stmt = conn.createStatement();
				
				ResultSet rs = stmt.executeQuery(sql);
				
				while (rs.next()) {
					
					String diff1 = rs.getString("diff1");
					String diff2 = rs.getString("diff2");
					String diff3 = rs.getString("diff3");
					String diff4 = rs.getString("diff4");
					
					for (int i=1; i<=5; i++) {
						
						if (diffsForGame.get(i) == null) {
							HashSet<String> a = new HashSet<String>();
							
							if (i == 1) a.add(diff2+"-"+diff3+"-"+diff4);
							if (i == 2) a.add(diff1+"-"+diff3+"-"+diff4);
							if (i == 3) a.add(diff1+"-"+diff2+"-"+diff4);
							if (i == 4) a.add(diff1+"-"+diff2+"-"+diff3);
							if (i == 5) a.add(diff1+"-"+diff2+"-"+diff3+"-"+diff4);
							diffsForGame.put(i, a);	
						} else {
							if (i == 1) diffsForGame.get(i).add(diff2+"-"+diff3+"-"+diff4);
							if (i == 2) diffsForGame.get(i).add(diff1+"-"+diff3+"-"+diff4);
							if (i == 3) diffsForGame.get(i).add(diff1+"-"+diff2+"-"+diff4);
							if (i == 4) diffsForGame.get(i).add(diff1+"-"+diff2+"-"+diff3);
							if (i == 5) diffsForGame.get(i).add(diff1+"-"+diff2+"-"+diff3+"-"+diff4);
						}
					}
					
				}
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} finally {
				if (conn != null)
					try {
						conn.close();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
			}
		
	
	}
	
	
	private void populateGapsHash(int gameCode, int serialNumber) {
		
		StringBuffer buff = new StringBuffer();
		
		gapsForGame = new Hashtable<Integer, HashSet<String>>();
		
		String serialClause = "";
		if (serialNumber > 0) serialClause = " and a.serialNumber < " + serialNumber;
	  
		buff.append("select a.serialNumber, a.secondValue-a.firstValue as diff1, "
				+ " a.thirdValue - a.secondValue as diff2, a.fourthValue - a.thirdValue as diff3, "
				+ " a.fifthValue - a.fourthValue as diff4 from jointView a where a.gameCode = " + gameCode + serialClause + " order by serialNumber desc"	);		
		
		String sql = buff.toString();
		Connection conn = null;
		try {
			
			conn = getConnection();
			Statement stmt = conn.createStatement();
			
			ResultSet rs = stmt.executeQuery(sql);
			
			while (rs.next()) {
				
				String diff1 = rs.getString("diff1");
				String diff2 = rs.getString("diff2");
				String diff3 = rs.getString("diff3");
				String diff4 = rs.getString("diff4");
				
				for (int i=1; i<=5; i++) {
					
					if (gapsForGame.get(i) == null) {
						HashSet<String> a = new HashSet<String>();
						
						if (i == 1) a.add(diff2+"-"+diff3+"-"+diff4);
						if (i == 2) a.add(diff1+"-"+diff3+"-"+diff4);
						if (i == 3) a.add(diff1+"-"+diff2+"-"+diff4);
						if (i == 4) a.add(diff1+"-"+diff2+"-"+diff3);
						if (i == 5) a.add(diff1+"-"+diff2+"-"+diff3+"-"+diff4);
						gapsForGame.put(i, a);	
					} else {
						if (i == 1) gapsForGame.get(i).add(diff2+"-"+diff3+"-"+diff4);
						if (i == 2) gapsForGame.get(i).add(diff1+"-"+diff3+"-"+diff4);
						if (i == 3) gapsForGame.get(i).add(diff1+"-"+diff2+"-"+diff4);
						if (i == 4) gapsForGame.get(i).add(diff1+"-"+diff2+"-"+diff3);
						if (i == 5) gapsForGame.get(i).add(diff1+"-"+diff2+"-"+diff3+"-"+diff4);
					}
				}
				
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			if (conn != null)
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
	

}
	
	public String getLastNForWithinLast(String attribute, int lastN, int serialNum) {
		String out = "";
		
		if (attribute == null || attribute.length() == 0)
			return out;
		
		if (getGameCode() == null) {
			System.out.println("ResultHistoryEntity.getLastN: Set gameCode first.");
			return out;
		}
		
		if (lastN <= 0) {
			return out;
		}
		
		if (attribute.endsWith("Redux")) {// If withinLast is more than 5, return nothing
			//if (lastN > 5) return out;
			lastN = 5;
		}
		
		String serialClause = "";
		
		if (serialNum > 0)
			serialClause = " and serialNumber <= " + serialNum + " and serialNumber > " + (serialNum - lastN);
		
		StringBuffer buff = new StringBuffer();
		
		
		if (attribute.endsWith("Follower")) {
			//return getFollowers(attribute, Integer.parseInt(getGameCode()), serialNum);
			String tempattribute = attribute.substring(0, attribute.indexOf("Follower")) + "Value";
			buff.append("select distinct(" + tempattribute + ") from follower_patterns where gameCode = " + getGameCode() + serialClause + " order by serialNumber desc LIMIT " + lastN);
		} else {
			buff.append("select distinct(" + attribute + ") from jointView where gameCode = " + getGameCode() + serialClause + " order by serialNumber desc LIMIT " + lastN);
		}
		
		String sql = buff.toString();
		Connection conn = null;
		try {
			
			conn = getConnection();
			Statement stmt = conn.createStatement();
			
			ResultSet rs = stmt.executeQuery(sql);
			
			while (rs.next()) {
				String val = rs.getString(1);
				if (val != null)
					out += val + ",";
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			if (conn != null)
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		
		List<String> list = new ArrayList<String>(Arrays.asList(out.substring(0, out.length()-1).split(",")));
		
		if ( attribute.endsWith("Bucket") && !attribute.endsWith("SumBucket")) {
			if (list.size() > 3) return "";
		}
		
		if ( attribute.endsWith("Prime")) {
			if (list.size() > 1) return "";
		}
		
		if ( attribute.endsWith("Follower")) {
			if (list.size() > 1) return "";
		}
		
		return out.substring(0, out.length()-1);
	}
	
	public String getLastNForAttribute(String attribute, int lastN, int serialNum) {
		String out = "";
		
		if (attribute == null || attribute.length() == 0)
			return out;
		
		if (getGameCode() == null) {
			System.out.println("ResultHistoryEntity.getLastN: Set gameCode first.");
			return out;
		}
		
		if (lastN <= 0) {
			return out;
		}
		
		String serialClause = "";
		
		if (serialNum > 0)
			serialClause = " and serialNumber <= " + serialNum + " and serialNumber > " + (serialNum - lastN);
		
		StringBuffer buff = new StringBuffer();
		
		
		if (attribute.endsWith("Follower")) {
			//return getFollowers(attribute, Integer.parseInt(getGameCode()), serialNum);
			String tempattribute = attribute.substring(0, attribute.indexOf("Follower")) + "Value";
			buff.append("select distinct(" + tempattribute + ") from follower_patterns where gameCode = " + getGameCode() + serialClause + " order by serialNumber desc LIMIT " + lastN);
		} else {
			buff.append("select distinct(" + attribute + ") from jointView where gameCode = " + getGameCode() + serialClause + " order by serialNumber desc LIMIT " + lastN);
		}
		
		String sql = buff.toString();
		Connection conn = null;
		try {
			
			conn = getConnection();
			Statement stmt = conn.createStatement();
			
			ResultSet rs = stmt.executeQuery(sql);
			
			while (rs.next()) {
				String val = rs.getString(1);
				if (val != null)
					out += val + ",";
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			if (conn != null)
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		
		return (out.length()>1)?out.substring(0, out.length()-1):"";
	}
	
	public String getNthPreviousValueForAttribute(String attribute, int nthprevious, int serialNum) {
		// serialNum 0  and nthprevious 1    returns the value before latest value
		// serialNum 0  and nthprevious 2    returns the value before the value before latest value
		// so on
		
		String out = "";
		
		if (getGameCode() == null) {
			System.out.println("ResultHistoryEntity.getNthPreviousValueForAttribute: Set gameCode first.");
			return out;
		}
		
		if (nthprevious == 0) {
			System.out.println("ResultHistoryEntity.getNthPreviousValueForAttribute: Invalid n value 0. Valid values are 1, 2, 3, etc.");
			return out;
		}
			
		String vals = getLastNForAttribute("dateOfDraw", nthprevious+1, 0);
		
		StringTokenizer datatok = new StringTokenizer(vals, ",");
		ArrayList<String> datalist =  new ArrayList<String>();
		while (datatok.hasMoreTokens()) {
			String thistoken = datatok.nextToken().trim();
			if (thistoken.length() > 0)
				datalist.add(thistoken);
		}
		
		if (datalist.size() >= nthprevious+1)
			return datalist.get(nthprevious);
		else 
			return "";
		
	}
	
	public String getHighDistanceValuesForAttribute(String attribute, int lastN, int serialNum) { // get lastN values
																						// which have not appeared in a long time
		String out = "";
		
		if (attribute == null || attribute.length() == 0)
			return out;
		
		if (getGameCode() == null) {
			System.out.println("ResultHistoryEntity.getHighDistanceValuesForAttribute: Set gameCode first.");
			return out;
		}
		
		if (lastN <= 0) {
			return out;
		}
		
		String serialClause = "";
		
		if (serialNum > 0)
			serialClause = " and serialNumber <= " + serialNum + " and serialNumber > " + (serialNum - lastN);
		
		StringBuffer buff = new StringBuffer();

		buff.append("select distinct " + attribute + ", max(serialNumber) from jointView where gameCode = " + getGameCode() + serialClause + " group by " + attribute + " order by max(serialNumber) LIMIT " + lastN);
		
		String sql = buff.toString();
		Connection conn = null;
		try {
			
			conn = getConnection();
			Statement stmt = conn.createStatement();
			
			ResultSet rs = stmt.executeQuery(sql);
			
			while (rs.next()) {
				String val = rs.getString(1);
				if (val != null)
					out += val + ",";
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			if (conn != null)
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		
		return (out.length()>1)?out.substring(0, out.length()-1):"";
	}
	
	public LinkedHashMap<Integer,ArrayList<Integer>> getLastNForAttributes(List<String> attributes, int lastN, int serialNum) {
		LinkedHashMap<Integer,ArrayList<Integer>> out = new LinkedHashMap<Integer,ArrayList<Integer>>();
		
		if (attributes == null || attributes.size() == 0)
			return out;
		
		if (getGameCode() == null) {
			System.out.println("ResultHistoryEntity.getLastN: Set gameCode first.");
			return out;
		}
		
		if (lastN < 0) {
			return out;
		}
		
		String serialClause = "";
		
		if (serialNum > 0)
			serialClause = " and serialNumber <= " + serialNum + " and serialNumber > " + (serialNum - lastN);
		
		String limitclause = "";
		
		if (lastN > 0) 
			limitclause = " LIMIT " + lastN;
		
		String selects = "";
		for(String att: attributes) {
		    selects += att.trim() + ",";
		   
		}
		
		StringBuffer buff = new StringBuffer();
				
			buff.append("select serialNumber, " + selects.substring(0,  selects.length()-1) + " from jointView where gameCode = " + getGameCode() + serialClause + " order by serialNumber desc " + limitclause);
		
		
		String sql = buff.toString();
		Connection conn = null;
		try {
			
			conn = getConnection();
			Statement stmt = conn.createStatement();
			
			ResultSet rs = stmt.executeQuery(sql);
			
			while (rs.next()) {
				ArrayList<Integer> list = new ArrayList<Integer>();
				for(String att : attributes) {
				   list.add(rs.getInt(att.trim()));
				}
				
				//list.add(rs.getInt("serialNumber"));
				out.put(rs.getInt(1), list );			

			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			if (conn != null)
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		 
		return out;
	}
	
	public String getAllValuesForAttribute(String attribute, int serialNum, boolean fillmissing) { // Get all unique and possible values
																								// if fillmissing is true, the method will insert
																								// missing values within the range
																								// e.g. given 9,10,11,14,15,16 will add 12,13.
		String out = "";
		int prevVal = 0;
		
		if (attribute == null || attribute.length() == 0)
			return out;
		
		if (getGameCode() == null) {
			System.out.println("ResultHistoryEntity.getAllValuesForAttribute: Set gameCode first.");
			return out;
		}
		
		String serialClause = "";
		
		if (serialNum > 0)
			serialClause = " and serialNumber <= " + serialNum ;
		
		StringBuffer buff = new StringBuffer();
		
		
		if (attribute.endsWith("Follower")) {
			//return getFollowers(attribute, Integer.parseInt(getGameCode()), serialNum);
			String tempattribute = attribute.substring(0, attribute.indexOf("Follower")) + "Value";
			buff.append("select distinct(" + tempattribute + ") from follower_patterns where gameCode = " + getGameCode() + serialClause + " order by " + tempattribute);
		} else {
			buff.append("select distinct(" + attribute + ") from jointView where gameCode = " + getGameCode() + serialClause + " order by " + attribute );
		}
		
		String sql = buff.toString();
		Connection conn = null;
		try {
			
			conn = getConnection();
			Statement stmt = conn.createStatement();
			
			ResultSet rs = stmt.executeQuery(sql);
			
			while (rs.next()) {
				int val = rs.getInt(1);
				
				if (prevVal > 0) {
					
					if (fillmissing) {
						while (val - prevVal > 1) {
							out += (prevVal+1) + ",";
							prevVal += 1;
						}
					}
						
				}
				
				out += val + ",";
				
				prevVal = val;
			
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			if (conn != null)
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		
		return out.substring(0, out.length()-1);
	}
	
	public ArrayList<String> getAllValuesForAttributes(ArrayList<String> attributes,
			int serialNum, boolean fillmissing, String orderattribute, String ascdesc) { // Get all unique and possible
													// values separated by ,
		// for a combination of attributes
		ArrayList<String> out = new ArrayList<String>();
		int prevVal = 0;
		
		String selectatts = "";

		if (attributes == null || attributes.size() == 0)
			return out;
		
		for (String att: attributes) {
			selectatts += att + ",";
		}

		if (getGameCode() == null) {
			System.out
					.println("ResultHistoryEntity.getAllValuesForAttributes: Set gameCode first.");
			return out;
		}
		
		if (ascdesc == null) ascdesc = " desc ";
		
		String orderclause = "";
		
		if (orderattribute != null && orderattribute.equals("val")) {
			int i = 0;
			for (String att: attributes) {
				
				if (i < 2)
					orderclause += att + " " + ascdesc + ","; 
				
				i++;
			}
		} else {
			 orderclause = " count(*) " + ascdesc + " ";
		}
		
		

		String serialClause = "";

		if (serialNum > 0)
			serialClause = " and serialNumber <= " + serialNum;

		StringBuffer buff = new StringBuffer();

		
			buff.append("select " + selectatts.substring(0, selectatts.length()-1) + ", count(*)"
					+ " from jointView where gameCode = " + getGameCode()
					+ serialClause +
					" group by " + selectatts.substring(0, selectatts.length()-1) + " order by " + orderclause.substring(0, orderclause.length()-1) );
		

		String sql = buff.toString();
		Connection conn = null;
		try {

			conn = getConnection();
			Statement stmt = conn.createStatement();

			ResultSet rs = stmt.executeQuery(sql);

			while (rs.next()) {
				String val="";
				for(String att: attributes) {
					val += rs.getInt(att) + ",";
				}
				out.add(val.substring(0, val.length()-1));

			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			if (conn != null)
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}

		return out;
	}
	
	
	public int getNumberOfPossibleValuesForAttributeCombinations(ArrayList<String> attributes,
			int serialNum, int lastN, boolean fillmissing) { // Get number of possible
													// values 
		// for a combination of attributes
		int out = 1;		
		
		if (attributes == null || attributes.size() == 0)
			return out;
		
		if (getGameCode() == null) {
			System.out
					.println("ResultHistoryEntity.getNumberOfPossibleValuesForAttributeCombinations: Set gameCode first.");
			return out;
		}
		
		//System.out.println("ResultHistoryEntity:getNumberOfPossibleValuesForAttributeCombinations -- input attributes " + attributes);
		String serialClause = "";
		String limitClause = "";
		
		if (lastN > 0)
			limitClause = " limit " + lastN;

		if (serialNum > 0)
			serialClause = " and serialNumber <= " + serialNum;

		String sql = "";

		for (String att: attributes) {
			
			sql = "select count(distinct " + att + ")"
					+ " from (select " + att + " from jointView where gameCode = " + getGameCode()
					+ serialClause +
					" order by serialNumber desc " +
					limitClause + ") as temp";
			
			Connection conn = null;
			try {
	
				conn = getConnection();
				Statement stmt = conn.createStatement();
	
				ResultSet rs = stmt.executeQuery(sql);
	
				if (rs.next()) {
					out *= rs.getInt(1);
	
				}
	
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} finally {
				if (conn != null)
					try {
						conn.close();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
			}
		}

		return out;
	}
	
	
	public LinkedHashMap<Integer,Integer> getDistancesDataForAttributeAndValue(String attribute, int serialNum,	int value) { 
		LinkedHashMap<Integer,Integer> out = new LinkedHashMap<Integer, Integer>();
		
		if (attribute == null || attribute.length() == 0)
			return out;

		if (getGameCode() == null) {
			System.out.println("ResultHistoryEntity.getDistancesDataForAttributeAndValue: Set gameCode first.");
			return out;
		}

		String serialClause = "";

		if (serialNum > 0)
			serialClause = " and a.serialNumber <= " + serialNum;

		StringBuffer buff = new StringBuffer();
		
			buff.append("select  a.serialNumber as aser,  min( a.serialNumber - b.serialNumber ) as distance	from jointView a, jointView b where a.gameCode = " + getGameCode() +
						" and a.gameCode = b.gameCode and a." + attribute + " = b." + attribute + " and a." + attribute + " = " + value + 
						" and b.serialNumber < a.serialNumber "
					+ serialClause + " group by a.serialNumber, a." + attribute + " order by a.serialNumber desc ");
		

		String sql = buff.toString();
		Connection conn = null;
		try {

			conn = getConnection();
			Statement stmt = conn.createStatement();

			ResultSet rs = stmt.executeQuery(sql);

			while (rs.next()) {
				out.put(rs.getInt(1), rs.getInt(2));			

			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			if (conn != null)
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}

		return out;
	}
	
	public LinkedHashMap<Integer,Integer> getDistancesDataForMultipleAttributeAndValue(Hashtable<String,Integer> attValues, int serialNum) { 
		LinkedHashMap<Integer,Integer> out = new LinkedHashMap<Integer, Integer>();
		
		if (attValues == null || attValues.size() == 0)
			return out;
		
		String queryPortion = "";
		
		String groupByPortion = " group by a.serialNumber, ";
		
		Enumeration<String> enumKey = attValues.keys();
		while(enumKey.hasMoreElements()) {
		    String key = enumKey.nextElement();
		    Integer val = attValues.get(key);
		    
		    queryPortion += " and a." + key + " = b." + key + " and a." + key + " = " + val + " " ;
		    
		    groupByPortion += " a." + key + "," ;
		}

		if (getGameCode() == null) {
			System.out.println("ResultHistoryEntity.getDistancesDataForMultipleAttributeAndValue: Set gameCode first.");
			return out;
		}

		String serialClause = "";

		if (serialNum > 0)
			serialClause = " and a.serialNumber <= " + serialNum;

		StringBuffer buff = new StringBuffer();
		
			buff.append("select  a.serialNumber as aser,  min( a.serialNumber - b.serialNumber ) as distance	from jointView a, jointView b where a.gameCode = " + getGameCode() +
						" and a.gameCode = b.gameCode " + queryPortion + 
						" and b.serialNumber < a.serialNumber "
					+ serialClause + groupByPortion.substring(0,  groupByPortion.length()-1) + " order by a.serialNumber desc ");
		

		String sql = buff.toString();
		Connection conn = null;
		try {

			conn = getConnection();
			Statement stmt = conn.createStatement();

			ResultSet rs = stmt.executeQuery(sql);

			while (rs.next()) {
				out.put(rs.getInt(1), rs.getInt(2));			

			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			if (conn != null)
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}

		//System.out.println("Data returned from : ResultHistoryEntity.getDistancesDataForMultipleAttributeAndValue");
		return out;
	}
	
	public LinkedHashMap<Integer,ArrayList<Integer>> getCurrentDistancesDataForMultipleAttributes(ArrayList<String> attValues, int lastN, int serialNum) { 
		LinkedHashMap<Integer,ArrayList<Integer>> out = new LinkedHashMap<Integer,ArrayList<Integer>>();
		
		if (attValues == null || attValues.size() == 0)
			return out;
		
		if (lastN < 0) {
			return out;
		}
		
		String queryPortion = "";
		String selectPortion = "";
		String groupByPortion = " group by a.serialNumber, ";
		
		for(String att : attValues) {
		    queryPortion += " and a." + att + " = b." + att  ;
		    
		    selectPortion += " a." + att + ",";
		    
		    groupByPortion += " a." + att + "," ;
		}
		
		if (getGameCode() == null) {
			System.out.println("ResultHistoryEntity.getCurrentDistancesDataForMultipleAttributes: Set gameCode first.");
			return out;
		}

		String serialClause = "";

		if (serialNum > 0)
			serialClause = " and a.serialNumber <= " + serialNum;
		
		String limitclause = "";
		
		if (lastN > 0) 
			limitclause = " LIMIT " + lastN;

		StringBuffer buff = new StringBuffer();
		
			buff.append("select  a.serialNumber as aser, " + selectPortion + 
					" min( a.serialNumber - b.serialNumber ) as distance, count(*) as freq	from jointView a, jointView b where a.gameCode = " + getGameCode() +
						" and a.gameCode = b.gameCode " + queryPortion + 
						" and b.serialNumber < a.serialNumber "
					+ serialClause + groupByPortion.substring(0,  groupByPortion.length()-1) + " order by a.serialNumber desc " + limitclause);
		

		String sql = buff.toString();
		Connection conn = null;
		try {

			conn = getConnection();
			Statement stmt = conn.createStatement();

			ResultSet rs = stmt.executeQuery(sql);

			while (rs.next()) {
				
				ArrayList<Integer> list = new ArrayList<Integer>();
				for(String att : attValues) {
				   list.add(rs.getInt(att));
				}
				
				list.add(rs.getInt("distance"));
				list.add(rs.getInt("freq"));
				out.put(rs.getInt(1), list );			

			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("ResultHistoryEntity.getCurrentDistancesDataForMultipleAttributes SQL: " + sql);
			e.printStackTrace();
		} finally {
			if (conn != null)
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}

		return out;
	}
	
	public String getLastNForSequence(String attribute, int lastN, int serialNum) { // We will not need a distinct for this.
		String out = "";
		
		if (attribute == null || attribute.length() == 0)
			return out;
		
		if (getGameCode() == null) {
			System.out.println("ResultHistoryEntity.getLastN: Set gameCode first.");
			return out;
		}
		
		if (lastN <= 0) {
			return out;
		}
		
		String serialClause = "";
		
		if (serialNum > 0)
			serialClause = " and serialNumber <= " + serialNum + " and serialNumber > " + (serialNum - lastN);
		
		StringBuffer buff = new StringBuffer();
		
		
		if (attribute.endsWith("Follower")) {
			//return getFollowers(attribute, Integer.parseInt(getGameCode()), serialNum);
			String tempattribute = attribute.substring(0, attribute.indexOf("Follower")) + "Value";
			buff.append("select " + tempattribute + " from follower_patterns where gameCode = " + getGameCode() + serialClause + " order by serialNumber desc LIMIT " + lastN);
		} else {
			buff.append("select ifNull(" + attribute + ",0) from jointView where gameCode = " + getGameCode() + serialClause + " order by serialNumber desc LIMIT " + lastN);
		}
		
		String sql = buff.toString();
		Connection conn = null;
		try {
			
			conn = getConnection();
			Statement stmt = conn.createStatement();
			
			ResultSet rs = stmt.executeQuery(sql);
			
			while (rs.next()) {
				String val = rs.getString(1);
				if (val != null)
					out += val + ",";
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			if (conn != null)
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		
		return out.substring(0, out.length()-1);
	}
	
	
	public String getLastNForSequenceFromCache(String attribute, int lastN, int serialNum) { // We will not need a distinct for this.
		String out = "";
		
		boolean serialSet = false;
		
		if (attribute == null || attribute.length() == 0)
			return out;
		
		if (getGameCode() == null) {
			System.out.println("ResultHistoryEntity.getLastN: Set gameCode first.");
			return out;
		}
		
		if (lastN <= 0) {
			return out;
		}
		
		String serialClause = "";
		
		if (serialNum > 0) {
			serialClause = " and serialNumber <= " + serialNum + " and serialNumber > " + (serialNum - lastN);
			serialSet = true;
		}
				
		if (attValuesForSeq == null || attValuesForSeq.get(attribute) == null) {
		
			
			StringBuffer buff = new StringBuffer();
			
			
			if (attribute.endsWith("Follower")) {
				//return getFollowers(attribute, Integer.parseInt(getGameCode()), serialNum);
				String tempattribute = attribute.substring(0, attribute.indexOf("Follower")) + "Value";
				buff.append("select serialNumber, " + tempattribute + " from follower_patterns where gameCode = " + getGameCode() + " order by serialNumber desc ");
			} else {
				buff.append("select serialNumber, ifNull(" + attribute + ",0) from jointView where gameCode = " + getGameCode()  + " order by serialNumber desc " );
			}
			
			String sql = buff.toString();
			Connection conn = null;
			try {
				
				conn = getConnection();
				Statement stmt = conn.createStatement();
				
				ResultSet rs = stmt.executeQuery(sql);
				
				Hashtable<Integer,Integer> tab = new Hashtable<Integer,Integer>();
				while (rs.next()) {
					int serial = rs.getInt(1);
					if (maxSerialForGame == 0)
						maxSerialForGame = serial;
					
					tab.put(serial,rs.getInt(2));
					
					if (!serialSet) {
						serialNum = serial;
						serialSet = true;
					}
					
				}
				
				attValuesForSeq = new Hashtable<String, Hashtable<Integer,Integer>>();
				attValuesForSeq.put(attribute, tab);
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} finally {
				if (conn != null)
					try {
						conn.close();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
			}
		}
		
		for (int i=0; i<lastN; i++) {
			
			if (!serialSet) {
				serialNum = maxSerialForGame;
				serialSet = true;
			}
			out += attValuesForSeq.get(attribute).get(serialNum-i) + ",";
		}
		
		return out.substring(0, out.length()-1);
	}
	
	
	public String getLastNForRegressionFromCache(String attribute, int lastN, int serialNum) { // We will not need a distinct for this.
		String out = "";
		
		if (attribute == null || attribute.length() == 0)
			return out;
		
		if (getGameCode() == null) {
			System.out.println("ResultHistoryEntity.getLastNForRegressionFromCache: Set gameCode first.");
			return out;
		}
		
		if (lastN <= 0) {
			return out;
		}
		
		if (attValuesForRegression == null || attValuesForRegression.get(attribute) == null) {
		
			
			StringBuffer buff = new StringBuffer();
			
			
			if (attribute.endsWith("Follower")) {
				//return getFollowers(attribute, Integer.parseInt(getGameCode()), serialNum);
				String tempattribute = attribute.substring(0, attribute.indexOf("Follower")) + "Value";
				buff.append("select serialNumber, " + tempattribute + " from follower_patterns where gameCode = " + getGameCode() + " order by serialNumber asc ");
			} else {
				buff.append("select serialNumber, ifNull(" + attribute + ",0) from jointView where gameCode = " + getGameCode()  + " order by serialNumber asc " );
			}
			
			String sql = buff.toString();
			Connection conn = null;
			try {
				
				conn = getConnection();
				Statement stmt = conn.createStatement();
				
				ResultSet rs = stmt.executeQuery(sql);
				
				Hashtable<Integer,Integer> tab = new Hashtable<Integer,Integer>();
				while (rs.next()) {
					tab.put(rs.getInt(1),rs.getInt(2));
				}
				
				attValuesForRegression = new Hashtable<String, Hashtable<Integer,Integer>>();
				attValuesForRegression.put(attribute, tab);
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} finally {
				if (conn != null)
					try {
						conn.close();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
			}
		}
		
		if (serialNum == 0)
			serialNum = Integer.parseInt(getLastNForAttribute("serialNumber",1,0));
		
		for (int i=lastN; i>0; i--) {
			out += attValuesForRegression.get(attribute).get(serialNum-i+1) + ",";
		}
		
		return out.substring(0, out.length()-1);
	}
	
	
	
	public String getLastNForChart(String attribute, int lastN) {
		String out = "";
		
		if (attribute == null || attribute.length() == 0)
			return out;
		
		if (getGameCode() == null) {
			System.out.println("ResultHistoryEntity.getLastNForChart: Set gameCode first.");
			return out;
		}
		
		if (lastN <= 0) {
			return out;
		}
		
		
		String serialClause = "";
		
		
		StringBuffer buff = new StringBuffer();
		
		
		if (attribute.endsWith("Follower")) {
			//return getFollowers(attribute, Integer.parseInt(getGameCode()), serialNum);
			String tempattribute = attribute.substring(0, attribute.indexOf("Follower")) + "Value";
			buff.append("select distinct(" + tempattribute + ") from follower_patterns where gameCode = " + getGameCode() + serialClause + " order by serialNumber desc LIMIT " + lastN);
		} else if (attribute.equals("bucketRank") || attribute.equals("bRnk")) {
				buff.append("select g.bucketRank FROM jointView v , game_buckets g	where v.gameCode = " + getGameCode()  + " and v.gameCode = g.gameCode " +
							" and v.firstBucket = g.firstBucket and v.secondBucket = g.secondBucket and v.thirdBucket = g.thirdBucket and v.fourthBucket = g.fourthBucket " +
							" and v.fifthBucket = g.fifthBucket order by serialNumber desc LIMIT " + lastN);
		}
		else if (attribute.equals("skpSum")) {
			buff.append("select firstSkip+secondSkip+thirdSkip+fourthSkip+fifthSkip as skpSum FROM jointView v 	where v.gameCode = " + getGameCode()  + " order by serialNumber desc LIMIT " + lastN);
		}	
		else if (attribute.equals("mdRnk")) {
			buff.append("select paramRank  FROM aggregate_ranks v , missing_digits m where v.gameCode = " + getGameCode()  + " and m.gameCode = v.gameCode and v.paramValue = m.missingDigits " +
					" and paramType='MIS' order by serialNumber desc LIMIT " + lastN);
		}
		
		else {
			
			if (attribute.equals("mxFctr")) attribute = "maxFactor";
			
			buff.append("select IFNULL(" + attribute + ",0) from jointView where gameCode = " + getGameCode() + serialClause + " order by serialNumber desc LIMIT " + lastN);
		}
		
		String sql = buff.toString();
		Connection conn = null;
		try {
			
			conn = getConnection();
			Statement stmt = conn.createStatement();
			
			ResultSet rs = stmt.executeQuery(sql);
			
			rs.afterLast();
			
			while (rs.previous()) {
				String val = rs.getString(1);
				if (val != null)
					out += val + ",";
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			if (conn != null)
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		
		/*List<String> list = new ArrayList<String>(Arrays.asList(out.substring(0, out.length()-1).split(",")));
		
		if ( attribute.endsWith("Bucket") && !attribute.endsWith("SumBucket")) {
			if (list.size() > 3) return "";
		}
		
		if ( attribute.endsWith("Prime")) {
			if (list.size() > 1) return "";
		}
		
		if ( attribute.endsWith("Follower")) {
			if (list.size() > 1) return "";
		}*/
		
		return out.substring(0, out.length()-1);
	}
	
	
	public String getValueForField(String attribute, String gameCode, int serialNum) {
		String out = "";
		
		if (attribute == null || attribute.length() == 0)
			return out;
		
		if (gameCode == null) {
			System.out.println("ResultHistoryEntity.getValueForField: Set gameCode first.");
			return out;
		}
		
		String serialClause = "";
		
		if (serialNum > 0)
			serialClause = " and serialNumber = " + serialNum;
		else
			serialClause = " order by serialNumber desc LIMIT 1 ";  // GET THE LATEST value
		
		StringBuffer buff = new StringBuffer();
		
		if (attribute.endsWith("Follower")) {
			attribute = attribute.substring(0, attribute.indexOf("Follower")) + "Value";
			buff.append("select " + attribute + " from follower_patterns where gameCode = " + gameCode + serialClause);

		} else {
			buff.append("select " + attribute + " from jointView where gameCode = " + gameCode + serialClause);
		}
		
		String sql = buff.toString();
		Connection conn = null;
		try {
			
			conn = getConnection();
			Statement stmt = conn.createStatement();
			
			ResultSet rs = stmt.executeQuery(sql);
			
			if (rs.next()) {
				out = rs.getString(1);
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			if (conn != null)
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		
		return out;
	}
	
	public String getValueForFieldFromCache(String attribute, String gameCode, int serialNum) {
		
		if (attValuesForSeq != null && attValuesForSeq.get(attribute) != null)
			return Integer.toString(attValuesForSeq.get(attribute).get(serialNum));
		else
			getLastNForSequenceFromCache(attribute, 5, serialNum);
			
		String out = "";
		
		if (attribute == null || attribute.length() == 0)
			return out;
		
		if (gameCode == null) {
			System.out.println("ResultHistoryEntity.getValueForField: Set gameCode first.");
			return out;
		}
		
		String serialClause = "";
		
		if (serialNum > 0)
			serialClause = " and serialNumber = " + serialNum;
		else
			serialClause = " order by serialNumber desc LIMIT 1 ";  // GET THE LATEST value
		
		StringBuffer buff = new StringBuffer();
		
		if (attribute.endsWith("Follower")) {
			attribute = attribute.substring(0, attribute.indexOf("Follower")) + "Value";
			buff.append("select " + attribute + " from follower_patterns where gameCode = " + gameCode + serialClause);

		} else {
			buff.append("select " + attribute + " from jointView where gameCode = " + gameCode + serialClause);
		}
		
		String sql = buff.toString();
		Connection conn = null;
		try {
			
			conn = getConnection();
			Statement stmt = conn.createStatement();
			
			ResultSet rs = stmt.executeQuery(sql);
			
			if (rs.next()) {
				out = rs.getString(1);
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			if (conn != null)
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		
		return out;
	}
	
	
	
	public String getExclusionsForField(String attribute, String gameCode, int serialNum, int safePercentile, int pastResults) {
		// Exclude values that occurred in pastResults, which do not belong in safePercentile 
		
		String out = "";
		
		String serialClause = "";
		
		int totalrecords=0;
		
		if (serialNum > 0) {
			serialClause = " and serialNumber <= " + serialNum + " " ;
			totalrecords = serialNum;
		}
		
		if (safePercentile == 0)
			safePercentile = 80;
		
		
		
		Connection conn = getConnection();
		
		
		
		Statement stmt;
		try {
			stmt = conn.createStatement();
			// Get the most likely follower pattern maps
			ResultSet rs = null;
			if (totalrecords ==0) {
				String sql2 = "select count(*) as records from jointView where gameCode = " + gameCode + serialClause ;
				rs = stmt.executeQuery(sql2);
				
				if (rs.next()) {
					totalrecords = rs.getInt("records");
					rs.close();
				}
			}
			
			
			rs = stmt.executeQuery("select ifnull(" + attribute + ",0), count(*) from jointView where gameCode = " + gameCode +  serialClause +
									" group by " + attribute + "  order by  count(*) desc ") ;
			  
			StringBuffer excludes = new StringBuffer();
			
			int percentilesSoFar = 0;
			int possibleValuesForAttrib = 0;
			while (rs.next()) {
				
				String thisVal = rs.getString(1);
				int thisCount = rs.getInt(2);
				
				percentilesSoFar += thisCount*100/totalrecords;
		  				  		
				if (percentilesSoFar < safePercentile)
					excludes.append("'" + thisVal + "',");
				
				possibleValuesForAttrib++;
				
		  	}
			
			rs.close();
			
			if (pastResults == 0)
				pastResults = possibleValuesForAttrib;
			
		  	
			// Get all the maps that appeared in last 50 results and match the least likely maps
			// We will not consider these
			rs = stmt.executeQuery("Select ifnull(" + attribute + ",0) as " + attribute + " from jointView where gameCode = " + gameCode + serialClause +
												" and serialNumber >  " + ((serialNum > 0)?serialNum:totalrecords ) +  " -  " + pastResults +
												" and " + attribute + " not in " +
												"(" + excludes.toString().substring(0,excludes.length()-1) + ") order by serialNumber desc");
		  	
		  	while (rs.next()) {
		  		//FollowerPatternEntity fte = new FollowerPatternEntity();
		  		//fte.setGameCode(rs.getString("gameCode"));
		  		//fte.setSerialNumber(rs.getString("serialNumber"));
		  		out += rs.getString(attribute) + ",";
		  		
		  				  		
		  		
		  	}
	  	
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				if (conn != null)
					conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		
		return (out.length() > 0)?out.substring(0, out.length()-1):out;
		
	}
	
	public String allOddOrEvenValuesInLastNDraws(String attribute, String gameCode, int lastN) {
		String out = null;
		int countOdds = 0;
		
		if (attribute == null || attribute.length() == 0)
			return out;
		
		if (gameCode == null) {
			System.out.println("ResultHistoryEntity.getValueForField: Set gameCode first.");
			return out;
		}
		 
		StringBuffer buff = new StringBuffer();
		
		if (attribute.endsWith("Follower")) {
			attribute = attribute.substring(0, attribute.indexOf("Follower")) + "Value";
			buff.append("select sum(odd) as odds from ( select  " + attribute + " % 2 as odd from follower_patterns where gameCode = " + gameCode +
					 " order by serialNumber desc LIMIT "	+ lastN + " ) as temp ");

		} else {
			buff.append("select sum(odd) as odds from ( select  " + attribute + " % 2 as odd from jointView where gameCode = " + gameCode +
					 " order by serialNumber desc LIMIT "	+ lastN + " ) as temp ");
		}
		
		String sql = buff.toString();
		Connection conn = null;
		try {
			conn = getConnection();
			Statement stmt = conn.createStatement();
			
			ResultSet rs = stmt.executeQuery(sql);
			
			if (rs.next()) {
				countOdds = rs.getInt("odds");
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			if (conn != null)
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		
		if (countOdds == lastN)
			out = "ODD";
		
		if (countOdds == 0)
			out = "EVEN";
		
		return out;
	}
	
	public Hashtable<String, Integer> evenOddBucketRemainderInSelectedResults(String attribute, String gameCode, int startSerial, int endSerial) {
		Hashtable<String, Integer> out = new Hashtable<String, Integer>();
		
		if (attribute == null || attribute.length() == 0)
			return out;
		
		if (gameCode == null) {
			System.out.println("ResultHistoryEntity.evenOddBucketRemainderInSelectedResults: Set gameCode first.");
			return out;
		}
		 
		StringBuffer buff = new StringBuffer();		
		
		buff.append("select " + attribute + " DIV 10 % 2 as buck, " + attribute + " % 10 % 2 as rem, count(*) as ins, max(serialNumber) as lastserial " +
					" from jointView " + 
					" where gameCode = " + gameCode + 
					" and serialNumber between " + startSerial + " and " + endSerial + 
					" group by " + attribute + " DIV 10 % 2 , " + attribute + " % 10 % 2  ");
		
		String sql = buff.toString();
		
		//System.out.println("resulthistoryentity.evenOddBucketRemainderInSelectedResults: Query.." + buff.toString());
		Connection conn = null;
		try {
			conn = getConnection();
			Statement stmt = conn.createStatement();
			
			ResultSet rs = stmt.executeQuery(sql);
			
			while (rs.next()) {
				String buck = (rs.getInt("buck") == 0)?"E":"O";
				String rem = (rs.getInt("rem") == 0)?"E":"O";
				int instances = rs.getInt("ins");
				
				out.put(buck+rem, instances);
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			if (conn != null)
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		
		return out;
	}
	
	
	public String getFollowers(String attribute, int gameCode, int serialNum) {
		String out = "";
		
		if (attribute == null || attribute.length() == 0)
			return out;
		
		if (gameCode == 0) {
			System.out.println("ResultHistoryEntity.getFollowers: invalid gameCode.");
			return out;
		}
		
		String serialClause = "";
		
		if (serialNum > 0)
			serialClause = " and c.serialNumber = " + serialNum ;
		else {
			String maxSerial = getValueForField("serialNumber", Integer.toString(gameCode), 0);
			serialClause = " and c.serialNumber = " + maxSerial ;
		}
			
		
		StringBuffer buff = new StringBuffer();
		
		if (attribute.toUpperCase().endsWith("FOLLOWER")) {
			String tempattribute = attribute.substring(0, attribute.toUpperCase().indexOf("FOLLOWER")) + "Value";
			buff.append("select distinct (n.number) from result_history a, result_history b , result_history c  ,game_types t, num_values n " +
						" where a.gameCode = c.gameCode and a.gameCode = b.gameCode and b.serialNumber < c.serialNumber and a.serialNumber = b.serialNumber +1 and b." 
						+ tempattribute + "= c." + tempattribute +
						" and c.gameCode = " + gameCode + serialClause + " and t.gameCode = a.gameCode	and n.number <= t.maximumValue and n.number = a." + tempattribute);
		} else {
			
		}
		
		String sql = buff.toString();
		Connection conn = null;
		try {
			
			conn = getConnection();
			Statement stmt = conn.createStatement();
			
			ResultSet rs = stmt.executeQuery(sql);
			
			while (rs.next()) {
				out += rs.getString(1) + ",";
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			if (conn != null)
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		
		if (out.length() > 0)
			return out.substring(0, out.length()-1);
		else
			return "";
	}

	@Override
	public String getUpdateSQL() {
		// TODO Auto-generated method stub
		return null;
	}
	
	
	public boolean sameReduxInHistory(int[] comb, String gameCode, int serialNum) {
		boolean out = false;		
		
		if (gameCode == null) {
			System.out.println("ResultHistoryEntity.sameReduxInHistory: Set gameCode first.");
			return out;
		}
		
		String serialClause = "";
		
		if (serialNum > 0)
			serialClause = " and a.serialNumber <= " + serialNum;
		
		StringBuffer buff = new StringBuffer();
		
		if (reduxesForGame == null) {
			System.out.println("resultHistoryEntity.sameReduxInHistory - populating reduxes.");
			reduxesForGame =  new ArrayList();
			buff.append("select a.serialNumber,a.firstRedux,a.secondRedux,a.thirdRedux,a.fourthRedux,a.fifthRedux  from jointView a where a.gameCode = " + gameCode
						+ serialClause + " order by serialNumber desc");		
			
			String sql = buff.toString();
			Connection conn = null;
			try {
				
				conn = getConnection();
				Statement stmt = conn.createStatement();
				
				ResultSet rs = stmt.executeQuery(sql);
				
				while (rs.next()) {
					String redx = rs.getString("firstRedux") + 
								rs.getString("secondRedux") +
								rs.getString("thirdRedux") +
								rs.getString("fourthRedux") +
								rs.getString("fifthRedux") ;
					
				
					reduxesForGame.add(redx);
				}
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} finally {
				if (conn != null)
					try {
						conn.close();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
			}
		}
		
		String inputRedx = "";
		
		for (int i=0; i< comb.length; i++) {
			inputRedx += Integer.toString(comb[i]);
		}
		
		if (reduxesForGame.contains(inputRedx)) out = true;
		
		return out;
	}
	
	public boolean sameVDiffInHistory(int[] vdiffs, String gameCode, int serialNum) {
		boolean out = false;		
		
		if (gameCode == null) {
			System.out.println("ResultHistoryEntity.sameVDiffInHistory: Set gameCode first.");
			return out;
		}
		
		String serialClause = "";
		
		if (serialNum > 0)
			serialClause = " and a.serialNumber <= " + serialNum;
		
		StringBuffer buff = new StringBuffer();
		
		if (VDiffsForGame == null) {
			System.out.println("resultHistoryEntity.sameVDiffInHistory - populating vdiffs.");
			VDiffsForGame =  new ArrayList();		
			
			buff.append("select abs(a.firstValue-b.firstValue) as firstVdiff, abs(a.secondValue-b.secondValue) as secondVdiff, abs(a.thirdValue-b.thirdValue) as thirdVdiff, abs(a.fourthValue-b.fourthValue) as fourthVdiff, abs(a.fifthValue-b.fifthValue) as fifthVdiff from jointView a, jointView b	where a.gameCode= b.gameCode and a.gameCode = " + gameCode
						+ " and b.serialNumber = a.serialNumber+1 " + serialClause + " order by a.serialNumber desc");		
			
			String sql = buff.toString();
			Connection conn = null;
			try {
				
				conn = getConnection();
				Statement stmt = conn.createStatement();
				
				ResultSet rs = stmt.executeQuery(sql);
				
				while (rs.next()) {
					String redx = rs.getString("firstVdiff") + " " +
								rs.getString("secondVdiff") + " " +
								rs.getString("thirdVdiff") + " " +
								rs.getString("fourthVdiff") + " " +
								rs.getString("fifthVdiff") ;
					
				
					VDiffsForGame.add(redx);
				}
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} finally {
				if (conn != null)
					try {
						conn.close();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
			}
		}
		
		String inputvdiffs = "";
		
		for (int i=0; i< vdiffs.length; i++) {
			inputvdiffs += Integer.toString(vdiffs[i]);
			
			if (i < vdiffs.length-1)
				inputvdiffs += " ";
		}
		
		if (VDiffsForGame.contains(inputvdiffs)) out = true;
		
		return out;
	}
	
	public String getFreqsForGameAndSerial(String gameCode, int serialNum) {
		String out = "";
		String serialClause = "";
		
		if (serialNum > 0)
			serialClause = " and serialNumber = " + serialNum;
		else
			return out;
		
		StringBuffer buff = new StringBuffer();
		
		buff.append("select firstFreq, secondFreq, thirdFreq, fourthFreq, fifthFreq, megaFreq  from jointView where gameCode = " + gameCode
				+ serialClause );		
	
		String sql = buff.toString();
		Connection conn = null;
		try {
			
			conn = getConnection();
			Statement stmt = conn.createStatement();
			
			ResultSet rs = stmt.executeQuery(sql);
			
			while (rs.next()) {
				out = rs.getString("firstFreq") + "," + 
							rs.getString("secondFreq") + "," + 
							rs.getString("thirdFreq") + "," + 
							rs.getString("fourthFreq") + "," + 
							rs.getString("fifthFreq") + "," + 
							rs.getString("megaFreq");
							
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			if (conn != null)
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		return out;
	}
	
	public boolean sameFreqReduxInHistory(int[] freqRdx, String gameCode, int serialNum) {
		boolean out = false;		
		
		if (gameCode == null) {
			System.out.println("ResultHistoryEntity.sameFreqReduxInHistory: Set gameCode first.");
			return out;
		}
		
		String serialClause = "";
		
		if (serialNum > 0)
			serialClause = " and a.serialNumber <= " + serialNum;
		
		StringBuffer buff = new StringBuffer();
		
		if (freqReduxesForGame == null) {
			System.out.println("resultHistoryEntity.sameFreqReduxInHistory - populating freqreduxes.");
			freqReduxesForGame =  new ArrayList();
			
			
			buff.append("select a.serialNumber,myRedux(firstFreq) as first , myRedux(secondFreq) as second ,myRedux(thirdFreq) as third ,myRedux(fourthFreq) as fourth ,myRedux(fifthFreq) as fifth  from jointView a where a.gameCode = " + gameCode
						+ serialClause + " order by serialNumber desc");		
			
			String sql = buff.toString();
			Connection conn = null;
			try {
				
				conn = getConnection();
				Statement stmt = conn.createStatement();
				
				ResultSet rs = stmt.executeQuery(sql);
				
				while (rs.next()) {
					String redx = rs.getString("first") + 
								rs.getString("second") +
								rs.getString("third") +
								rs.getString("fourth") +
								rs.getString("fifth") ;
					
				
					freqReduxesForGame.add(redx);
				}
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} finally {
				if (conn != null)
					try {
						conn.close();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
			}
		}
		
		String inputRedx = "";
		
		for (int i=0; i< freqRdx.length; i++) {
			inputRedx += Integer.toString(freqRdx[i]);
		}
		
		if (freqReduxesForGame.contains(inputRedx)) out = true;
		
		return out;
	}
	
	
	public boolean unlikelyFreqShadowRedux(int[] freqShadowRdx, String gameCode, int serialNum) {
		boolean out = false;		
		
		if (gameCode == null) {
			System.out.println("ResultHistoryEntity.unlikelyFreqShadowRedux: Set gameCode first.");
			return out;
		}
		
		String serialClause = "";
		
		if (serialNum > 0)
			serialClause = " and a.serialNumber <= " + serialNum;
		
		StringBuffer buff = new StringBuffer();
		
		if (unlikelyFreqShadowReduxesForGame == null) {
			System.out.println("resultHistoryEntity.unlikelyFreqShadowRedux - populating unlikelyFreqShadowReduxesForGame.");
			unlikelyFreqShadowReduxesForGame =  new ArrayList();
			
			
			buff.append("select myRedux(firstFreqShadow) as first , myRedux(secondFreqShadow) as second ,myRedux(thirdFreqShadow) as third ,myRedux(fourthFreqShadow) as fourth ,myRedux(fifthFreqShadow) as fifth, count(*)  from jointView a where a.gameCode = " + gameCode
						+ serialClause + " group by  myRedux(firstFreqShadow),myRedux(secondFreqShadow),myRedux(thirdFreqShadow),myRedux(fourthFreqShadow),myRedux(fifthFreqShadow) " +
						" having count(*) = 1");		
			
			String sql = buff.toString();
			Connection conn = null;
			try {
				
				conn = getConnection();
				Statement stmt = conn.createStatement();
				
				ResultSet rs = stmt.executeQuery(sql);
				
				while (rs.next()) {
					String redx = rs.getString("first") + 
								rs.getString("second") +
								rs.getString("third") +
								rs.getString("fourth") +
								rs.getString("fifth") ;
					
				
					unlikelyFreqShadowReduxesForGame.add(redx);
				}
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} finally {
				if (conn != null)
					try {
						conn.close();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
			}
		}
		
		String inputRedx = "";
		
		for (int i=0; i< freqShadowRdx.length; i++) {
			inputRedx += Integer.toString(freqShadowRdx[i]);
		}
		
		if (unlikelyFreqShadowReduxesForGame.contains(inputRedx)) out = true;
		
		return out;
	}
	
	
	public boolean sameDigitDiffInHistory(int[] comb, String gameCode, int serialNum) {
		boolean out = false;		
		
		if (gameCode == null) {
			System.out.println("ResultHistoryEntity.sameDigitDiffInHistory: Set gameCode first.");
			return out;
		}
		
		String serialClause = "";
		
		if (serialNum > 0)
			serialClause = " and a.serialNumber <= " + serialNum;
		
		StringBuffer buff = new StringBuffer();
		
		if (digitDiffsForGame == null) {
			System.out.println("resultHistoryEntity.sameReduxInHistory - populating reduxes.");
			digitDiffsForGame =  new ArrayList();
			buff.append("select a.serialNumber,abs((firstValue DIV 10) - (firstValue % 10)) as firstDigitDiff ," +
					"abs((secondValue DIV 10) - (secondValue % 10)) as secondDigitDiff," + 
					"abs((thirdValue DIV 10) - (thirdValue % 10)) as thirdDigitDiff," + 
					"abs((fourthValue DIV 10) - (fourthValue % 10)) as fourthDigitDiff," + 
					"abs((fifthValue DIV 10) - (fifthValue % 10)) as fifthDigitDiff  from jointView a where a.gameCode = " + gameCode
						+ serialClause + " order by serialNumber desc");		
			
			String sql = buff.toString();
			Connection conn = null;
			try {
				
				conn = getConnection();
				Statement stmt = conn.createStatement();
				
				ResultSet rs = stmt.executeQuery(sql);
				
				while (rs.next()) {
					String redx = rs.getString("firstDigitDiff") + 
								rs.getString("secondDigitDiff") +
								rs.getString("thirdDigitDiff") +
								rs.getString("fourthDigitDiff") +
								rs.getString("fifthDigitDiff") ;
					
				
					digitDiffsForGame.add(redx);
				}
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} finally {
				if (conn != null)
					try {
						conn.close();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
			}
		}
		
		String inputRedx = "";
		
		for (int i=0; i< comb.length; i++) {
			inputRedx += Integer.toString(Math.abs((comb[i] / 10) - (comb[i] % 10)));
		}
		
		if (digitDiffsForGame.contains(inputRedx)) out = true;
		
		return out;
	}
	
	public ArrayList<Integer> getFirstFiveSumExcludesBasedOnMultiplesHistory(String gameCode, int serialNum, int historySpan ) {
		ArrayList<Integer> out = new ArrayList<Integer>();
		
		HashSet<Integer> uniqs = new HashSet<Integer>();
		if (gameCode == null) {
			System.out.println("ResultHistoryEntity.getFirstFiveSumMultiplesHistory: Set gameCode first.");
			return out;
		}
		
		String serialClause = "";
		String sumSerialClause = "";
		
		int lastSum = 0;
		
		if (serialNum > 0) {
			serialClause = " and a.serialNumber <= " + serialNum;
			
			sumSerialClause = " and serialNumber <= " + serialNum;
		}
		
		String sumSQL = "select firstFiveSum from jointView where gameCode = "+ gameCode + sumSerialClause + " order by serialNumber desc LIMIT 1";
		
		StringBuffer buff = new StringBuffer();
		
			buff.append("select  a.firstFiveSum/b.firstFiveSum as divi, count(*) as instances from jointView a, jointView B	where a.gameCode = b.gameCode " +
						" and a.gameCode = " + gameCode
						+ serialClause + " and a.serialNumber = b.serialNumber+1 group by a.firstFiveSum/b.firstFiveSum order by a.serialNumber desc LIMIT " + historySpan);		
			
			String sql = buff.toString();
			Connection conn = null;
			try {
				
				conn = getConnection();
				Statement stmt = conn.createStatement();
				
				ResultSet rs = stmt.executeQuery(sumSQL);
				
				if (rs.next()) {
					lastSum = rs.getInt("firstFiveSum");
				}
				
				rs = stmt.executeQuery(sql);
				
				while (rs.next()) {
					if (rs.getInt("instances") < 2) {
						
						int newSum = Math.round(rs.getFloat("divi")*lastSum);
						
						if (uniqs.add(newSum))
							out.add(newSum);
					}
				}
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} finally {
				if (conn != null)
					try {
						conn.close();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
			}
		
		return out;
	}
	
	public ArrayList<Integer> getFirstFiveSumIncludesBasedOnBucketAndPercentile(String gameCode, int serialNum, int bucket, int safePercentile ) {
		ArrayList<Integer> out = new ArrayList<Integer>();
		
		HashSet<Integer> uniqs = new HashSet<Integer>();
		if (gameCode == null) {
			System.out.println("ResultHistoryEntity.getFirstFiveSumExcludesBasedOnBucketAndPercentile: Set gameCode first.");
			return out;
		}
		
		String serialClause = "";
		
		int totalrecords = 0;
		
		if (serialNum > 0) {
			serialClause = " and serialNumber <= " + serialNum;
			
		}
		
		if (safePercentile == 0)
			safePercentile = 60;
	
		Connection conn = getConnection();
	
		Statement stmt;
		try {
			stmt = conn.createStatement();
			// Get the most likely follower pattern maps
			ResultSet rs = null;
			if (totalrecords ==0) {
				String sql2 = "select count(*) as records from jointView where gameCode = " + gameCode + serialClause + "  and firstFiveSumBucket = " + bucket ;
				rs = stmt.executeQuery(sql2);
				
				if (rs.next()) {
					totalrecords = rs.getInt("records");
					rs.close();
				}
			}
			
			
			rs = stmt.executeQuery("select ifnull(firstFiveSum,0) , count(*) as freq	from (select serialNumber, ifnull(firstFiveSum,0) as firstFiveSum from jointView a where  gameCode = " + 
					gameCode  + serialClause + "  and a.firstFiveSumBucket = " + bucket + 
					 " order by serialNumber desc  ) as temp group by firstFiveSum	order by count(*) desc") ;
			  
			ArrayList<Integer> excludes = new ArrayList<Integer>();
			
			int percentilesSoFar = 0;
			
			while (rs.next()) {
				
				int thisVal = rs.getInt(1);
				int thisCount = rs.getInt(2);
				
				percentilesSoFar += thisCount*100/totalrecords;
		  				  		
				if (percentilesSoFar < safePercentile)
					excludes.add( thisVal);
							
		  	}
			
			rs.close();
			
			//Commenting since we want the values to be INCLUDED
			//Retrying...
			for (int i=0; i<10; i++) {
				if (!excludes.contains(bucket*10+i)) {
					 out.add(bucket*10+i);
				}
			}
			
			//out.addAll(excludes);
			
	  	
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				if (conn != null)
					conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		
		return out;
	}
	
	
	public List getColumnNames() {
		ArrayList l = new ArrayList();
		Connection conn = null;
		
		String sql = "show columns from " + getTableName();
		
		try {
			
			conn = getConnection();
			Statement stmt = conn.createStatement();
			
			ResultSet rs = stmt.executeQuery(sql);
			
			int previousSerial = 0;
			while (rs.next()) {
				String thisField = rs.getString("field");
				
				if (!(thisField.equals("gameCode") || thisField.equals("serialNumber") || thisField.equals("withinLast")))
					l.add(thisField);
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			if (conn != null)
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		
		return l;
	}


}
