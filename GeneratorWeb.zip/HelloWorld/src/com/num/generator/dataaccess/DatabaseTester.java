package com.num.generator.dataaccess;

public class DatabaseTester {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		ResultHistoryEntity rhe = new ResultHistoryEntity();
		
		/*rhe.setDayOfTheWeek("Tue");
		rhe.setGameCode("1");
		rhe.setSerialNumber("20130203");
		rhe.setFirstValue("3");
		rhe.setSecondValue("12");
		rhe.setThirdValue("23");
		rhe.setFourthValue("45");
		rhe.setFifthValue("52");
		rhe.setMegaValue("12");
		
		rhe.create();*/
		System.out.println(rhe.getFollowers("megaFollower", 2, 0));
	}

}
