package com.num.generator.dataaccess;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Collection;
import java.util.List;

import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

public abstract class Base {
	
	public Base() {
		 /*Connection conn = null;
		try {
			Class.forName("com.mysql.jdbc.Driver").newInstance();
		   // conn = DriverManager.getConnection(ConnectionParams.getDatabaseURL(), ConnectionParams.getUser(), ConnectionParams.getPassword());
		    
		    Statement stmt = conn.createStatement();
		  
		  	ResultSet rs = stmt.executeQuery("Select * from game_types");
		  	
		  	while (rs.next()) {
		  		
		  		System.out.println("Game name : " + rs.getString("gameName") + " Game code : " + rs.getString("gameCode"));
		  	}
		    
		    
		} catch (SQLException ex) {
		    // handle any errors
		    System.out.println("SQLException: " + ex.getMessage());
		    System.out.println("SQLState: " + ex.getSQLState());
		    System.out.println("VendorError: " + ex.getErrorCode());
		} catch (InstantiationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				if (conn != null)
					conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}*/
	}
	
	public Connection getConnection () {
		Connection conn = null;
		try {
			Class.forName("com.mysql.jdbc.Driver").newInstance();
		    conn = DriverManager.getConnection(ConnectionParams.getDatabaseURL(), ConnectionParams.getUser(), ConnectionParams.getPassword());
		   
		} catch (SQLException ex) {
		    // handle any errors
		    System.out.print("SQLException: " + ex.getMessage());
		    System.out.print(" + SQLState: " + ex.getSQLState());
		    System.out.println(" + VendorError: " + ex.getErrorCode());
		} catch (InstantiationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return conn;
	}
	
	public boolean create() {
		boolean out = false;
		int outInt = 0;
		Connection conn = getConnection();
		Statement stmt;
		try {
			stmt = conn.createStatement();
			outInt = stmt.executeUpdate(getInsertSQL());
			
			if (conn != null) conn.close();
			
		} catch (SQLException e) {
			System.out.println("SQL Exception in " + this.getClass().getName() + " while inserting a row: SQLSTATE: " + e.getSQLState() + " CAUSE: " + e.getCause());
			//System.out.println(getInsertSQL());
		}
		
		if (outInt > 0) out = true;
		
		return out;
	}
	
	public int createWithAutoIncrement() {
		int out = -1;
		Connection conn = getConnection();
		PreparedStatement stmt;
		try {
			stmt = conn.prepareStatement(getInsertSQL(),Statement.RETURN_GENERATED_KEYS);
			stmt.executeUpdate();
			
			ResultSet rs = stmt.getGeneratedKeys();
			if (rs.next()){
				out=rs.getInt(1);
			}
			
			if (conn != null) conn.close();
			
		} catch (SQLException e) {
			System.out.println("SQL Exception while inserting a row: SQLSTATE: " + e.getSQLState() + " CAUSE: " + e.getCause());
			//System.out.println(getInsertSQL());
		}
		
		
		return out;
	}
	
	public boolean update() {
		boolean out = false;
		int outInt = 0;
		Connection conn = getConnection();
		Statement stmt;
		try {
			stmt = conn.createStatement();
			outInt = stmt.executeUpdate(getUpdateSQL());
			
			if (conn != null) conn.close();
			
		} catch (SQLException e) {
			System.out.println("SQL Exception while updating a row: SQLSTATE: " + e.getSQLState() + " CAUSE: " + e.getCause());
		}
		
		if (outInt > 0) out = true;
		
		return out;
	}
	
	public abstract String getTableName();
	
	public abstract String getInsertSQL();
	
	public abstract String getUpdateSQL();
	
	public abstract Collection readAll ();
	
	public abstract Collection findRows ();
	
	public String toString() {
		return ReflectionToStringBuilder.toString(this, ToStringStyle.MULTI_LINE_STYLE);
	}
	
	

}
