package com.num.generator.dataaccess;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Hashtable;
import java.util.Iterator;

public class GameBucketEntity extends Base {

	private String gameCode;
	private String firstBucket;
	private String secondBucket;
	private String thirdBucket;
	private String fourthBucket;
	private String fifthBucket;
	private String instances;
	private String bucketRank;
	private String bucketGapMapRank;
	
	private ArrayList<GameBucketEntity> listOfBuckets = new ArrayList<GameBucketEntity>();
	private static ArrayList<String> highRankingBuckets = new ArrayList<String>();
	
	
	public static void main(String[] args) {
		GameBucketEntity e = new GameBucketEntity();
		System.out.println("Creating GameBuckets ");
		
		e.populateGameBuckets("1");
		/*e.populateMaxFactorRanks("2");
		e.populateFollowerMapRanks("1");
		e.populateMissingDigitRanks("1");
		*/
		
	}
	
	
	
	public String getGameCode() {
		return gameCode;
	}

	public void setGameCode(String gameCode) {
		this.gameCode = gameCode;
	}

	public String getFirstBucket() {
		return firstBucket;
	}

	public void setFirstBucket(String firstBucket) {
		this.firstBucket = firstBucket;
	}

	public String getSecondBucket() {
		return secondBucket;
	}

	public void setSecondBucket(String secondBucket) {
		this.secondBucket = secondBucket;
	}

	public String getThirdBucket() {
		return thirdBucket;
	}

	public void setThirdBucket(String thirdBucket) {
		this.thirdBucket = thirdBucket;
	}

	public String getFourthBucket() {
		return fourthBucket;
	}

	public void setFourthBucket(String fourthBucket) {
		this.fourthBucket = fourthBucket;
	}

	public String getFifthBucket() {
		return fifthBucket;
	}

	public void setFifthBucket(String fifthBucket) {
		this.fifthBucket = fifthBucket;
	}

	public String getBucketRank() {
		return bucketRank;
	}

	public void setBucketRank(String bucketRank) {
		this.bucketRank = bucketRank;
	}

	public ArrayList<GameBucketEntity> getListOfBuckets() {
		return listOfBuckets;
	}

	public void setListOfBuckets(ArrayList<GameBucketEntity> listOfBuckets) {
		this.listOfBuckets = listOfBuckets;
	}

	public String getInstances() {
		return instances;
	}

	public void setInstances(String instances) {
		this.instances = instances;
	}

	public ArrayList<String> getHighRankingBuckets() {
		return highRankingBuckets;
	}

	public void setHighRankingBuckets(ArrayList<String> highRankingBuckets) {
		this.highRankingBuckets = highRankingBuckets;
	}

	public String getTableName() {
		// TODO Auto-generated method stub
		return " game_buckets ";
	}

	@Override
	public String getInsertSQL() {
		
		if (listOfBuckets != null && listOfBuckets.size() > 0)
			return getMultipleInsertSQL();
		
		StringBuffer buff = new StringBuffer();
		
		StringBuffer internalBuffer = new StringBuffer();
		
		buff.append("Insert into " + getTableName() + "( ");
		
		if (getGameCode() != null)  {
			buff.append("gameCode,");
			internalBuffer.append("'" + getGameCode() + "',");
		}
		
		
		if (getFirstBucket() != null)  {
			buff.append("firstBucket,");
			internalBuffer.append("'" + getFirstBucket() + "',");
		}
		
		if (getSecondBucket() != null)  {
			buff.append("secondBucket,");
			internalBuffer.append("'" + getSecondBucket() + "',");
		}
		
		if (getThirdBucket() != null)  {
			buff.append("thirdBucket,");
			internalBuffer.append("'" + getThirdBucket() + "',");
		}
		
		if (getFourthBucket() != null)  {
			buff.append("fourthBucket,");
			internalBuffer.append("'" + getFourthBucket() + "',");
		}
		
		if (getFifthBucket() != null)  {
			buff.append("fifthBucket,");
			internalBuffer.append("'" + getFifthBucket() + "',");
		}
		
		if (getInstances() != null)  {
			buff.append("instances,");
			internalBuffer.append("'" + getInstances() + "',");
		}
		
		if (getBucketRank() != null)  {
			buff.append("bucketRank,");
			internalBuffer.append("'" + getBucketRank() + "',");
		}
		
		if (getBucketGapMapRank() != null)  {
			buff.append("bucketGapMapRank,");
			internalBuffer.append("'" + getBucketGapMapRank() + "',");
		}
		
		
		return buff.substring(0,buff.length()-1) + ") values ( "+ internalBuffer.substring(0,internalBuffer.length()-1) + ")" ;
	}

	private String getMultipleInsertSQL() {
		StringBuffer buff = new StringBuffer();
		
		StringBuffer internalBuffer = new StringBuffer();
		
		buff.append("Insert into " + getTableName() + "( ");
		
		Iterator it = listOfBuckets.iterator();
		
		int counter = 0;
		
		while(it.hasNext()) {
			GameBucketEntity gb = (GameBucketEntity) it.next();
			if (counter == 0) {
				if (gb.getGameCode() != null)  {
					buff.append("gameCode,");
					internalBuffer.append("'" + gb.getGameCode() + "',");
				}
				
				if (gb.getFirstBucket() != null)  {
					buff.append("firstBucket,");
					internalBuffer.append("'" + gb.getFirstBucket() + "',");
				}
				
				if (gb.getSecondBucket() != null)  {
					buff.append("secondBucket,");
					internalBuffer.append("'" + gb.getSecondBucket() + "',");
				}
				
				if (gb.getThirdBucket() != null)  {
					buff.append("thirdBucket,");
					internalBuffer.append("'" + gb.getThirdBucket() + "',");
				}
				
				if (gb.getFourthBucket() != null)  {
					buff.append("fourthBucket,");
					internalBuffer.append("'" + gb.getFourthBucket() + "',");
				}
				
				if (gb.getFifthBucket() != null)  {
					buff.append("fifthBucket,");
					internalBuffer.append("'" + gb.getFifthBucket() + "',");
				}
				
				if (gb.getInstances() != null)  {
					buff.append("instances,");
					internalBuffer.append("'" + gb.getInstances() + "',");
				}
				
				if (gb.getBucketRank() != null)  {
					buff.append("bucketRank,");
					internalBuffer.append("'" + gb.getBucketRank() + "',");
				}
				
				if (gb.getBucketGapMapRank() != null)  {
					buff.append("bucketGapMapRank,");
					internalBuffer.append("'" + gb.getBucketGapMapRank() + "',");
				}
				
				
				internalBuffer.deleteCharAt(internalBuffer.length()-1);
				internalBuffer.append(")");
				
			} else {
				internalBuffer.append(",(");
				if (gb.getGameCode() != null)  {
					internalBuffer.append("'" + gb.getGameCode() + "',");
				}
				
				if (gb.getFirstBucket() != null)  {
					internalBuffer.append("'" + gb.getFirstBucket() + "',");
				}
				
				if (gb.getSecondBucket() != null)  {
					internalBuffer.append("'" + gb.getSecondBucket() + "',");
				}
				
				if (gb.getThirdBucket() != null)  {
					internalBuffer.append("'" + gb.getThirdBucket() + "',");
				}
				
				if (gb.getFourthBucket() != null)  {
					internalBuffer.append("'" + gb.getFourthBucket() + "',");
				}
				
				if (gb.getFifthBucket() != null)  {
					internalBuffer.append("'" + gb.getFifthBucket() + "',");
				}
				
				if (gb.getInstances() != null)  {
					internalBuffer.append("'" + gb.getInstances() + "',");
				}
				
				if (gb.getBucketRank() != null)  {
					internalBuffer.append("'" + gb.getBucketRank() + "',");
				}
				
				if (gb.getBucketGapMapRank() != null)  {
					internalBuffer.append("'" + gb.getBucketGapMapRank() + "',");
				}
				
				internalBuffer.deleteCharAt(internalBuffer.length()-1);
				internalBuffer.append(")");
			}
			
			counter++;
		
		}
		
		
		return buff.substring(0,buff.length()-1) + ") values ( "+ internalBuffer.toString() ;
	}
	

	@Override
	public String getUpdateSQL() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Collection readAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Collection findRows() {
		// TODO Auto-generated method stub
		return null;
	}
	
	public int populateGameBuckets(String gameCode) {
		int updatedCount = 0;
		
		// FIRST find if game_buckets for this gameCode need to be populated
		
		if (gameCode == null)  {
			System.out.println("Pass a valid gameCode ");
			return -1;
		}
		
		String sql1 = "select sum(instances) as totals from game_buckets where gameCode =  " + gameCode ;

		Connection conn = null;
		boolean doInsert = false;
		try {
			
			conn = getConnection();
			Statement stmt = conn.createStatement();
			
			ResultSet rs = stmt.executeQuery(sql1);
			
			int instances = 0;
			
			if (rs.next()) {
				instances = rs.getInt("totals");
				
				rs.close();
				
				if (instances > 0) {
					String sql2 = "select count(*) as records from jointView where gameCode = " + gameCode ;
					rs = stmt.executeQuery(sql2);
					
					if (rs.next()) {
						if ((rs.getInt("records") - instances) > 0) doInsert = true;
						rs.close();
					}
					
				} else {
					doInsert = true;
				}
			}
			
			if (doInsert) {
				if (instances > 0) {// DELETE all first
					int outInt = stmt.executeUpdate("delete from " + getTableName() + "  where gameCode = "  + gameCode);
					
					if (outInt > 0)
						doInsert = true;
				}
				
				if (doInsert) {
					// First compute bucketMapRank
					Hashtable<String, Integer> bucketMapRankHash = new Hashtable<String, Integer>();
					String sqlbm = "select firstBucket, secondBucket, thirdBucket, fourthBucket, fifthBucket, concat(" +
									"(secondValue DIV 10) - (firstValue div 10) , " +
									"(thirdValue DIV 10) - (secondValue div 10) , " +
									"(fourthValue DIV 10) - (thirdValue div 10) , " +
									"(fifthValue DIV 10) - (fourthValue div 10) " +
									") as paramValue, count(*) as instances " +
							" from jointView where gameCode = "  + gameCode +
							" group by paramValue " +
							" order by count(*) desc , paramValue";
					
					rs = stmt.executeQuery(sqlbm);
					int counter = 1;
					while (rs.next()) {
						String bucketdef = rs.getString("paramValue");
						bucketMapRankHash.put(bucketdef, counter);
						counter++;
					}
					
					String sql3 = "select firstBucket, secondBucket, thirdBucket, fourthBucket, fifthBucket, count(*) as instances " +
									" from jointView where gameCode = "  + gameCode +
									" group by firstBucket, secondBucket, thirdBucket, fourthBucket, fifthBucket " +
									" order by count(*) desc , firstBucket, secondBucket, thirdBucket, fourthBucket, fifthBucket";
					
					rs = stmt.executeQuery(sql3);
					counter = 1;
					while (rs.next()) {
						GameBucketEntity gb = new GameBucketEntity();
						gb.setGameCode(gameCode);
						gb.setFirstBucket(rs.getString("firstBucket"));
						gb.setSecondBucket(rs.getString("secondBucket"));
						gb.setThirdBucket(rs.getString("thirdBucket"));
						gb.setFourthBucket(rs.getString("fourthBucket"));
						gb.setFifthBucket(rs.getString("fifthBucket"));
						gb.setInstances(rs.getString("instances"));
						gb.setBucketRank(Integer.toString(counter));
						
						String bucketGapmap = Integer.toString(Integer.parseInt(gb.getSecondBucket()) - Integer.parseInt(gb.getFirstBucket())) + 
								Integer.toString(Integer.parseInt(gb.getThirdBucket()) - Integer.parseInt(gb.getSecondBucket())) + 
								Integer.toString(Integer.parseInt(gb.getFourthBucket()) - Integer.parseInt(gb.getThirdBucket())) + 
								Integer.toString(Integer.parseInt(gb.getFifthBucket()) - Integer.parseInt(gb.getFourthBucket())) ;
						
						if (bucketMapRankHash.get(bucketGapmap
							) != null) {
							gb.setBucketGapMapRank(Integer.toString(bucketMapRankHash.get(bucketGapmap)));
						} else {
 							System.out.println("no map rank for " + bucketGapmap);
						}
						
						listOfBuckets.add(gb);
						counter++;
					}
					
					this.create();
				}
				
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			if (conn != null)
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
				
		return updatedCount;
		
	}
	
	public boolean isHighRankingBucket(String buckets, String gameCode,  int within) {
		
		boolean out =  false;
		
		if (getHighRankingBucketList(gameCode, within).contains(buckets)) out = true;
		
		return out;
		
	}
	
	public ArrayList<String> getHighRankingBucketList(String gameCode, int within) {
		
		highRankingBuckets = new ArrayList<String>();
		if (getHighRankingBuckets() == null) {
			if (within == 0)
				within = 100;  // Default to 100
			
			String sql1 = "select firstBucket,secondBucket,thirdBucket,fourthBucket,fifthBucket from game_buckets where gameCode =  " + gameCode + " and bucketRank <= " +  within;
			
			Connection conn = null;
			boolean doInsert = false;
			try {
				
				conn = getConnection();
				Statement stmt = conn.createStatement();
				
				ResultSet rs = stmt.executeQuery(sql1);
				
				while (rs.next()) {
					String buck = "";
				
					buck += rs.getString("firstBucket");
					buck += rs.getString("secondBucket");
					buck += rs.getString("thirdBucket");
					buck += rs.getString("fourthBucket");
					buck += rs.getString("fifthBucket");
	
					highRankingBuckets.add(buck);
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} finally {
				if (conn != null)
					try {
						conn.close();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
			}
			
			return highRankingBuckets;
			
		} else {
			return getHighRankingBuckets();
		}
		
		
	}
	
	
	public ArrayList<String> getUnlikelyBucketsList(String gameCode, int within) { // We select the buckets that have appeared in previous history which have a high bucket rank
		
		ArrayList<String> out = new ArrayList<String>();
			
			if (within == 0)
				within = 200;  // Default to 200 
			
			String sql1 = "	select * from (	SELECT  v.serialNumber, v.firstBucket,  v.secondBucket, v.thirdBucket, v.fourthBucket, v.fifthBucket, v.bucketSkip, g.bucketRank, g.bucketGapMapRank " +
											" FROM jointView v left outer join game_buckets g " +
											" on v.gameCode = g.gameCode " +
												" and v.firstBucket = g.firstBucket " +
												" and v.secondBucket = g.secondBucket " +
												" and v.thirdBucket = g.thirdBucket " +
												" and v.fourthBucket = g.fourthBucket " +
												" and v.fifthBucket = g.fifthBucket " +
											" where v.gameCode = " + gameCode + 
											" order by v.serialNumber desc LIMIT " + within +
											" ) as temp " +
							" where temp.bucketRank > 100  " 
						//	+ " or ( temp.bucketGapMapRank % 2 = 1 and temp.bucketRank % 2 = 1)"
						//	+ " or temp.bucketGapMapRank > 44"
							;
			
			Connection conn = null;
			try {
				
				conn = getConnection();
				Statement stmt = conn.createStatement();
				
				ResultSet rs = stmt.executeQuery(sql1);
				
				while (rs.next()) {
					String buck = "";
				
					buck += rs.getString("firstBucket");
					buck += rs.getString("secondBucket");
					buck += rs.getString("thirdBucket");
					buck += rs.getString("fourthBucket");
					buck += rs.getString("fifthBucket");
	
					out.add(buck);
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} finally {
				if (conn != null)
					try {
						conn.close();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
			}
			
			return out;
			
		
		
		
	}
	
	public int getBucketRankForGameAndSerial(String gameCode, int serialNumber) {
		int rank = 0;
		String serialClause = "";
		
		if (serialNumber > 0) {
			serialClause = " and serialNumber <= " + serialNumber;
		}
		
		Connection conn = getConnection();
		
		Statement stmt;
		try {
			stmt = conn.createStatement();
	
		  	ResultSet rs = stmt.executeQuery("select CONCAT(g.firstBucket,g.secondBucket, g.thirdBucket, g.fourthBucket, g.fifthBucket) as paramValue, g.bucketRank as paramRank, serialNumber from game_buckets g, jointView v where v.gameCode = " + gameCode + serialClause + 
		  						" and v.gameCode = g.gameCode and v.firstBucket = g.firstBucket and v.secondBucket = g.secondBucket and v.thirdBucket = g.thirdBucket and v.fourthBucket = g.fourthBucket and v.fifthBucket = g.fifthBucket " +
		  						" order by serialNumber desc LIMIT 1");
		  	
		  	if (rs.next()) {
		  		rank = rs.getInt("paramRank");
		  	}
		  	
		 	  		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				if (conn != null)
					conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		return rank;
	}
	
	public Hashtable<String, Integer> getBucketRanksForGame(String gameCode) {
		Hashtable<String, Integer> out = new Hashtable<String, Integer>();
				
		Connection conn = getConnection();
		
		Statement stmt;
		try {
			stmt = conn.createStatement();
			
		  	ResultSet rs = stmt.executeQuery("select CONCAT(g.firstBucket,g.secondBucket, g.thirdBucket, g.fourthBucket, g.fifthBucket) as value, g.bucketRank as rank from game_buckets g where g.gameCode = " + gameCode);
		  	
		  	while (rs.next()) {
		  		out.put(rs.getString("value"), rs.getInt("rank"));
		  	}
		  	
		 	  		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				if (conn != null)
					conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		return out;
	}

	public String getBucketGapMapRank() {
		return bucketGapMapRank;
	}

	public void setBucketGapMapRank(String bucketMapRank) {
		this.bucketGapMapRank = bucketMapRank;
	}

}
