package com.num.generator.dataaccess;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Hashtable;
import java.util.Iterator;

public class FollowerPatternEntity extends Base {
	
	private String gameCode = null;
	private String serialNumber= null;
	private String 	firstValue = null;
	private String secondValue = null;
	private String thirdValue = null;
	private String fourthValue = null;
	private String fifthValue = null;
	private String megaValue = null;
	private String match3Diff = null;
	private String miss3Diff = null;
	private String match3Gaps = null;
	public String getMatch3Gaps() {
		return match3Gaps;
	}

	public void setMatch3Gaps(String match3Gaps) {
		this.match3Gaps = match3Gaps;
	}

	public String getMiss3Gaps() {
		return miss3Gaps;
	}

	public void setMiss3Gaps(String miss3Gaps) {
		this.miss3Gaps = miss3Gaps;
	}

	private String miss3Gaps = null;
	private String followerMapSkip = null;
	
	private static Collection last10Patterns = null;
	private static Hashtable currentFollowerTable = null;
	
	public static void main(String[] args) {
		FollowerPatternEntity e = new FollowerPatternEntity();
		System.out.println("Current followers for gameCode 1 ");
		System.out.println(e.getCurrentFollowerTableForGame("1").toString());
		
		e.populateLast10Patterns("1",0);
		
		ArrayList<String> excludes = (ArrayList<String>) e.getLast10Patterns();
		
		ArrayList<String> allpatterns = e.getAllPossibleFollowerPatterns("1");
		
		Iterator<String> it = excludes.iterator();
		
		while (it.hasNext()) {
			String removed = it.next();
			if (allpatterns.contains(removed.substring(0, removed.length()-1)))
					allpatterns.remove(removed.substring(0, removed.length()-1));
		}
		
		System.out.println("Excluded " + excludes.toString());
		System.out.println("Possible " + allpatterns.toString());
		
	}
	
	public static Hashtable getCurrentFollowerTable() {
		return currentFollowerTable;
	}

	public static void setCurrentFollowerTable(Hashtable currentFollowerTable) {
		FollowerPatternEntity.currentFollowerTable = currentFollowerTable;
	}
	
	public String getGameCode() {
		return gameCode;
	}

	public void setGameCode(String gameCode) {
		this.gameCode = gameCode;
	}

	public String getSerialNumber() {
		return serialNumber;
	}

	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}

	public String getFirstValue() {
		return firstValue;
	}

	public void setFirstValue(String firstValue) {
		this.firstValue = firstValue;
	}

	public String getSecondValue() {
		return secondValue;
	}

	public void setSecondValue(String secondValue) {
		this.secondValue = secondValue;
	}

	public String getThirdValue() {
		return thirdValue;
	}

	public void setThirdValue(String thirdValue) {
		this.thirdValue = thirdValue;
	}

	public String getFourthValue() {
		return fourthValue;
	}

	public void setFourthValue(String fourthValue) {
		this.fourthValue = fourthValue;
	}

	public String getFifthValue() {
		return fifthValue;
	}

	public void setFifthValue(String fifthValue) {
		this.fifthValue = fifthValue;
	}

	public String getMegaValue() {
		return megaValue;
	}

	public void setMegaValue(String megaValue) {
		this.megaValue = megaValue;
	}

	public String getMatch3Diff() {
		return match3Diff;
	}

	public void setMatch3Diff(String match3Diff) {
		this.match3Diff = match3Diff;
	}

	public String getMiss3Diff() {
		return miss3Diff;
	}

	public void setMiss3Diff(String miss3Diff) {
		this.miss3Diff = miss3Diff;
	}

	public static Collection getLast10Patterns() {
		return last10Patterns;
	}

	public static void setLast10Patterns(Collection last10Patterns) {
		FollowerPatternEntity.last10Patterns = last10Patterns;
	}


	public String getFollowerMapSkip() {
		return followerMapSkip;
	}

	public void setFollowerMapSkip(String followerMapSkip) {
		this.followerMapSkip = followerMapSkip;
	}

	@Override
	public String getTableName() {
		return " follower_patterns ";
	}

	@Override
	public String getInsertSQL() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Collection readAll() {
		return null;
	}
	
	public void populateLast10Patterns (String gameCode, int excludeLastN) {
		
		if (excludeLastN == 0)
			excludeLastN = 15;
		
		int excludeSpan = 70;
		
		System.out.println("FollowerPatternEntity:populateLast10Patterns : Excluding bottom " + (32 - excludeLastN) + " ranked follower maps from last " + excludeSpan + " draws");
		
		if (getLast10Patterns() == null) {
			Collection out = new ArrayList();
			Connection conn = getConnection();
			
			Statement stmt;
			try {
				stmt = conn.createStatement();
				// Get the most likely follower pattern maps
				ResultSet rs = stmt.executeQuery("select CONCAT(firstValue,secondValue, thirdValue, fourthValue, fifthValue) as folmap from " + getTableName() + " where gameCode = " + gameCode +  
										" group by CONCAT(firstValue,secondValue, thirdValue, fourthValue, fifthValue)  order by  count(*) desc LIMIT " + excludeLastN) ;
				  
				StringBuffer excludes = new StringBuffer();
				while (rs.next()) {
			  				  		
			  		excludes.append("'" + rs.getString("folmap") + "',");
			  	}
				
				rs.close();
			  	
				// Get all the maps that appeared in last 50 results and match the least likely maps
				// We will not consider these
				rs = stmt.executeQuery("Select * from " + getTableName() + " where gameCode = " + gameCode + 
													" and serialNumber > (select max(serialNumber) from follower_patterns where gameCode = " + gameCode +") -  " + excludeSpan +
													" and CONCAT(firstValue,secondValue, thirdValue, fourthValue, fifthValue) not in " +
													"(" + excludes.toString().substring(0,excludes.length()-1) + ") order by serialNumber desc");
			  	
			  	while (rs.next()) {
			  		//FollowerPatternEntity fte = new FollowerPatternEntity();
			  		//fte.setGameCode(rs.getString("gameCode"));
			  		//fte.setSerialNumber(rs.getString("serialNumber"));
			  		String pattern = "";
			  		pattern += rs.getString("firstValue");
			  		pattern += rs.getString("secondValue");
			  		pattern += rs.getString("thirdValue");
			  		pattern += rs.getString("fourthValue");
			  		pattern += rs.getString("fifthValue");
			  		//pattern += rs.getString("megaValue");
			  				  		
			  		out.add(pattern);
			  	}
		  	
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} finally {
				try {
					if (conn != null)
						conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			setLast10Patterns(out);
		}
	}
	
	
	public ArrayList<String> getAllPossibleFollowerPatterns (String gameCode) {
		ArrayList<String> out = new ArrayList<String>();
		
			Connection conn = getConnection();
			
			Statement stmt;
			try {
				stmt = conn.createStatement();
				// Get the most likely follower pattern maps
				ResultSet rs = stmt.executeQuery("select firstValue,secondValue, thirdValue, fourthValue, fifthValue from " + getTableName() + " where gameCode = " + gameCode +  
										" group by firstValue,secondValue, thirdValue, fourthValue, fifthValue  order by  count(*) desc  " ) ;
				  
				
			  	while (rs.next()) {
			  		//FollowerPatternEntity fte = new FollowerPatternEntity();
			  		//fte.setGameCode(rs.getString("gameCode"));
			  		//fte.setSerialNumber(rs.getString("serialNumber"));
			  		String pattern = "";
			  		pattern += rs.getString("firstValue");
			  		pattern += rs.getString("secondValue");
			  		pattern += rs.getString("thirdValue");
			  		pattern += rs.getString("fourthValue");
			  		pattern += rs.getString("fifthValue");
			  		
			  				  		
			  		out.add(pattern);
			  	}
		  	
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} finally {
				try {
					if (conn != null)
						conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			
		
		return out;
	}

	public Hashtable returnFollowerTableForASerialNumber(String serialNum, String ingameCode) { // This table contains the list of followers for all the 6 numbers 
																				// from previous results
		String firstSQL = "select distinct n.number	from result_history a, result_history b , result_history c  ,game_types t, num_values n " +
							 " where a.gameCode = c.gameCode and a.gameCode = b.gameCode and a.gameCode = " + ingameCode + " and a.serialNumber = b.serialNumber +1 " +
							 " and b.firstValue = c.firstValue and c.serialNumber= " + serialNum + " and b.serialNumber < c.serialNumber " +
							 " and t.gameCode = a.gameCode and n.number <= t.maximumValue and n.number = a.firstValue";
		
		String secondSQL = "select distinct n.number	from result_history a, result_history b , result_history c  ,game_types t, num_values n " +
				 " where a.gameCode = c.gameCode and a.gameCode = b.gameCode and a.gameCode = " + ingameCode + " and a.serialNumber = b.serialNumber +1 " +
		 					" and b.secondValue = c.secondValue and c.serialNumber= " + serialNum + " and b.serialNumber < c.serialNumber " +
		 					" and t.gameCode = a.gameCode and n.number <= t.maximumValue and n.number = a.secondValue";

		
		String thirdSQL = "select distinct n.number	from result_history a, result_history b , result_history c  ,game_types t, num_values n " +
				 " where a.gameCode = c.gameCode and a.gameCode = b.gameCode and a.gameCode = " + ingameCode + " and a.serialNumber = b.serialNumber +1 " +
		 					" and b.thirdValue = c.thirdValue and c.serialNumber= " + serialNum + " and b.serialNumber < c.serialNumber " +
		 					" and t.gameCode = a.gameCode and n.number <= t.maximumValue and n.number = a.thirdValue";

		
		String fourthSQL = "select distinct n.number	from result_history a, result_history b , result_history c  ,game_types t, num_values n " +
				 " where a.gameCode = c.gameCode and a.gameCode = b.gameCode and a.gameCode = " + ingameCode + " and a.serialNumber = b.serialNumber +1 " +
				" and b.fourthValue = c.fourthValue and c.serialNumber= " + serialNum + " and b.serialNumber < c.serialNumber " +
		 					" and t.gameCode = a.gameCode and n.number <= t.maximumValue and n.number = a.fourthValue";

		
		String fifthSQL = "select distinct n.number	from result_history a, result_history b , result_history c  ,game_types t, num_values n " +
				 " where a.gameCode = c.gameCode and a.gameCode = b.gameCode and a.gameCode = " + ingameCode + " and a.serialNumber = b.serialNumber +1 " +
		 					" and b.fifthValue = c.fifthValue and c.serialNumber= " + serialNum + " and b.serialNumber < c.serialNumber " +
		 					" and t.gameCode = a.gameCode and n.number <= t.maximumValue and n.number = a.fifthValue";

					
		String megaSQL = "select distinct n.number from result_history a, result_history b , result_history c  ,game_types t, num_values n " +
				 " where a.gameCode = c.gameCode and a.gameCode = b.gameCode and a.gameCode = " + ingameCode + " and a.serialNumber = b.serialNumber +1 " +
						" and b.megaValue = c.megaValue	and c.serialNumber= " + serialNum + " and b.serialNumber < c.serialNumber " +
						" and t.gameCode = a.gameCode and n.number <= t.maxMegaValue and n.number = a.megaValue";
		
		Hashtable out = new Hashtable();
		
		Connection conn = getConnection();
		
		Statement stmt;
		try {
			stmt = conn.createStatement();
			  
		  	ResultSet rs = stmt.executeQuery(firstSQL);
		  	ArrayList nums = new ArrayList();
		  	while (rs.next()) {
		  		nums.add(rs.getString("number"));
		  	}
		  	out.put("1", nums);
		  	
		  	rs = stmt.executeQuery(secondSQL);
		  	nums = new ArrayList();
		  	while (rs.next()) {
		  		nums.add(rs.getString("number"));
		  	}
		  	out.put("2", nums);
		  	
		  	rs = stmt.executeQuery(thirdSQL);
		  	nums = new ArrayList();
		  	while (rs.next()) {
		  		nums.add(rs.getString("number"));
		  	}
		  	out.put("3", nums);
		  	
		  	rs = stmt.executeQuery(fourthSQL);
		  	nums = new ArrayList();
		  	while (rs.next()) {
		  		nums.add(rs.getString("number"));
		  	}
		  	out.put("4", nums);
		  	
		  	rs = stmt.executeQuery(fifthSQL);
		  	nums = new ArrayList();
		  	while (rs.next()) {
		  		nums.add(rs.getString("number"));
		  	}
		  	out.put("5", nums);
		  	
		  	
		  	rs = stmt.executeQuery(megaSQL);
		  	nums = new ArrayList();
		  	while (rs.next()) {
		  		nums.add(rs.getString("number"));
		  	}
		  	out.put("MEGA", nums);
	  	
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				if (conn != null)
					conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return out;
	}
	
	
	public Hashtable getCurrentFollowerTableForGame(String gameCode) {
		Hashtable out = null;
		if (currentFollowerTable == null || currentFollowerTable.get(gameCode) == null) {
			
			Connection conn = getConnection();
			
			Statement stmt;
			try {
				stmt = conn.createStatement();
				  
			  	ResultSet rs = stmt.executeQuery("Select serialNumber from result_history where gameCode = " + gameCode + " order by serialNumber desc LIMIT 1");
			  	String maxserial = null;
			  	while (rs.next()) {
			  		maxserial = rs.getString("serialNumber");
			  	}
			  	
			  	try {
					if (conn != null)
						conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				if (getCurrentFollowerTable() == null)
					setCurrentFollowerTable(new Hashtable());
				out = returnFollowerTableForASerialNumber(maxserial, gameCode);
				getCurrentFollowerTable().put(gameCode, out);
		  		
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} finally {
				try {
					if (conn != null)
						conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			
		} else {
			out = (Hashtable)currentFollowerTable.get(gameCode);
		}
		return out;
	}
	
	public int getFollowerPatternRankForGameAndSerial(String gameCode, int serialNumber) {
		int rank = 0;
		String serialClause = "";
		
		if (serialNumber > 0) {
			serialClause = " and serialNumber <= " + serialNumber;
		}
		
		Connection conn = getConnection();
		
		Statement stmt;
		try {
			stmt = conn.createStatement();
			  
		  	ResultSet rs = stmt.executeQuery("select paramValue, paramRank, serialNumber from aggregate_ranks agr, follower_patterns f where f.gameCode = " + gameCode + serialClause + 
		  						" and f.gameCode = agr.gameCode and  agr.paramType = 'FOL' and  agr.paramValue = CONCAT(f.firstValue,f.secondValue, f.thirdValue, f.fourthValue, f.fifthValue) " +
		  						" order by serialNumber desc LIMIT 1");
		  	
		  	if (rs.next()) {
		  		rank = rs.getInt("paramRank");
		  	}
		  	
		 	  		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				if (conn != null)
					conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		return rank;
	}
	
	public static Hashtable<String, Integer> getAllFollowerPatternRanks(String gameCode, int serialNumber) {
		Hashtable<String, Integer> ranks = new Hashtable<String, Integer>();
		
		
		return ranks;
	}
	
	
	@Override
	public Collection findRows() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getUpdateSQL() {
		// TODO Auto-generated method stub
		return null;
	}

}
