package com.num.generator.dataaccess;

import java.util.Collection;

public class ResultHistoryTestFilterEntity extends Base {
	
	private String gameCode;
	private String 	serialNumber;
	private String 	properDistribution;
	private String last9CombsAverage;
	private String equiDistantFilter;
	private String combsAlreadyAppeared;
	private String removeCombsHavingBelowAverageNumbers;
	private String removeAllEvensAndOdds;		
	private String aboveAverageFreq;
	private String frqBasedFilter ;
	private String exclusions ;	
	private String predictThroughRedux;
	private String DBPredicAnalysis ;
	private String  followerPatternAnalysis;
	private String  isALikelyBucketPattern;
	private String  sameReduxInHistory ;
	private String  sameVDiffsInHistory ;
	private String  sameFreqReduxInHistory;
	private String  sameDigitDiffsInHistory ;
	private String  missedDigitsInHistory ;			
	private String  skipSumWithinRange;
	private String  isLikelyMaxFactor;
	private String  ranksNotInSameDirection;
	private String  sameObsDate;
	private String  sameObsPercentile;
	private String  unlikelyFreqShadowReduxes;
	private String  possibleCombAccordingToGeneratorVTwoCount;
	private String threeOrMoreRelations;


	public String getTableName() {
		return "result_history_test_filters";
	}

	
	public String getInsertSQL() {
		StringBuffer buff = new StringBuffer();
		
		StringBuffer internalBuffer = new StringBuffer();
		
		buff.append("Insert into " + getTableName() + "( ");
		
		if (getGameCode() != null)  {
			buff.append("gameCode,");
			internalBuffer.append("'" + getGameCode() + "',");
		}
	
		if (getSerialNumber() != null)  {
			buff.append("serialNumber,");
			internalBuffer.append("'" + getSerialNumber() + "',");
		}
		
		if (getProperDistribution() != null)  {
			buff.append("properDistribution,");
			internalBuffer.append("'" + getProperDistribution() + "',");
		}
		
		if (getLast9CombsAverage() != null)  {
			buff.append("last9CombsAverage,");
			internalBuffer.append("'" + getLast9CombsAverage() + "',");
		}
			
		if (getEquiDistantFilter() != null)  {
			buff.append("equiDistantFilter,");
			internalBuffer.append("'" + getEquiDistantFilter() + "',");
		}
		
		if (getCombsAlreadyAppeared() != null)  {
			buff.append("combsAlreadyAppeared,");
			internalBuffer.append("'" + getCombsAlreadyAppeared() + "',");
		}
		
		if (getRemoveCombsHavingBelowAverageNumbers() != null)  {
			buff.append("removeCombsHavingBelowAverageNumbers,");
			internalBuffer.append("'" + getRemoveCombsHavingBelowAverageNumbers() + "',");
		}
		
			
		if (getRemoveAllEvensAndOdds() != null)  {
			buff.append("removeAllEvensAndOdds,");
			internalBuffer.append("'" + getRemoveAllEvensAndOdds() + "',");
		}
		
		if (getAboveAverageFreq() != null)  {
			buff.append("aboveAverageFreq,");
			internalBuffer.append("'" + getAboveAverageFreq() + "',");
		}
		
		if (getFrqBasedFilter() != null)  {
			buff.append("frqBasedFilter,");
			internalBuffer.append("'" + getFrqBasedFilter() + "',");
		}
		
		
		if (getExclusions() != null)  {
			buff.append("exclusions,");
			internalBuffer.append("'" + getExclusions() + "',");
		}
		
		if (getPredictThroughRedux() != null)  {
			buff.append("predictThroughRedux,");
			internalBuffer.append("'" + getPredictThroughRedux() + "',");
		}
		
		if (getDBPredicAnalysis() != null)  {
			buff.append("DBPredicAnalysis,");
			internalBuffer.append("'" + getDBPredicAnalysis() + "',");
		}
		
		if (getFollowerPatternAnalysis() != null)  {
			buff.append("followerPatternAnalysis,");
			internalBuffer.append("'" + getFollowerPatternAnalysis() + "',");
		}
		
		
		if (getIsALikelyBucketPattern() != null)  {
			buff.append("isALikelyBucketPattern,");
			internalBuffer.append("'" + getIsALikelyBucketPattern() + "',");
		}
		
		if (getSameReduxInHistory() != null)  {
			buff.append("sameReduxInHistory,");
			internalBuffer.append("'" + getSameReduxInHistory() + "',");
		}
		
		if (getSameVDiffsInHistory() != null)  {
			buff.append("sameVDiffsInHistory,");
			internalBuffer.append("'" + getSameVDiffsInHistory() + "',");
		}
		
		if (getSameFreqReduxInHistory() != null)  {
			buff.append("sameFreqReduxInHistory,");
			internalBuffer.append("'" + getSameFreqReduxInHistory() + "',");
		}
		
		if (getSameDigitDiffsInHistory() != null)  {
			buff.append("sameDigitDiffsInHistory,");
			internalBuffer.append("'" + getSameDigitDiffsInHistory() + "',");
		}
		
		
		if (getMissedDigitsInHistory() != null)  {
			buff.append("missedDigitsInHistory,");
			internalBuffer.append("'" + getMissedDigitsInHistory() + "',");
		}
		
		if (getSkipSumWithinRange() != null)  {
			buff.append("skipSumWithinRange,");
			internalBuffer.append("'" + getSkipSumWithinRange() + "',");
		}
		
		
		if (getIsLikelyMaxFactor() != null)  {
			buff.append("isLikelyMaxFactor,");
			internalBuffer.append("'" + getIsLikelyMaxFactor() + "',");
		}
		
		if (getRanksNotInSameDirection() != null)  {
			buff.append("ranksNotInSameDirection,");
			internalBuffer.append("'" + getRanksNotInSameDirection() + "',");
		}
		
		
		if (getSameObsDate() != null)  {
			buff.append("sameObsDate,");
			internalBuffer.append("'" + getSameObsDate() + "',");
		}
		
		if (getSameObsPercentile() != null)  {
			buff.append("sameObsPercentile,");
			internalBuffer.append("'" + getSameObsPercentile() + "',");
		}
		
		
		if (getUnlikelyFreqShadowReduxes() != null)  {
			buff.append("unlikelyFreqShadowReduxes,");
			internalBuffer.append("'" + getUnlikelyFreqShadowReduxes() + "',");
		}
		
		
		if (getPossibleCombAccordingToGeneratorVTwoCount() != null)  {
			buff.append("possibleCombAccordingToGeneratorVTwoCount,");
			internalBuffer.append("'" + getPossibleCombAccordingToGeneratorVTwoCount() + "',");
		}
		
		if (getThreeOrMoreRelations() != null)  {
			buff.append("threeOrMoreRelations,");
			internalBuffer.append("'" + getThreeOrMoreRelations() + "',");
		}
		
			
		return buff.substring(0,buff.length()-1) + ") values ( "+ internalBuffer.substring(0,internalBuffer.length()-1) + ")" ;

	}

	@Override
	public String getUpdateSQL() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Collection readAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Collection findRows() {
		// TODO Auto-generated method stub
		return null;
	}

	public String getGameCode() {
		return gameCode;
	}

	public void setGameCode(String gameCode) {
		this.gameCode = gameCode;
	}

	public String getSerialNumber() {
		return serialNumber;
	}

	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}

	public String getProperDistribution() {
		return properDistribution;
	}

	public void setProperDistribution(String properDistribution) {
		this.properDistribution = properDistribution;
	}

	public String getLast9CombsAverage() {
		return last9CombsAverage;
	}

	public void setLast9CombsAverage(String last9CombsAverage) {
		this.last9CombsAverage = last9CombsAverage;
	}

	public String getEquiDistantFilter() {
		return equiDistantFilter;
	}

	public void setEquiDistantFilter(String equiDistantFilter) {
		this.equiDistantFilter = equiDistantFilter;
	}

	public String getCombsAlreadyAppeared() {
		return combsAlreadyAppeared;
	}

	public void setCombsAlreadyAppeared(String combsAlreadyAppeared) {
		this.combsAlreadyAppeared = combsAlreadyAppeared;
	}

	public String getRemoveCombsHavingBelowAverageNumbers() {
		return removeCombsHavingBelowAverageNumbers;
	}

	public void setRemoveCombsHavingBelowAverageNumbers(
			String removeCombsHavingBelowAverageNumbers) {
		this.removeCombsHavingBelowAverageNumbers = removeCombsHavingBelowAverageNumbers;
	}

	public String getRemoveAllEvensAndOdds() {
		return removeAllEvensAndOdds;
	}

	public void setRemoveAllEvensAndOdds(String removeAllEvensAndOdds) {
		this.removeAllEvensAndOdds = removeAllEvensAndOdds;
	}

	public String getAboveAverageFreq() {
		return aboveAverageFreq;
	}

	public void setAboveAverageFreq(String aboveAverageFreq) {
		this.aboveAverageFreq = aboveAverageFreq;
	}

	public String getFrqBasedFilter() {
		return frqBasedFilter;
	}

	public void setFrqBasedFilter(String frqBasedFilter) {
		this.frqBasedFilter = frqBasedFilter;
	}

	public String getExclusions() {
		return exclusions;
	}

	public void setExclusions(String exclusions) {
		this.exclusions = exclusions;
	}

	public String getPredictThroughRedux() {
		return predictThroughRedux;
	}

	public void setPredictThroughRedux(String predictThroughRedux) {
		this.predictThroughRedux = predictThroughRedux;
	}

	public String getDBPredicAnalysis() {
		return DBPredicAnalysis;
	}

	public void setDBPredicAnalysis(String dBPredicAnalysis) {
		DBPredicAnalysis = dBPredicAnalysis;
	}

	public String getFollowerPatternAnalysis() {
		return followerPatternAnalysis;
	}

	public void setFollowerPatternAnalysis(String followerPatternAnalysis) {
		this.followerPatternAnalysis = followerPatternAnalysis;
	}

	public String getIsALikelyBucketPattern() {
		return isALikelyBucketPattern;
	}

	public void setIsALikelyBucketPattern(String isALikelyBucketPattern) {
		this.isALikelyBucketPattern = isALikelyBucketPattern;
	}

	public String getSameReduxInHistory() {
		return sameReduxInHistory;
	}

	public void setSameReduxInHistory(String sameReduxInHistory) {
		this.sameReduxInHistory = sameReduxInHistory;
	}

	public String getSameFreqReduxInHistory() {
		return sameFreqReduxInHistory;
	}

	public void setSameFreqReduxInHistory(String sameFreqReduxInHistory) {
		this.sameFreqReduxInHistory = sameFreqReduxInHistory;
	}

	public String getSameDigitDiffsInHistory() {
		return sameDigitDiffsInHistory;
	}

	public void setSameDigitDiffsInHistory(String sameDigitDiffsInHistory) {
		this.sameDigitDiffsInHistory = sameDigitDiffsInHistory;
	}

	public String getMissedDigitsInHistory() {
		return missedDigitsInHistory;
	}

	public void setMissedDigitsInHistory(String missedDigitsInHistory) {
		this.missedDigitsInHistory = missedDigitsInHistory;
	}

	public String getSkipSumWithinRange() {
		return skipSumWithinRange;
	}

	public void setSkipSumWithinRange(String skipSumWithinRange) {
		this.skipSumWithinRange = skipSumWithinRange;
	}

	public String getIsLikelyMaxFactor() {
		return isLikelyMaxFactor;
	}

	public void setIsLikelyMaxFactor(String isLikelyMaxFactor) {
		this.isLikelyMaxFactor = isLikelyMaxFactor;
	}

	public String getRanksNotInSameDirection() {
		return ranksNotInSameDirection;
	}

	public void setRanksNotInSameDirection(String ranksNotInSameDirection) {
		this.ranksNotInSameDirection = ranksNotInSameDirection;
	}

	public String getSameObsDate() {
		return sameObsDate;
	}

	public void setSameObsDate(String sameObsDate) {
		this.sameObsDate = sameObsDate;
	}

	public String getSameObsPercentile() {
		return sameObsPercentile;
	}

	public void setSameObsPercentile(String sameObsPercentile) {
		this.sameObsPercentile = sameObsPercentile;
	}

	public String getUnlikelyFreqShadowReduxes() {
		return unlikelyFreqShadowReduxes;
	}

	public void setUnlikelyFreqShadowReduxes(String unlikelyFreqShadowReduxes) {
		this.unlikelyFreqShadowReduxes = unlikelyFreqShadowReduxes;
	}

	public String getPossibleCombAccordingToGeneratorVTwoCount() {
		return possibleCombAccordingToGeneratorVTwoCount;
	}

	public void setPossibleCombAccordingToGeneratorVTwoCount(
			String possibleCombAccordingToGeneratorVTwoCount) {
		this.possibleCombAccordingToGeneratorVTwoCount = possibleCombAccordingToGeneratorVTwoCount;
	}


	public String getSameVDiffsInHistory() {
		return sameVDiffsInHistory;
	}


	public void setSameVDiffsInHistory(String sameVDiffsInHistory) {
		this.sameVDiffsInHistory = sameVDiffsInHistory;
	}


	public String getThreeOrMoreRelations() {
		return threeOrMoreRelations;
	}


	public void setThreeOrMoreRelations(String threeOrMoreRelations) {
		this.threeOrMoreRelations = threeOrMoreRelations;
	}

}
