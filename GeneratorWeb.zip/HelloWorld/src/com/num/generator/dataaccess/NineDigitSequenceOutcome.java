package com.num.generator.dataaccess;

import java.util.Hashtable;

public class NineDigitSequenceOutcome {
	
	public static void main(String[] args) {
		int[] input = new int [] {2,3,1,4,4,2,1,3,7,2};
		System.out.println("IsConsistent: " + isConsistentOutcome(input));
	}

	private static Hashtable<String,String> data = new Hashtable<String, String>(){
	    {
	        	put("OOO","N");
	        	put("OON","O");
	        	put("ONO","O");
	        	put("NNO","O"); /* wide margin */
	        	put("ONN","O"); /* wide margin */
	        	put("NOO","O");
	        	put("NON","O");
	        	put("NNN","O");
	        
	    }
	};
	
	public static String getOutcome(String predecessor) {
		
		return data.get(predecessor);
	}
	
	public static boolean isConsistentOutcome (int [] series) { // series is a list of 10 values
																// output is true if 10th value is consistent with predicted outcome
		
		if (series.length != 10) {
			System.out.println("Invalid input length: please pass an array of size 10");
			return false;
		}
		
		String pattern = "";
		
		String sseries = "";
		
		for (int j=0; j<series.length; j++) sseries += Integer.toString(series[j]);
		
		for (int i=series.length-4;i<series.length;i++) {
			if (sseries.substring(0, i).contains(Integer.toString(series[i])))
				pattern += "O";
			else
				pattern += "N";
			
		}
		
		String skey = pattern.substring(0, 3);
		
		if (data.get(skey) != null) {
			if (data.get(skey).equals(pattern.substring(3)))
				return true;
			
		}
		return false;
	}

	public static Hashtable<String, String> getData() {
		return data;
	}
	
}
