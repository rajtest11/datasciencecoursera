package com.num.generator.dataaccess;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;

public class CurrentStateEntity extends Base {
	
	public static final String ENTRYTYPEFIRSTFIVE = "FF";
	public static final String ENTRYTYPEMEGA = "ME";
	private String gameCode ;
	private String firstFiveOrMega;
	private String number;
	private String frequency;
	private String skip;

	
	public static void main(String[] args) {
		CurrentStateEntity cs = new CurrentStateEntity();
		//cs.setGameCode("2");
		
		System.out.println(cs.getValuesInFreqShadow("2", "FF", 3));
	}
	
	public String getGameCode() {
		return gameCode;
	}

	public void setGameCode(String gameCode) {
		this.gameCode = gameCode;
	}

	public String getFirstFiveOrMega() {
		return firstFiveOrMega;
	}

	public void setFirstFiveOrMega(String firstFiveOrMega) {
		this.firstFiveOrMega = firstFiveOrMega;
	}

	public String getNumber() {
		return number;
	}

	public void setNumber(String number) {
		this.number = number;
	}

	public String getFrequency() {
		return frequency;
	}

	public void setFrequency(String frequency) {
		this.frequency = frequency;
	}

	public String getSkip() {
		return skip;
	}

	public void setSkip(String skip) {
		this.skip = skip;
	}


	@Override
	public String getTableName() {
		
		return " current_state ";
	}

	@Override
	public String getInsertSQL() {
		StringBuffer buff = new StringBuffer();
		
		StringBuffer internalBuffer = new StringBuffer();
		
		buff.append("Insert into " + getTableName() + "( ");
		
		if (getGameCode() != null)  {
			buff.append("gameCode,");
			internalBuffer.append("'" + getGameCode() + "',");
		}
		
		if (getFirstFiveOrMega() != null && (getFirstFiveOrMega().equals(ENTRYTYPEFIRSTFIVE) || getFirstFiveOrMega().equals(ENTRYTYPEMEGA)))  {
			buff.append("firstFiveOrMega,");
			internalBuffer.append("'" + getFirstFiveOrMega() + "',");
		} else {
			return null;
		}
		
		if (getNumber() != null)  {
			buff.append("number,");
			internalBuffer.append("'" + getNumber() + "',");
		}
		
		if (getFrequency() != null)  {
			buff.append("frequency,");
			internalBuffer.append("'" + getFrequency() + "',");
		}
		
		if (getSkip() != null)  {
			buff.append("skip,");
			internalBuffer.append("'" + getSkip() + "',");
		}
		
		
		return buff.substring(0,buff.length()-1) + ") values ( "+ internalBuffer.substring(0,internalBuffer.length()-1) + ")" ;
	}
	
	@Override
	public String getUpdateSQL() {
		StringBuffer buff = new StringBuffer();
		StringBuffer whereBuff = new StringBuffer();
		
		buff.append("Update " + getTableName() + " SET ");
		
		if (getGameCode() != null)  {
			whereBuff.append(" where gameCode = '" + getGameCode() + "' ");
		}
		
		if (getFirstFiveOrMega() != null)  {
			whereBuff.append("AND firstFiveOrMega = '" + getFirstFiveOrMega() + "' ");
			
		}
		
		if (getNumber() != null)  {
			whereBuff.append("AND number = '" + getNumber() + "' ");
			
		}
		
		if (getFrequency() != null)  {
			buff.append(" frequency = '" + getFrequency() + "',");
		}
		
		if (getSkip() != null)  {
			buff.append(" skip = '" + getSkip() + "',");
		}
		
		
		return buff.toString().substring(0,buff.length()-1) + whereBuff.toString();
	}

	@Override
	public Collection readAll() {
		
		if (getGameCode() == null || getFirstFiveOrMega() == null) 
			return null;
		
		Collection out = new ArrayList();
		Connection conn = getConnection();
		
		Statement stmt;
		try {
			stmt = conn.createStatement();
			  
		  	ResultSet rs = stmt.executeQuery("Select * from " + getTableName() + " where gameCode = " + getGameCode() + " and firstFiveOrMega = '" + getFirstFiveOrMega() + "'");
		  	
		  	while (rs.next()) {
		  		CurrentStateEntity gte = new CurrentStateEntity();
		  		gte.setGameCode(rs.getString("gameCode"));
		  		gte.setFirstFiveOrMega(rs.getString("firstFiveOrMega"));
		  		gte.setNumber(rs.getString("number"));
		  		gte.setFrequency(rs.getString("frequency"));
		  		gte.setSkip(rs.getString("skip"));
		  		
		  		out.add(gte);
		  	}
	  	
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				if (conn != null)
					conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return out;
	}
	
	
	public Collection readLastResult() {
		
		if (getGameCode() == null || getFirstFiveOrMega() == null) 
			return null;
		
		Collection out = new ArrayList();
		Connection conn = getConnection();
		
		Statement stmt;
		try {
			stmt = conn.createStatement();
			  
		  	ResultSet rs = stmt.executeQuery("Select * from " + getTableName() + " where gameCode = " + getGameCode() + " and firstFiveOrMega = '" + getFirstFiveOrMega() + "'" + " and skip = 1");
		  	
		  	while (rs.next()) {
		  		CurrentStateEntity gte = new CurrentStateEntity();
		  		gte.setGameCode(rs.getString("gameCode"));
		  		gte.setFirstFiveOrMega(rs.getString("firstFiveOrMega"));
		  		gte.setNumber(rs.getString("number"));
		  		gte.setFrequency(rs.getString("frequency"));
		  		gte.setSkip(rs.getString("skip"));
		  		
		  		out.add(gte);
		  	}
	  	
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				if (conn != null)
					conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return out;
	}

	@Override
	public Collection findRows() {
		// TODO Auto-generated method stub
		return null;
	}
	
	public boolean exists() {
		boolean out = false;
		StringBuffer buff = new StringBuffer();
		
		StringBuffer internalBuffer = new StringBuffer();
		
		buff.append("select * from " + getTableName() + " where ");
		
		if (getGameCode() != null)  {
			internalBuffer.append("gameCode = ");
			internalBuffer.append("'" + getGameCode() + "'");
		}
		
		if (getFirstFiveOrMega() != null)  {
			if (internalBuffer.length() > 0)
				internalBuffer.append(" AND firstFiveOrMega = ");
			else
				internalBuffer.append(" firstFiveOrMega = ");
			internalBuffer.append("'" + getFirstFiveOrMega() + "'");
		}
		
		if (getNumber() != null)  {
			if (internalBuffer.length() > 0)
				internalBuffer.append(" AND number = ");
			else
				internalBuffer.append(" number = ");
			internalBuffer.append("'" + getNumber() + "'");
		}
		
		String sql = buff.toString() + internalBuffer.toString();
		Connection conn = null;
		try {
			
			conn = getConnection();
			Statement stmt = conn.createStatement();
			
			ResultSet rs = stmt.executeQuery(sql);
			
			if (rs.next())
				out = true;
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			if (conn != null)
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		
		return out;
	}
	
	
	public String getValuesForFrequency(String gameCode, String firstFiveOrMega, int freq) {
		String out = "";
		
		
		if (gameCode == null) {
			System.out.println("CurrentStateEntity.getValuesForFrequency: Set gameCode first.");
			return out;
		}
		
		StringBuffer buff = new StringBuffer();
		
		buff.append("select number from " + getTableName() + " where gameCode = " + gameCode  + 
						" and firstFiveOrMega = '" + firstFiveOrMega + "' and frequency = " + freq);
		
		String sql = buff.toString();
		Connection conn = null;
		try {
			
			conn = getConnection();
			Statement stmt = conn.createStatement();
			
			ResultSet rs = stmt.executeQuery(sql);
			
			while (rs.next()) {
				out += rs.getInt(1) + ",";
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			if (conn != null)
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		
		return out.substring(0, out.length()-1);
	}
	
	public int getMaxFrequency(String gameCode) {
		int out = 0;
		
		
		if (gameCode == null) {
			System.out.println("CurrentStateEntity.getMaxFrequency: Set gameCode first.");
			return out;
		}
		
		StringBuffer buff = new StringBuffer();
		
		buff.append("select max(frequency) from " + getTableName() + " s, game_types g where s.gameCode = g.gameCode and s.gameCode = " + gameCode +
				" and s.firstFiveOrMega = 'FF' and s.number <= g.maximumValue");

		String sql = buff.toString();
		Connection conn = null;
		try {
			
			conn = getConnection();
			Statement stmt = conn.createStatement();
			
			ResultSet rs = stmt.executeQuery(sql);
			
			if (rs.next()) {
				out = rs.getInt(1);
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			if (conn != null)
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		
		return out;
	}
	
	public int getMinFrequency(String gameCode) {
		int out = 0;
		
		
		if (gameCode == null) {
			System.out.println("CurrentStateEntity.getMinFrequency: Set gameCode first.");
			return out;
		}
		
		StringBuffer buff = new StringBuffer();
		
		buff.append("select min(frequency) from " + getTableName() + " s, game_types g where s.gameCode = g.gameCode and s.gameCode = " + gameCode +
						" and s.firstFiveOrMega = 'FF' and s.number <= g.maximumValue");
		
		String sql = buff.toString();
		Connection conn = null;
		try {
			
			conn = getConnection();
			Statement stmt = conn.createStatement();
			
			ResultSet rs = stmt.executeQuery(sql);
			
			if (rs.next()) {
				out = rs.getInt(1);
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			if (conn != null)
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		
		return out;
	}
	
	public String getValuesForSkip(String gameCode, String firstFiveOrMega, int skip) {
		String out = "";
		
		
		if (gameCode == null) {
			System.out.println("CurrentStateEntity.getValuesForFrequency: Set gameCode first.");
			return out;
		}
		
		StringBuffer buff = new StringBuffer();
		
		buff.append("select number from " + getTableName() + " where gameCode = " + gameCode  + 
						" and firstFiveOrMega = '" + firstFiveOrMega + "' and skip = " + skip);
		
		String sql = buff.toString();
		Connection conn = null;
		try {
			
			conn = getConnection();
			Statement stmt = conn.createStatement();
			
			ResultSet rs = stmt.executeQuery(sql);
			
			while (rs.next()) {
				out += rs.getInt(1) + ",";
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			if (conn != null)
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		
		return (out.length()>0)?out.substring(0, out.length()-1):out;
	}
	
	
	
	public String getValuesInFreqShadow(String gameCode, String firstFiveOrMega, int freqShadow) {
		String out = "";
		
		
		if (gameCode == null) {
			System.out.println("CurrentStateEntity.getValuesInFreqShadow: Set gameCode first.");
			return out;
		}
		
		ResultHistoryEntity rhe = new ResultHistoryEntity();
		rhe.setGameCode(gameCode);
		
		List<String> attlist = new ArrayList<String>(Arrays.asList("firstFreq","secondFreq", "thirdFreq", "fourthFreq", "fifthFreq"));
		LinkedHashMap<Integer,ArrayList<Integer>> freqs = rhe.getLastNForAttributes(attlist,1,0);
		
		List<List<Integer>> l = new ArrayList<List<Integer>>(freqs.values());
		
		StringBuffer buff = new StringBuffer();
		
		buff.append("select number from " + getTableName() + " where gameCode = " + gameCode  + 
						" and firstFiveOrMega = '" + firstFiveOrMega + 
						"' and (frequency between  " + (l.get(0).get(0) - freqShadow) + " and " + (l.get(0).get(0) + freqShadow) + 
						"   or frequency between  " + (l.get(0).get(1) - freqShadow) + " and " + (l.get(0).get(1) + freqShadow) + 
						"  or frequency between  " + (l.get(0).get(2) - freqShadow) + " and " + (l.get(0).get(2) + freqShadow) + 
						" or frequency between " + (l.get(0).get(3) - freqShadow) + " and " + (l.get(0).get(3) + freqShadow) + 
						" or frequency between  " + (l.get(0).get(4) - freqShadow) + " and " + (l.get(0).get(4) + freqShadow) + ") " + 
						" order by number asc");
		
		String sql = buff.toString();
		Connection conn = null;
		try {
			
			conn = getConnection();
			Statement stmt = conn.createStatement();
			
			ResultSet rs = stmt.executeQuery(sql);
			
			while (rs.next()) {
				out += rs.getInt(1) + ",";
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			if (conn != null)
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		
		return (out.length()>0)?out.substring(0, out.length()-1):out;
	}
	
	public String getValuesForEvenSkip(String gameCode, String firstFiveOrMega) {
		String out = "";
		
		
		if (gameCode == null) {
			System.out.println("CurrentStateEntity.getValuesForFrequency: Set gameCode first.");
			return out;
		}
		
		StringBuffer buff = new StringBuffer();
		
		buff.append("select number from " + getTableName() + " where gameCode = " + gameCode  + 
						" and firstFiveOrMega = '" + firstFiveOrMega + "' and skip % 2 = 0");
		
		String sql = buff.toString();
		Connection conn = null;
		try {
			
			conn = getConnection();
			Statement stmt = conn.createStatement();
			
			ResultSet rs = stmt.executeQuery(sql);
			
			while (rs.next()) {
				out += rs.getInt(1) + ",";
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			if (conn != null)
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		
		return out.substring(0, out.length()-1);
	}
	
	public String getValuesForOddSkip(String gameCode, String firstFiveOrMega) {
		String out = "";
		
		
		if (gameCode == null) {
			System.out.println("CurrentStateEntity.getValuesForFrequency: Set gameCode first.");
			return out;
		}
		
		StringBuffer buff = new StringBuffer();
		
		buff.append("select number from " + getTableName() + " where gameCode = " + gameCode  + 
						" and firstFiveOrMega = '" + firstFiveOrMega + "' and skip % 2 > 0");
		
		String sql = buff.toString();
		Connection conn = null;
		try {
			
			conn = getConnection();
			Statement stmt = conn.createStatement();
			
			ResultSet rs = stmt.executeQuery(sql);
			
			while (rs.next()) {
				out += rs.getInt(1) + ",";
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			if (conn != null)
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		
		return out.substring(0, out.length()-1);
	}
	
	public List<Integer> getIndivAttributeValuesBasedOnPrediction(InclusionExclusionEntity pred) {
		List<Integer> out = new ArrayList<Integer>();
		
		
		if (gameCode == null) {
			System.out.println("CurrentStateEntity.getIndivValuesBasedOnPrediction: Set gameCode first.");
			return out;
		}
		
		String fforme = "";
		
		if (pred.getAttribute().startsWith("mega"))
			fforme = " and firstFiveOrMega = 'ME' ";
		else
			fforme = " and firstFiveOrMega = 'FF' ";
		
		String whereparam = getWhereParam(pred.getAttribute());
		
		if (pred.getAttribute().contains("FiveSum")) {
			whereparam = getWhereParamForSumAttributes(pred.getAttribute());
		}
		
		String whereclause = getWhereOperator(pred, whereparam);
		
		if ( whereclause ==null)
			return out;
		
		StringBuffer buff = new StringBuffer();
		
		if (pred.getAttribute().contains("FiveSum")) {
				buff.append("select distinct " + pred.getAttribute() + " as number from jointView where gameCode = " + gameCode  + 
					" and " +  whereclause);
			
		} else {
			buff.append("select number from " + getTableName() + " where gameCode = " + gameCode  + fforme + 
						" and " +  whereclause);
		}
		
		String sql = buff.toString();
		Connection conn = null;
		try {
			
			conn = getConnection();
			Statement stmt = conn.createStatement();
			
			//System.out.println("Executing SQL: " + sql);
			ResultSet rs = stmt.executeQuery(sql);
			
			while (rs.next()) {
				out.add(rs.getInt("number"));
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			if (conn != null)
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		
		return out;
	}

	private String getWhereOperator(InclusionExclusionEntity pred, String whereparam) {
		String whereop = null;
		
		if (pred.getData() == null || pred.getData().size() == 0) {
			System.out.println("CurrentStateEntity.getWhereOperator : No data values to operate on." );
			return whereop;
		}
		if (pred.getIsInclusionInd().equals("true")) {
			
			if (pred.getAlgorithmType().equals(InclusionExclusionEntity.ALGORITHM_TYPE_ASC_DESC_PATTERNS)) {
				
				if (pred.getData().get(0) > 0)
					whereop = whereparam + " > " + pred.getData().get(0);
				
				if (pred.getData().get(0) < 0)
					whereop = whereparam + " < " + (0-pred.getData().get(0));
			}
			
			if (pred.getAlgorithmType().equals(InclusionExclusionEntity.ALGORITHM_TYPE_PRIME_NONPRIME_PATTERNS)) {
				
				whereop = " isPrime(" + whereparam + ") = " + pred.getData().get(0);
				
			}
			
			if (pred.getAlgorithmType().equals(InclusionExclusionEntity.ALGORITHM_TYPE_EVEN_ODD_PATTERNS)) {
				
				if (pred.getData().get(0) > 0)
					whereop = whereparam + " % 2 = 0";
				
				if (pred.getData().get(0) < 0)
					whereop = whereparam + " % 2 = 1";
			}
			
			if (pred.getAlgorithmType().equals(InclusionExclusionEntity.ALGORITHM_TYPE_DIST_FREQ_SAME_DIFF)) {
				
				String inclause = "(";
				
				for (int val: pred.getData()) {
					inclause += val + ",";
				}
				
				inclause = inclause.substring(0, inclause.length()-1) + ")";
				
				whereop = whereparam + " in " + inclause;
				
				
			}
			
		} else { // this is the fail prediction to reverse all the earlier operations
			if (pred.getAlgorithmType().equals(InclusionExclusionEntity.ALGORITHM_TYPE_ASC_DESC_PATTERNS)) {
				
				if (pred.getData().get(0) > 0)
					whereop = whereparam + " < " + pred.getData().get(0);
				
				if (pred.getData().get(0) < 0)
					whereop = whereparam + " > " + (0-pred.getData().get(0));
			}
			
			if (pred.getAlgorithmType().equals(InclusionExclusionEntity.ALGORITHM_TYPE_PRIME_NONPRIME_PATTERNS)) {
				
				whereop = " isPrime(" + whereparam + ") != " + pred.getData().get(0);
				
			}
			
			if (pred.getAlgorithmType().equals(InclusionExclusionEntity.ALGORITHM_TYPE_EVEN_ODD_PATTERNS)) {
				
				if (pred.getData().get(0) > 0)
					whereop = whereparam + " % 2 = 1 ";
				
				if (pred.getData().get(0) < 0)
					whereop = whereparam + " % 2 = 0 ";
			}
			
			if (pred.getAlgorithmType().equals(InclusionExclusionEntity.ALGORITHM_TYPE_DIST_FREQ_SAME_DIFF)) {
				
				String inclause = "(";
				
				for (int val: pred.getData()) {
					inclause += val + ",";
				}
				
				inclause = inclause.substring(0, inclause.length()-1) + ")";
				
				whereop = whereparam + " not in " + inclause;
				
				
			}
		}
		
		
		
		return whereop;
	}

	private String getWhereParam(String attribute) {
		
		String whereparam = null;
		
		if (attribute.contains("FreqShadow")) {// NEED to decide how to handle it 
			System.out.println("CurrentStateEntity.getWhereParam: Can not handle freqshadow.");
			return whereparam;
		}
		
		if (attribute.contains("Freq"))
			whereparam = " frequency ";
		
		if (attribute.contains("Skip"))
			whereparam = " skip ";
		
		if (attribute.contains("DigitDiff"))
			whereparam = " myDigitDiff(number) ";
		
		if (attribute.contains("Redux"))
			whereparam = " myRedux(number) ";
		
		if (attribute.contains("Bucket"))
			whereparam = " number DIV 10 ";		
		
		if (attribute.contains("Value"))
			whereparam = " number ";
		
		return whereparam;
	}
	
	private String getWhereParamForSumAttributes(String attribute) {
		
		String whereparam = null;
		
		if (attribute.contains("FreqShadow")) {// NEED to decide how to handle it 
			System.out.println("CurrentStateEntity.getWhereParam: Can not handle freqshadow.");
			return whereparam;
		}		
		
		whereparam = " " + attribute + " " ;
		
		return whereparam;
	}

}
