package com.num.generator.dataaccess;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.StringTokenizer;

public class MissingDigitsEntity extends Base {
	
	private String gameCode;
	private String 	serialNumber;
	private String 	missingDigits;
	private String missingDigitSkip;
	private int newRecords;
	private ArrayList<MissingDigitsEntity> listOfMissingDigits = new ArrayList<MissingDigitsEntity>();
	private HashMap<String, Integer> unlikelyMissingDigits = new HashMap<String, Integer>();


	public static void main(String [] args) {
		
		String forgameCode = "1";
		MissingDigitsEntity mde = new MissingDigitsEntity();
		mde.loadMissingDigitsForGame(forgameCode);
		mde.populateMissingDigits(forgameCode);
	}
	public HashMap<String, Integer> getUnlikelyMissingDigits() {
		
		return unlikelyMissingDigits;
	}

	public void setUnlikelyMissingDigits(
			HashMap<String, Integer> unlikelyMissingDigits) {
		this.unlikelyMissingDigits = unlikelyMissingDigits;
	}

	public ArrayList<MissingDigitsEntity> getListOfMissingDigits() {
		return listOfMissingDigits;
	}

	public void setListOfMissingDigits(
			ArrayList<MissingDigitsEntity> listOfMissingDigits) {
		this.listOfMissingDigits = listOfMissingDigits;
	}

	public String getGameCode() {
		return gameCode;
	}

	public void setGameCode(String gameCode) {
		this.gameCode = gameCode;
	}

	public String getSerialNumber() {
		return serialNumber;
	}

	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}

	public String getMissingDigits() {
		return missingDigits;
	}

	public void setMissingDigits(String missingDigits) {
		this.missingDigits = missingDigits;
	}

	

	public String getMissingDigitSkip() {
		return missingDigitSkip;
	}

	public void setMissingDigitSkip(String missingDigitSkip) {
		this.missingDigitSkip = missingDigitSkip;
	}

	public String getTableName() {
		
		return " missing_digits ";
	}

	@Override
	public String getInsertSQL() {
		
		if (listOfMissingDigits != null && listOfMissingDigits.size() > 0)
			return getMultipleInsertSQL();
		
		StringBuffer buff = new StringBuffer();
		
		StringBuffer internalBuffer = new StringBuffer();
		
		buff.append("Insert into " + getTableName() + "( ");
		
		if (getGameCode() != null)  {
			buff.append("gameCode,");
			internalBuffer.append("'" + getGameCode() + "',");
		}
		
		if (getSerialNumber() != null)  {
			buff.append("serialNumber,");
			internalBuffer.append("'" + getSerialNumber() + "',");
		}
		
		if (getMissingDigits() != null)  {
			buff.append("missingDigits,");
			internalBuffer.append("'" + getMissingDigits() + "',");
		}
		
		
		
		if (getMissingDigitSkip() != null)  {
			buff.append("missingDigitSkip,");
			internalBuffer.append("'" + getMissingDigitSkip() + "',");
		}
		
			
		return buff.substring(0,buff.length()-1) + ") values ( "+ internalBuffer.substring(0,internalBuffer.length()-1) + ")" ;
	}
	
	
	private String getMultipleInsertSQL() {
		StringBuffer buff = new StringBuffer();
		
		StringBuffer internalBuffer = new StringBuffer();
		
		buff.append("Insert into " + getTableName() + "( ");
		
		Iterator it = listOfMissingDigits.iterator();
		
		int counter = 0;
		
		while(it.hasNext()) {
			
			if (counter < newRecords) {
				MissingDigitsEntity gb = (MissingDigitsEntity) it.next();
				
				if (gb.getSerialNumber() == null) {
					gb.setSerialNumber(Integer.toString(listOfMissingDigits.size() - counter));
				}
				
				if (counter == 0) {
					if (gb.getGameCode() != null)  {
						buff.append("gameCode,");
						internalBuffer.append("'" + gb.getGameCode() + "',");
					}
					
					if (gb.getSerialNumber() != null)  {
						buff.append("serialNumber,");
						internalBuffer.append("'" + gb.getSerialNumber() + "',");
					}
					
					if (gb.getMissingDigits() != null)  {
						buff.append("missingDigits,");
						internalBuffer.append("'" + gb.getMissingDigits() + "',");
					}
					
										
					
					if (gb.getMissingDigitSkip() != null)  {
						buff.append("missingDigitSkip,");
						internalBuffer.append("'" + gb.getMissingDigitSkip() + "',");
					}
					
					internalBuffer.deleteCharAt(internalBuffer.length()-1);
					internalBuffer.append(")");
					
				} else {
					internalBuffer.append(",(");
					if (gb.getGameCode() != null)  {
						internalBuffer.append("'" + gb.getGameCode() + "',");
					}
					
					if (gb.getSerialNumber() != null)  {
						internalBuffer.append("'" + gb.getSerialNumber() + "',");
					}
					
					if (gb.getMissingDigits() != null)  {
						internalBuffer.append("'" + gb.getMissingDigits() + "',");
					}
					
										
					if (gb.getMissingDigitSkip() != null)  {
						internalBuffer.append("'" + gb.getMissingDigitSkip() + "',");
					}
									
					internalBuffer.deleteCharAt(internalBuffer.length()-1);
					internalBuffer.append(")");
				}
			}
			counter++;
		
		}
		
		
		return buff.substring(0,buff.length()-1) + ") values ( "+ internalBuffer.toString() ;
	}

	@Override
	public String getUpdateSQL() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Collection readAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Collection findRows() {
		// TODO Auto-generated method stub
		return null;
	}
	
	public int populateMissingDigits(String gameCode) {
		int updatedCount = 0;
		
		// FIRST find if missing_digits for this gameCode need to be populated
		
		if (gameCode == null)  {
			System.out.println("MissingDigitsEntity.populateMissingDigits : Pass a valid gameCode ");
			return -1;
		}
		
		if (listOfMissingDigits == null || listOfMissingDigits.size() == 0) {
			System.out.println("MissingDigitsEntity.populateMissingDigits : Nothing to populate in " + getTableName() + " for game " + gameCode);
			return -1;
		}
		
		String sql1 = "select count(*) as totals from " + getTableName() + " where gameCode =  " + gameCode ;

		Connection conn = null;
		boolean doInsert = false;
		try {
			
			conn = getConnection();
			Statement stmt = conn.createStatement();
			
			ResultSet rs = stmt.executeQuery(sql1);
			
			int instances = 0;
			
			if (rs.next()) {
				instances = rs.getInt("totals");
				
				rs.close();
				
				if (instances > 0) {
					
					// DELETE all first
					int outInt = stmt.executeUpdate("delete from " + getTableName() + "  where gameCode = "  + gameCode );
					
					if (outInt > 0) {
						System.out.println("MissingDigitsEntity.populateMissingDigits : " + outInt + " Entries deleted from " + getTableName());
						instances = 0;
					}
					
					String sql2 = "select count(*) as records from jointView where gameCode = " + gameCode ;
					rs = stmt.executeQuery(sql2);
					
					if (rs.next()) {
						newRecords = rs.getInt("records") - instances;
						if ( newRecords > 0) {
							
							doInsert = true;
						}
						rs.close();
					}
					
				} else {
					newRecords = listOfMissingDigits.size();
					doInsert = true;
				}
			}
			
			if (doInsert) {
			
				if (this.create()) System.out.println("MissingDigitsEntity.populateMissingDigits : " + newRecords + " Entries created in " + getTableName());
				
				
			} else {
				System.out.println("MissingDigitsEntity.populateMissingDigits : Table " + getTableName() + " up to date for game " + gameCode + " Instances " + instances);
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			if (conn != null)
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
				
		return updatedCount;
		
	}
	
	private void loadMissingDigitsForGame(String gameCode) {
		if (gameCode == null)  {
			System.out.println("Pass a valid gameCode ");
			return ;
		}
		
		String sql = "	select h.serialNumber, firstValue, secondValue, thirdValue, fourthValue, fifthValue from result_history h" +
					 " left outer join missing_digits f on h.serialNumber = f.SerialNumber and h.gameCode = f.gameCode " +
					 " where f.serialNumber is null and h.gameCode = " + gameCode  + " order by h.serialNumber desc";
		Connection conn = null;
		try {
			
			conn = getConnection();
			Statement stmt = conn.createStatement();
			
			ResultSet rs = stmt.executeQuery(sql);
			
			while (rs.next()) {
				
				MissingDigitsEntity mde = new MissingDigitsEntity();
				mde.setGameCode(gameCode);
				mde.setSerialNumber(rs.getString("serialNumber"));
				
				int[] values = new int[5];
				
				values[0] = rs.getInt("firstValue");
				values[1] = rs.getInt("secondValue");
				values[2] = rs.getInt("thirdValue");
				values[3] = rs.getInt("fourthValue");
				values[4] = rs.getInt("fifthValue");
				
				mde.setMissingDigits(getMissingDigitsForArray(values));
				listOfMissingDigits.add(mde);
				
			}
			
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			if (conn != null)
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		
		
	}
	
	private String getMissingDigitsForArray(int[] nums) {
		String missingDigits = "";
		ArrayList complete = new ArrayList(Arrays.asList(new String[]{"1","2","3","4","5","6","7","8","9","0"}));
		ArrayList<String> removeList = new ArrayList<String>();
		
		for (int i = 0; i < 5; i++) {
			String num = Integer.toString(nums[i]);
			
			if (num.length() > 1) {
				if (complete.contains(Integer.toString(Integer.parseInt(num)/10)))
					removeList.add(Integer.toString(Integer.parseInt(num)/10));
			}
			
			if (complete.contains(Integer.toString(Integer.parseInt(num)%10)))
				removeList.add(Integer.toString(Integer.parseInt(num)%10));

			
		}
		
		for(String removeEntry : removeList) {
	         complete.remove(removeEntry);
	      }
		
		Iterator it = complete.iterator();
		while (it.hasNext()) {
			missingDigits += ((String)it.next());
		}

		//System.out.println("Numbers.java: -- Missing digits : " + missingDigits);
		return missingDigits;
	}
	
	
	public void populateUnlikelyMissingDigits (String gameCode, int excludeLastN) {
		
		if (excludeLastN == 0)
			excludeLastN = 100;
		
		if (getUnlikelyMissingDigits() == null || getUnlikelyMissingDigits().size() == 0) {
			Collection out = new ArrayList();
			Connection conn = getConnection();
			
			Statement stmt;
			try {
				stmt = conn.createStatement();
				// Get the most likely missing digits
				ResultSet rs = stmt.executeQuery("select missingDigits from " + getTableName() + " where gameCode = " + gameCode +  
										" group by missingDigits  order by  count(*) desc LIMIT " + excludeLastN) ;
				  
				StringBuffer excludes = new StringBuffer();
				while (rs.next()) {
			  				  		
			  		excludes.append("'" + rs.getString("missingDigits") + "',");
			  	}
				
				rs.close();
			  	
				// Get all the maps that appeared in last 50 results and match the least likely maps
				// We will not consider these
				rs = stmt.executeQuery("Select * from " + getTableName() + " where gameCode = " + gameCode + 
													" and serialNumber > (select max(serialNumber) from jointView where gameCode = " + gameCode +") - 300 " +
													" and missingDigits not in " +
													"(" + excludes.toString().substring(0,excludes.length()-1) + ") order by serialNumber desc");
			  	
			  	while (rs.next()) {
			  		//FollowerPatternEntity fte = new FollowerPatternEntity();
			  		//fte.setGameCode(rs.getString("gameCode"));
			  		//fte.setSerialNumber(rs.getString("serialNumber"));
			  		
			  		getUnlikelyMissingDigits().put(rs.getString("missingDigits"), 1);
		  		
			  	}
		  	
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} finally {
				try {
					if (conn != null)
						conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			
		}
	}
	
	public void populateSkipValuesForMissingDigits(String gameCode) {
		
		/*
		 * update missing_digits f join (
					select  a.gameCode, a.serialNumber, max(b.serialNumber), (a.serialNumber -  max(b.serialNumber)) as missingDigitSkip
				from 
						missing_digits a, missing_digits b
				
					where a.gameCode = b.gameCode
					and a.gameCode = 1
					and b.serialNumber < a.serialNumber
					and a.missingDigits = b.missingDigits
					group by a.serialNumber order by a.serialNumber desc
					) as temp 
					on f.gameCode = temp.gameCode 
					and f.serialNumber = temp.serialNumber
					and f.missingDigitSkip is null
					set f.missingDigitSkip = temp.missingDigitSkip
		 */
		
	}
	
	public int getMissingDigitRankForGameAndSerial(String gameCode, int serialNumber) {
		int rank = 0;
		String serialClause = "";
		
		if (serialNumber > 0) {
			serialClause = " and serialNumber <= " + serialNumber;
		}
		
		Connection conn = getConnection();
			
		Statement stmt;
		try {
			stmt = conn.createStatement();
			  
		  	ResultSet rs = stmt.executeQuery("select paramValue, paramRank, serialNumber from aggregate_ranks agr, missing_digits m where m.gameCode = " + gameCode + serialClause + 
		  						" and m.gameCode = agr.gameCode and  agr.paramType = 'MIS' and  agr.paramValue = m.missingDigits " +
		  						" order by serialNumber desc LIMIT 1");
		  	
		  	if (rs.next()) {
		  		rank = rs.getInt("paramRank");
		  	}
		  	
		 	  		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				if (conn != null)
					conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		return rank;
	}

}
