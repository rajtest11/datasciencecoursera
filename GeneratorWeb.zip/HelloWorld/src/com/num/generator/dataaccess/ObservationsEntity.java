package com.num.generator.dataaccess;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Hashtable;

public class ObservationsEntity extends Base {
	
	private String obID;
	private String dateOfObs;
	private String sequence;
	private String dayOfTheWeek;
	private String number;
	
	private Hashtable<String, ArrayList<Integer>> obsData = null;
	
	private static Connection conn = null;
	
	public static void main(String[] args) { 
		ObservationsEntity obs = new ObservationsEntity();
		
		obs.getObsPercentiles("1");
	}
	
	public Connection getConnection () {
		try {
			if (conn == null || conn.isClosed())
				conn = super.getConnection();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return conn;
	}

	public String getObID() {
		return obID;
	}

	public void setObID(String obID) {
		this.obID = obID;
	}

	public String getDateOfObs() {
		return dateOfObs;
	}

	public void setDateOfObs(String dateOfObs) {
		this.dateOfObs = dateOfObs;
	}

	public String getSequence() {
		return sequence;
	}

	public void setSequence(String sequence) {
		this.sequence = sequence;
	}

	public String getDayOfTheWeek() {
		return dayOfTheWeek;
	}

	public void setDayOfTheWeek(String dayOfTheWeek) {
		this.dayOfTheWeek = dayOfTheWeek;
	}

	public String getNumber() {
		return number;
	}

	public void setNumber(String number) {
		this.number = number;
	}

	@Override
	public String getTableName() {
		
		return " observations ";
	}

	@Override
	public String getInsertSQL() {
		StringBuffer buff = new StringBuffer();
		
		StringBuffer internalBuffer = new StringBuffer();
		
		buff.append("Insert into " + getTableName() + "( ");
		
		if (getObID() != null)  {
			buff.append("obID,");
			internalBuffer.append("'" + getObID() + "',");
		}
		
		if (getNumber() != null)  {
			buff.append("number,");
			internalBuffer.append("'" + getNumber() + "',");
		}
		
		if (getDateOfObs() != null)  {
			buff.append("dateOfObs,");
			internalBuffer.append("'" + getDateOfObs() + "',");
		}
		
		if (getDayOfTheWeek() != null)  {
			buff.append("dayOfTheWeek,");
			internalBuffer.append("'" + getDayOfTheWeek() + "',");
		}
		
		if (getSequence() != null)  {
			buff.append("sequence,");
			internalBuffer.append("'" + getSequence() + "',");
		}
		
		
		return buff.substring(0,buff.length()-1) + ") values ( "+ internalBuffer.substring(0,internalBuffer.length()-1) + ")" ;
	}
	
	
	@Override
	public Collection readAll() {
		
		if (getObID() == null || getDateOfObs() == null) 
			return null;
		
		Collection out = new ArrayList();
		Connection conn = getConnection();
		
		Statement stmt;
		try {
			stmt = conn.createStatement();
			  
		  	ResultSet rs = stmt.executeQuery("Select * from " + getTableName() + " where dateOfObs = '" + getDateOfObs() + "'");
		  	
		  	while (rs.next()) {
		  		ObservationsEntity gte = new ObservationsEntity();
		  		gte.setObID(rs.getString("obID"));
		  		gte.setDateOfObs(rs.getString("dateOfObs"));
		  		gte.setDayOfTheWeek(rs.getString("dayOfTheWeek"));
		  		gte.setNumber(rs.getString("number"));
		  		gte.setSequence(rs.getString("sequence"));
		  		
		  		out.add(gte);
		  	}
	  	
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				if (conn != null)
					conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return out;
	}

	@Override
	public Collection findRows() {
		// TODO Auto-generated method stub
		return null;
	}
	
	public boolean exists() {
		boolean out = false;
		StringBuffer buff = new StringBuffer();
		
		StringBuffer internalBuffer = new StringBuffer();
		
		buff.append("select * from " + getTableName() + " where ");
		
		if (getDateOfObs() != null)  {
			internalBuffer.append("dateOfObs = ");
			internalBuffer.append("'" + getDateOfObs() + "'");
		}
		
		if (getDayOfTheWeek() != null)  {
			
			if (internalBuffer.length() > 0) internalBuffer.append(" and ");
			internalBuffer.append("dayOfTheWeek = ");
			internalBuffer.append("'" + getDayOfTheWeek() + "'");
		}
		
		if (getSequence() != null)  {
			
			if (internalBuffer.length() > 0) internalBuffer.append(" and ");
			internalBuffer.append("sequence = ");
			internalBuffer.append("'" + getSequence() + "'");
		}
			
		String sql = buff.toString() + internalBuffer.toString();
		Connection conn = null;
		try {
			
			conn = getConnection();
			Statement stmt = conn.createStatement();
			
			ResultSet rs = stmt.executeQuery(sql);
			
			if (rs.next())
				out = true;
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			if (conn != null)
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		
		return out;
	}
	
	
	public String getObservationsFromHistory(String forDate, int daysOld) {
		String out = "";
		StringBuffer buff = new StringBuffer();
		
		Calendar cal = Calendar.getInstance();
		String syear = Integer.toString(cal.get(Calendar.YEAR));
		
	buff.append("select distinct number from observations where STR_TO_DATE(dateOfObs,'%Y%m%d') >  DATE_SUB(STR_TO_DATE('" + syear + forDate + "','%Y%m%d'), INTERVAL " + daysOld + " DAY)" + 
					" order by dateOfObs desc, sequence");
		
		
		String sql = buff.toString() ;
		Connection conn = null;
		try {
			
			conn = getConnection();
			Statement stmt = conn.createStatement();
			
			ResultSet rs = stmt.executeQuery(sql);
			
			while (rs.next())
				out += rs.getString("number") + ",";
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			if (conn != null)
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		
		if (out.length() > 0)
			return out.substring(0, out.length()-1);
		else
			return out;
	}

	@Override
	public String getUpdateSQL() {
		// TODO Auto-generated method stub
		return null;
	}
	
	public Hashtable<String, ArrayList<Integer>> loadObsData(String gameCode) {
		
		StringBuffer buff = new StringBuffer();
		
		
		buff.append("select distinct number, dateOfObs from observations " +
					" where dateOfObs in (" +
										" select dateOfObs from ( select dateOfObs, count(*) from observations " + 
										" group by dateOfObs having count(*) > 5 and count(*) < 11 " + 
										" ) as temp " +
								")" + 
					" order by dateOfObs desc");
		
		
		String sql = buff.toString() ;
		Connection conn = null;
		try {
			
			conn = getConnection();
			Statement stmt = conn.createStatement();
			
			ResultSet rs = stmt.executeQuery(sql);
			
			if (obsData == null)
				obsData = new Hashtable<String, ArrayList<Integer>>();
			
			while (rs.next()) {
				String date = rs.getString("dateOfObs");
				if (obsData.get(date) == null) {
					obsData.put(date, new ArrayList<Integer>());
					obsData.get(rs.getString("dateOfObs")).add(rs.getInt("number"));
					
				} else {
					obsData.get(rs.getString("dateOfObs")).add(rs.getInt("number"));
				}
				
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			if (conn != null)
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		
		return obsData;
	}
	
	
public Hashtable<Integer, Integer> getObsPercentiles(String gameCode) {
		
		StringBuffer buff = new StringBuffer();
		Hashtable<Integer, Integer> out = new Hashtable<Integer, Integer>();
		
		buff.append("select number, count(*) as coun, datediff(curdate(), max(dateofobs)) " +
					" from observations o, game_types g " +
					" where g.gameCode = " + gameCode +
					" and o.number <= g.maximumValue " +
					" group by number " +
					" order by count(*) desc");
		
		
		String sql = buff.toString() ;
		Connection conn = null;
		try {
			
			conn = getConnection();
			Statement stmt = conn.createStatement();
			
			ResultSet rs = stmt.executeQuery(sql);
			
			rs.last();
			
			int total = rs.getRow();
			
			int firstpct = (total/4);
			int secondpct = (firstpct +1)*2;
			int thirdpct = (firstpct +1)*3;
		
			 do {
				
				int thisRow = rs.getRow();
				
				if (thisRow <= firstpct) {
					out.put(rs.getInt("number"), 1);
				}
				
				if (thisRow > firstpct && thisRow <= secondpct) {
					out.put(rs.getInt("number"), 2);
				}
				
				if (thisRow > secondpct && thisRow <= thirdpct) {
					out.put(rs.getInt("number"), 3);
				}
				
				if ( thisRow > thirdpct) {
					out.put(rs.getInt("number"), 4);
				}
				
			} while (rs.previous());
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			if (conn != null)
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
				
		return out;
	}

	public Hashtable<Integer, Integer> getObsPercentilesAsOfDaysBefore(String gameCode, int daysBefore) {
		
		StringBuffer buff = new StringBuffer();
		Hashtable<Integer, Integer> out = new Hashtable<Integer, Integer>();
		
		buff.append("select number, count(*) as coun, datediff(curdate(), max(dateofobs)) " +
					" from observations o, game_types g " +
					" where g.gameCode = " + gameCode +
					" and o.number <= g.maximumValue " +
					" and datediff(curdate(), dateofobs) > " + daysBefore +
					" group by number " +
					" order by count(*) desc");
		
		
		String sql = buff.toString() ;
		Connection conn = null;
		try {
			
			conn = getConnection();
			Statement stmt = conn.createStatement();
			
			ResultSet rs = stmt.executeQuery(sql);
			
			rs.last();
			
			int total = rs.getRow();
			
			int firstpct = (total/4);
			int secondpct = (firstpct +1)*2;
			int thirdpct = (firstpct +1)*3;
		
			 do {
				
				int thisRow = rs.getRow();
				
				if (thisRow <= firstpct) {
					out.put(rs.getInt("number"), 1);
				}
				
				if (thisRow > firstpct && thisRow <= secondpct) {
					out.put(rs.getInt("number"), 2);
				}
				
				if (thisRow > secondpct && thisRow <= thirdpct) {
					out.put(rs.getInt("number"), 3);
				}
				
				if ( thisRow > thirdpct) {
					out.put(rs.getInt("number"), 4);
				}
				
			} while (rs.previous());
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			if (conn != null)
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
				
		return out;
	}
	
	
}
