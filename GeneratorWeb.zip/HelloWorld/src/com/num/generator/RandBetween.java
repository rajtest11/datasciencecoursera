package com.num.generator;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Random;

public class RandBetween {

 /**
  * @param args
  */
 private  int min = 1;
 private  int max = 100;
 private static int lookingForMatches = 4;
 private  int[] testSet = {10,29,31,35,45,78};//{10,29,31,35,45}

 public static void main(String[] args) {
  int iterations = 1000000;
  boolean print = false;
  int printCount = 10;

  int univs = 0;
  Factors f = new Factors();
  Factors.populateFactors();
  RandBetween rnd = new RandBetween();

  Date date = new Date();
        
     System.out.println("Started at : " + date.toString() + " matching -- " + rnd.testSet[0] + ","+ 
               rnd.testSet[1] + ","+ rnd.testSet[2] + ","
               + rnd.testSet[3] + ","+ rnd.testSet[4]);
     
  while (!print) {
   univs++;
   int uniquecombs = 0;
   
   int peek = generate(1,1000000);
   String peekString = "";
   int printCounter = 0;
   for (int i = 0; i < iterations; i++) {
    
    HashSet<Integer> uniques = new HashSet<Integer>();
    
    
    int first = rnd.getRandomNumberFrom();
    int second = rnd.getRandomNumberFrom();
    int third = rnd.getRandomNumberFrom();
    int fourth = rnd.getRandomNumberFrom();
    int fifth = rnd.getRandomNumberFrom();

    uniques.add(first);
    uniques.add(second);
    uniques.add(third);
    uniques.add(fourth);
    uniques.add(fifth);

    if (uniques.size() == 5) {
     uniquecombs++;
     int[] arr = { first, second, third, fourth, fifth };
     
     int matched = 0;
     Arrays.sort(arr);

     if (arr[0] == rnd.testSet[0]) matched++;
     if (arr[1] == rnd.testSet[1]) matched++;
     if (arr[2] == rnd.testSet[2]) matched++;
     if (arr[3] == rnd.testSet[3]) matched++;
     if (arr[4] == rnd.testSet[4]) matched++;
     
     if (matched == lookingForMatches) {
      print = true;
      
     }

     if (print) printCounter++;
     if (print && printCounter < printCount) {
      System.out.print(i + " --- " + arr[0] + " " + arr[1] + " " + arr[2] + " " + arr[3] + " " + arr[4]);
      
      Hashtable<Integer, Integer> maxFactor = new Hashtable<Integer, Integer>();
      for (int k=0; k<5; k++) {
       ArrayList<Integer> factors = Factors.factorsMap.get(arr[k]);
       if (arr[k] > 2 && factors.size() > 0) {
        Iterator<Integer> it = factors.iterator();
        
        while (it.hasNext()) {
         int thisfactor = it.next();
         if (maxFactor.containsKey(thisfactor)) {
          maxFactor.put(thisfactor, maxFactor.get(thisfactor)+1);
         } else {
          maxFactor.put(thisfactor, 1);
         }
        }
        
       }
      }
      sortValue(maxFactor);
      
      clearHash(maxFactor);
      System.out.println("----" + maxFactor + "top: " +  chooseTopKey(maxFactor));
     }
     
     if (i == peek)
      peekString += peek + "-" + arr[0] + " " + arr[1] + " " + arr[2] + " " + arr[3] + " " + arr[4];

    } else {
     continue;
    }

   }
   
   if (univs % 100 == 0) 
    System.out.println(univs + " iterations." + uniquecombs + " uniques." + " ex. " + peekString);
  }
  System.out.println("Done : " + univs);
 }

 private static int generate(int min, int max) {
  return (min + (int) (Math.random() * ((max - min) + 1)));
 }

 public  int getRandomNumberFrom() {
  Random foo = new Random();
  int randomNumber = foo.nextInt((max + 1) - min) + min;

  return randomNumber;

 }
 
  private static void sortValue(Hashtable<?, Integer> t){

        //Transfer as List and sort it
        ArrayList<Map.Entry<?, Integer>> l = new ArrayList(t.entrySet());
        Collections.sort(l, new Comparator<Map.Entry<?, Integer>>(){

          public int compare(Map.Entry<?, Integer> o1, Map.Entry<?, Integer> o2) {
             return o1.getValue().compareTo(o2.getValue());
         }});

        //System.out.println(l);
     }
  
  private static void clearHash(Hashtable<Integer, Integer> t) {
  Enumeration<Integer> enumkeys = t.keys();
     while (enumkeys.hasMoreElements()) {
     Integer thisKey = enumkeys.nextElement();
     
     if (thisKey == 2) {
      t.remove(thisKey);
     } else {
      if (t.get(thisKey) == 1)
       t.remove(thisKey);
     }
     
    }
  }
  
  private static int chooseTopKey(Hashtable<Integer, Integer> t) {
   
    if (t.size() > 0) {
    Enumeration<Integer> enumkeys = t.keys();
   int maxkey = 0;
   int maxVal = 0;
   int tempMaxKey = 0;
   
   
      while (enumkeys.hasMoreElements()) {
      Integer thisKey = enumkeys.nextElement();
      
      if (maxkey == 0)
       maxkey = thisKey;
      else {
       if (thisKey > maxkey) maxkey = thisKey;
      }
      
      if (maxVal == 0) {
       maxVal = t.get(thisKey);
       tempMaxKey = thisKey;
      }
      else {
       if (t.get(thisKey) > maxVal) {
        maxVal = t.get(thisKey);
        tempMaxKey = thisKey;
       }
      }
     
     }
      
      if (t.get(maxkey) > maxVal) return maxkey;
      else return tempMaxKey;
    } else {
     return 0;
    }
   }

}