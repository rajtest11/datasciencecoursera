package com.num.generator;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.*;

public class PatternInRealData {
	static TreeMap freq = new TreeMap();
	static HashMap<Integer,HashMap> followers = new HashMap<Integer,HashMap>();
	static int avgFreqOfFollowers = 0;
	static int[] lastComb = new int[]{16,29,48,52,54};
	
	public static void main(String[] args){
		PatternInRealData p = new PatternInRealData();
		p.patterns();
	}
	
	public void patterns(){
		
		double starttime = System.currentTimeMillis();
		
		
		
		try {
			// Open the file that is the first
			// command line parameter
			FileInputStream fstream = new FileInputStream("D:\\numbers\\mm.txt");
			// Get the object of DataInputStream
			DataInputStream in = new DataInputStream(fstream);
			BufferedReader br = new BufferedReader(new InputStreamReader(in));
			String strLine, firstLine=null;
			String secondLine=null;
			int lineNum = 0;
			int sumofFreq = 0;
			int countOfFollowers = 0;
			// Read File Line By Line
			while ((strLine = br.readLine()) != null) {
				// Print the content on the console
				String[] strtop = strLine.split("\\+");
				//StringTokenizer strtok = new StringTokenizer(strtop[0],",");
				strLine = strtop[0] + ",";
				
				if (firstLine == null) firstLine = strLine;
				
				StringTokenizer strtokf = new StringTokenizer(firstLine,",");
				
				for (int i = 0; i<5; i++) {
					String num = strtokf.nextToken();
					if (!followers.containsKey(new Integer(num))) {
						followers.put(new Integer(num), new HashMap<String, Integer>());
					} 
					
					if (lineNum > 0) {//On the second line or more, process to compute followers
						secondLine = strLine;	
						StringTokenizer strtokfs = new StringTokenizer(secondLine,",");
						for (int k = 0; k<5; k++) {
							String foll = strtokfs.nextToken();
							if (followers.containsKey(new Integer(num))) {
								sumofFreq++;
								HashMap<String, Integer> follMap = (HashMap<String, Integer>)followers.get(new Integer(num));
								if (follMap.containsKey(foll)) {
									follMap.put(foll, follMap.get(foll)+1);
								} else {
									follMap.put(foll, new Integer(1));
									countOfFollowers++;
								}
								followers.put(new Integer(num), follMap);
							} else {
								//SHOULD NOT HAPPEN
							}
						}
					}
				}
					
				firstLine = secondLine;
				lineNum++;
			}
			avgFreqOfFollowers = sumofFreq/countOfFollowers;
			// Close the input stream
			in.close();
		} catch (Exception e) {// Catch exception if any
			System.err.println("Error: " + e.getMessage());
		}
	
		//printFollowers(followers);
		
		//predict based on last occurrence
		
		includeNextNums(lastComb);
		excludeNextNums(lastComb);
		
		
		
		System.out.println("Time taken "
				+ (System.currentTimeMillis() - starttime) + " ms");

	
	} 
	
static void printFollowers(HashMap<Integer,HashMap> in) {
		
		Iterator iterator = in.keySet().iterator();   
	    
		while (iterator.hasNext()) {   
		   Integer key = (Integer) iterator.next();   
		   HashMap value = (HashMap) in.get(key);   
		    
		  // System.out.println(key + " " + sortByValue(value));   
		   System.out.println(key + " " + value);   
		   
		   System.out.println();
		}  
	
	}
	
	static Map sortDesByValue(Map map) {
		List list = new LinkedList(map.entrySet());
		Collections.sort(list, new Comparator() {
			public int compare(Object o1, Object o2) {
				return ((Comparable) ((Map.Entry) (o2)).getValue())
						.compareTo(((Map.Entry) (o1)).getValue());
			}
		});
		Map result = new LinkedHashMap();

		for (Iterator it = list.iterator(); it.hasNext();) {
			Map.Entry entry = (Map.Entry) it.next();
			result.put(entry.getKey(), entry.getValue());
		}
		return result;
	}  
	
	static Map sortAscByValue(Map map) {
		List list = new LinkedList(map.entrySet());
		Collections.sort(list, new Comparator() {
			public int compare(Object o1, Object o2) {
				return ((Comparable) ((Map.Entry) (o1)).getValue())
						.compareTo(((Map.Entry) (o2)).getValue());
			}
		});
		Map result = new LinkedHashMap();

		for (Iterator it = list.iterator(); it.hasNext();) {
			Map.Entry entry = (Map.Entry) it.next();
			result.put(entry.getKey(), entry.getValue());
		}
		return result;
	}  
	
static void includeNextNums (int[] lastComb) {
		
		System.out.println ("INCLUDE THESE +++++++++++++++++++");
		Iterator iterator = followers.keySet().iterator();  
		
		while (iterator.hasNext()) {
			Integer key = (Integer) iterator.next();
			HashMap value = (HashMap) followers.get(key);
			int counter = 0;

			for (int i = 0; i < lastComb.length; i++) {
				int follFreq = (value
						.containsKey(Integer.toString(lastComb[i]))) ? (Integer) value
						.get(Integer.toString(lastComb[i]))
						: 0;

				if (follFreq >
				// averageOfValues(value)
				avgFreqOfFollowers
			//	13
				)
					counter++;
			}

			int topCount = 0;
			if (counter >= 4) { // At least 4 numbers in the input are above
								// average followers of the number in key
				// AND some are in top 5

				HashMap sortedMapOfFollowers = (HashMap) sortDesByValue(value);

				for (int i = 0; i < lastComb.length; i++) {
					Iterator it = sortedMapOfFollowers.entrySet().iterator();
					for (int j = 0; j < 5; j++) {
						if (it.hasNext()) {
							String entry = it.next().toString();
							if (lastComb[i] == (Integer.parseInt(entry
									.substring(0, entry.indexOf("=")))))
								topCount++;
						}
					}
				}

			}
			if (topCount > 0)
				System.out.println(key + " matches " + counter
						+ " times. TopCount " + topCount + " "
						+ sortDesByValue(value));
		}  
	}
	
static void excludeNextNums (int[] lastComb) {
		
		System.out.println ("EXCLUDE THESE +++++++++++++++++++");
		Iterator iterator = followers.keySet().iterator();  
		
		while (iterator.hasNext()) {
			Integer key = (Integer) iterator.next();
			HashMap value = (HashMap) followers.get(key);
			int counter = 0;

			for (int i = 0; i < lastComb.length; i++) {
				int follFreq = (value
						.containsKey(Integer.toString(lastComb[i]))) ? (Integer) value
						.get(Integer.toString(lastComb[i]))
						: 0;

				if (follFreq <
						// averageOfValues(value)
						avgFreqOfFollowers
											)
					counter++;
			}

			int topCount = 0;
			if (counter >=4) { // At least 3 numbers in the input are below
								// average followers of the number in key
				// AND some are in top 5

				HashMap sortedMapOfFollowers = (HashMap) sortAscByValue(value);

				for (int i = 0; i < lastComb.length; i++) {
					Iterator it = sortedMapOfFollowers.entrySet().iterator();
					for (int j = 0; j < 5; j++) {
						if (it.hasNext()) {
							String entry = it.next().toString();
							if (lastComb[i] == (Integer.parseInt(entry
									.substring(0, entry.indexOf("=")))))
								topCount++;
						}
					}
				}
			//	if (topCount > 0)
				System.out.println(key + " matches " + counter
						+ " times. TopCount " + topCount + " "
						+ sortAscByValue(value));
			}
			
				
		}  
	}
	
	static int averageOfValues(HashMap<String,Integer> in) {
		int sum = 0;
		int count = 0;
		Iterator iterator = in.values().iterator();   
		while (iterator.hasNext()) {
			sum += (Integer)iterator.next();
			count++;
		}
		
		return sum/count;
	}
	
}
