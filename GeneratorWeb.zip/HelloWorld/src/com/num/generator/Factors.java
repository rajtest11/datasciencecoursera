package com.num.generator;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import com.num.generator.dataaccess.ResultHistoryEntity;

public class Factors {

	/**
	 * 
	 * @param args
	 */

	public static HashMap<Integer, ArrayList> factorsMap = new HashMap<Integer, ArrayList>();

	public static void main(String[] args)

	{

		for (int j = 3; j <= 75; j++) {

			List<Integer> fac = factorsOf(j);

			if (!factorsMap.containsKey(j))

				factorsMap.put(j, (ArrayList) fac);

			System.out.println(j + "=" + fac);

		}
		
		System.out.println(getMaxFactorAndCountForComb(new int[] { 11,13,51,57,69 }));
		//System.out.println(getSumLoops());
		
		/*ResultHistoryEntity rhe = new ResultHistoryEntity();
		String gameCode = "2";
		rhe.setGameCode(gameCode);
		String serials = rhe.getLastN("serialNumber", 1800,0);
		
		String[] serArr = serials.split(",");
		
		for (int j=0; j< serArr.length; j++) {
			rhe.updateMaxFactorForDerivedRecords(gameCode, serArr[j]);
			
			
		}*/
		
		
	}
	
	
	public static void populateFactors()

	{
		System.out.println("Factors.populateFactors: .....");

		for (int j = 3; j <= 75; j++) {

			if (!factorsMap.containsKey(j)) {

				List<Integer> fac = factorsOf(j);

				factorsMap.put(j, (ArrayList) fac);

			}

		}

	}
	
	public static String getMaxFactorAndCountForComb(int[] in) {
		
		if (factorsMap.size() == 0) populateFactors();
		 
		Hashtable<Integer, Integer> maxFactor = new Hashtable<Integer, Integer>();
		
	      for (int k=0; k<5; k++) {
	       ArrayList<Integer> factors = Factors.factorsMap.get(in[k]);
	       if (in[k] > 2 && factors.size() > 0) {
	        Iterator<Integer> it = factors.iterator();
	        
	        while (it.hasNext()) {
	         int thisfactor = it.next();
	         if (maxFactor.containsKey(thisfactor)) {
	          maxFactor.put(thisfactor, maxFactor.get(thisfactor)+1);
	         } else {
	          maxFactor.put(thisfactor, 1);
	         }
	        }
	        
	       }
	      }
	     // sortValue(maxFactor);
	      
	      clearHash(maxFactor);
	      
	      if (maxFactor.size() > 0) {
	      int maximumFactor = chooseTopKey(maxFactor);
	      int maxFactorCount = maxFactor.get(maximumFactor);
	      //System.out.println("----" + maxFactor + "top: " + maximumFactor  + " - " + maxFactorCount);
	      
	      return maximumFactor  + " " + maxFactorCount;
	      } else 
	    	  return "";
	}

	private static List<Integer> factorsOf(int val) {

		List<Integer> factors = new ArrayList<Integer>();

		for (int i = 2; i <= val; i++)

		{

			if (val % i == 0)

			{

				factors.add(i);

			}

		}

		return factors;

	}
	
	
	
	private static void sortValue(Hashtable<?, Integer> t){

        //Transfer as List and sort it
        ArrayList<Map.Entry<?, Integer>> l = new ArrayList(t.entrySet());
        Collections.sort(l, new Comparator<Map.Entry<?, Integer>>(){

          public int compare(Map.Entry<?, Integer> o1, Map.Entry<?, Integer> o2) {
             return o1.getValue().compareTo(o2.getValue());
         }});

        //System.out.println(l);
     }
  
  private static void clearHash(Hashtable<Integer, Integer> t) {
  Enumeration<Integer> enumkeys = t.keys();
     while (enumkeys.hasMoreElements()) {
     Integer thisKey = enumkeys.nextElement();
     
     if (thisKey == 2) {
      t.remove(thisKey);
     } else {
      if (t.get(thisKey) == 1)
       t.remove(thisKey);
     }
     
    }
  }
  
  private static int chooseTopKey(Hashtable<Integer, Integer> t) {
   
    if (t.size() > 0) {
    Enumeration<Integer> enumkeys = t.keys();
   int maxkey = 0;
   int maxVal = 0;
   int tempMaxKey = 0;
   
   
      while (enumkeys.hasMoreElements()) {
      Integer thisKey = enumkeys.nextElement();
      
      if (maxkey == 0)
       maxkey = thisKey;
      else {
       if (thisKey > maxkey) maxkey = thisKey;
      }
      
      if (maxVal == 0) {
       maxVal = t.get(thisKey);
       tempMaxKey = thisKey;
      }
      else {
       if (t.get(thisKey) > maxVal) {
        maxVal = t.get(thisKey);
        tempMaxKey = thisKey;
       }
      }
     
     }
      
      if (t.get(maxkey) > maxVal) return maxkey;
      else return tempMaxKey;
    } else {
     return 0;
    }
   }

}
