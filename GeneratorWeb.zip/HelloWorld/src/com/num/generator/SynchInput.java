package com.num.generator;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Properties;

import com.num.generator.dataaccess.DBUtils;
import com.num.generator.dataaccess.GameTypesEntity;
import com.num.generator.dataaccess.ResultHistoryEntity;

public class SynchInput {

	// This class runs Numbers class once for each extra line in mm or pb txt files
	/**
	 * @param args
	 */
	private static String gameCode;
	public static boolean fromBatchProgram = false;
	private static String type = null;
	
	public static void main(String[] args) {
		// START processing missing lines
		Properties prop = new Properties();
		Numbers n = null;		
		
		if (args != null && args.length > 0) {
			type = args[0];
		}		
		
		Numbers.addLineToFile("C:\\temp\\MyGameScraper.log", "SYNCHINPUT : Type " + type , false); 
		
		if (type == null) {
			FileInputStream fis;
			try {
				fis = new FileInputStream(new File("C:\\Users\\johris\\git\\git\\Generator\\props.properties"));
			
				prop.load(fis);
				fis.close();
			} catch (FileNotFoundException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			type = prop.getProperty("type"); 
		}
		
		String inputFileName = (type.equals("mm"))?"C:\\Users\\johris\\git\\git\\HelloWorld\\mm.txt":"C:\\Users\\johris\\git\\git\\HelloWorld\\pb.txt";
		Hashtable excessInputBuffer = new Hashtable();
		
		int inputLines = Numbers.getLinesCountFromFile(inputFileName);
		int processedLines = getLastProcessedLineForType(type);
		System.out.println("Lines in input " + inputLines + " already processed " + processedLines);
		
		if (fromBatchProgram)
			Numbers.addLineToFile("C:\\temp\\MyGameScraper.log", "SYNCHINPUT : Lines in input " + inputLines + " already processed " + processedLines , false);
		
		if (inputLines > processedLines) {
			//PROCESSING EXTRA LINES
			
			if (fromBatchProgram)
				Numbers.addLineToFile("C:\\temp\\MyGameScraper.log", "SYNCHINPUT : PROCESSING EXTRA LINES"  , false);
			
			System.out.println("PROCESSING EXTRA LINES");
			int diff = inputLines - processedLines;
			try {
				File m = new File(inputFileName);
				FileReader fr = new FileReader(m);
				BufferedReader in = new BufferedReader(fr);
			
				String line;
				int lineNum = 0;
				while ((line = in.readLine()) != null) {
					if (lineNum < diff) {
						excessInputBuffer.put(lineNum, line);
						
					} else continue;
				
					lineNum++;
				}
				
				fr.close();
				in.close();
			
								
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} 
			//System.out.println(excessInputBuffer);

			Numbers.removeLineFromFile(inputFileName+".stmp", "*");
			Enumeration index = excessInputBuffer.keys();
			while (index.hasMoreElements()) {
				Integer ind = (Integer) index.nextElement();
				//System.out.println(ind + ": " + excessInputBuffer.get(ind));
				Numbers.removeLineFromFile(inputFileName, (String)excessInputBuffer.get(ind));
				Numbers.addLineToFile(inputFileName+".stmp", (String)excessInputBuffer.get(ind),false);
			}
			
			// NOW process .stmp file line by line
			try {
				File m = new File(inputFileName + ".stmp");
				FileReader fr = new FileReader(m);
				BufferedReader in = new BufferedReader(fr);

				String line;
				while ((line = in.readLine()) != null) {
					//System.out.println("Adding " + line +  " to " + inputFileName);
					
					addFilterTestResults(line);
					System.gc();
					if (!Numbers.addLineToFile(inputFileName, line, true)) {
						
						if (fromBatchProgram) {
							Numbers.addLineToFile("C:\\temp\\MyGameScraper.log", " Could not add " + line + " to " + inputFileName + " EXITING!" , false);
						}
						
						m.delete();
						
						Runtime.getRuntime().exit(1);
					}
					
					if (inputLines - processedLines > 4) // If it is a batch synch, stop update of the database.
						Numbers.doNotUpdateInDatabase = true;
					else
						Numbers.doNotUpdateInDatabase = false; // false
					
										
					if (fromBatchProgram)
						Numbers.addLineToFile("C:\\temp\\MyGameScraper.log", " CREATING NUMBERS OBJECT with TYPE " + type  , false);
					
					n = new Numbers(type);
					Numbers.numberAppearance(10);
					Numbers.freq = new HashMap();
					Numbers.frq = new HashMap();
					Numbers.numRecordsInFile = 0;
					Numbers.setLoaded(false);
					System.out.println("ADDED " + line);
					
					if (fromBatchProgram) {
						Numbers.addLineToFile("C:\\temp\\MyGameScraper.log", " ADDED " + line  , false);
					}
					n = null;
				}
				
				in.close();
				fr.close();
				m.delete();
			} catch (FileNotFoundException e) {
				if (fromBatchProgram)
					Numbers.addLineToFile("C:\\temp\\MyGameScraper.log", "EXCEPTION " + e.getMessage() , false);
			} catch (IOException e) {
				if (fromBatchProgram)
					Numbers.addLineToFile("C:\\temp\\MyGameScraper.log", "EXCEPTION " + e.getMessage() , false);
			}
			Numbers.doNotUpdateInDatabase = false;
			
		} else {
			System.out.println("INPUT UP TO DATE");
			//System.exit(0);
		}
		
		// END processing missing lines


	}

	private static void addFilterTestResults(String line) {
		// Populate the result history test filter table
		String[] linesplit = line.split(",");
		int[] comb = new int[5];
		
		comb[0] = Integer.parseInt(linesplit[0]);
		comb[1] = Integer.parseInt(linesplit[1]);
		comb[2] = Integer.parseInt(linesplit[2]);
		comb[3] = Integer.parseInt(linesplit[3]);
		
		String[] lastsplit = linesplit[4].split("\\+");
		comb[4] = Integer.parseInt(lastsplit[0]);
		
		Generator.setGameCode(gameCode);
		Generator.setType(type);
		Generator g = new Generator();
			
		Generator.CombTest(comb, true);
		
		//Numbers.numberAppearance(10);
		Numbers.freq = new HashMap();
		Numbers.frq = new HashMap();
		Numbers.numRecordsInFile = 0;
		Numbers.setLoaded(false);
		
	}

	private static int getLastProcessedLineForType(String type) {
		GameTypesEntity gte = new GameTypesEntity();
		gameCode = gte.findGameCodeByProgramCode(type);
		ResultHistoryEntity rhe = new ResultHistoryEntity();
		int value  =  Integer.parseInt(rhe.getValueForField("serialNumber",gameCode,0));
		
		return value;
	}

}
