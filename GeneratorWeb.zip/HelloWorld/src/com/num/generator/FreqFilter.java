package com.num.generator;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.List;
import java.util.Properties;

public class FreqFilter {

	static boolean doPrint = true;

	static Writer output = null;
	//PARAMETERS
	
	static int choices = 5;
	static int startSum = 90, endSum = 200;
	static int last5Range = 2;
	static int numberOfZeroInAllBrackets = 2;
	static int numberMaxInBracket = 3;
	static int maxNumbersNotIn25Combs =1;
	//static int[] freqList = new int[] {155,154,153,151,150,149,147,146,145,144,143,142,141,140,139,138,136,135,134,132,130,129,127,126,123,122,121,114,112,110,75,63,60,52};
	static Integer[] freqList = null;
	static int[] lastfrqs = null;
	
	static int[] movements = new int[] {4,10,10,12,70};   // {80,70,60,20,15} - 89K, {2,10,40,50,80} - 74K - {2,6,10,12,20} - 31K
	static int avgFreq = 133;
	static Numbers n = null;
	static int maxSumOfFreqDistance = 55;
	static int minSumOfFreqDistance = -55;
	
	static int equiDistantFilterCount =0;
	static int processPreselectedFreqsCount = 0;
	private static int maxRepeatFilterCount=0;

	private static int coagulationFilterCount=0;

	private static int atLeastOneSharedFreqCount=0;
	
	
	static int maxValue = 0; // size of current freq list
	static String frqNumbers = null;

	public static int[] matchMap = null; //new int[] {2,0,2,1,0,0}; // {1,2,2,0,0} Take 1 freq from 0 appearance, 2 from 1 appearance etc.
	static ArrayList<String> autoFreqRanges = null; // Read the last 5 freq results and for each freq, get the max and min.

	
	public static void main(String[] args) {
		int counter = 1;
		int numberPassedTest = 0;
		int sumofdigits = 0;
		int[] comblocal = new int[choices];
		
		
		Numbers.doNotUpdateInDatabase = true;
		
		if (n == null)
			n = new Numbers(null);
		
		if (freqList == null) {
			if (n.getCurrentActiveFreqs() == null)
				freqList = n.getCurrentFreqList();
			else
				freqList = n.getCurrentActiveFreqs();
		}
		
		Arrays.sort(freqList, Collections.reverseOrder());
		
		maxValue = freqList.length;
		// Setup comb for the initial combination 
		double starttime = System.currentTimeMillis();
		try{
			File f = new File("C:\\eclipse\\workspace\\first\\HelloWorld\\frqs.properties");
			if(f.exists())
				f.delete();
			output = new OutputStreamWriter(new FileOutputStream(f,true));
			output.write("StartSUM:" + startSum + " | EndSum:" + endSum + " | numbersFromlast5CombsMax:" + last5Range + " | numberOfZeroInAllBrackets:" + numberOfZeroInAllBrackets +" | numberMaxInBracket:" + numberMaxInBracket + " | maxNumbersNotIn25Combs:" + maxNumbersNotIn25Combs);	    
			output.write("\r\n");
			
			int[] comb = new int[choices];
	
			for (int i = 0; i < choices; i++) {
	
				comb[i] = i;
				comblocal[i] = freqList[comb[i]];
	
			}
	
			// Print the first combination 
			
			if (intelligentTest(comblocal)) { 
				numberPassedTest++;
				if(doPrint && maxValue <= 50) {
					myprint(counter, comblocal, choices);
				}
			}
			
			sumofdigits += sum(comb);
	
			while (next_comb(comb, choices, maxValue)) {
				counter++;
				sumofdigits += sum(comb);
			
				for (int i = 0; i < choices; i++) {
					
					//comb[i] = i;
					comblocal[i] = freqList[comb[i]];
		
				}
				
				//if (comblocal[0] == 154 && comblocal[1] == 137 && comblocal[2] == 136 && comblocal[3] == 126 && comblocal[4] == 118) {
				//	System.out.println("Hi");
				//}
				
				if (intelligentTest(comblocal)) {
					numberPassedTest++;
					if(doPrint&& maxValue <= 50)
						myprint(counter, comblocal, choices);
				}
			}
		}catch(FileNotFoundException fx){
	    	fx.printStackTrace();
	    }catch(IOException ix){
	    	ix.printStackTrace();
	    }finally{
	    	try{
	    	output.close();
	    	}catch(IOException ix){
	    		ix.printStackTrace();
	    	}
	    }
		System.out.println(choices + " out of " + maxValue + " | Total choices " + counter + " | Average of sums " + 
							 + sumofdigits/counter + " | Passed filter " + numberPassedTest + " | Percentage " + (numberPassedTest*100/counter));
		
		System.out.println(
				" equiDistantFilterCount " + equiDistantFilterCount*100/counter +
				" processPreselectedFreqsCount " + processPreselectedFreqsCount*100/counter +
				" maxRepeatFilterCount " + maxRepeatFilterCount*100/counter +
				" coagulationFilterCount " + coagulationFilterCount*100/counter +
				" atLeastOneSharedFreqCount " + atLeastOneSharedFreqCount*100/counter 
				 );
		
		
		System.out.println("Time taken "
				+ (System.currentTimeMillis() - starttime) + " ms");
		
		
		//freqTest(new int[]{75,67,59,57,48});
	
	}

	private static boolean intelligentTest(int[] comb) {
		boolean out = false;
		
		if (lastfrqs == null || lastfrqs.length == 0) {
			getLastFreqsFromFile();
		}
		
		if ( 
							//numsum >= startSum
							//&& numsum <= endSum 
				(equiDistantFilter(comb) ? true: (++equiDistantFilterCount > 0? false:true ))
							//&& spreadRangeFilter(comb,15, 80)
							//&& maxDistanceFilter(comb, movements)
				&& (processPreselectedFreqs(comb)? true: (++processPreselectedFreqsCount> 0?false:true ))
				&& (maxRepeatFilter(comb,lastfrqs)? true: (++maxRepeatFilterCount> 0?false:true ))
				&& (coagulationFilter(comb,lastfrqs)? true: (++coagulationFilterCount> 0?false:true ))
							//&& minHighestFreq (comb, 146) 
							//&& maxLowestFreq (comb, avgFreq)
				//&& Numbers.handleMustIncludes(comb,5)
							//&& n.directionOfFreqMovement(comb)
							//&& gapFilling (comb)
				//&& sumOfFreqDistanceFromAvg (comb,maxSumOfFreqDistance,minSumOfFreqDistance)  /// High, Low values for sum of distance of freqs
							//&& removeExtremes(comb)
				&& (n.atLeastOneSharedFreq(comb)? true: (++atLeastOneSharedFreqCount> 0?false:true ))
				//&& n.performMAAnalysis(comb)
				
				
		){ 
		out = true;
		 
		}
		return out;
	}
	
	private static void getLastFreqsFromFile() {
		File m = new File("C:\\Users\\johris\\git\\git\\Generator\\freqAppearanceMap"+ Numbers.gam);
		BufferedReader in;
		try {
			in = new BufferedReader(new FileReader(m));
			String line;
			int lineNum = 0;
			while ((line = in.readLine()) != null) {
				if (lineNum > 0)
					break;
				else {
					String[] splitplus = line.split(" \\t")[1].split(" ");
					//System.out.println(splitplus);
					FreqFilter.lastfrqs = new int [splitplus.length];
					for (int i=0; i< splitplus.length; i++) {
						FreqFilter.lastfrqs[i] = Integer.parseInt(splitplus[i].trim());
					}
				}
				
				
				lineNum++;
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

	private static boolean processPreselectedFreqs(int[] comb) {
		//preSelectedFreqs=150,153;145-149
		boolean out = false;
		
		List lst = Arrays.asList(comb);
		
		if (frqNumbers == null) {
			try {
				Properties prop = new Properties();
				File propFile = new File("C:\\Users\\johris\\git\\git\\Generator\\props.properties"); 
				FileInputStream fis = new FileInputStream(propFile);
				
				prop.load(fis);
				
				frqNumbers = prop.getProperty("preSelectedFreqs");
				System.out.println("FreqFilter.processPreSelectedFreqs ---- Preselected Freqs : " + frqNumbers);
				fis.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		int [][] freqMatrix = new int[5][5];
		if (frqNumbers.length() == 0) {
			if (autoFreqRanges == null) {
				
				File m = new File("C:\\Users\\johris\\git\\git\\Generator\\freqAppearanceMap"+ Numbers.gam);
				BufferedReader in;
				try {
					in = new BufferedReader(new FileReader(m));
					String line;
					int lineNum = 0;
					while ((line = in.readLine()) != null) {
						if (lineNum > 4)
							break;
						else {
							String[] splitplus = line.split(" \\t")[1].split(" ");
							//System.out.println(splitplus);
							//FreqFilter.lastfrqs = new int [splitplus.length];
							for (int i=0; i< splitplus.length; i++) {
								freqMatrix[lineNum][i] = Integer.parseInt(splitplus[i].trim());
							}
						}
						lineNum++;
					}
					
					for (int x=0; x<5;x++) {
						Arrays.sort(freqMatrix[x]);
					}
				} catch (FileNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				
				autoFreqRanges = new ArrayList<String>();
				for (int i=0; i< 5; i++) {
					
					autoFreqRanges.add(Math.min(freqMatrix[0][i],Math.min(freqMatrix[1][i],Math.min(freqMatrix[2][i],Math.min(freqMatrix[3][i],freqMatrix[4][i])))) + "-" + 
							Math.max(freqMatrix[0][i],Math.max(freqMatrix[1][i],Math.max(freqMatrix[2][i],Math.max(freqMatrix[3][i],freqMatrix[4][i])))));
				}
			}
			
			for (int j=0; j<autoFreqRanges.size(); j++) {
				frqNumbers = frqNumbers + autoFreqRanges.get(j) + ((j == autoFreqRanges.size()-1)?"":";");
			}
			
			System.out.println("FreqFilter.processPreSelectedFreqs ---- Computed Preselected Freqs : " + frqNumbers);
			
		}
		
		
		
		if (frqNumbers.length() > 0) {
			
			 String[] frqNumbersArrays = frqNumbers.split("\\;");
			 
			 for(int k =0;k<frqNumbersArrays.length;k++){
				 int matches = 0;
				 if (frqNumbersArrays[k].indexOf("-") < 0) { // No range provided
					 String[] indivFreqNumbers = frqNumbersArrays[k].split("\\,");
					 for(int j=0;j<indivFreqNumbers.length;j++){
						if (lst.contains(indivFreqNumbers[j]))
							matches++;
					 }
				 } else { // Its a range
					 String[] indivFreqNumbers = frqNumbersArrays[k].split("-");
					 for (int p=0; p<comb.length;p++) {
						 if (Integer.parseInt(indivFreqNumbers[0]) <= comb[p]  && comb[p] <= Integer.parseInt(indivFreqNumbers[1]))
							 matches++;
					 }
					 
				 }
				 if (matches == 1 || matches == 2 || matches == 3) {
					 out = true;
				 } else {
					 out = false;
					 break;
				 }
			 }
		 } else
			 out = true;
		
		return out;
	}

	private static boolean removeExtremes(int[] comb) { // Remove combinations with 2 out of top 4 or bottom 4 frequencies
		boolean out = true;
		
		if ((comb[0] == freqList[0] || comb[0] == freqList[1] || comb[0] == freqList[2] || comb[0] == freqList[3]) &&
				(comb[1] == freqList[0] || comb[1] == freqList[1] || comb[1] == freqList[2] || comb[1] == freqList[3]))
			out = false;
		
		
		return out;
	}

	private static boolean sumOfFreqDistanceFromAvg(int[] comb, int high, int  low) { // We want the sum of distances from the average to be within a certain range
																// Normally higher than 0 but less than 0 in cases when very high freq numbers have 
																// appeared recently.		
															
		boolean out = true;
		
		int rangeHigh = high; // Max value = 63
		int rangeLow = low; // Min value = -213
		
		int sumOfDistance = comb[0] + comb[1] +comb[2] +comb[3] +comb[4] - 5*avgFreq;
		
		if (sumOfDistance > rangeHigh || sumOfDistance < rangeLow ) out = false;
		
		return out;
	}

	private static boolean gapFilling(int[] comb) {
		// If top two freq are at least 4 apart, we want at least one freq to fall between those in the next comb
		boolean out = false;
		int nums = 0;
		if (lastfrqs[0] - lastfrqs[1] >= 4) {
			for (int i=0; i<comb.length; i++) {
				if (lastfrqs[0] >= comb[i] && lastfrqs[1] <= comb[i])
					nums ++;
			}
		} else {
			return true;
		}
		
		if (nums > 0 && nums < 4)
			out = true;
		
		return out;
	}

	

	private static boolean maxLowestFreq(int[] comb, int maxLow) { // We want least one freq lower than maxLow
		boolean b = true;
		
		if (comb[4] > maxLow) b= false;
		
		return b;
	}

	static void myprint(int counter, int[] comb, int k) {

		try {  
			output.write("");
		

			for (int i = 0; i < k; i++)    
				//output.write((comb[i]+1) + ",");
				output.write((comb[i]) + ",");
			

			output.write(";");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	
	static int sum (int[] comb) {
		int sum = 0;
		for (int i=0; i < comb.length; i++)
			sum += comb[i];
		
		return sum;
	}
	
	static boolean next_comb(int comb[], int k, int n) {

		int i = k - 1;

		comb[i]++;

		while (i > 0 && (comb[i] >= n - k + 1 + i)) {
			i--;
			comb[i]++;
		}
		
		if (comb[0] > n - k) /* Combination (n-k, n-k+1, ..., n) reached */
			return false; /* No more combinations can be generated */

		/* comb now looks like (..., x, n, n, n, ..., n). 

		 Turn it into (..., x, x + 1, x + 2, ...) */

		for (i = i + 1; i < k && i > 0; i++)
			comb[i] = comb[i - 1] + 1;

		return true;

	}
	
	static boolean equiDistantFilter(int [] comb){ // We do not want more than 3 freqs equidistant
		boolean b =true;
		int distance1 = 0;	
		int distance2 = 0; 
		int distance3 = 0;
		int distance4 = 0;
		
		distance1 = comb[0] - comb[1];
		distance2 = comb[1] - comb[2];
		distance3 = comb[2] - comb[3];
		distance4 = comb[3] - comb[4];
		
		Hashtable<Integer, Integer> hash = new Hashtable<Integer, Integer>();
		
		hash.put(distance1,1);
		
		if (hash.get(distance2)!= null) {
			int count = hash.get(distance2);
			hash.put(distance2, count+1);
		} else {
			hash.put(distance2, 1);
		}
		
		if (hash.get(distance3)!= null) {
			int count = hash.get(distance3);
			hash.put(distance3, count+1);
		} else {
			hash.put(distance3, 1);
		}
			
		if (hash.get(distance4)!= null) {
			int count = hash.get(distance4);
			hash.put(distance4, count+1);
			
		} else {
			hash.put(distance4, 1);
		}
		
		Enumeration en = hash.keys();
		while(en.hasMoreElements()) {
			int count = hash.get(en.nextElement());
			
			if (count > 2) {
				b = false;
				break;
			}
		}
			
//		if (!b) System.out.println(comb[0] + " " + comb[1]+ " " + comb[2] + " " + comb[3]+ " " + comb[4] );
		return b;	
	}
	
	static boolean spreadRangeFilter(int [] comb, int minSpread, int maxSpread){ // We do not want consecutive numbers
																		// MinDistance = 2, we also want max and min to be at least 5 apart
		boolean b =true;
		int min = 0;
		int max = 0;
		
		min = comb[comb.length-1];
		max = comb[0];
		/*for (int i=1; i<comb.length; i++) {
			if (comb[i-1]-comb[i] < minDistance) {
				b = false;
				return b;
			}
			
			if (comb[i] > comb[i-1])
				max = comb[i];
			
			if (comb[i] > comb[i-1])
				min = comb[i-1];
			
		}*/
		
		if (max- min < minSpread || max -min > maxSpread)
			b = false;
		
		return b;
	}
	
	static boolean maxDistanceFilter(int [] comb, int [] moves){ // We do not want freqs that are further than some distance apart from last freq
																
		boolean b = true;

		for (int i = 0; i < comb.length; i++) {
			if (comb[i] - lastfrqs[i] > 0) {
				if (comb[i] - lastfrqs[i] > moves[i]) {
					b = false;
					return b;
				}
			}
			
			if (comb[i] - lastfrqs[i] < 0) {
				if (comb[i] - lastfrqs[i] < 0- moves[i]) {
					b = false;
					return b;
				}
			}

			
		}

		return b;
	}
	
	static boolean maxRepeatFilter(int [] comb, int [] last){ //
		
		boolean b = true;
		int repeats = 0;
		
		for (int i = 0; i < comb.length; i++) {
			if (comb[i] == lastfrqs[0] || comb[i] == lastfrqs[1] || comb[i] == lastfrqs[2]||comb[i] == lastfrqs[3]|| comb[i] == lastfrqs[4] ) {
				repeats +=1;
			}
		}

		if (repeats > 2) b= false;
		
		return b;
	}
	
	static boolean coagulationFilter(int [] comb, int [] last){ // We do not want freqs mostly higher than last highest or lower than last lowest
												// We also do not want 
		
		boolean b = true;
		int highs = 0;
		int lows = 0;
		
		for (int i = 0; i < comb.length; i++) {
			if (comb[i] >= lastfrqs[0]  ) {
				highs +=1;
			}
			
			if (comb[i] <= lastfrqs[4])
				lows +=1;
		}

		if (highs > 4 || lows > 4) b= false;
		
		return b;
	}
	
	
	static boolean minHighestFreq(int [] comb, int minhigh){ // We want at least one freq higher than minhigh
		
		boolean b = true;
				
		if (comb[0] < minhigh) b= false;
		
		return b;
		}
	
	static void freqTest(int[] comb){
		boolean out = false;

		System.out.println();
		System.out.println("Testing these freqs: " + comb[0] + "," + comb[1]+ "," + comb[2]+ "," + comb[3]+ "," + comb[4]);
		System.out.println("equiDistantFilter " + equiDistantFilter(comb));
		System.out.println("coagulationFilter " + coagulationFilter(comb, lastfrqs));
		//System.out.println("spreadRangeFilter " +spreadRangeFilter(comb,15, 80));
		//System.out.println("maxDistanceFilter " + maxDistanceFilter(comb, movements));
		System.out.println("maxRepeatFilter " + maxRepeatFilter(comb, lastfrqs));
		//System.out.println("minHighestFreq " + minHighestFreq (comb, 146));
	//	System.out.println("maxLowestFreq " + maxLowestFreq (comb, avgFreq));
		System.out.println("n.handleMustIncludes " + n.handleMustIncludes(comb,5));
		System.out.println("gapFilling " + gapFilling(comb));
		//System.out.println("n.directionOfFreqMovement " + n.directionOfFreqMovement(comb));
		//System.out.println("sumOfFreqDistanceFromAvg " + sumOfFreqDistanceFromAvg(comb,maxSumOfFreqDistance,minSumOfFreqDistance));
		System.out.println("removeExtremes " + removeExtremes(comb));
		System.out.println("n.atLeastOneSharedFreq(comb) " + n.atLeastOneSharedFreq(comb));
		System.out.println("n.performMAAnalysis(comb) " + n.performMAAnalysis(comb));
		System.out.println("processPreselectedFreqs(comb) " + processPreselectedFreqs(comb));
		
		
	}
	}
