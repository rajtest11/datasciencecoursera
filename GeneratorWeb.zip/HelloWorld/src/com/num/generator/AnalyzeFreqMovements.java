package com.num.generator;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Arrays;
import java.util.Properties;

public class AnalyzeFreqMovements {
	private static String gameType;
	private static Properties prop = new Properties();

	public static void main(String[] args) {

		if (args != null && args.length >0) {
			gameType = args[0];
		}
		
		FileInputStream fis;
		//gameType = ""; // mm or pb or frq
		File f = null;
		try {
			
			if (gameType == null || gameType.length() == 0) {
				fis = new FileInputStream(
						new File(
								"C:\\Users\\johris\\git\\git\\Generator\\props.properties"));
	
				prop.load(fis);
				
				gameType = prop.getProperty("type");
			}
			
			//if (gameType.equals("mm")) {
				f = new File(
						"C:\\Users\\johris\\git\\git\\Generator\\freqAppearanceMap" + gameType);
			//}

			BufferedReader in = new BufferedReader(new FileReader(f));
			String line = null;
			int[] prevFreqs = null;

			while ((line = in.readLine()) != null) {
				
				int[] thisFreqs = new int[5];
				
				if (!(line.startsWith("start") || line.startsWith("Start"))) {
					String[] combs = line.split(" ");

					for (int i = 8; i < 13; i++) {
						//System.out.print( combs[i].trim() + " ");
						thisFreqs[i-8] = Integer.parseInt(combs[i].trim());
					}
					Arrays.sort(thisFreqs);
				}
				if (prevFreqs == null) {
					prevFreqs = thisFreqs;
				} else {
					//System.out.print (thisFreqs[0] +  " " + thisFreqs[1]+  " " + thisFreqs[2]+  " " + thisFreqs[3]+  " " + thisFreqs[4] + " -- ");
					System.out.println( (prevFreqs[0] - thisFreqs[0]) +  " " + 
										(prevFreqs[1] - thisFreqs[1]) +  " " + 
										(prevFreqs[2] - thisFreqs[2]) +  " " + 
										(prevFreqs[3] - thisFreqs[3]) +  " " + 
										(prevFreqs[4] - thisFreqs[4]));
				}
				prevFreqs = thisFreqs;
			}

			//System.out.print(sortByValueDes(freq));
			//System.out.println(" SIZE " + freq.size());
			
			

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
}
