package com.num.generator;

public class Combination {

	int a;
	int b;
	int c;
	int d;
	int e;
	int nmbrsInCombApprdInLstfiv;
	int nmbrsInCombApprdNvr;
	int sum;
	public int getSum() {
		return sum;
	}
	public void setSum(int sum) {
		this.sum = sum;
	}
	public int getA() {
		return a;
	}
	public void setA(int a) {
		this.a = a;
	}
	public int getB() {
		return b;
	}
	public void setB(int b) {
		this.b = b;
	}
	public int getC() {
		return c;
	}
	public void setC(int c) {
		this.c = c;
	}
	public int getD() {
		return d;
	}
	public void setD(int d) {
		this.d = d;
	}
	public int getE() {
		return e;
	}
	public void setE(int e) {
		this.e = e;
	}
	public int getNmbrsInCombApprdInLstfiv() {
		return nmbrsInCombApprdInLstfiv;
	}
	public void setNmbrsInCombApprdInLstfiv(int nmbrsInCombApprdInLstfiv) {
		this.nmbrsInCombApprdInLstfiv = nmbrsInCombApprdInLstfiv;
	}
	public int getNmbrsInCombApprdNvr() {
		return nmbrsInCombApprdNvr;
	}
	public void setNmbrsInCombApprdNvr(int nmbrsInCombApprdNvr) {
		this.nmbrsInCombApprdNvr = nmbrsInCombApprdNvr;
	}
	
}
