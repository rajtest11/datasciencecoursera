package com.num.generator;

import java.util.*;
import java.util.Map.*;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.SecureRandomSpi;
import java.awt.font.NumericShaper;
import java.io.*;

import com.num.generator.*;
import com.num.generator.dataaccess.AggregateRanksEntity;
import com.num.generator.dataaccess.CurrentStateEntity;
import com.num.generator.dataaccess.DBUtils;
import com.num.generator.dataaccess.GameBucketEntity;
import com.num.generator.dataaccess.GamePredictionStateEntity;
import com.num.generator.dataaccess.GameTypesEntity;
import com.num.generator.dataaccess.MissingDigitsEntity;
import com.num.generator.dataaccess.ResultHistoryEntity;

import java.util.regex.Pattern.*;
import java.util.regex.*;

public class Numbers {
	static String gam = null;
	LinkedHashMap<String, String> mm = new LinkedHashMap<String, String>();
	LinkedHashMap<String, String> pb = new LinkedHashMap<String, String>();
	ArrayList<Combination> cmbs = new ArrayList<Combination>();
	ArrayList<Integer> runDelta = new ArrayList<Integer>();
	int standeredDeviation;
	int newGoodSum;
	static int freqAvg = 0;
	int DBGameCode = 0;
	Set<Integer> last5Occured = new HashSet<Integer>();
	Set<Integer> last25Occured = new HashSet<Integer>();
	static Entry<String, String>[] mmArray = null;
	static CurrentStateEntity cse = new CurrentStateEntity();
	Set<Integer> last25NotOccured = new HashSet<Integer>();
	static HashMap<Integer, Integer> freqHash = new HashMap<Integer, Integer>();
	static HashMap<Integer, Integer> numbersHash = new HashMap<Integer, Integer>();
	static HashMap<Integer, Integer> skipHashCurrent = new HashMap<Integer, Integer>(); // List of
																					// the
																					// number
																					// of
																					// draws
																					// this
																					// number
																					// appeared
																					// last
	HashMap<Integer, Integer> skipMBHashCurrent = new HashMap<Integer, Integer>(); // List
																					// of
																					// the
																					// number
																					// of
																					// draws
																					// this
																					// number
																					// appeared
																					// last
	HashMap<Integer, Integer> skipHashPrevious = new HashMap<Integer, Integer>(); // Skip
																					// hash
																					// without
																					// the
																					// current
																					// results
																					// -
																					// stored
																					// in
																					// a
																					// file
	HashMap<Integer, Integer> skipMBHashPrevious = new HashMap<Integer, Integer>(); // Skip
																					// hash
																					// without
																					// the
																					// current
																					// results
																					// -
																					// stored
																					// in
																					// a
																					// file
	HashMap<Integer, Integer> skipFreqlast10 = new HashMap<Integer, Integer>(); // Skip
																				// freqs
																				// in
																				// the
																				// last
																				// 10
																				// draws
	HashMap<Integer, Integer> skipFreqlast5 = new HashMap<Integer, Integer>(); // Skip
																				// freqs
																				// in
																				// the
																				// last
																				// 10
																				// draws
	HashMap<Integer, Integer> skipFreqInlast3 = new HashMap<Integer, Integer>(); // Skip
																					// freqs
																					// in
																					// the
																					// last
																					// 10
																					// draws
	Set<Integer> hotSkipsList = new HashSet<Integer>();
	Set<Integer> hotSkipsListV2 = new HashSet<Integer>();
	Set skipBucketsLast7 = new HashSet();
	static HashMap<Integer, Integer> bucketFreqlast10 = new HashMap<Integer, Integer>(); // Bucket
																							// freqs
																							// in
																							// the
																							// last
																							// 10
																							// draws

	static Set<Integer> lastFewSums = new HashSet<Integer>();
	int countAbove15Last5 = 0;

	int[] singleExclusionList = null; // new int[] { 1, 8, 13, 25, 55, 56 };
	static HashMap freqListFromFreqMap = null;

	static int[] mustExclusionList = null;
	int[] mergeToLast25List = new int[25];
	Set<Integer> commonOfMergeAndLast25List = new HashSet<Integer>();
	ArrayList<Integer> mb = new ArrayList<Integer>();
	ArrayList<Integer> plb = new ArrayList<Integer>();

	int avg5 = 0;
	int mvgavg3 = 0;
	int mvgavg10 = 0;
	int[][] freqTracker = new int[100][6];

	int[][] mbfreqTracker = new int[100][2];

	int[][] maTracker = new int[100][12]; // For each row, store 3 moving
											// average in indexes 0-5 and 10
											// moving average in indexes 6-11

	static HashMap freq = new HashMap();
	static HashMap mbfreq = new HashMap();
	static int numRecordsInFile = 0;

	static HashMap<Integer, Integer> frq = null; // Which freq has appeared how
													// many times in some trials
	static HashMap<Integer, Integer> frqnum = null; // Which num has appeared
													// how many times in some
													// trials

	static String dataFor = "15"; // "15" "l" -- 1st five or last one

	static String dataFileName = "C:\\Users\\johris\\git\\git\\HelloWorld\\pb.txt";

	String currentResult = null;
	private static Integer[] currentActiveFreqs;
	private static String freqAppearanceMapFileText = null;
	public static int evenOddLastNineCount = 0; // We count every even num as +1
												// and odd as -1. We sum last 9
												// occurances. If this sum is >
												// 11, we play
												// for majority of odds, if this
												// is less than -8, we play for
												// majority of Evens
	public static String lastEvenOdd = null; // If evenOddLastNineCount does not
												// give an answer (between -8
												// and 11, we switch even and
												// odds.
	static int dateNotAppearedCount = 0; // Number of draws when date last
											// appeared in the results
	static int monthNotAppearedCount = 0;
	static int yearNotAppearedCount = 0;
	static int todayDate = 0;

	static HashMap<Integer, Integer> freqInLast25 = new HashMap<Integer, Integer>(); // Calculated
																						// to
																						// determine
																						// crossovers

	ArrayList<String> bucketPatterns = new ArrayList<String>(); // what buckets
																// each num
																// falls in like
																// 01135 for 2 11 18 32 51

	ArrayList<Integer> drawsBetweenDateInResults = new ArrayList<Integer>(); // List
																				// of
																				// number
																				// of
																				// draws
																				// when
																				// dates
																				// appeared
																				// in
																				// results
																				// like
																				// {3,5,2,6,4}

	HashMap<Integer, HashMap> bucketAnalysisHash = new HashMap<Integer, HashMap>();

	// TODO: Add multiples and primes present in each result
	// MULTIPLES PRESENT
	int multiplesPresent = 0;
	// PRIMES PRESENT
	int primesPresent = 0;

	public static List primesTill75 = Arrays.asList(2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31,37, 41, 43, 47, 53, 59, 61, 67, 71, 73);
	
	static ArrayList<String> last10MultAndPrimes = new ArrayList<String>();
	
	static HashMap<String, Integer> missingDigits = new HashMap<String, Integer>();
	static Collection lastResults = null;

	static int last9SumAvg = 0;
	
	static boolean doNotUpdateInDatabase = true;
	
	private static int minFreqForGame = 0;
	private static int maxFreqForGame = 0;
	

	public static Integer[] getCurrentActiveFreqs() {
		return currentActiveFreqs;
	}

	Properties prop = new Properties();
	
	private static boolean loaded = false;

	// static int[] nextresult = new int[] { 2, 6, 8, 18, 51 }; // After those
	// in
	// txt file

	
	public Numbers(String gm) {
		if (!loaded) {
			try {
				// gam = gm;
				// Read Properties
				Calendar todayCal = Calendar.getInstance();
				int imon = todayCal.get(Calendar.MONTH) + 1;
				String smon = ((imon < 10) ? "0" : "") + (Integer.toString(imon));
				int iday = todayCal.get(Calendar.DAY_OF_MONTH);
				String sday = ((iday < 10) ? "0" : "") + (Integer.toString(iday));
				int iyear = todayCal.get(Calendar.YEAR);
				String syear = Integer.toString(iyear % 2000);
				int hh = todayCal.get(Calendar.HOUR_OF_DAY);
				String sHH = Integer.toString(hh);
				String todayDate = smon + "/" + sday + "/" + syear + ":" + sHH;
	
				int dayOfWeek = todayCal.get(Calendar.DAY_OF_WEEK);
	
				int daysBefore = 0;
				int lastDrawWithDate = 0;
	
				// System.out.println("Today's day " + dayOfWeek + " Today's date "
				// + todayDate);
	
				FileInputStream fis = new FileInputStream(
						new File(
								"C:\\Users\\johris\\git\\git\\Generator\\props.properties"));
				prop.load(fis);
				String excludeList = prop.getProperty("mustExclusionList");
				String[] excludeListA = excludeList.split("\\,");
				mustExclusionList = new int[excludeListA.length];
				if (excludeListA.length > 1) {
					for (int i = 0; i < excludeListA.length; i++) {
						mustExclusionList[i] = Integer.parseInt(excludeListA[i]
								.trim());
					}
				}
				String mergeList = prop.getProperty("mergeToLast25List");
				String[] mergeListA = mergeList.split("\\,");
				if (mergeListA.length > 1) {
					for (int i = 0; i < mergeListA.length; i++) {
						mergeToLast25List[i] = Integer.parseInt(mergeListA[i]
								.trim());
					}
				}
	
				fis.close();
	
				if (gm == null)
					gam = prop.getProperty("type");
				else
					gam = gm;
				
				if (DBGameCode == 0) {
					GameTypesEntity gte = new GameTypesEntity();
					DBGameCode = Integer.parseInt(gte.findGameCodeByProgramCode(gam));
					cse.setGameCode(Integer.toString(DBGameCode));
					cse.setFirstFiveOrMega("FF");
					lastResults = cse.readLastResult();
				}
				
				if (minFreqForGame == 0 || maxFreqForGame == 0) {
					
					minFreqForGame = cse.getMinFrequency(Integer.toString(DBGameCode));
					maxFreqForGame =  cse.getMaxFrequency(Integer.toString(DBGameCode));
				}

				
				removeLineFromFile(
						"C:\\Users\\johris\\git\\git\\Generator\\props.properties",
						"Appears");
				removeLineFromFile(
						"C:\\Users\\johris\\git\\git\\Generator\\props.properties",
						"FreqTracker");
	
				removeLineFromFile(
						"C:\\Users\\johris\\git\\git\\Generator\\bucketsList"
								+ gam, "*");
				
				MissingDigitsEntity mde = new MissingDigitsEntity();
				mde.setGameCode(Integer.toString(DBGameCode));
				// Read Real Data
				if (gam.equals("mm")) {
					File m = new File(
							"C:\\Users\\johris\\git\\git\\HelloWorld\\mm.txt");
					String line;
					int inputLines = Numbers.getLinesCountFromFile("C:\\Users\\johris\\git\\git\\HelloWorld\\mm.txt");
					BufferedReader in = new BufferedReader(new FileReader(m));
					
					// Between Fri and Tuesday
					if ((dayOfWeek == 6 && hh > 21) || dayOfWeek == 7)
						daysBefore = dayOfWeek - 6;
	
					if (dayOfWeek == 1 || dayOfWeek == 2
							|| (dayOfWeek == 3 && hh < 21))
						daysBefore = dayOfWeek + 1;
	
					// Between Tue and Fri
	
					if ((dayOfWeek == 3 && hh > 21) || dayOfWeek == 4
							|| dayOfWeek == 5 || (dayOfWeek == 6 && hh < 21))
						daysBefore = dayOfWeek - 3;
	
					while ((line = in.readLine()) != null) {
						Numbers.addReduxToFile("C:\\Users\\johris\\git\\git\\HelloWorld\\reduxOutput" + gam, line, true);
						if (findStringInFile("C:\\Users\\johris\\git\\git\\HelloWorld\\MultAndPrimes" + gam, line) < 0) {
							multiplesPresent = getMultiplesCount(line);
							primesPresent = getPrimesCount(line);
	
							addLineToFile("C:\\Users\\johris\\git\\git\\HelloWorld\\MultAndPrimes"+gam, line + " \t\t"
									+ multiplesPresent + "---" + primesPresent,
									false);
						}
						String bucketPatternString = "";
						numRecordsInFile++;
						
						if (numRecordsInFile < 10)
							last10MultAndPrimes.add(multiplesPresent + "---" + primesPresent);
						
						//if (numRecordsInFile < 500) {
							String mdigs =  getMissingDigits(line);
							MissingDigitsEntity mdeinternal = new MissingDigitsEntity();
							mdeinternal.setGameCode(Integer.toString(DBGameCode));
							mdeinternal.setMissingDigits(mdigs);
							mde.getListOfMissingDigits().add(mdeinternal);
							
							/*if (missingDigits.containsKey(mdigs)) {
								missingDigits.put(mdigs,(missingDigits.get(mdigs)+1));
							} else {
								missingDigits.put(mdigs,1);
							}*/
						//}
						
						if (numRecordsInFile <= 50)
							printBucketCountToFile(numRecordsInFile, line);
						if (currentResult == null) {
							currentResult = line;
						}
	
						// Deriving the date of this result
						if (numRecordsInFile > 1)
							daysBefore = (isEven(numRecordsInFile) > 0) ? 3 : 4;
	
						todayCal.add(Calendar.DAY_OF_MONTH, 0 - daysBefore);
						imon = todayCal.get(Calendar.MONTH) + 1;
						smon = Integer.toString(imon);
						iday = todayCal.get(Calendar.DAY_OF_MONTH);
						sday = Integer.toString(iday);
						iyear = todayCal.get(Calendar.YEAR);
						syear = Integer.toString(iyear % 2000);
						hh = todayCal.get(Calendar.HOUR_OF_DAY);
						sHH = Integer.toString(hh);
						todayDate = smon + "/" + sday + "/" + syear + ":" + sHH;
	
						dayOfWeek = todayCal.get(Calendar.DAY_OF_WEEK);
	
						if (!doNotUpdateInDatabase) {
							createResultHistoryEntity(line, inputLines, todayCal, "mm");
							
							
						}
						// if (numRecordsInFile < 10)
						// System.out.println(" Result's date " + todayDate +
						// " Result " + line);
	
						// DONE Deriving the date of this result
	
						if (isNumberInResults(line, sday)) {
	
							if (dateNotAppearedCount == 0)
								dateNotAppearedCount = numRecordsInFile + 1;
	
							// drawsBetweenDateInResults.add(numRecordsInFile -
							// lastDrawWithDate);
							// lastDrawWithDate = numRecordsInFile;
	
						}
	
						if (isNumberInResults(line, smon)) {
							if (monthNotAppearedCount == 0)
								monthNotAppearedCount = numRecordsInFile;
						}
	
						if (isNumberInResults(line, syear)) {
							if (yearNotAppearedCount == 0)
								yearNotAppearedCount = numRecordsInFile;
						}
	
						String[] key = line.split("\\+");
						mm.put(key[0], key[1]);
						mb.add(Integer.parseInt(key[1]));
	
						StringTokenizer strtok = new StringTokenizer(line, ",");
						for (int i = 0; i < 5; i++) {
							String num = strtok.nextToken();
							if (i < 4) {
								if (!skipHashCurrent.containsKey(new Integer(num))) {
									skipHashCurrent.put(new Integer(num),
											numRecordsInFile);
								}
	
								if (numRecordsInFile > 1) {// From second record
															// onwards
									if (!skipHashPrevious.containsKey(new Integer(
											num))) {
										skipHashPrevious.put(new Integer(num),
												numRecordsInFile - 1);
									}
								}
	
								if (freq.containsKey(new Integer(num))) {
									int count = Integer.parseInt((String) freq
											.get(new Integer(num)));
									freq.put(new Integer(num),
											Integer.toString(count + 1));
								} else {
									freq.put(new Integer(num), Integer.toString(1));
								}
	
								if (numRecordsInFile < 25) {
									if (freqInLast25.containsKey(new Integer(num))) {
										int count = freqInLast25.get(new Integer(
												num));
										freqInLast25.put(new Integer(num),
												(count + 1));
									} else {
										freqInLast25.put(new Integer(num), (1));
									}
								}
	
								if (10 > Integer.parseInt(num)
										&& Integer.parseInt(num) >= 0)
									bucketPatternString += "0";
								if (20 > Integer.parseInt(num)
										&& Integer.parseInt(num) >= 10)
									bucketPatternString += "1";
								if (30 > Integer.parseInt(num)
										&& Integer.parseInt(num) >= 20)
									bucketPatternString += "2";
								if (40 > Integer.parseInt(num)
										&& Integer.parseInt(num) >= 30)
									bucketPatternString += "3";
								if (50 > Integer.parseInt(num)
										&& Integer.parseInt(num) >= 40)
									bucketPatternString += "4";
								if (60 > Integer.parseInt(num)
										&& Integer.parseInt(num) >= 50)
									bucketPatternString += "5";
	
								if (bucketAnalysisHash.containsKey(i)) {
									HashMap<String, Integer> intHash = (HashMap<String, Integer>) bucketAnalysisHash
											.get(i);
									if (intHash
											.containsKey(bucketPatternString
													.substring(bucketPatternString
															.length() - 1))) {
										int val = intHash.get(bucketPatternString
												.substring(bucketPatternString
														.length() - 1));
										intHash.put(bucketPatternString
												.substring(bucketPatternString
														.length() - 1), val + 1);
									} else {
										intHash.put(bucketPatternString
												.substring(bucketPatternString
														.length() - 1), 1);
									}
								} else {
									HashMap<String, Integer> internalHash = new HashMap<String, Integer>();
									internalHash.put(
											bucketPatternString
													.substring(bucketPatternString
															.length() - 1), 1);
	
									bucketAnalysisHash.put(i, internalHash);
								}
	
							} else {
								String[] splitlast = num.split("\\+");
								if (!skipHashCurrent.containsKey(new Integer(
										splitlast[0]))) {
									skipHashCurrent.put(new Integer(splitlast[0]),
											numRecordsInFile);
								}
	
								if (numRecordsInFile > 1) {// From second record
															// onwards
									if (!skipHashPrevious.containsKey(new Integer(
											splitlast[0]))) {
										skipHashPrevious
												.put(new Integer(splitlast[0]),
														numRecordsInFile - 1);
									}
								}
								if (freq.containsKey(new Integer(splitlast[0]))) {
									int count = Integer.parseInt((String) freq
											.get(new Integer(splitlast[0])));
									freq.put(new Integer(splitlast[0]),
											Integer.toString(count + 1));
								} else {
									freq.put(new Integer(splitlast[0]),
											Integer.toString(1));
								}
	
								if (numRecordsInFile < 25) {
									if (freqInLast25.containsKey(new Integer(
											splitlast[0]))) {
										int count = freqInLast25.get(new Integer(
												splitlast[0]));
										freqInLast25.put(new Integer(splitlast[0]),
												(count + 1));
									} else {
										freqInLast25.put(new Integer(splitlast[0]),
												(1));
									}
								}
	
								if (10 > Integer.parseInt(splitlast[0])
										&& Integer.parseInt(splitlast[0]) >= 0)
									bucketPatternString += "0";
								if (20 > Integer.parseInt(splitlast[0])
										&& Integer.parseInt(splitlast[0]) >= 10)
									bucketPatternString += "1";
								if (30 > Integer.parseInt(splitlast[0])
										&& Integer.parseInt(splitlast[0]) >= 20)
									bucketPatternString += "2";
								if (40 > Integer.parseInt(splitlast[0])
										&& Integer.parseInt(splitlast[0]) >= 30)
									bucketPatternString += "3";
								if (50 > Integer.parseInt(splitlast[0])
										&& Integer.parseInt(splitlast[0]) >= 40)
									bucketPatternString += "4";
								if (60 > Integer.parseInt(splitlast[0])
										&& Integer.parseInt(splitlast[0]) >= 50)
									bucketPatternString += "5";
	
								if (bucketAnalysisHash.containsKey(i)) {
									HashMap<String, Integer> intHash = (HashMap<String, Integer>) bucketAnalysisHash
											.get(i);
									if (intHash
											.containsKey(bucketPatternString
													.substring(bucketPatternString
															.length() - 1))) {
										int val = intHash.get(bucketPatternString
												.substring(bucketPatternString
														.length() - 1));
										intHash.put(bucketPatternString
												.substring(bucketPatternString
														.length() - 1), val + 1);
									} else {
										intHash.put(bucketPatternString
												.substring(bucketPatternString
														.length() - 1), 1);
									}
								} else {
									HashMap<String, Integer> internalHash = new HashMap<String, Integer>();
									internalHash.put(
											bucketPatternString
													.substring(bucketPatternString
															.length() - 1), 1);
	
									bucketAnalysisHash.put(i, internalHash);
								}
	
								if (!skipMBHashCurrent.containsKey(new Integer(
										splitlast[1]))) {
									skipMBHashCurrent.put(
											new Integer(splitlast[1]),
											numRecordsInFile);
	
								}
	
								if (numRecordsInFile > 1) {// From second record
															// onwards
									if (!skipMBHashPrevious
											.containsKey(new Integer(splitlast[1]))) {
										skipMBHashPrevious
												.put(new Integer(splitlast[1]),
														numRecordsInFile - 1);
									}
								}
								if (mbfreq.containsKey(new Integer(splitlast[1]))) {
									int count = Integer.parseInt((String) mbfreq
											.get(new Integer(splitlast[1])));
									mbfreq.put(new Integer(splitlast[1]),
											Integer.toString(count + 1));
								} else {
									mbfreq.put(new Integer(splitlast[1]),
											Integer.toString(1));
								}
	
							}
						}
						if (numRecordsInFile < 31)
							bucketPatterns.add(bucketPatternString);
					}
					in.close();
				}
	
				if (gam.equals("pb")) {
					File f = new File(
							"C:\\Users\\johris\\git\\git\\HelloWorld\\pb.txt");
					
					String lin;
					int inputLines = Numbers.getLinesCountFromFile("C:\\Users\\johris\\git\\git\\HelloWorld\\pb.txt");
					// Between Sat and Wed
					if ((dayOfWeek == 7 && hh > 21))
						daysBefore = dayOfWeek - 7;
	
					if (dayOfWeek == 1 || dayOfWeek == 2 || dayOfWeek == 3
							|| (dayOfWeek == 4 && hh < 21))
						daysBefore = dayOfWeek;
	
					// Between Wed and Sat
	
					if ((dayOfWeek == 4 && hh > 21) || dayOfWeek == 5
							|| dayOfWeek == 6 || (dayOfWeek == 7 && hh < 21))
						daysBefore = dayOfWeek - 4;
	
					try (BufferedReader inp = new BufferedReader(new FileReader(f))) {
					
					while ((lin = inp.readLine()) != null) {
	
						Numbers.addReduxToFile("C:\\Users\\johris\\git\\git\\HelloWorld\\reduxOutput" + gam, lin, true);
						if (findStringInFile("C:\\Users\\johris\\git\\git\\HelloWorld\\MultAndPrimes" + gam, lin) < 0) {
							multiplesPresent = getMultiplesCount(lin);
							primesPresent = getPrimesCount(lin);
	
							addLineToFile("C:\\Users\\johris\\git\\git\\HelloWorld\\MultAndPrimes"+gam, lin + " \t\t"
									+ multiplesPresent + "---" + primesPresent,
									true);
						}
	
						String bucketPatternString = "";
	
						numRecordsInFile++;
						
						if (numRecordsInFile < 10)
							last10MultAndPrimes.add(multiplesPresent + "---" + primesPresent);
						
						//if (numRecordsInFile < 500) {
							String mdigs =  getMissingDigits(lin);
							MissingDigitsEntity mdeinternal = new MissingDigitsEntity();
							mdeinternal.setGameCode(Integer.toString(DBGameCode));
							mdeinternal.setMissingDigits(mdigs);
							mde.getListOfMissingDigits().add(mdeinternal);
							
							/*if (missingDigits.containsKey(mdigs)) {
								missingDigits.put(mdigs,(missingDigits.get(mdigs)+1));
							} else {
								missingDigits.put(mdigs,1);
							}*/
						//}
						
						if (numRecordsInFile <= 50)
							printBucketCountToFile(numRecordsInFile, lin);
						if (currentResult == null)
							currentResult = lin;
	
						// Deriving the date of this result
						if (numRecordsInFile > 1)
							daysBefore = (isEven(numRecordsInFile) > 0) ? 3 : 4;
	
						todayCal.add(Calendar.DAY_OF_MONTH, 0 - daysBefore);
						imon = todayCal.get(Calendar.MONTH) + 1;
						smon = Integer.toString(imon);
						iday = todayCal.get(Calendar.DAY_OF_MONTH);
						sday = Integer.toString(iday);
						iyear = todayCal.get(Calendar.YEAR);
						syear = Integer.toString(iyear % 2000);
						hh = todayCal.get(Calendar.HOUR_OF_DAY);
						sHH = Integer.toString(hh);
						todayDate = smon + "/" + sday + "/" + syear + ":" + sHH;
	
						dayOfWeek = todayCal.get(Calendar.DAY_OF_WEEK);
	
						if (!doNotUpdateInDatabase) {
							createResultHistoryEntity(lin, inputLines, todayCal, "pb");
							
						}
						// if (numRecordsInFile < 10)
						// System.out.println(" Result's date " + todayDate +
						// " Result " + lin);
	
						// DONE Deriving the date of this result
	
						if (isNumberInResults(lin, sday)) {
	
							if (dateNotAppearedCount == 0)
								dateNotAppearedCount = numRecordsInFile + 1;
	
							// drawsBetweenDateInResults.add(numRecordsInFile -
							// lastDrawWithDate);r
							// lastDrawWithDate = numRecordsInFile;
	
						}
	
						if (isNumberInResults(lin, smon)) {
							if (monthNotAppearedCount == 0)
								monthNotAppearedCount = numRecordsInFile + 1;
						}
	
						if (isNumberInResults(lin, syear)) {
							if (yearNotAppearedCount == 0)
								yearNotAppearedCount = numRecordsInFile + 1;
						}
	
						String[] key = lin.split("\\+");
						pb.put(key[0], key[1]);
						plb.add(Integer.parseInt(key[1]));
	
						StringTokenizer strtok = new StringTokenizer(lin, ",");
						for (int i = 0; i < 5; i++) {
							String num = strtok.nextToken();
							if (i < 4) {
								if (!skipHashCurrent.containsKey(new Integer(num))) {
									skipHashCurrent.put(new Integer(num),
											numRecordsInFile);
	
								}
	
								if (numRecordsInFile > 1) {// From second record
															// onwards
									if (!skipHashPrevious.containsKey(new Integer(
											num))) {
										skipHashPrevious.put(new Integer(num),
												numRecordsInFile - 1);
									}
								}
	
								if (freq.containsKey(new Integer(num))) {
									int count = Integer.parseInt((String) freq
											.get(new Integer(num)));
									freq.put(new Integer(num),
											Integer.toString(count + 1));
								} else {
									freq.put(new Integer(num), Integer.toString(1));
								}
	
								if (numRecordsInFile < 25) {
									if (freqInLast25.containsKey(new Integer(num))) {
										int count = freqInLast25.get(new Integer(
												num));
										freqInLast25.put(new Integer(num),
												(count + 1));
									} else {
										freqInLast25.put(new Integer(num), (1));
									}
								}
	
								if (10 > Integer.parseInt(num)
										&& Integer.parseInt(num) >= 0)
									bucketPatternString += "0";
								if (20 > Integer.parseInt(num)
										&& Integer.parseInt(num) >= 10)
									bucketPatternString += "1";
								if (30 > Integer.parseInt(num)
										&& Integer.parseInt(num) >= 20)
									bucketPatternString += "2";
								if (40 > Integer.parseInt(num)
										&& Integer.parseInt(num) >= 30)
									bucketPatternString += "3";
								if (50 > Integer.parseInt(num)
										&& Integer.parseInt(num) >= 40)
									bucketPatternString += "4";
								if (60 > Integer.parseInt(num)
										&& Integer.parseInt(num) >= 50)
									bucketPatternString += "5";
	
								if (bucketAnalysisHash.containsKey(i)) {
									HashMap<String, Integer> intHash = (HashMap<String, Integer>) bucketAnalysisHash
											.get(i);
									if (intHash
											.containsKey(bucketPatternString
													.substring(bucketPatternString
															.length() - 1))) {
										int val = intHash.get(bucketPatternString
												.substring(bucketPatternString
														.length() - 1));
										intHash.put(bucketPatternString
												.substring(bucketPatternString
														.length() - 1), val + 1);
									} else {
										intHash.put(bucketPatternString
												.substring(bucketPatternString
														.length() - 1), 1);
									}
								} else {
									HashMap<String, Integer> internalHash = new HashMap<String, Integer>();
									internalHash.put(
											bucketPatternString
													.substring(bucketPatternString
															.length() - 1), 1);
	
									bucketAnalysisHash.put(i, internalHash);
								}
	
							} else {
								String[] splitlast = num.split("\\+");
	
								if (!skipHashCurrent.containsKey(new Integer(
										splitlast[0]))) {
									skipHashCurrent.put(new Integer(splitlast[0]),
											numRecordsInFile);
								}
	
								if (numRecordsInFile > 1) {// From second record
															// onwards
									if (!skipHashPrevious.containsKey(new Integer(
											splitlast[0]))) {
										skipHashPrevious
												.put(new Integer(splitlast[0]),
														numRecordsInFile - 1);
									}
								}
	
								if (freq.containsKey(new Integer(splitlast[0]))) {
									int count = Integer.parseInt((String) freq
											.get(new Integer(splitlast[0])));
									freq.put(new Integer(splitlast[0]),
											Integer.toString(count + 1));
								} else {
									freq.put(new Integer(splitlast[0]),
											Integer.toString(1));
								}
	
								if (numRecordsInFile < 25) {
									if (freqInLast25.containsKey(new Integer(
											splitlast[0]))) {
										int count = freqInLast25.get(new Integer(
												splitlast[0]));
										freqInLast25.put(new Integer(splitlast[0]),
												(count + 1));
									} else {
										freqInLast25.put(new Integer(splitlast[0]),
												(1));
									}
								}
	
								if (10 > Integer.parseInt(splitlast[0])
										&& Integer.parseInt(splitlast[0]) >= 0)
									bucketPatternString += "0";
								if (20 > Integer.parseInt(splitlast[0])
										&& Integer.parseInt(splitlast[0]) >= 10)
									bucketPatternString += "1";
								if (30 > Integer.parseInt(splitlast[0])
										&& Integer.parseInt(splitlast[0]) >= 20)
									bucketPatternString += "2";
								if (40 > Integer.parseInt(splitlast[0])
										&& Integer.parseInt(splitlast[0]) >= 30)
									bucketPatternString += "3";
								if (50 > Integer.parseInt(splitlast[0])
										&& Integer.parseInt(splitlast[0]) >= 40)
									bucketPatternString += "4";
								if (60 > Integer.parseInt(splitlast[0])
										&& Integer.parseInt(splitlast[0]) >= 50)
									bucketPatternString += "5";
	
								if (bucketAnalysisHash.containsKey(i)) {
									HashMap<String, Integer> intHash = (HashMap<String, Integer>) bucketAnalysisHash
											.get(i);
									if (intHash
											.containsKey(bucketPatternString
													.substring(bucketPatternString
															.length() - 1))) {
										int val = intHash.get(bucketPatternString
												.substring(bucketPatternString
														.length() - 1));
										intHash.put(bucketPatternString
												.substring(bucketPatternString
														.length() - 1), val + 1);
									} else {
										intHash.put(bucketPatternString
												.substring(bucketPatternString
														.length() - 1), 1);
									}
								} else {
									HashMap<String, Integer> internalHash = new HashMap<String, Integer>();
									internalHash.put(
											bucketPatternString
													.substring(bucketPatternString
															.length() - 1), 1);
	
									bucketAnalysisHash.put(i, internalHash);
								}
	
								if (!skipMBHashCurrent.containsKey(new Integer(
										splitlast[1]))) {
									skipMBHashCurrent.put(
											new Integer(splitlast[1]),
											numRecordsInFile);
								}
	
								if (numRecordsInFile > 1) {// From second record
															// onwards
									if (!skipMBHashPrevious
											.containsKey(new Integer(splitlast[1]))) {
										skipMBHashPrevious
												.put(new Integer(splitlast[1]),
														numRecordsInFile - 1);
									}
								}
								if (mbfreq.containsKey(new Integer(splitlast[1]))) {
									int count = Integer.parseInt((String) mbfreq
											.get(new Integer(splitlast[1])));
									mbfreq.put(new Integer(splitlast[1]),
											Integer.toString(count + 1));
								} else {
									mbfreq.put(new Integer(splitlast[1]),
											Integer.toString(1));
								}
							}
						}
						if (numRecordsInFile < 31)
							bucketPatterns.add(bucketPatternString);
					}
					} catch (Exception ex) {
						System.out.println("Numbers. init: Exception caught in try with resources...");
					}
					//inp.close();
				}
				avg5 = averageOfValues(freq, freq.size());
	
				// System.out.println(drawsBetweenDateInResults);
	 
				// PRINTING TRACKER
	
				// if (dataFor.equals("15")) // Numbers, their frequencies and their
				// last appearance (skip)
				// printFreqAndLastAppearance(freq, skipHashCurrent); else
				// printFreqAndLastAppearance(mbfreq, skipMBHashCurrent);
				
				missingDigits = mde.getUnlikelyMissingDigits();
					
					//agr.populateSkipSumRanks(gameType);
				if (!doNotUpdateInDatabase) {
					ResultHistoryEntity rhe = new ResultHistoryEntity();
					rhe.setGameCode(Integer.toString(DBGameCode));
					//rhe.insertResultsWithinLastNHistory(rhe.getGameCode()); 
					
					// CREATE MISSING DIGITS -- Do it AFTER records have been created so that
					//				we get the ranks based on PREVIOUS data
					//MissingDigitsEntity mde = new MissingDigitsEntity();
					
					mde.populateMissingDigits(Integer.toString(DBGameCode));
					mde.populateUnlikelyMissingDigits(Integer.toString(DBGameCode), 100);
										
					//CREATE GAME BUCKET RANKS 
					
					GameBucketEntity gb = new GameBucketEntity();
					gb.populateGameBuckets(Integer.toString(DBGameCode));

					
					// CREATE OTHER AGGREGATE RANKS FIRST
					
					AggregateRanksEntity agr = new AggregateRanksEntity();
					agr.populateMissingDigitRanks(Integer.toString(DBGameCode));
					agr.populateFollowerMapRanks(Integer.toString(DBGameCode));
					agr.populateMaxFactorRanks(Integer.toString(DBGameCode));
					
					// Populate last prediction's status
					
					GamePredictionStateEntity e = new GamePredictionStateEntity();					
					e.popultateGamePredictionStateHistory(Integer.toString(DBGameCode));
					
					// Populate new predictions
					DBUtils dbu = new DBUtils();
					dbu.setTestMode(false);
					dbu.getCurrentInclusionAndExclusionsForAllAttributes(Integer.toString(DBGameCode));
					
				}
	
				System.out.println("Numbers.java: Numbers(): Missing digits list size " + missingDigits.size() + " " + missingDigits.toString());
				
				//Dropping this check because this is stopping currentstate from being updated
				/*if (findStringInFile(
						"C:\\Users\\johris\\git\\git\\Generator\\latestFreqsSkips"
								+ gam, Integer.toString(numRecordsInFile)) < 0) {*/
					removeLineFromFile(
							"C:\\Users\\johris\\git\\git\\Generator\\latestFreqsSkips"
									+ gam, "*");
					addLineToFile( 
							"C:\\Users\\johris\\git\\git\\Generator\\latestFreqsSkips"
									+ gam, numRecordsInFile + " ", false);
					addLineToFile(
							"C:\\Users\\johris\\git\\git\\Generator\\latestFreqsSkips"
									+ gam,
							"Number	Freq	Skip	Freq in last 25 draws ", false);
	
					Set nums = freq.keySet();
					Iterator it = nums.iterator();
					while (it.hasNext()) {
						Integer str = (Integer) it.next();
						addLineToFile(
								"C:\\Users\\johris\\git\\git\\Generator\\latestFreqsSkips"
										+ gam, " " + str + " " + freq.get(str)
										+ " " + skipHashCurrent.get(str) + " "
										+ freqInLast25.get(str), false);
						
						
						cse = new CurrentStateEntity();
						cse.setGameCode(Integer.toString(DBGameCode));
						cse.setFirstFiveOrMega(CurrentStateEntity.ENTRYTYPEFIRSTFIVE);
						cse.setNumber(Integer.toString(str));
						cse.setFrequency((String)freq.get(str));
						cse.setSkip(Integer.toString(skipHashCurrent.get(str)));
						if (cse.exists()) {
							cse.update();
						} else {
							cse.create();
						}
					}
	
					addLineToFile(
							"C:\\Users\\johris\\git\\git\\Generator\\latestFreqsSkips"
									+ gam, "-----------------", false);
	
					nums = mbfreq.keySet();
					it = nums.iterator();
					while (it.hasNext()) {
						int str = (Integer) it.next();
						addLineToFile(
								"C:\\Users\\johris\\git\\git\\Generator\\latestFreqsSkips"
										+ gam, " " + str + " " + mbfreq.get(str)
										+ " " + skipMBHashCurrent.get(str), false);
						
						cse = new CurrentStateEntity();
						cse.setGameCode(Integer.toString(DBGameCode));
						cse.setFirstFiveOrMega(CurrentStateEntity.ENTRYTYPEMEGA);
						cse.setNumber(Integer.toString(str));
						cse.setFrequency((String)mbfreq.get(str));
						cse.setSkip(Integer.toString(skipMBHashCurrent.get(str)));
						if (cse.exists()) {
							cse.update();
						} else {
							cse.create();
						}
						
					}
				/*}*/
	
				printCumulativeSkipResultsToFile();
	
				if (gam.equals("mm"))
					dataFileName = "C:\\Users\\johris\\git\\git\\HelloWorld\\mm.txt";
	
				System.out.println("Numbers.java ------ Datafile: " + dataFileName);
	
				// Pass true to print
				createFreqTracker(false); // Distance from average frequencies and 3
											// and 10 MA
	
				/*
				 * System.out.println("Numbers.java ------" + "Next results' freqs "
				 * + freq.get(nextresult[0]) + " " + freq.get(nextresult[1]) + " " +
				 * freq.get(nextresult[2]) + " " + freq.get(nextresult[3]) + " " +
				 * freq.get(nextresult[4]) + " " +
				 * " --- printed to compare with program output.");
				 */
				System.out.println("Numbers.java ------");
				System.out.println("Numbers.java ------ bucketAnalysisHash "
						+ bucketAnalysisHash);
	
				printFreqAppearance(freqAppearance(10), 7); // Which freq have
															// appeared how many
															// times? Writes to
															// props.properties
	
				// System.out.println("Numbers.java Bucket Patterns ------" +
				// bucketPatterns);
				// last 5 comb's numbers(set)
				Set<Entry<String, String>> se = null;
				if (gam != null && gam.equalsIgnoreCase("mm")) {
					se = mm.entrySet();
				} else {
					se = pb.entrySet();
				}
				mmArray = new Entry[se.size()];
				se.toArray(mmArray);
	
				for (int i = 0; i < 5; i++) {
					String mmKey = mmArray[i].getKey();
					String[] s = mmKey.split("\\,");
					last5Occured.add(Integer.valueOf(s[0]));
					last5Occured.add(Integer.valueOf(s[1]));
					last5Occured.add(Integer.valueOf(s[2]));
					last5Occured.add(Integer.valueOf(s[3]));
					last5Occured.add(Integer.valueOf(s[4]));
				}
				// Merge the Follower number list to last5's list and create the Set
				// of Common numbers
				/*
				 * for (int i = 0; i < mergeToLast25List.length; i++) { if
				 * (!(last5Occured.add(mergeToLast25List[i])))
				 * commonOfMergeAndLast25List.add(mergeToLast25List[i]);
				 * 
				 * }
				 */
				// last 25 combs numbers(set)
				for (int i = 0; i < 17; i++) {
					String mmKey = mmArray[i].getKey();
					String[] s = mmKey.split("\\,");
					last25Occured.add(Integer.valueOf(s[0]));
					last25Occured.add(Integer.valueOf(s[1]));
					last25Occured.add(Integer.valueOf(s[2]));
					last25Occured.add(Integer.valueOf(s[3]));
					last25Occured.add(Integer.valueOf(s[4]));
				}
				// last 25 combs doesn't have numbers(set)
				int gmMax = 56;
				int notConsiderAfter = 53;
				if (gam != null && gam.equalsIgnoreCase("mm")) {
					gmMax = 75;
					notConsiderAfter = 75;
				} else {
					gmMax = 69;
					notConsiderAfter = 69;
				}
				for (int i = 1; i <= gmMax; i++) {
					if (!last25Occured.contains(i)) {
						if (!(i > notConsiderAfter)) {
							last25NotOccured.add(i);
							// System.out.print("last25NotOccured:"+ i + " " );
						}
					}
				}
				// Merge the last 17 not occured list to last5's + Followers list
				Iterator<Integer> iter = last25NotOccured.iterator();
				while (iter.hasNext()) {
					int v = iter.next();
					// if (!(last5Occured.add(v)))
					// commonOfMergeAndLast25List.add(v);
				}
	
				if (gam != null && gam.equalsIgnoreCase("mm")) {
					for (int i = 1; i <= 75; i++) {
						freqHash.put(i, 0);
						numbersHash.put(i, 0);
					}
				} else {
					for (int i = 1; i <= 69; i++) {
						freqHash.put(i, 0);
						numbersHash.put(i, 0);
					}
				}
				for (int k = 0; k < mmArray.length; k++) {
					String s = mmArray[k].getKey();
					String[] sa = s.split("\\,");
					for (int j = 0; j < sa.length; j++) {
						freqHash.put(Integer.parseInt(sa[j]),
								freqHash.get(Integer.parseInt(sa[j])) + 1);
					}
				}
	
				Collection<Integer> c = freqHash.values();
				Iterator<Integer> itr = c.iterator();
				int sumFreq = 0;
				while (itr.hasNext()) {
					int val = itr.next();
					sumFreq += val;
				}
	
				freqAvg = sumFreq / 56;
	
				// Number Freq for Last Six Combs only
				for (int i = 0; i < 6; i++) {
					String s = mmArray[i].getKey();
					String[] sa = s.split("\\,");
					for (int k = 0; k < sa.length; k++) {
						int histvalue = Integer.parseInt(sa[k]);
						if (numbersHash.containsKey(histvalue))
							numbersHash.put(histvalue,
									(numbersHash.get(histvalue) + 1));
						else
							numbersHash.put(histvalue, 1);
					}
				}
	
				dateMonthYearInResults();
				
				/*Set<Entry<String, Integer>> it = missingDigits.entrySet();
				Iterator iteror = it.iterator();
				
				while (iteror.hasNext()) {
					Entry<String,Integer> item = (Entry<String, Integer>) iteror.next();
					
					System.out.println(item.getKey() + "--" + item.getValue());
				}*/
	
			} catch (FileNotFoundException fx) {
				fx.printStackTrace();
			} catch (IOException ix) {
				System.out.println(last5Occured);
				ix.printStackTrace();
			}
			
			loaded = true;
		}
	}

	public static String getMissingDigits(String line) {
		String missingDigits = "";
		ArrayList complete = new ArrayList(Arrays.asList(new String[]{"1","2","3","4","5","6","7","8","9","0"}));
		ArrayList<String> removeList = new ArrayList<String>();
		
		int[] thisLine = new int[6];
		StringTokenizer strtok = new StringTokenizer(line, ",");
		for (int i = 0; i < 5; i++) {
			String num = strtok.nextToken();
			if (i < 4) {
				if (num.length() > 1) {
					if (complete.contains(Integer.toString(Integer.parseInt(num)/10)))
						removeList.add(Integer.toString(Integer.parseInt(num)/10));
				}
				
				if (complete.contains(Integer.toString(Integer.parseInt(num)%10)))
					removeList.add(Integer.toString(Integer.parseInt(num)%10));

			} else {
				String[] splitlast = num.split("\\+");
				thisLine[4] = Integer.parseInt(splitlast[0]);
				
				if (splitlast[0].length() > 1) {
					if (complete.contains(Integer.toString(Integer.parseInt(splitlast[0])/10)))
						removeList.add(Integer.toString(Integer.parseInt(splitlast[0])/10));
				}
				
				if (complete.contains(Integer.toString(Integer.parseInt(splitlast[0])%10)))
					removeList.add(Integer.toString(Integer.parseInt(splitlast[0])%10));
				
				//thisLine[5] = Integer.parseInt(splitlast[1]);
			}
		}
		
		for(String removeEntry : removeList) {
	         complete.remove(removeEntry);
	      }
		
		Iterator it = complete.iterator();
		while (it.hasNext()) {
			missingDigits += ((String)it.next());
		}

		//System.out.println("Numbers.java: -- Missing digits : " + missingDigits);
		return missingDigits;
	}

	private void createResultHistoryEntity(String line, int inputLines, Calendar cal, String gam2) {
		ResultHistoryEntity rhe = new ResultHistoryEntity();
		
		String[] mega = line.split("\\+");
		
		String[] nums = mega[0].split(",");
		rhe.setFirstValue(nums[0]);
		rhe.setSecondValue(nums[1]);
		rhe.setThirdValue(nums[2]);
		rhe.setFourthValue(nums[3]);
		rhe.setFifthValue(nums[4]);
		rhe.setMegaValue(mega[1]);
		
		if (DBGameCode > 0) {
			rhe.setGameCode(Integer.toString(DBGameCode));
		} else {
			GameTypesEntity gte = new GameTypesEntity();
			DBGameCode = Integer.parseInt(gte.findGameCodeByProgramCode(gam2));
			rhe.setGameCode(Integer.toString(DBGameCode));
		}
		
		if (!rhe.exists()) {
			rhe.setSerialNumber(Integer.toString(inputLines));
			rhe.setDateOfDraw(DBUtils.getNextDateForGameAndSerial(Integer.toString(DBGameCode), inputLines-1));
			
			System.out.println("ResultHistoryEntity does not exist: " + rhe.toString() + "..... creating.");
			
			Calendar nextDateCal = Calendar.getInstance();
			
			nextDateCal.set(Calendar.YEAR,Integer.parseInt(rhe.getDateOfDraw().substring(0, 4)));
			nextDateCal.set(Calendar.MONTH,Integer.parseInt(rhe.getDateOfDraw().substring(4, 6))-1);
			nextDateCal.set(Calendar.DATE,Integer.parseInt(rhe.getDateOfDraw().substring(6, 8)));
			
			rhe.setDayOfTheWeek(Integer.toString(nextDateCal.get(Calendar.DAY_OF_WEEK)));
			rhe.create();
			
			System.out.println(line + "Added to " + gam2 + ".txt");
			
			rhe.createDerivedRecords();
			rhe.updateMaxFactorForDerivedRecords(rhe.getGameCode(), rhe.getSerialNumber());
			rhe.createEvidenceOfFollowers(rhe.getGameCode());
			//rhe.insertResultsWithinLastNHistory(rhe.getGameCode());
			
			
			
		} else {
			//System.out.println("ResultHistoryEntity exists: " + rhe.toString());
		}
		
	}

	private int getPrimesCount(String line) {
		int primesCount = 0;
		StringTokenizer strtok = new StringTokenizer(line, ",");
		for (int i = 0; i < 5; i++) {
			String num = strtok.nextToken();
			if (i < 4) {
				if (primesTill75.contains(Integer.parseInt(num)))
					primesCount++;
			} else {
				String[] splitlast = num.split("\\+");
				if (primesTill75.contains(Integer.parseInt(splitlast[0])))
					primesCount++;
				if (primesTill75.contains(Integer.parseInt(splitlast[1])))
					primesCount++;
			}
		}
		return primesCount;
	}

	private int getMultiplesCount(String line) {
		int multiplesCount = 0;
		int[] thisLine = new int[6];
		StringTokenizer strtok = new StringTokenizer(line, ",");
		for (int i = 0; i < 5; i++) {
			String num = strtok.nextToken();
			if (i < 4) {
				thisLine[i] = Integer.parseInt(num);

			} else {
				String[] splitlast = num.split("\\+");
				thisLine[4] = Integer.parseInt(splitlast[0]);
				thisLine[5] = Integer.parseInt(splitlast[1]);
			}
		}
		for (int j = thisLine.length - 1; j > 0; j--) {
			for (int k = j - 1; k > -1; k--) {
				if (thisLine[k] > 1)
					if (thisLine[j] % thisLine[k] == 0) {
						multiplesCount++;
						// CAN WE SET IT UP SO THAT it counts one multiple only
						// once?
					}
			}

		}

		return multiplesCount;
	}

	private static void dateMonthYearInResults() {

		Calendar todayCal = Calendar.getInstance();
		int imon = todayCal.get(Calendar.MONTH) + 1;
		String smon = ((imon < 10) ? "0" : "") + (Integer.toString(imon));
		int iday = todayCal.get(Calendar.DAY_OF_MONTH);
		String sday = ((iday < 10) ? "0" : "") + (Integer.toString(iday));
		int iyear = todayCal.get(Calendar.YEAR);
		String syear = Integer.toString(iyear % 2000);
		int hh = todayCal.get(Calendar.HOUR_OF_DAY);
		String sHH = Integer.toString(hh);
		String todayDate = smon + "/" + sday + "/" + syear + ":" + sHH;

		int dayOfWeek = todayCal.get(Calendar.DAY_OF_WEEK);

		if (Numbers.dateNotAppearedCount > 5) {
			System.out
					.print("Numbers.java ------"
							+ Numbers.dateNotAppearedCount
							+ " draws since date appeared in results. Include dates - ");

			if (dayOfWeek <= 3) {
				Calendar todayCalClone = (Calendar) todayCal.clone();
				todayCalClone.add(Calendar.DAY_OF_YEAR, 3 - dayOfWeek);
				System.out
						.print(todayCalClone.get(Calendar.DAY_OF_MONTH) + " ");
				todayCalClone.add(Calendar.DAY_OF_YEAR, 3);
				System.out
						.print(todayCalClone.get(Calendar.DAY_OF_MONTH) + " ");
				todayCalClone.add(Calendar.DAY_OF_YEAR, 4);
				System.out
						.print(todayCalClone.get(Calendar.DAY_OF_MONTH) + " ");
				todayCalClone.add(Calendar.DAY_OF_YEAR, 3);
				System.out
						.print(todayCalClone.get(Calendar.DAY_OF_MONTH) + " ");
				todayCalClone.add(Calendar.DAY_OF_YEAR, 4);
				System.out
						.print(todayCalClone.get(Calendar.DAY_OF_MONTH) + " ");

			} else {

				if (dayOfWeek <= 6) {
					Calendar todayCalClone = (Calendar) todayCal.clone();
					todayCalClone.add(Calendar.DAY_OF_YEAR, 6 - dayOfWeek);
					System.out.print(todayCalClone.get(Calendar.DAY_OF_MONTH)
							+ " ");
					todayCalClone.add(Calendar.DAY_OF_YEAR, 4);
					System.out.print(todayCalClone.get(Calendar.DAY_OF_MONTH)
							+ " ");
					todayCalClone.add(Calendar.DAY_OF_YEAR, 3);
					System.out.print(todayCalClone.get(Calendar.DAY_OF_MONTH)
							+ " ");
					todayCalClone.add(Calendar.DAY_OF_YEAR, 4);
					System.out.print(todayCalClone.get(Calendar.DAY_OF_MONTH)
							+ " ");
					todayCalClone.add(Calendar.DAY_OF_YEAR, 3);
					System.out.print(todayCalClone.get(Calendar.DAY_OF_MONTH)
							+ " ");

				} else {
					Calendar todayCalClone = (Calendar) todayCal.clone();
					todayCalClone.add(Calendar.DAY_OF_YEAR, 3);
					System.out.print(todayCalClone.get(Calendar.DAY_OF_MONTH)
							+ " ");
					todayCalClone.add(Calendar.DAY_OF_YEAR, 4);
					System.out.print(todayCalClone.get(Calendar.DAY_OF_MONTH)
							+ " ");
					todayCalClone.add(Calendar.DAY_OF_YEAR, 3);
					System.out.print(todayCalClone.get(Calendar.DAY_OF_MONTH)
							+ " ");
					todayCalClone.add(Calendar.DAY_OF_YEAR, 4);
					System.out.print(todayCalClone.get(Calendar.DAY_OF_MONTH)
							+ " ");
					todayCalClone.add(Calendar.DAY_OF_YEAR, 3);
					System.out.print(todayCalClone.get(Calendar.DAY_OF_MONTH)
							+ " ");
				}

			}
			System.out.println();
		} else {
			System.out.print("Numbers.java ------"
					+ " draws since date "
					+ Numbers.dateNotAppearedCount);
		}

		if (Numbers.monthNotAppearedCount > 8) {
			System.out.println("Numbers.java ------"
					+ Numbers.monthNotAppearedCount
					+ " draws since month appeared in results. Include month");
		} else {
			System.out.print( " --- draws since month "
					+ Numbers.monthNotAppearedCount);
		}

		if (Numbers.yearNotAppearedCount > 12) {
			System.out.println("Numbers.java ------"
					+ Numbers.yearNotAppearedCount 
					+ " draws since year appeared in results. Include year");
		} else {
			System.out.println(" --- draws since year "
					+ Numbers.yearNotAppearedCount);
		}

	}

	private void printCumulativeSkipResultsToFile() {
		// TODO Auto-generated method stub
		String outString = "";
		StringTokenizer strtok = new StringTokenizer(currentResult, ",");
		for (int i = 0; i < 5; i++) {
			String num = strtok.nextToken();
			if (i < 4) {
				outString += skipHashPrevious.get(Integer.parseInt(num)) + " ";
			} else {
				String[] splitlast = num.split("\\+");
				outString += skipHashPrevious.get(Integer
						.parseInt(splitlast[0])) + " ";

				outString += " \t\t"
						+ skipMBHashPrevious
								.get(Integer.parseInt(splitlast[1])) + " ";
			}

		}
		if (findStringInFile(
				"C:\\Users\\johris\\git\\git\\Generator\\skipResults" + gam,
				Integer.toString(numRecordsInFile)) < 0)
			addLineToFile(
					"C:\\Users\\johris\\git\\git\\Generator\\skipResults"
							+ gam, (numRecordsInFile + " " + currentResult
							+ "\t\t " + outString), true);
		
		
		currentResult =  null;
	}

	void printBucketCountToFile(int lineNum, String lineFromFile) {

		String outString;
		int[] bucketCount = new int[8];
		String bucketPatternString = "";
		if (bucketFreqlast10 == null || bucketFreqlast10.size() == 0) {
			for (int i = 0; i < 8; i++)
				bucketFreqlast10.put(i, 0);

		}

		String[] key = lineFromFile.split("\\+");
		pb.put(key[0], key[1]);
		plb.add(Integer.parseInt(key[1]));

		StringTokenizer strtok = new StringTokenizer(lineFromFile, ",");
		for (int i = 0; i < 5; i++) {
			String num = strtok.nextToken();

			if (i < 4) {
				if (10 > Integer.parseInt(num) && Integer.parseInt(num) >= 0)
					bucketCount[0] += 1; 
				if (20 > Integer.parseInt(num) && Integer.parseInt(num) >= 10)
					bucketCount[1] += 1;
				if (30 > Integer.parseInt(num) && Integer.parseInt(num) >= 20)
					bucketCount[2] += 1;
				if (40 > Integer.parseInt(num) && Integer.parseInt(num) >= 30)
					bucketCount[3] += 1;
				if (50 > Integer.parseInt(num) && Integer.parseInt(num) >= 40)
					bucketCount[4] += 1;
				if (60 > Integer.parseInt(num) && Integer.parseInt(num) >= 50)
					bucketCount[5] += 1;
				if (70 > Integer.parseInt(num) && Integer.parseInt(num) >= 60)
					bucketCount[6] += 1;
				if (80 > Integer.parseInt(num) && Integer.parseInt(num) >= 70)
					bucketCount[7] += 1;


				if (10 > Integer.parseInt(num) && Integer.parseInt(num) >= 0)
					bucketPatternString += "0";
				if (20 > Integer.parseInt(num) && Integer.parseInt(num) >= 10)
					bucketPatternString += "1";
				if (30 > Integer.parseInt(num) && Integer.parseInt(num) >= 20)
					bucketPatternString += "2";
				if (40 > Integer.parseInt(num) && Integer.parseInt(num) >= 30)
					bucketPatternString += "3";
				if (50 > Integer.parseInt(num) && Integer.parseInt(num) >= 40)
					bucketPatternString += "4";
				if (60 > Integer.parseInt(num) && Integer.parseInt(num) >= 50)
					bucketPatternString += "5";
				if (70 > Integer.parseInt(num) && Integer.parseInt(num) >= 60)
					bucketPatternString += "6";
				if (80 > Integer.parseInt(num) && Integer.parseInt(num) >= 70)
					bucketPatternString += "7";

			} else {
				String[] splitlast = num.split("\\+");
				num = splitlast[0];
				if (10 > Integer.parseInt(num) && Integer.parseInt(num) >= 0)
					bucketCount[0] += 1;
				if (20 > Integer.parseInt(num) && Integer.parseInt(num) >= 10)
					bucketCount[1] += 1;
				if (30 > Integer.parseInt(num) && Integer.parseInt(num) >= 20)
					bucketCount[2] += 1;
				if (40 > Integer.parseInt(num) && Integer.parseInt(num) >= 30)
					bucketCount[3] += 1;
				if (50 > Integer.parseInt(num) && Integer.parseInt(num) >= 40)
					bucketCount[4] += 1;
				if (60 > Integer.parseInt(num) && Integer.parseInt(num) >= 50)
					bucketCount[5] += 1;
				if (70 > Integer.parseInt(num) && Integer.parseInt(num) >= 60)
					bucketCount[6] += 1;
				if (80 > Integer.parseInt(num) && Integer.parseInt(num) >= 70)
					bucketCount[7] += 1;

				if (10 > Integer.parseInt(num) && Integer.parseInt(num) >= 0)
					bucketPatternString += "0";
				if (20 > Integer.parseInt(num) && Integer.parseInt(num) >= 10)
					bucketPatternString += "1";
				if (30 > Integer.parseInt(num) && Integer.parseInt(num) >= 20)
					bucketPatternString += "2";
				if (40 > Integer.parseInt(num) && Integer.parseInt(num) >= 30)
					bucketPatternString += "3";
				if (50 > Integer.parseInt(num) && Integer.parseInt(num) >= 40)
					bucketPatternString += "4";
				if (60 > Integer.parseInt(num) && Integer.parseInt(num) >= 50)
					bucketPatternString += "5";
				if (70 > Integer.parseInt(num) && Integer.parseInt(num) >= 60) 
					bucketPatternString += "6";
				if (80 > Integer.parseInt(num) && Integer.parseInt(num) >= 70)
					bucketPatternString += "7"; 
			}

		}

		outString = bucketPatternString + " ---- " + bucketCount[0] + " "
				+ bucketCount[1] + " " + bucketCount[2] + " " + bucketCount[3]
				+ " " + bucketCount[4] + " " + bucketCount[5]+ " " + bucketCount[6]+ " " + bucketCount[7];

		if (lineNum <= 10) {
			for (int i = 0; i < 8; i++) {
				int lastCount = bucketFreqlast10.get(i);
				bucketFreqlast10.put(i, lastCount + bucketCount[i]);
			}

		}

		addLineToFile("C:\\Users\\johris\\git\\git\\Generator\\bucketsList"
				+ gam, (lineNum + " " + lineFromFile + " " + outString), false);

	}

	void printFreqAndLastAppearance(HashMap inFreq, HashMap inLastAppearance) {

		Set nums = inFreq.keySet();
		Iterator it = nums.iterator();
		while (it.hasNext()) {
			Integer str = (Integer) it.next();
			System.out.println("Numbers.java ------" + str + " "
					+ inFreq.get(str) + " " + inLastAppearance.get(str));
		}
	}

	private void createFreqTracker(boolean printToConsole) {
		int linenum = 0;
		try {
			FileInputStream fstream = new FileInputStream(dataFileName);

			HashMap freqClone = (HashMap) freq.clone();

			// Get the object of DataInputStream
			DataInputStream in = new DataInputStream(fstream);
			BufferedReader br = new BufferedReader(new InputStreamReader(in));
			String strLine = null;
			int sumofFreq = 0;

			// Read File Line By Line
			while ((strLine = br.readLine()) != null) {
				// Print the content on the console for 100 records

				if (linenum < 100) {
					int sumOfNum = 0;
					StringTokenizer strtok = new StringTokenizer(strLine, ",");

					for (int i = 0; i < 4; i++) {
						String num = strtok.nextToken();

						int count = Integer.parseInt((String) freq
								.get(new Integer(num)));
						freqTracker[linenum][i] = count - 1 - avg5;
						freq.put(new Integer(num), Integer.toString(count - 1));
						sumOfNum += Integer.parseInt(num);
					}
					freqTracker[linenum][5] = avg5;
					// Arrays.sort(freqTracker[linenum]);

					int mbavg = averageOfValues(mbfreq, mbfreq.size());
					for (int i = 0; i < 1; i++) { // Last num and MB num now
						String num = strtok.nextToken();

						String[] splitplus = num.split("\\+");

						int count = Integer.parseInt((String) freq
								.get(new Integer(splitplus[0])));
						freqTracker[linenum][4] = count - 1 - avg5;
						freq.put(new Integer(splitplus[0]),
								Integer.toString(count - 1));

						sumOfNum += Integer.parseInt(splitplus[0]);

						count = Integer.parseInt((String) mbfreq
								.get(new Integer(splitplus[1])));
						mbfreqTracker[linenum][i] = count - 1 - mbavg;
						mbfreq.put(new Integer(splitplus[1]),
								Integer.toString(count - 1));
					}
					mbfreqTracker[linenum][1] = mbavg;
					// Arrays.sort(mbfreqTracker[linenum]);

					if (linenum < 40) {
						boolean sumAdded = lastFewSums.add(sumOfNum);
						// System.out.println("Sum " + sumOfNum +
						// " repeated on line " + linenum);
					}
					linenum++;
				}

			}

			for (int i = 0; i < linenum; i++) {
				String line = "";

				String savetoFile = "";

				int[][] temp = null;

				if (dataFor.equals("15"))
					temp = freqTracker;
				else
					temp = mbfreqTracker;

				Arrays.sort(temp[i]);
				for (int j = 0; j < temp[i].length; j++) {
					line += temp[i][j] + " ";
				}

				if (printToConsole)
					System.out.print(line);

				savetoFile += line;

				line = "";
				if (i < linenum - 10) {
					Arrays.sort(temp[i + 1]);
					Arrays.sort(temp[i + 2]);
					Arrays.sort(temp[i + 3]);
					Arrays.sort(temp[i + 4]);
					Arrays.sort(temp[i + 5]);
					Arrays.sort(temp[i + 6]);
					Arrays.sort(temp[i + 7]);
					Arrays.sort(temp[i + 8]);
					Arrays.sort(temp[i + 9]);

					for (int j = 0; j < temp[i].length - 1; j++) {
						maTracker[i][j] = (temp[i][j] + temp[i + 1][j] + temp[i + 2][j]) / 3;
						line += maTracker[i][j] + " ";
					}
					if (printToConsole)
						System.out.print("\t3MA:" + line);
					savetoFile += "\t3MA:" + line;

					line = "";
					for (int j = 0; j < temp[i].length - 1; j++) {
						maTracker[i][j + 5] = (temp[i][j] + temp[i + 1][j]
								+ temp[i + 2][j] + temp[i + 3][j]
								+ temp[i + 4][j] + temp[i + 5][j]
								+ temp[i + 6][j] + temp[i + 7][j]
								+ temp[i + 8][j] + temp[i + 9][j]) / 10;
						line += maTracker[i][j + 5] + " ";
					}
					if (printToConsole)
						System.out.println("\t10MA:" + line);
					savetoFile += "\t10MA:" + line;

					if (i == 0) // Save the last tracker values in
								// props.properties
						addLineToFile(
								"C:\\Users\\johris\\git\\git\\Generator\\props.properties",
								"FreqTracker=" + savetoFile, false);
				}
			}
			System.out.println("Numbers.java ------" + "");
			// getNex

			freq = freqClone;
			fstream.close();
			in.close();
			br.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NumberFormatException e) {
			System.out.println(linenum);
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	private boolean isNumberInResults(String results, String num) {
		boolean out = false;
		String[] key = results.split("\\+");

		if (key[1].equals(num))
			return true;

		StringTokenizer strtok = new StringTokenizer(key[0], ",");
		for (int i = 0; i < 5; i++) {
			String numRes = strtok.nextToken();

			if (numRes.equals(num))
				return true;
		}

		return out;
	}

	static HashMap numberAppearance(int trials) {// These are the numbers that
													// appeared n times in past
													// trials trials
		// HashMap<Integer, Integer> frq = new HashMap();

		HashMap freqClone = (HashMap) freq.clone();

		Set nums = freq.keySet();
		Iterator it = nums.iterator();
		while (it.hasNext()) {
			Integer str = (Integer) it.next();
			if (frqnum == null)
				frqnum = new HashMap();
			frqnum.put(str, 0);
		}

		ArrayList<Integer> firstCombList = new ArrayList<Integer>();
		ArrayList<Integer> lastCombList = new ArrayList<Integer>();

		int linenum = 0;
		try {
			FileInputStream fstream = new FileInputStream(dataFileName);

			// Get the object of DataInputStream
			DataInputStream in = new DataInputStream(fstream);
			BufferedReader br = new BufferedReader(new InputStreamReader(in));
			String strLine = null;

			// Read File Line By Line
			while ((strLine = br.readLine()) != null) {
				String result = " ";
				int evenOddCounter = 0;

				// /String freqResult = "";
				if (linenum < trials + 1) {

					StringTokenizer strtok = new StringTokenizer(strLine, ",");

					for (int i = 0; i < 4; i++) {
						String num = strtok.nextToken();

						result += num + " ";
						// freqResult += count + " ";

						if (linenum == 0)
							evenOddCounter += isEven(Integer.parseInt(num));

						if (linenum == 0) {
							firstCombList.add(Integer.parseInt(num));

						}

						if (linenum == trials)
							lastCombList.add(Integer.parseInt(num));

						if (linenum > 0) {
							int freqcountinlastn = frqnum.get(Integer
									.parseInt(num));
							frqnum.put(Integer.parseInt(num),
									freqcountinlastn + 1);

						}
					}

					for (int i = 0; i < 1; i++) { // Last num and MB num now
						String num = strtok.nextToken();

						String[] splitplus = num.split("\\+");

						result += splitplus[0] + " ";

						if (linenum == 0)
							evenOddCounter += isEven(Integer
									.parseInt(splitplus[0]));

						if (linenum == 0)
							firstCombList.add(Integer.parseInt(splitplus[0]));

						if (linenum == trials)
							lastCombList.add(Integer.parseInt(splitplus[0]));

						if (linenum > 0) {
							int freqcountinlastn = frqnum.get(Integer
									.parseInt(splitplus[0]));
							frqnum.put(Integer.parseInt(splitplus[0]),
									freqcountinlastn + 1);

							// WE WILL DEAL WITH mbfreq later
							num = splitplus[1];
						}
					}

				}

				if (linenum == 0) {
					if (evenOddCounter > 0)
						lastEvenOdd = "E";
					else
						lastEvenOdd = "O";
				}

				// if (linenum > 0) {
				evenOddLastNineCount += evenOddCounter;
				// }

				linenum++;
			}

			freq = freqClone;
			fstream.close();
			in.close();
			br.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		// Add the latest result's appearance count to props file like
		// 4 19 25 32 53 2 0 2 0 1 [2 out of 0 appearances, 0 out of 1
		// etc]

		int coun = 0;

		// removeLineFromFile("C:\\Users\\johris\\git\\git\\Generator\\numAppearanceMap"
		// +gam,
		// numRecordsInFile + " " + firstCombList.toString());

		String outline = numRecordsInFile + " " + firstCombList.toString();
		ArrayList<Integer>[] al = new ArrayList[trials];
		Integer[] comb = new Integer[firstCombList.size()];

		firstCombList.toArray(comb);

		int sumofnums = 0;

		for (int i = 0; i < comb.length; i++)
			sumofnums += comb[i];

		for (int i = 0; i < trials; i++) {
			al[i] = new ArrayList<Integer>();
		}

		Set numbers = frqnum.keySet();
		Iterator it1 = numbers.iterator();
		while (it1.hasNext()) {
			Integer str = (Integer) it1.next();
			if (frqnum.get(str) < trials) {
				if (al[frqnum.get(str)] == null)
					al[frqnum.get(str)] = new ArrayList<Integer>();

				al[frqnum.get(str)].add(str);
			}

		}

		if (trials > 0) {
			for (int i = 0; i < comb.length; i++) {
				for (int j = 0; j < al[0].size(); j++) {
					if (comb[i].intValue() == al[0].get(j).intValue())
						coun++;
				}
			}
			outline += " " + coun + " ";
		}

		coun = 0;
		if (trials > 1) {
			for (int i = 0; i < comb.length; i++) {
				for (int j = 0; j < al[1].size(); j++) {
					if (comb[i].intValue() == al[1].get(j).intValue())
						coun++;
				}
			}
			outline += " " + coun + " ";
		}

		coun = 0;
		if (trials > 2) {
			for (int i = 0; i < comb.length; i++) {
				for (int j = 0; j < al[2].size(); j++) {
					if (comb[i].intValue() == al[2].get(j).intValue())
						coun++;
				}
			}
			outline += " " + coun + " ";
		}

		coun = 0;
		if (trials > 3) {
			for (int i = 0; i < comb.length; i++) {
				for (int j = 0; j < al[3].size(); j++) {
					if (comb[i].intValue() == al[3].get(j).intValue())
						coun++;
				}
			}
			outline += " " + coun + " ";
		}

		coun = 0;
		if (trials > 4) {
			for (int i = 0; i < comb.length; i++) {
				for (int j = 0; j < al[4].size(); j++) {
					if (comb[i].intValue() == al[4].get(j).intValue())
						coun++;
				}
			}
			outline += " " + coun + " ";
		}

		if (findStringInFile(
				"C:\\Users\\johris\\git\\git\\Generator\\numAppearanceMap"
						+ gam, Integer.toString(numRecordsInFile)) < 0) {
			addLineToFile(
					"C:\\Users\\johris\\git\\git\\Generator\\numAppearanceMap"
							+ gam, outline + " " + sumofnums, true);
			// Also print the latest value of evenOddLastNineCount
			System.out.print("Value of evenOddLastNineCount "
					+ evenOddLastNineCount + " ");
			if (evenOddLastNineCount <= -7)
				System.out.println(" Lots of odds in last 9, go for Evens");
			else if (evenOddLastNineCount >= 4)
				System.out.println(" Lots of evens in last 9, go for odds");
			else
				System.out
						.println(" Between -7 and 4 -- evenly balanced between odds and evens.");
		}

		// Adjust frqnum map to include current freq result...
		for (int i = 0; i < comb.length; i++) { // comb has the last freq
			int freqcountinlast = frqnum.get(comb[i]);
			frqnum.put(comb[i], freqcountinlast + 1);
		}

		// Adjust frq map to exclude last freq result...
		lastCombList.toArray(comb);
		for (int i = 0; i < comb.length; i++) { // comb has the last freq
			int freqcountinlast = frqnum.get(comb[i]);
			frqnum.put(comb[i], freqcountinlast - 1);
		}

		return frqnum;
	}

	static int isEven(int num) {
		if (num % 2 == 0) {
			return 1;
		}
		return -1;
	}

	static HashMap freqAppearance(int trials) {// These are the frqs that
												// appeared n times in past
												// trials trials
		// HashMap<Integer, Integer> frq = new HashMap();

		HashMap freqClone = (HashMap) freq.clone();

		Set nums = freq.keySet();
		Iterator it = nums.iterator();
		while (it.hasNext()) {
			Integer str = (Integer) it.next();
			if (frq == null)
				frq = new HashMap();
			frq.put(Integer.parseInt((String) freq.get(str)), 0);
		}

		ArrayList<Integer> firstCombList = new ArrayList<Integer>();
		ArrayList<Integer> lastCombList = new ArrayList<Integer>();

		int linenum = 0;
		try {
			FileInputStream fstream = new FileInputStream(dataFileName);

			// Get the object of DataInputStream
			DataInputStream in = new DataInputStream(fstream);
			BufferedReader br = new BufferedReader(new InputStreamReader(in));
			String strLine = null;

			// Read File Line By Line
			while ((strLine = br.readLine()) != null) {
				String result = " ";
				String freqResult = "";
				if (linenum < trials + 1) {

					StringTokenizer strtok = new StringTokenizer(strLine, ",");

					for (int i = 0; i < 4; i++) {
						String num = strtok.nextToken();
						int count = Integer.parseInt((String) freq
								.get(new Integer(num)));

						if (linenum == 0) {
							result += num + " ";
							freqResult += count - 1 + " ";
							firstCombList.add(count - 1);
						}

						if (linenum == trials)
							lastCombList.add(count - 1);

						if (linenum > 0) {
							if (!frq.containsKey(count - 1))
								frq.put(count - 1, 0);
							int freqcountinlastn = frq.get(count - 1);
							frq.put(count - 1, freqcountinlastn + 1);

						}
						freq.put(new Integer(num), Integer.toString(count - 1));
					}

					for (int i = 0; i < 1; i++) { // Last num and MB num now
						String num = strtok.nextToken();

						String[] splitplus = num.split("\\+");

						int count = Integer.parseInt((String) freq
								.get(new Integer(splitplus[0])));

						if (linenum == 0) {
							result += splitplus[0] + " ";
							freqResult += count - 1 + " ";
							firstCombList.add(count - 1);
						}

						if (linenum == trials)
							lastCombList.add(count - 1);

						if (linenum > 0) {
							if (!frq.containsKey(count - 1))
								frq.put(count - 1, 0);

							int freqcountinlastn = frq.get(count - 1);
							frq.put(count - 1, freqcountinlastn + 1);

							// WE WILL DEAL WITH mbfreq later
							count = Integer.parseInt((String) mbfreq
									.get(new Integer(splitplus[1])));
						}
						freq.put(new Integer(splitplus[0]),
								Integer.toString(count - 1));

					}

					if (linenum == 0) { // Print mapstring to file
						String mapString = printFreqResultMap(result,
								freqResult, freq);
						if (findStringInFile(
								"C:\\Users\\johris\\git\\git\\Generator\\freqAppearanceMap"
										+ gam,
								Integer.toString(numRecordsInFile)) < 0) {
							addLineToFile(
									"C:\\Users\\johris\\git\\git\\Generator\\freqAppearanceMap"
											+ gam, mapString, true);
							freqAppearanceMapFileText = null;
						}
					}
				} else {
					break;
				}

				linenum++;
			}

			freq = freqClone;
			fstream.close();
			in.close();
			br.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		// Add the latest result's appearance count to props file like
		// 114 123 130 145 155 2 0 2 0 1 [2 out of 0 appearances, 0 out of 1
		// etc]

		int coun = 0;

		// removeLineFromFile("C:\\Users\\johris\\git\\git\\Generator\\freqAppearanceMap",
		// numRecordsInFile + " " + firstCombList.toString());

		String freqs = firstCombList.toString().replace(",", "")
				.replace("[", "").replace("]", "");
		String outline = "";
		ArrayList<Integer>[] al = new ArrayList[trials];
		Integer[] comb = new Integer[firstCombList.size()];

		firstCombList.toArray(comb);

		for (int i = 0; i < trials; i++) {
			al[i] = new ArrayList<Integer>();
		}

		Set numbers = frq.keySet();
		Iterator it1 = numbers.iterator();
		while (it1.hasNext()) {
			Integer str = (Integer) it1.next();
			if (frq.get(str) < trials) {
				if (al[frq.get(str)] == null)
					al[frq.get(str)] = new ArrayList<Integer>();

				al[frq.get(str)].add(str);
			}

		}

		if (trials > 0 && al[0].size() > 0) {
			for (int i = 0; i < comb.length; i++) {
				for (int j = 0; j < al[0].size(); j++) {
					if (comb[i].intValue() == al[0].get(j).intValue())
						coun++;
				}
			}
			outline += " " + coun + " ";
		}

		coun = 0;
		if (trials > 1 && al[1].size() > 0) {
			for (int i = 0; i < comb.length; i++) {
				for (int j = 0; j < al[1].size(); j++) {
					if (comb[i].intValue() == al[1].get(j).intValue())
						coun++;
				}
			}
			outline += " " + coun + " ";
		}

		coun = 0;
		if (trials > 2 && al[2].size() > 0) {
			for (int i = 0; i < comb.length; i++) {
				for (int j = 0; j < al[2].size(); j++) {
					if (comb[i].intValue() == al[2].get(j).intValue())
						coun++;
				}
			}
			outline += " " + coun + " ";
		}

		coun = 0;
		if (trials > 3 && al[3].size() > 0) {
			for (int i = 0; i < comb.length; i++) {
				for (int j = 0; j < al[3].size(); j++) {
					if (comb[i].intValue() == al[3].get(j).intValue())
						coun++;
				}
			}
			outline += " " + coun + " ";
		}

		coun = 0;
		if (trials > 4 && al[4].size() > 0) {
			for (int i = 0; i < comb.length; i++) {
				for (int j = 0; j < al[4].size(); j++) {
					if (comb[i].intValue() == al[4].get(j).intValue())
						coun++;
				}
			}
			outline += " " + coun + " ";
		}

		if (findStringInFile(
				"C:\\Users\\johris\\git\\git\\Generator\\freqAppearanceMap"
						+ gam, freqs) < 0)
			addLineToFile(
					"C:\\Users\\johris\\git\\git\\Generator\\freqAppearanceMap"
							+ gam, numRecordsInFile + " " + freqs + " "
							+ outline, true);
		else { // Append to the existing line
			appendStringToMatchedLineAndAddLineNumInFile(
					"C:\\Users\\johris\\git\\git\\Generator\\freqAppearanceMap"
							+ gam, freqs, outline);
		}

		// Adjust frq map to include current freq result...
		for (int i = 0; i < comb.length; i++) { // comb has the last freq
			if (!frq.containsKey(comb[i]))
				frq.put(comb[i], 0);
			int freqcountinlast = frq.get(comb[i]);
			frq.put(comb[i], freqcountinlast + 1);
		}

		// Adjust frq map to exclude last freq result...
		lastCombList.toArray(comb);
		for (int i = 0; i < comb.length; i++) { // comb has the last freq
			int freqcountinlast = frq.get(comb[i]);
			frq.put(comb[i], freqcountinlast - 1);
		}

		return frq;
	}

	static String freqAppearanceMapForATestComb(int trials, Integer[] arr) {// These
																			// are
																			// the
																			// frqs
																			// that
																			// appeared
																			// n
																			// times
																			// in
																			// past
																			// trials
																			// trials
		// HashMap<Integer, Integer> frq = new HashMap();

		ArrayList<Integer> firstCombList = new ArrayList<Integer>();
		ArrayList<Integer> lastCombList = new ArrayList<Integer>();

		int linenum = 0;
		String result = " ";
		String freqResult = "";

		for (int i = 0; i < arr.length; i++) {
			int fcount = 0;
			if (freq.get(arr[i].intValue()) != null)
				fcount = Integer.parseInt((String) freq.get(arr[i].intValue()));
			result += arr[i].intValue() + " ";
			freqResult += fcount + " ";
		}

		return printFreqResultMap(result, freqResult, freq);

	}

	private static String printFreqResultMap(String result, String freqResult,
			HashMap freq2) { // Prints resulting freq on a map like
		// ---*----*-------------*---*-----------------*--

		// First sort the map based on values (frequencies)
		String out = "";
		HashMap cloneFreq2 = (HashMap) freq2.clone();
		// System.out.print("Results: " + result + "\t" + ((result.length() <
		// 15) ? "\t" : "") + freqResult + "\t");
		out += "Results: " + result + "\t"
				+ ((result.length() < 15) ? "\t" : "") + freqResult + "\t";
		List mapKeys = new ArrayList(freq2.keySet());
		List mapValues = new ArrayList(freq2.values());
		// Convert the mapValues to a list of Integers
		List<Integer> mapValuesInt = new ArrayList<Integer>();

		for (int i = 0; i < mapValues.size(); i++) {
			mapValuesInt.add(Integer.parseInt((String) mapValues.get(i)));
		}
		Collections.sort(mapValuesInt);
		Collections.sort(mapKeys);

		LinkedHashMap sortedMap = new LinkedHashMap();

		Iterator valueIt = mapValuesInt.iterator();
		while (valueIt.hasNext()) {
			Object val = valueIt.next();
			Iterator keyIt = mapKeys.iterator();

			while (keyIt.hasNext()) {
				Object key = keyIt.next();
				String comp1 = freq2.get(key).toString();
				String comp2 = val.toString();

				if (comp1.equals(comp2)) {
					freq2.remove(key);
					mapKeys.remove(key);
					sortedMap.put(key, val);
					break;
				}
			}
		}

		// Now sort through the map and print the freq in result with a *

		// System.out.print("Range : " + mapValuesInt.get(0) + " - " +
		// mapValuesInt.get(mapValuesInt.size() - 1));
		out += "Range : " + mapValuesInt.get(0) + " - "
				+ mapValuesInt.get(mapValuesInt.size() - 1);
		List sortedMapKeys = new ArrayList(sortedMap.keySet());
		for (int i = 0; i < sortedMapKeys.size(); i++) {
			/*
			 * if (result.contains(sortedMapKeys.get(i)+" "))
			 * System.out.print("");
			 */
			// System.out.print((result.contains(" " + sortedMapKeys.get(i) +
			// " ")) ? "*": "-");
			out += (result.contains(" " + sortedMapKeys.get(i) + " ")) ? "*"
					: "-";
		}

		String[] resArr = result.split(" ");
		int sum = 0;
		for (int i = 0; i < resArr.length; i++) {
			if (resArr[i].trim().length() > 0)
				sum += Integer.parseInt(resArr[i].trim());
		}
		// System.out.println("  Sum: " + sum);

		freq = cloneFreq2;

		return out;

	}

	private void printFreqAppearance(HashMap<Integer, Integer> frq, int n) {// Print
																			// freqs
																			// appearing
																			// 0..n
																			// times
																			// in
																			// the
																			// hashmap
																			// writes
																			// to
																			// props.properties
		ArrayList<Integer>[] al = new ArrayList[n];

		for (int i = 0; i < n; i++) {
			al[i] = new ArrayList<Integer>();
		}

		if (currentActiveFreqs == null) {
			currentActiveFreqs = getCurrentFreqList();
		}
		ArrayList<Integer> currentActiveFreqList = new ArrayList<Integer>(
				Arrays.asList(currentActiveFreqs));

		Set nums = frq.keySet();
		Iterator it = nums.iterator();
		while (it.hasNext()) {
			Integer str = (Integer) it.next();
			// See if this freq exists in currentActiveFreqList
			if (currentActiveFreqList.contains(str)) {
				if (frq.get(str) < n) {
					if (al[frq.get(str)] == null)
						al[frq.get(str)] = new ArrayList<Integer>();

					al[frq.get(str)].add(str);
				}
			}

		}

		for (int i = 0; i < n; i++) {
			int[] freq = null;
			String res = "";

			res += al[i];
			// System.out.println("Freqs appearing " + i + " times in last 10: "
			// + res);
			addLineToFile(
					"C:\\Users\\johris\\git\\git\\Generator\\props.properties",
					"Appears " + i + " times in 10 draws: " + res, false);
		}

	}

	static boolean handleMustIncludes(int[] comb, int n) { // These are the
															// combination of 1
															// .. n time
															// appearing
															// frequencies in
															// our list are
															// populated
															// Matches against
															// existing
															// frequencies in
															// props.properties
															// and
															// Excludes a repeat
		int[] matchMap = FreqFilter.matchMap; // Frequencies from each bucket

		// if (matchMap == null) return true;

		boolean out = false;
		int count = 0;
		String freqMap = "";

		if (frq == null)
			frq = freqAppearance(10);

		if (frqnum == null) // This is ONLY to print the number appearance in
							// numAppearanceMap
							// How many times a number appearing n time turned
							// up in results
			frqnum = numberAppearance(10);

		ArrayList<Integer>[] al = new ArrayList[n];

		for (int i = 0; i < n; i++) {
			al[i] = new ArrayList<Integer>();
		}

		Set nums = frq.keySet();
		Iterator it = nums.iterator();
		while (it.hasNext()) {
			Integer str = (Integer) it.next();
			if (frq.get(str) < n) {
				if (al[frq.get(str)] == null)
					al[frq.get(str)] = new ArrayList<Integer>();

				al[frq.get(str)].add(str);
			}
		}

		if (n > 0 && al[0].size() > 0) {
			for (int i = 0; i < comb.length; i++) {
				for (int j = 0; j < al[0].size(); j++) {
					if (comb[i] == al[0].get(j))
						count++;
				}
			}

			if (count <= 4) // count == 0 || count == 1 || count == 2 || count
							// == 3
				out = true;
			else
				return false;

		}

		freqMap += " " + count + " ";

		count = 0;
		if (n > 1 && al[1].size() > 0) {
			for (int i = 0; i < comb.length; i++) {
				for (int j = 0; j < al[1].size(); j++) {
					if (comb[i] == al[1].get(j))
						count++;
				}
			}
			if (count <= 4) // count == 0 || count == 1 || count == 2 || count
							// == 3
				out = true;
			else
				return false;
		}
		freqMap += " " + count + " ";

		count = 0;
		if (n > 2 && al[2].size() > 0) {
			for (int i = 0; i < comb.length; i++) {
				for (int j = 0; j < al[2].size(); j++) {
					if (comb[i] == al[2].get(j))
						count++;
				}
			}
			if (count <= 4) // count == 0 || count == 1 || count == 2 || count
							// == 3
				out = true;
			else
				return false;

		}
		freqMap += " " + count + " ";

		count = 0;
		if (n > 3 && al[3].size() > 0) {
			for (int i = 0; i < comb.length; i++) {
				for (int j = 0; j < al[3].size(); j++) {
					if (comb[i] == al[3].get(j))
						count++;
				}
			}
			if (count <= 4) // count == 0 || count == 1 || count == 2 || count
							// == 3
				out = true;
			else
				return false;

		}
		freqMap += " " + count + " ";

		count = 0;
		if (n > 4 && al[4].size() > 0) {
			for (int i = 0; i < comb.length; i++) {
				for (int j = 0; j < al[4].size(); j++) {
					if (comb[i] == al[4].get(j))
						count++;
				}
			}
			if (count <= 4) // count == 0 || count == 1 || count == 2 || count
							// == 3
				out = true;
			else
				return false;

		}
		freqMap += " " + count + " ";

		if (findStringInFile(
				"C:\\Users\\johris\\git\\git\\Generator\\freqAppearanceMap"
						+ gam, freqMap) == -1) // Does not exist in file
			out = true;
		else
			out = false;

		return out;
	}

	public static void removeLineFromFile(String file, String lineToRemove) {

		try {

			File inFile = new File(file);

			if (!inFile.isFile()) {
				System.out
						.println("Numbers.java ------"
								+ file + " does not exist, so can not remove Line.");
				return;
			}

			// Construct the new file that will later be renamed to the original
			// filename.
			File tempFile = new File(inFile.getAbsolutePath() + ".tmp");

			BufferedReader br = new BufferedReader(new FileReader(file));
			PrintWriter pw = new PrintWriter(new FileWriter(tempFile));

			String line = null;

			// Read from the original file and write to the new
			// unless content matches data to be removed.
			while ((line = br.readLine()) != null) {

				if (!lineToRemove.equals("*")) { // If * is passed, then delete
													// everything
					if (!line.trim().startsWith(lineToRemove)) {

						pw.println(line);
						pw.flush();
					}
				}
			}
			pw.close();
			br.close();

			// Delete the original file
			if (!inFile.delete()) {
				System.out.println("Numbers.java ------"
						+ "Could not delete file " + inFile.getAbsolutePath());
				return;
			}

			// Rename the new file to the filename the original file had.
			if (!tempFile.renameTo(inFile))
				System.out.println("Numbers.java ------"
						+ "Could not rename file " + inFile.getAbsolutePath());

		} catch (FileNotFoundException ex) {
			ex.printStackTrace();
		} catch (IOException ex) {
			ex.printStackTrace();
		}
	}

	public static boolean addLineToFile(String file, String line, boolean prepend) { // Pass
																					// true
																					// in
																					// the
																					// third
																					// argument
																					// if
																					// want
																					// to
																					// add
																					// this
																					// string
																					// To
																					// the
																					// top
																					// of
																					// file
		try {

			if (prepend) {
				return insertStringInFile(new File(file), 1, line);
			} else {
				FileWriter fr = new FileWriter(file,	true);
				BufferedWriter writer = new BufferedWriter(fr);
				writer.write(line);
				writer.write(System.getProperty("line.separator"));
				
				if (writer != null)
					writer.close();
				if (fr != null)
					fr.close();
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}

		return true;
	}

	public static boolean insertStringInFile(File inFile, int lineno,
			String lineToBeInserted) throws Exception {
		// temp file
		File outFile = new File("$$$$$$$$.tmp");

		// input
		FileInputStream fis = new FileInputStream(inFile);
		BufferedReader in = new BufferedReader(new InputStreamReader(fis));

		// output
		FileOutputStream fos = new FileOutputStream(outFile);
		PrintWriter out = new PrintWriter(fos);

		String thisLine = "";
		int i = 1;
		while ((thisLine = in.readLine()) != null) {
			if (i == lineno)
				out.println(lineToBeInserted);
			out.println(thisLine);
			i++;
		}
		out.flush();
		out.close();
		in.close();
		
		if (fis != null)
			fis.close();
		
		if (fos != null)
			fos.close();

		if (!inFile.delete()) {
			System.out.println("Numbers.insertStringInFile : Could not delete " + inFile.getAbsolutePath() );
			return false;
		}
		if (!outFile.renameTo(inFile)) {
			System.out.println("Numbers.insertStringInFile : Could not move " + outFile.getAbsolutePath() + " to " + inFile.getAbsolutePath() + " EXITING!");
			
			return false;
		}
		
		return true;
	}

	public static int findStringInFile(String file, String line) { // Return
																	// whether a
																	// string
																	// exists in
																	// a file
																	// -1 if
																	// does not
																	// exist
		int found = 0;

		// if (freqAppearanceMapFileText == null) {
		StringBuilder sb = new StringBuilder();

		try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
			// Reads until the end-of-file met
			while (reader.ready()) {
				// Read line-by-line directly
				sb.append(reader.readLine());
			}

		} catch (IOException ex) {
			System.out
					.println("File " + file + " does not exist. Creating it.");
			File newFile = new File(file);
			try {
				boolean createNewFile = newFile.createNewFile();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return -1;
		}

		freqAppearanceMapFileText = sb.toString();
		// }

		found = freqAppearanceMapFileText.indexOf(line);

		return found;
	}

	public static void appendStringToMatchedLineInFile(String file,
			String matchline, String appendString) { // See whether matchline
														// exists in a file, if
														// yes,
		// append appendString to that line
		try {

			File inFile = new File(file);

			if (!inFile.isFile()) {
				System.out
						.println("Numbers.java ------"
								+ "Parameter is not an existing file, so can not append Line.");
				return;
			}

			// Construct the new file that will later be renamed to the original
			// filename.
			File tempFile = new File(inFile.getAbsolutePath() + ".tmp");

			BufferedReader br = new BufferedReader(new FileReader(file));
			PrintWriter pw = new PrintWriter(new FileWriter(tempFile));

			String line = null;

			// Read from the original file and write to the new
			// unless content matches data to be removed.
			while ((line = br.readLine()) != null) {

				if (line.trim().indexOf(matchline) < 0) {
					pw.println(line);
					pw.flush();
				} else {
					if (line.trim().indexOf(appendString) < 0) { // Add only if
																	// appendString
																	// doesn't
																	// already
																	// exist in
																	// this line
						pw.println(line + appendString);
						pw.flush();
					}
				}

			}
			pw.close();
			br.close();

			// Delete the original file
			if (!inFile.delete()) {
				System.out.println("Numbers.java ------"
						+ "Could not delete file " + inFile.getAbsolutePath());
				return;
			}

			// Rename the new file to the filename the original file had.
			if (!tempFile.renameTo(inFile))
				System.out.println("Numbers.java ------"
						+ "Could not rename file " + inFile.getAbsolutePath());

		} catch (FileNotFoundException ex) {
			ex.printStackTrace();
		} catch (IOException ex) {
			ex.printStackTrace();
		}

	}

	public static void appendStringToMatchedLineAndAddLineNumInFile(
			String file, String matchline, String appendString) { // See whether
																	// matchline
																	// exists in
																	// a file,
																	// if yes,
		// append appendString to that line
		// Also add the numberRecordsInFile to the start of the line
		try {

			File inFile = new File(file);

			if (!inFile.isFile()) {
				System.out
						.println("Numbers.java ------"
								+ "Parameter is not an existing file, so can not append Line.");
				return;
			}

			// Construct the new file that will later be renamed to the original
			// filename.
			File tempFile = new File(inFile.getAbsolutePath() + ".tmp");

			BufferedReader br = new BufferedReader(new FileReader(file));
			PrintWriter pw = new PrintWriter(new FileWriter(tempFile));

			String line = null;

			// Read from the original file and write to the new
			// unless content matches data to be removed.
			while ((line = br.readLine()) != null) {

				if (line.trim().indexOf(matchline) < 0) {
					pw.println(line);
					pw.flush();
				} else {
					if (line.trim().indexOf(appendString.trim()) < 0) { // Add
																		// only
																		// if
																		// appendString
																		// doesn't
																		// already
																		// exist
																		// in
																		// this
																		// line
						pw.println(numRecordsInFile + " " + line + appendString);
						pw.flush();
					} else {
						pw.println(line);
						pw.flush();
					}
				}

			}
			pw.close();
			br.close();

			// Delete the original file
			if (!inFile.delete()) {
				System.out.println("Numbers.java ------"
						+ "Could not delete file " + inFile.getAbsolutePath());
				return;
			}

			// Rename the new file to the filename the original file had.
			if (!tempFile.renameTo(inFile))
				System.out.println("Numbers.java ------"
						+ "Could not rename file " + inFile.getAbsolutePath());

		} catch (FileNotFoundException ex) {
			ex.printStackTrace();
		} catch (IOException ex) {
			ex.printStackTrace();
		}

	}

	static void swap(ArrayList a, int i, int j) {
		int temp = 0;
		temp = (Integer) a.get(i);
		a.set(i, a.get(j));
		a.set(j, temp);
	}

	static void popOutNumber(ArrayList a, int index) {
		if ((a.size() - 1) == index) {
			a.remove(index);
		} else {
			int k = index;
			for (int i = index; i < (a.size() - 1); i++) {
				a.set(k, a.get(k + 1));
				++k;
			}
			a.remove(a.size() - 1);
		}
	}

	void runningDelta(LinkedHashMap<String, String> a) {
		int sum = 0;
		ArrayList b = new ArrayList();
		System.out.println("Numbers.java ------" + "Size of combs " + a.size());
		for (String key : a.keySet()) {
			String[] s = key.split("\\,");
			sum = Integer.parseInt(s[0]) + Integer.parseInt(s[1])
					+ Integer.parseInt(s[2]) + Integer.parseInt(s[3])
					+ Integer.parseInt(s[4]);
			b.add(sum);
		}
		for (int k = 0; k < (b.size() - 1); k++) {
			runDelta.add(k, (Integer) b.get(k) - (Integer) b.get(k + 1));
			// System.out.println((Integer)b.get(k)-(Integer)b.get(k+1));
		}
	}

	void stDev(ArrayList<Integer> t) {
		int median = 0;
		int sum = 0;
		int stDev = 0;
		for (int i = 0; i < t.size(); i++) {
			median = median + (t.get(i) > 0 ? t.get(i) : (-t.get(i)));
			// median = median + (t.get(i));
		}
		median = median / t.size();
		System.out.println("Numbers.java ------" + "mean " + median);
		for (int k = 0; k < t.size(); k++) {
			sum += ((t.get(k) > 0 ? t.get(k) : (-t.get(k))) - median)
					* ((t.get(k) > 0 ? t.get(k) : (-t.get(k))) - median);
			// sum += (t.get(k) - median)*(t.get(k) - median);
		}

		stDev = (int) Math.sqrt(sum / t.size());

		standeredDeviation = stDev;

		System.out.println("Numbers.java ------" + "Standered Deviation "
				+ stDev);

	}

	void randomNumbers() {
		try {
			System.out
					.println("Generating Combinations of 5 random integers in the range of 1..56");
			for (int k = 0; k <= 0; k++) {
				long hours = 0L;
				int milliSec = 0;
				int randomInt = 0;
				int maxNumber = 56;
				Set seedArraySet = new HashSet();
				StringBuffer combs = new StringBuffer();
				ArrayList numbers = new ArrayList();
				ArrayList genNumbers = new ArrayList();

				for (int i = 0; i < 56; i++) {
					numbers.add(i, i + 1);
				}
				hours = Calendar.getInstance().getTimeInMillis();
				String s1 = Long.toString(hours);
				String s = s1.substring(s1.length() - 4, s1.length());
				milliSec = Integer.parseInt(s);
				System.out.println("Numbers.java ------" + "milliSec "
						+ milliSec);
				for (int i = 0; i <= 999; i++) {
					if (milliSec % 2 == 0) {
						milliSec = milliSec + 3;
					} else {
						milliSec = milliSec - 5;
					}
					seedArraySet.add(milliSec);
				}
				ArrayList seedArrayArray = new ArrayList(seedArraySet);
				System.out.println("Numbers.java ------" + "seedArray size "
						+ seedArrayArray.size());
				SecureRandom shuffleSeed = new SecureRandom();
				for (int i = 0; i <= 999; i++) {
					int randNum = shuffleSeed.nextInt(999);
					swap(seedArrayArray, i, 999 - randNum);
				}
				SecureRandom indexOfSeed = new SecureRandom();
				int randomSeed = (Integer) seedArrayArray.get(indexOfSeed
						.nextInt(999));
				System.out.println("Numbers.java ------"
						+ "randomSeed out of list " + randomSeed);
				byte[] b = SecureRandom.getSeed(randomSeed > 0 ? randomSeed
						: -randomSeed);
				SecureRandom randomGenerator = SecureRandom
						.getInstance("SHA1PRNG");
				randomGenerator.setSeed(b);
				for (int idx = 1; idx <= 5; idx++) {
					randomInt = randomGenerator.nextInt(maxNumber);
					genNumbers.add(numbers.get(randomInt));
					popOutNumber(numbers, randomInt);
					--maxNumber;
				}
				Collections.sort(genNumbers);
				Combination cmb = new Combination();
				cmb.setA((Integer) genNumbers.get(0));
				cmb.setB((Integer) genNumbers.get(1));
				cmb.setC((Integer) genNumbers.get(2));
				cmb.setD((Integer) genNumbers.get(3));
				cmb.setE((Integer) genNumbers.get(4));
				cmb.setSum((Integer) genNumbers.get(0)
						+ (Integer) genNumbers.get(1)
						+ (Integer) genNumbers.get(2)
						+ (Integer) genNumbers.get(3)
						+ (Integer) genNumbers.get(4));
				cmbs.add(cmb);
				for (int sc = 0; sc < genNumbers.size(); sc++) {
					combs.append(genNumbers.get(sc));
					if (sc != 4)
						combs.append(",");
				}
				System.out.print("Numbers.java ------" + " combination "
						+ combs);
				System.out.println("Numbers.java ------" + "+"
						+ randomGenerator.nextInt(46));
				File f = new File("D:\\numbers\\meg.properties");
				Writer out = new OutputStreamWriter(new FileOutputStream(f,
						true));
				out.write(combs.toString());
				out.write("\r\n");
				out.flush();
			}
			// calculate running Delta
			runningDelta(mm);
			// calculate stdev
			stDev(runDelta);
			// calculate the next Good Sum
			Set<Entry<String, String>> se = mm.entrySet();
			Entry<String, String>[] te = new Entry[se.size()];
			se.toArray(te);
			String mmKey = te[0].getKey();
			String[] s = mmKey.split("\\,");
			int mmRecentCombSum = Integer.parseInt(s[0])
					+ Integer.parseInt(s[1]) + Integer.parseInt(s[2])
					+ Integer.parseInt(s[3]) + Integer.parseInt(s[4]);

			/*
			 * Set<Entry<String, String>> fe = mm.entrySet();
			 * Entry<String,String>[] ke = new Entry[fe.size()]; fe.toArray(te);
			 * String pbKey = ke[0].getKey(); String [] j = pbKey.split("\\,");
			 * int pbRecentCombSum = Integer.parseInt(j[0]) +
			 * Integer.parseInt(j[
			 * 1])+Integer.parseInt(j[2])+Integer.parseInt(j[3
			 * ])+Integer.parseInt(j[4]);
			 */
			if (runDelta.get(0) > 0) {
				newGoodSum = mmRecentCombSum - standeredDeviation;
				System.out.println("Numbers.java ------" + "newGoodSum sub "
						+ newGoodSum);
			} else {
				newGoodSum = mmRecentCombSum + standeredDeviation;
				System.out.println("Numbers.java ------" + "newGoodSum add "
						+ newGoodSum);
			}

		} catch (NoSuchAlgorithmException ex) {
			ex.printStackTrace();
		} catch (FileNotFoundException fx) {
			fx.printStackTrace();
		} catch (IOException ix) {
			ix.printStackTrace();
		}
	}

	boolean in5History(int[] comb, int h) {
		boolean out = false;
		int count = 0;
		// System.out.print("in History");

		for (int k = 0; k < comb.length; k++) {
			if (last5Occured.contains(comb[k])) {
				count++;
			}
		}
		if (count > 0 && count <= h)
			out = true;

		return out;

	}

	boolean checkSkipDetails(int[] comb) { // Make sure that atleast 2 numbers
											// in this combination have
											// skip values between 6-15.
											// And some other skip properties
											// are enforced
		boolean out = false;
		int countof1 = 0;
		int countof2 = 0;
		int countof3 = 0;
		int countof4 = 0;
		int countof5 = 0;
		int countBetween6And15 = 0;
		int hotSkipCount = 0;
		Set uniqueSkipBuckets = new HashSet();

		int countAbove15 = 0;
		// System.out.print("in History");

		if (skipFreqlast10 == null || skipFreqlast10.size() == 0) {

			for (int i = 1; i < 16; i++) {
				skipFreqlast10.put(i, 0);
				skipFreqlast5.put(i, 0);
				skipFreqInlast3.put(i, 0);
			}

			File m = new File(
					"C:\\Users\\johris\\git\\git\\Generator\\skipResults"
							+ gam);
			BufferedReader in;
			try {
				in = new BufferedReader(new FileReader(m));

				String line;
				int lineNum = 0;

				while ((line = in.readLine()) != null) {
					countBetween6And15 = 0;
					countAbove15 = 0;

					String[] key = line.split(" ");
					for (int i = 2; i < 7; i++) {

						if (Integer.parseInt(key[i].trim()) > 5
								&& Integer.parseInt(key[i].trim()) < 16) {
							countBetween6And15++;
						}

						if (Integer.parseInt(key[i].trim()) >= 16) {
							countAbove15++;
						}
						if (lineNum < 10) {
							if (Integer.parseInt(key[i].trim()) < 16) {
								int freq = skipFreqlast10.get(Integer
										.parseInt(key[i].trim()));
								skipFreqlast10.put(
										Integer.parseInt(key[i].trim()),
										freq + 1);
							}

							if (lineNum < 5
									&& Integer.parseInt(key[i].trim()) > 15) {
								countAbove15Last5 += 1;

							}

							if (lineNum < 5
									&& Integer.parseInt(key[i].trim()) < 16) {
								int freq = skipFreqlast5.get(Integer
										.parseInt(key[i].trim()));
								skipFreqlast5.put(
										Integer.parseInt(key[i].trim()),
										freq + 1);
							}

							if (lineNum < 3
									&& Integer.parseInt(key[i].trim()) < 16) {
								int freq = skipFreqInlast3.get(Integer
										.parseInt(key[i].trim()));
								skipFreqInlast3.put(
										Integer.parseInt(key[i].trim()),
										freq + 1);
							}
						}
						// System.out.println(key[2] + "-" + key[3] + "-" +
						// key[4] + "-"+ key[5] + "-" + key[6] );

						// System.out.println(key[2] + "-" + key[3] + "-" +
						// key[4] + "-"+ key[5] + "-" + key[6] );

					}

					if (skipBucketsLast7.size() < 10) {
						String skipBuckets = (5 - countAbove15 - countBetween6And15)
								+ " " + countBetween6And15 + " " + countAbove15;
						boolean inserted = skipBucketsLast7.add(skipBuckets);
						// System.out.println("Skip buckets " + skipBuckets +
						// ((inserted)?"":" Dup"));
					}
					lineNum++;

				}
			} catch (FileNotFoundException e) {
				System.out
						.println("Numbers.java --- checkSkipDetails --- ERROR - File "
								+ "C:\\Users\\johris\\git\\git\\Generator\\skipResults"
								+ gam + " DOES NOT EXIST.");
			} catch (IOException e) {
				System.out
						.println("Numbers.java --- checkSkipDetails --- ERROR - File "
								+ "C:\\Users\\johris\\git\\git\\Generator\\skipResults"
								+ gam + " READ ERROR.");
			}
		}

		int y = 0;
		if (hotSkipsListV2.size() == 0) {
			for (Iterator i = sortByValueAsc(skipFreqlast10).iterator(); i
					.hasNext();) {
				if (y > skipFreqlast10.size() - 1)
					break;

				Integer key = (Integer) i.next();

				if (skipFreqInlast3.get(key) < 1
						|| skipFreqlast10.get(key) <= 2) { // Upto 1 times in
															// last 3 or Upto 2
															// times in last 10
					hotSkipsListV2.add(key);
				}

				// System.out.printf("%s:(%s) ", key, skipFreqlast10.get(key));
				y++;
			}
			System.out.print("Numbers.java.checkSkipDetails ---- Hot skips v2 "
					+ hotSkipsListV2);
		}

		if (hotSkipsList.size() == 0) {
			// System.out.println("Numbers.java.checkSkipDetails ---- Last 3 skips "
			// + skipFreqNotInlast3);
			// System.out.println("Numbers.java.checkSkipDetails ---- Last 5 skips "
			// + skipFreqlast5);
			// System.out.println("Numbers.java.checkSkipDetails ---- Last 10 skips "
			// + skipFreqlast10);

			Set nums = skipFreqlast10.keySet();
			Iterator it = nums.iterator();
			while (it.hasNext()) {
				Integer skip = (Integer) it.next();
				int diff = skipFreqlast10.get(skip) - skipFreqlast5.get(skip);

				skipFreqlast10.put(skip, diff);

			}
			int x = 0;
			for (Iterator i = sortByValueAsc(skipFreqlast10).iterator(); i
					.hasNext();) {
				if (x > skipFreqlast10.size() - 1)
					break;
				Integer key = (Integer) i.next();

				if (x < 3 || x > skipFreqlast10.size() - 4) // Add first 3 and
															// last 3 skips from
															// the 10-5 table
					hotSkipsList.add(key);

				if (skipFreqInlast3.get(key) <= 1) { // Also add 0 and 1 time
														// appearances from last
														// 3 skips
					hotSkipsList.add(key);
				}

				// System.out.printf("%s:(%s) ", key, skipFreqlast10.get(key));
				x++;
			}

			System.out.println(" | Hot skips v1 " + hotSkipsList);
		}

		countBetween6And15 = 0;
		countAbove15 = 0;

		for (int k = 0; k < comb.length; k++) {
			if (skipHashCurrent.get(comb[k]) == 1)
				countof1++;
			if (skipHashCurrent.get(comb[k]) == 2)
				countof2++;
			if (skipHashCurrent.get(comb[k]) == 3)
				countof3++;
			if (skipHashCurrent.get(comb[k]) == 4)
				countof4++;
			if (skipHashCurrent.get(comb[k]) == 5)
				countof5++;

			if (skipHashCurrent.get(comb[k]) >= 6
					&& skipHashCurrent.get(comb[k]) <= 10) {
				countBetween6And15++;
			}
			if (skipHashCurrent.get(comb[k]) > 10) {
				countAbove15++;
			}

			if (hotSkipsListV2.contains(skipHashCurrent.get(comb[k])))
				hotSkipCount++;

		}
		if ((countof1 + countof2 + countof3 + countof4 + countof5
				+ countBetween6And15 >= 1)
				&& ((countAbove15Last5 > 9) ? countAbove15 < 1
						: countAbove15 >= 1) // Do not want skips above 10 if
												// there are more than 9 skips
												// above 15 in last 5
				&& hotSkipCount > 1)
			out = true;

		String skipBuckets = (5 - countAbove15 - countBetween6And15) + " "
				+ countBetween6And15 + " " + countAbove15;

		if (skipBucketsLast7.contains(skipBuckets)
				&& !skipBuckets.equals("1 2 2"))
			return false;

		if (skipBuckets.endsWith("4")) // Do not allow 4 skips more than 15
			return false;

		// if (skipBuckets.equals("1 2 2"))
		// System.out.println("122 skips found " + comb[0] + " "+ comb[1] + " "+
		// comb[2] + " "+ comb[3] + " "+ comb[4]);
		//
		return out;

	}

	boolean notIn25History(int[] comb, int l) {
		boolean out = false;
		int count = 0;
		// System.out.print("in History");

		for (int k = 0; k < comb.length; k++) {
			if (last25NotOccured.contains(comb[k])) {
				count++;
			}
		}
		if (count > 0 && count <= l)
			out = true;

		return out;

	}

	int testStringMatchInFile() {
		int b = 0;
		try {
			for (int i = 0; i < mmArray.length; i++) {
				BufferedReader r = new BufferedReader(new FileReader(new File(
						"D:\\numbers\\meg.properties")));
				String line = null;
				Pattern p = Pattern.compile(mmArray[i].getKey());

				while ((line = r.readLine()) != null) {
					Matcher m = p.matcher(line);
					if (m.find()) {
						b = b + 1;
						break;
					}
				}
			}
		} catch (FileNotFoundException fx) {
			fx.printStackTrace();
		} catch (IOException ix) {
			ix.printStackTrace();
		}
		return b;

	}

	int testAboveAveragematchInFile() {
		int b = 0;

		for (int i = 0; i < mmArray.length; i++) {
			String s = mmArray[i].getKey();
			String[] sa = s.split("\\,");

			boolean bo = aboveAverageFreq(new int[] { Integer.parseInt(sa[0]),
					Integer.parseInt(sa[1]), Integer.parseInt(sa[2]),
					Integer.parseInt(sa[3]), Integer.parseInt(sa[4]) });
			if (bo)
				b++;
		}
		System.out.println("Numbers.java ------" + b);

		return b;

	}

	static boolean last9CombsAverage(int[] comb, int avgSt, int avgEnd) {
		boolean b = false;
		String s = null;
		String[] sa = null;
		int sum0f9 = 0;
		int avergae = 0;
		int[] no2fromRecentOcc = new int[5];
		int count = 0;
		int numberAbove50Count = 0;

		if (last9SumAvg == 0) {
			for (int i = 0; i < 9; i++) {
				s = mmArray[i].getKey();
				sa = s.split("\\,");
				if (i == 0) {
					no2fromRecentOcc[0] = Integer.parseInt(sa[0]);
					no2fromRecentOcc[1] = Integer.parseInt(sa[1]);
					no2fromRecentOcc[2] = Integer.parseInt(sa[2]);
					no2fromRecentOcc[3] = Integer.parseInt(sa[3]);
					no2fromRecentOcc[4] = Integer.parseInt(sa[4]);
				}
				if (i < 5) {
					if (Integer.parseInt(sa[0]) > 50)
						numberAbove50Count++;
					if (Integer.parseInt(sa[1]) > 50)
						numberAbove50Count++;
					if (Integer.parseInt(sa[2]) > 50)
						numberAbove50Count++;
					if (Integer.parseInt(sa[3]) > 50)
						numberAbove50Count++;
					if (Integer.parseInt(sa[4]) > 50)
						numberAbove50Count++;
				}
				sum0f9 = sum0f9 + Integer.parseInt(sa[0])
						+ Integer.parseInt(sa[1]) + Integer.parseInt(sa[2])
						+ Integer.parseInt(sa[3]) + Integer.parseInt(sa[4]);
			}

			last9SumAvg = sum0f9 / 9;
			System.out.println("Numbers.java ------" + " Last 9 Sum Avg "
					+ last9SumAvg);

		} else {
			sum0f9 = last9SumAvg * 9;
		}

		sum0f9 = sum0f9 + comb[0] + comb[1] + comb[2] + comb[3] + comb[4];
		avergae = sum0f9 / 10;

		if (avergae >= avgSt && avergae <= avgEnd)
			b = true;

		/*for (int i = 0; i < no2fromRecentOcc.length; i++) {
			if (comb[0] == no2fromRecentOcc[i])
				count++;
			if (comb[1] == no2fromRecentOcc[i])
				count++;
			if (comb[2] == no2fromRecentOcc[i])
				count++;
			if (comb[3] == no2fromRecentOcc[i])
				count++;
			if (comb[4] == no2fromRecentOcc[i])
				count++;
		}

		if (b && count >= 2)
			b = false;

		if (b && numberAbove50Count >= 2) {
			int cnt = 0;
			for (int i = 0; i < comb.length; i++) {
				if (comb[i] > 50)
					cnt++;
			}
			if (cnt >= 2)
				b = false;
		}*/

		return b;
	}

	boolean combsAlreadyAppeared(int[] comb) {
		boolean b = true;
		String s = Integer.toString(comb[0]) + "," + comb[1] + "," + comb[2]
				+ "," + comb[3] + "," + comb[4];
		
		if (gam.equals("mm")) {
			if (mm.containsKey(s)) {
				return false;
			}
			
			
		} else {
			if (pb.containsKey(s)) {
				return false;
			}
				
		}
		
		// Check redux also  -- commenting 3/6/16 because sameredux method in Generator does the same check
		/*String reduxStr = "";
		for (int i=0; i< comb.length; i++) {
			reduxStr += getRedux(Integer.toString(comb[i]));
		}
		if (findStringInFile("reduxOutput" + gam, reduxStr) > 0)
			return false;
		*/
		// Check MultAndPrimes
		// if MultAndPrimes is 0---1, allow, otherwise it should not be in the last 10
		// TODO:
		

		/*
		 * for(int i=0; i<mmArray.length;i++){ int matches = 0; String key =
		 * mmArray[i].getKey(); String [] sa=key.split("\\,"); for (int k =0;
		 * k<comb.length;k++) { if (Integer.parseInt(sa[0]) == comb[k])
		 * matches++; if (Integer.parseInt(sa[1]) == comb[k]) matches++; if
		 * (Integer.parseInt(sa[2]) == comb[k]) matches++; if
		 * (Integer.parseInt(sa[3]) == comb[k]) matches++; if
		 * (Integer.parseInt(sa[4]) == comb[k]) matches++; } if (matches>=4) { b
		 * = false; break; }
		 * 
		 * }
		 */
		return b;
	}

	boolean calculateBuckets(int[] comb) {
		boolean b = false;
		boolean[] buckets = new boolean[6];
		int[] a = new int[6];
		int minBucket = 0;
		int numberOfBucketsPlay = 0;
		int combHasNoOfBucketsPlay = 0;
		// The below loop will calculate the minimum bucket appeared in real
		// data(10),the bucket never appeared in last 2 occurances and
		// bucket(50-60) never appeared in last 4 occurances
		for (int i = 0; i < 10; i++) {
			String s = mmArray[i].getKey();
			String[] sa = s.split("\\,");
			boolean flag1 = true;
			boolean flag2 = true;
			boolean flag3 = true;
			boolean flag4 = true;
			boolean flag5 = true;
			boolean flag6 = true;

			for (int k = 0; k < sa.length; k++) {
				int histvalue = Integer.parseInt(sa[k]);
				if (i < 4) {
					if (histvalue >= 50 && histvalue < 60 && flag6) {
						a[5]++;
						flag6 = false;
					}
				}
				if (histvalue > 0 && histvalue < 10 && flag1) {
					a[0]++;
					flag1 = false;
				}
				if (histvalue >= 10 && histvalue < 20 && flag2) {
					a[1]++;
					flag2 = false;
				}
				if (histvalue >= 20 && histvalue < 30 && flag3) {
					a[2]++;
					flag3 = false;
				}
				if (histvalue >= 30 && histvalue < 40 && flag4) {
					a[3]++;
					flag4 = false;
				}
				if (histvalue >= 40 && histvalue < 50 && flag5) {
					a[4]++;
					flag5 = false;
				}
			}
			if (i == 1) {
				if (a[0] == 0)
					buckets[0] = true;
				if (a[1] == 0)
					buckets[1] = true;
				if (a[2] == 0)
					buckets[2] = true;
				if (a[3] == 0)
					buckets[3] = true;
				if (a[4] == 0)
					buckets[4] = true;
			}
		}
		// Play the last bucket if never appeared in last 4 occurances
		if (a[5] == 0) {
			buckets[5] = true;
		}
		// Get the minimum Value of Bucket
		minBucket = a[0];
		for (int i = 0; i < a.length - 1; i++) {
			if (a[i] < minBucket)
				minBucket = a[i];
		}
		// Set the corresponding bucketFlag to True if minimum
		for (int i = 0; i < a.length; i++) {
			if (a[i] == minBucket)
				buckets[i] = true;
		}
		// Calculate the number of Buckets to play
		for (int i = 0; i < buckets.length; i++) {
			if (buckets[i])
				numberOfBucketsPlay++;
		}
		// Test the comb passes Buckets filter
		boolean flag6 = true;
		boolean flag7 = true;
		boolean flag8 = true;
		boolean flag9 = true;
		boolean flag10 = true;
		boolean flag11 = true;
		for (int j = 0; j < comb.length; j++) {
			if (buckets[0])
				if (comb[j] > 0 && comb[j] < 9 && flag6) {
					combHasNoOfBucketsPlay++;
					flag6 = false;
				}
			if (buckets[1])
				if (comb[j] >= 10 && comb[j] < 19 && flag7) {
					combHasNoOfBucketsPlay++;
					flag7 = false;
				}
			if (buckets[2])
				if (comb[j] >= 20 && comb[j] < 29 && flag8) {
					combHasNoOfBucketsPlay++;
					flag8 = false;
				}
			if (buckets[3])
				if (comb[j] >= 30 && comb[j] < 39 && flag9) {
					combHasNoOfBucketsPlay++;
					flag9 = false;
				}
			if (buckets[4])
				if (comb[j] >= 40 && comb[j] < 49 && flag10) {
					combHasNoOfBucketsPlay++;
					flag10 = false;
				}
			if (buckets[5])
				if (comb[j] >= 50 && comb[j] < 60 && flag11) {
					combHasNoOfBucketsPlay++;
					flag11 = false;
				}
		}

		if (combHasNoOfBucketsPlay >= numberOfBucketsPlay)
			b = true;

		return b;
	}

	static boolean exclusions(int[] comb) {
		boolean b = true;
		for (int i = 0; i < comb.length; i++) {
			if (numbersHash.get(comb[i]) >= 3) {
				b = false;
				break;
			}
			if (mustExclusionList != null) {
				for (int j = 0; j < mustExclusionList.length; j++)
					if (comb[i] == mustExclusionList[j]) {
						b = false;
						break;
					}
			}
			if (!b)
				break;
		}
		return b;
	}

	static boolean aboveAverageFreq(int[] comb) {// At least one freq above average and distance between min and max should be greater than 10 percent of
											// possible distance
		
		// Also see that at least 2 freqs are at least 2 away from all last freqs
		boolean b = false;
		int count = 0;
		int minFreq = 0; 
		int maxFreq = 0;
		
		int prevFreq = 0;
		int numsAtleast2Away = 0;
		
		for (int i = 0; i < comb.length; i++) {
			int thisFreq = freqHash.get(comb[i]);
			if (thisFreq >= freqAvg) count++;
			
			if (prevFreq == 0) {
				prevFreq = thisFreq;
				minFreq = thisFreq;
				maxFreq = thisFreq;
			} else {
				if (thisFreq > maxFreq) maxFreq = thisFreq;
				if (thisFreq < minFreq) minFreq = thisFreq;
			}
			
			Iterator it = lastResults.iterator();
			int prevminDistance = 0;
			while (it.hasNext()) {
				CurrentStateEntity ent = (CurrentStateEntity) it.next();
				int minDistance = Math.abs(thisFreq - Integer.parseInt(ent.getFrequency()));
				
				if (prevminDistance == 0) {
					prevminDistance = minDistance;
				} else {
					if (minDistance < prevminDistance) prevminDistance = minDistance;
				}
				
			}
			
			if (prevminDistance > 2) numsAtleast2Away++;
		}
		
		

		if (count >= 1 && (maxFreq-minFreq)>= (maxFreqForGame-minFreqForGame)/10 && numsAtleast2Away > 1)
			b = true;
		return b;
	}

	public static final void main(String... aArgs) {
		Numbers n = new Numbers(null);

		int b = 0;
		double starttime = System.currentTimeMillis();
		// n.randomNumbers();
		// b=n.testStringMatchInFile();
		/*
		 * for(int i=0;i<n.mmArray.length;i++){ String s =
		 * n.mmArray[i].getKey(); String [] sa=s.split("\\,"); int[] comb = new
		 * int[]{Integer.parseInt(sa[0]), Integer.parseInt(sa[1]),
		 * Integer.parseInt(sa[2]) , Integer.parseInt(sa[3]) ,
		 * Integer.parseInt(sa[4])}; boolean bo =
		 * Generator.properDistribution(comb, 2, 3); if(bo) b++; }
		 */
		// System.out.println(n.calculateBuckets(new int[]{31,32,24,40,50}));
		// n.testAboveAveragematchInFile();
		System.out.println("Numbers.java ------"
				+ n.exclusions(new int[] { 1, 2, 21, 51, 53 }));
		System.out.println("Numbers.java ------" + "Time taken "
				+ (System.currentTimeMillis() - starttime) + " ms");
		System.out
				.println("Numbers.java ------" + "Number of coms passed " + b);
	}

	boolean matchesFreqs(int[] comblocal) { // the passed combination has
											// freqs same as generated
											// by FreqFilter program
		boolean out = false;
		int[] freqArr = new int[comblocal.length];
		String freqKey = "";

		if (freqListFromFreqMap == null) {
			freqListFromFreqMap = new HashMap();
			File f = new File(
					"C:\\Users\\johris\\git\\git\\HelloWorld\\frqs.properties");
			BufferedReader inp;
			try {
				inp = new BufferedReader(new FileReader(f));

				String lin;
				while ((lin = inp.readLine()) != null) {
					String[] key = lin.split("\\;");
					// System.out.println(key[0] + " " + key[1]);
					for (int i = 0; i < key.length; i++) {
						freqListFromFreqMap.put(key[i], "");
					}
				}
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				System.out.println("Numbers.java ------"
						+ "Generated frqs.properties file does not exist...");
				System.out.println("Numbers.java ------" + "Run FreqFilter..");
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		if (freqListFromFreqMap.size() == 0)
			return out;
		else {
			for (int i = 0; i < comblocal.length; i++)
				freqArr[i] = freqHash.get(comblocal[i]);

			Arrays.sort(freqArr);
			for (int i = 0; i < freqArr.length; i++)
				freqKey += freqArr[freqArr.length - i - 1] + ",";

			if (freqListFromFreqMap.containsKey(freqKey))
				out = true;
		}

		return out;
	}

	int averageOfValues(HashMap in, int howMany) {
		int sum = 0;
		int count = 0;
		Iterator iterator = in.values().iterator();
		while (iterator.hasNext()) {
			if (count < howMany) {
				sum += Integer.parseInt((String) iterator.next());
				count++;
			} else
				break;
		}

		return sum / count;
	}

	public boolean directionOfFreqMovement(int[] comb) { // We do not want all
															// these freq to be
															// in the same
															// direction
															// compared
															// to lastFreqs
		boolean out = true;
		int countUp = 0;
		int countDown = 0;
		int countEqual = 0;

		StringTokenizer strtok = new StringTokenizer(currentResult, ",");
		for (int i = 0; i < 5; i++) {
			String num = strtok.nextToken();
			if (i < 4) {
				if (Integer.parseInt((String) freq.get(new Integer(num)))
						- comb[i] > 0) {
					countDown++;
				}
				if (Integer.parseInt((String) freq.get(new Integer(num)))
						- comb[i] == 0) {
					countEqual++;
				}
				if (Integer.parseInt((String) freq.get(new Integer(num)))
						- comb[i] < 0) {
					countUp++;
				}
			} else {
				String[] splitlast = num.split("\\+");
				if (Integer.parseInt((String) freq
						.get(new Integer(splitlast[0]))) - comb[i] > 0) {
					countDown++;
				}
				if (Integer.parseInt((String) freq
						.get(new Integer(splitlast[0]))) - comb[i] == 0) {
					countEqual++;
				}
				if (Integer.parseInt((String) freq
						.get(new Integer(splitlast[0]))) - comb[i] < 0) {
					countUp++;
				}

			}
		}

		if (countUp >= 4 || countDown >= 4)
			out = false;

		return out;
	}

	public static Integer[] getCurrentFreqList() {
		HashMap in = null;
		HashSet outset = new HashSet();
		Integer[] out = null;

		if (dataFor.equals("15")) {// Numbers and their frequencies
			System.out
					.println("Numbers.java.getCurrentFreqList ---- Loading Current Active 1--5 freq list.");
			in = freq;
		} else {
			System.out
					.println("Numbers.java.getCurrentFreqList ---- Loading last num [MB] freq list.");
			in = mbfreq;
		}

		Set nums = in.keySet();
		Iterator it = nums.iterator();
		while (it.hasNext()) {
			Integer str = (Integer) it.next();
			outset.add(in.get(str));
		}

		out = new Integer[outset.size()];

		Iterator it2 = outset.iterator();
		for (int i = 0; i < out.length; i++) {
			out[i] = Integer.parseInt((String) it2.next());
		}

		currentActiveFreqs = out;

		return out;
	}

	public boolean atLeastOneSharedFreq(int[] comb) { // We want at least one
														// freq that is shared
														// by more than one
														// numbers
		boolean out = false;
		int found = 0;

		for (int i = 0; i < comb.length; i++) {
			found = 0;
			Set se = freq.entrySet();
			Iterator it = se.iterator();

			while (it.hasNext()) {
				Entry en = (Entry) it.next();

				if (((String) en.getValue()).equals(Integer.toString(comb[i]))) {
					found++;
				}

				if (found > 1) {
					out = true;
					break;
				}

			}
		}

		return out;
	}

	public boolean performMAAnalysis(int[] comb) { // We look at the implied
													// move from average for all
													// the nums
													// and apply some filters,
													// we do not want all
													// movements in the same
													// direction as last move
													// We do not want all small
													// moves
		boolean out = true;
		int up = 0, down = 0;

		String freqTracker = prop.getProperty("FreqTracker");

		if (freqTracker == null || freqTracker.length() == 0)
			return true;

		String[] trackerArr = freqTracker.split(" "); // This is in reverse
														// order (movement of
														// lowest freq and so on
														// comb starts with
														// highest freq down

		// Highest freq 0
		if (comb[0] - freqAvg - Integer.parseInt(trackerArr[4]) > 0)
			up++;
		if (comb[0] - freqAvg - Integer.parseInt(trackerArr[4]) < 0)
			down++;

		// 1
		if (comb[1] - freqAvg - Integer.parseInt(trackerArr[3]) > 0)
			up++;
		if (comb[1] - freqAvg - Integer.parseInt(trackerArr[3]) < 0)
			down++;

		// 2
		if (comb[2] - freqAvg - Integer.parseInt(trackerArr[2]) > 0)
			up++;
		if (comb[2] - freqAvg - Integer.parseInt(trackerArr[2]) < 0)
			down++;

		// 3
		if (comb[3] - freqAvg - Integer.parseInt(trackerArr[1]) > 0)
			up++;
		if (comb[3] - freqAvg - Integer.parseInt(trackerArr[1]) < 0)
			down++;

		// 4
		if (comb[4] - freqAvg - Integer.parseInt(trackerArr[0]) > 0)
			up++;
		if (comb[4] - freqAvg - Integer.parseInt(trackerArr[0]) < 0)
			down++;

		if (up == 5 || down == 5)
			out = false;

		return out;
	}

	public static List sortByValueAsc(final Map m) {
		List keys = new ArrayList();
		keys.addAll(m.keySet());
		Collections.sort(keys, new Comparator() {
			public int compare(Object o1, Object o2) {
				Object v1 = m.get(o1);
				Object v2 = m.get(o2);
				if (v1 == null) {
					return (v2 == null) ? 0 : 1;
				} else if (v1 instanceof Comparable) {
					return ((Comparable) v1).compareTo(v2);
				} else {
					return 0;
				}
			}
		});
		return keys;
	}

	public static List sortByValueDes(final Map m) {
		List keys = new ArrayList();
		keys.addAll(m.keySet());
		Collections.sort(keys, new Comparator() {
			public int compare(Object o1, Object o2) {
				Object v1 = m.get(o1);
				Object v2 = m.get(o2);
				if (v1 == null) {
					return (v2 == null) ? 0 : 1;
				} else if (v2 instanceof Comparable) {
					return ((Comparable) v2).compareTo(v1);
				} else {
					return 0;
				}
			}
		});
		return keys;
	}

	public boolean uniqueBucketPatterns(int[] comblocal) {
		String bucketPatternString = "";
		for (int i = 0; i < comblocal.length; i++) {
			if (10 > comblocal[i] && comblocal[i] >= 0)
				bucketPatternString += "0";
			if (20 > comblocal[i] && comblocal[i] >= 10)
				bucketPatternString += "1";
			if (30 > comblocal[i] && comblocal[i] >= 20)
				bucketPatternString += "2";
			if (40 > comblocal[i] && comblocal[i] >= 30)
				bucketPatternString += "3";
			if (50 > comblocal[i] && comblocal[i] >= 40)
				bucketPatternString += "4";
			if (60 > comblocal[i] && comblocal[i] >= 50)
				bucketPatternString += "5";
			if (70 > comblocal[i] && comblocal[i] >= 60)
				bucketPatternString += "6";
			if (80 > comblocal[i] && comblocal[i] >= 70)
				bucketPatternString += "7";
		}

		if (bucketPatterns.contains(bucketPatternString))
			return false;
		else
			return true;
	}

	public static int getLinesCountFromFile(String sfile) { // returning the
															// number of lines
															// from
															// Input file so
															// that we can run
															// Numbers
															// one by one
		//LineNumberReader lineNumberReader = null;
		try (LineNumberReader lineNumberReader  = new LineNumberReader(new FileReader(sfile))) {
			/*File file = new File(sfile);
			lineNumberReader = new LineNumberReader(new FileReader(file));*/
			lineNumberReader.skip(Long.MAX_VALUE);
		
			if (lineNumberReader != null) {
				int lines = lineNumberReader.getLineNumber();
				lineNumberReader.close();
				return lines;
			}
			else {
				lineNumberReader.close();
				return -1;
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		
		return -1;
	}
	
	public static int getLastProcessedLineForType(String type) {
		String numAppearanceFileName = "C:\\Users\\johris\\git\\git\\Generator\\numAppearanceMap"
				+ type;

		File m = new File(numAppearanceFileName);
		BufferedReader in = null;
		
		int lastProcessedLine = -1;
		try {
			in = new BufferedReader(new FileReader(m));

			String line = in.readLine();
			if (line != null) {
				StringTokenizer strtok = new StringTokenizer(line, " ");
				lastProcessedLine = Integer.parseInt(strtok.nextToken());
			}

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			if (in != null) {
				try {
					in.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}

		return lastProcessedLine;

	}

	public static void addReduxToFile(String filename, String line, boolean b) {
		
		String out = "";
		String[] key = line.split("\\+");
		
		String[] firstFive = key[0].split(",");
		String firstFiveReduxed = "";
		
		for (int i=0;i<firstFive.length; i++) {
			String thisval = getRedux(firstFive[i]);
			firstFiveReduxed += thisval;
			out += thisval;
		}
		out += " + ";
	
		out += getRedux(key[1]) + " " + getRedux(firstFiveReduxed);
		
		if (findStringInFile(filename, out) < 0)
			addLineToFile(filename, out, b);
		
	}
	
	public static String getRedux(String num) { // Add the digits of the passed number
												 // 23 becomes 5
		String out = "-1";
		int inputNum = 0;
		try {
			inputNum = Integer.parseInt(num);
		} catch (Exception e) {
			System.out.println("Numbers.java: getRedux method called with bad input " +  num);
			return out;
		}
		
		while (inputNum >= 10) {
			inputNum = inputNum%10 + inputNum/10;
		}
		
		return Integer.toString(inputNum);
	}
	
	public HashMap<Integer, Integer> getSkipHashCurrent() {
		return skipHashCurrent;
	}

	public void setSkipHashCurrent(HashMap<Integer, Integer> skipHashCurrent) {
		this.skipHashCurrent = skipHashCurrent;
	}

	public static int[] getMustExclusionList() {
		return mustExclusionList;
	}

	public static void setMustExclusionList(int[] mustExclusionList) {
		Numbers.mustExclusionList = mustExclusionList;
	}
	public static boolean isLoaded() {
		return loaded;
	}

	public static void setLoaded(boolean loaded) {
		Numbers.loaded = loaded;
	}

}
