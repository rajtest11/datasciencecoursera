package com.num.generator.predic;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

import com.num.generator.Numbers;
import com.num.generator.dataaccess.GameTypesEntity;
import com.num.generator.dataaccess.ObservationsEntity;
import com.num.generator.dataaccess.ResultHistoryEntity;
import com.num.generator.dataaccess.ResultsWithinLastN;

public class CreateDBPredicFile {
	private static int blanks = 0;
	private static String inPrgCode = null;
	private static String inGameCode = "1"; // Mandatory 1 for MM, 2 for PB
	

	private static String nextDate = "1125"; // Mandatory format 0107
	
	private static int useSerial = 0;   // Use one draw and three draw earlier to create MM Predic (future 2 and 4)
	
	private static boolean suppressVerboseOut = false;
	private static int obsPeriod = 10;
	
	public static int getObsPeriod() {
		return obsPeriod;
	}

	public static void setObsPeriod(int obsPeriod) {
		CreateDBPredicFile.obsPeriod = obsPeriod;
	}

	public static boolean isSuppressVerboseOut() {
		return suppressVerboseOut;
	}

	public static void setSuppressVerboseOut(boolean suppressVerboseOut) {
		CreateDBPredicFile.suppressVerboseOut = suppressVerboseOut;
	}

	public static String getInPrgCode() {
		return inPrgCode;
	}

	public static void setInPrgCode(String inPrgCode) {
		CreateDBPredicFile.inPrgCode = inPrgCode;
	} 

	public static String getNextDate() {
		return nextDate;
	}

	public static void setNextDate(String nextDate) {
		CreateDBPredicFile.nextDate = nextDate;
	}

	public static int getUseSerial() {
		return useSerial;
	}

	public static void setUseSerial(int useSerial) {
		CreateDBPredicFile.useSerial = useSerial;
	}

	public static String getInGameCode() {
		return inGameCode;
	}

	public static void setInGameCode(String inGameCode) {
		CreateDBPredicFile.inGameCode = inGameCode;
	}
	
	public static void main(String[] arg) {
		long start = System.currentTimeMillis();
				
		ResultsWithinLastN lastN = new ResultsWithinLastN();
		
		
		if (getInPrgCode() == null) {
			GameTypesEntity gte = new GameTypesEntity();
			gte.setGameCode(inGameCode);
			
			Iterator itg = ( gte.findRows()).iterator();
			
			if (itg.hasNext()) {
				gte = (GameTypesEntity)itg.next();
				setInPrgCode(gte.getProgramCode());
			}
		}
		
		
		String filename = "C:\\eclipse\\workspace\\first\\Pred\\PredFor" + nextDate + "-" + getInPrgCode().toUpperCase();
		//String megafilename = "C:\\eclipse\\workspace\\first\\Pred\\MegaPredFor" + nextDate + "-" + getInPrgCode().toUpperCase();
		
		String indivfilename = "C:\\eclipse\\workspace\\first\\Pred\\IndivPredFor" + nextDate + "-" + getInPrgCode().toUpperCase();
		
		Numbers.removeLineFromFile(filename, "*");
		Numbers.removeLineFromFile(indivfilename, "*");
		
		
		int withinLast = 0;
		System.out.println( "CreateDBPredicFile.main: forDate " + nextDate + " gameCode " + inGameCode + " Using SerialNumber : " + useSerial);
		
		Numbers.addLineToFile(filename, " Used Serial Number : " + useSerial , false);
		Numbers.addLineToFile(indivfilename, " Used Serial Number : " + useSerial , false);
		Numbers.addLineToFile(filename,"MATCH3DIFFS=Y", false);
		Numbers.addLineToFile(filename,"MATCH3GAPS=Y", false);
		Numbers.addLineToFile(filename,"OBSINCLUDECOUNT=1", false);
		
		 ObservationsEntity obse = new  ObservationsEntity();
		String obslist = obse.getObservationsFromHistory(nextDate, getObsPeriod());
		Numbers.addLineToFile(filename,"OBSLIST=[" + obslist + "]", false);
		
		List l = lastN.getColumnNames();
		
		Iterator it = l.iterator();
		
		while (it.hasNext()) {
			String fieldName = (String) it.next();
			LastnBackTest.setInGameCode(inGameCode);
			
			withinLast = LastnBackTest.getWithinLastForField(fieldName, useSerial);
			
			if (fieldName.endsWith("Value"))
				withinLast = (withinLast>10)?withinLast:10;
			
			if (fieldName.endsWith("Redux"))
				withinLast = (withinLast>5)?withinLast:5;
			
			String paramLine = createDBPredicLine(fieldName, inGameCode, useSerial, withinLast);
			
			if ( !fieldName.endsWith("Prime") && !fieldName.endsWith("Follower") && !fieldName.endsWith("Bucket")) {
				ResultHistoryEntity rhe = new ResultHistoryEntity();
				String allEvenOrOdd = rhe.allOddOrEvenValuesInLastNDraws(fieldName, inGameCode, 5);
				
				// Adding a check so that this filter does not get added if all values
				// in paramLine are the opposite of the filter. e.g. [4,8]ODD does not make sense
				
				if (allEvenOrOdd != null) {
					int evenCount = 0;
					boolean isInconsitent = true;
					int startInd = paramLine.indexOf("[") + 1;
					if (startInd > 0) {
						String val = paramLine.substring(startInd,
								paramLine.indexOf("]"));

						String[] valA = val.split("\\,");
						List lis = (List) Arrays.asList(valA);

						for (int k = 0; k < valA.length; k++) {
							if (Integer.parseInt(valA[k]) % 2 == 0) evenCount++;
						}
						
						if (evenCount == 0 && allEvenOrOdd.equals("EVEN") ) isInconsitent =  false;
						
						if (evenCount == valA.length && allEvenOrOdd.equals("ODD") ) isInconsitent =  false;
						
						if (evenCount > 0  && evenCount < valA.length) isInconsitent =  false;
					}
					
					
					if (!isInconsitent) {
						if (allEvenOrOdd.equals("EVEN")) {
							paramLine += "ODD";
						} else {
							paramLine += "EVEN";
						}
					}
				}
			}
			
			if (!suppressVerboseOut) System.out.println(paramLine);
			
			if ((fieldName.toUpperCase().startsWith("FIRST") ||  fieldName.toUpperCase().startsWith("SECOND")  ||  fieldName.toUpperCase().startsWith("THIRD")
					 ||  fieldName.toUpperCase().startsWith("FOURTH")	 ||  fieldName.toUpperCase().startsWith("FIFTH") ||  fieldName.toUpperCase().startsWith("MEGA")	
					 )  
					&& !fieldName.toUpperCase().contains("SUM")) 
				Numbers.addLineToFile(indivfilename, paramLine, false);
			else
				Numbers.addLineToFile(filename, paramLine, false);
			
		}
		
		
		System.out.println("CreateDBPredicFile.main: " + filename + " created.");
		System.out.println("CreateDBPredicFile.main: " + indivfilename + " created.");
		
		if (!suppressVerboseOut) System.out.println("Time taken to produce DBPredicFile for gameCode " + inGameCode + " : " + (System.currentTimeMillis()-start)/1000 + " sec");
		
	}
	
	public static String createDBPredicLine(String fieldName, String gameCode, int serialNum, int withinLast) {
		
		String out = "";
		
			out += fieldName.toUpperCase() + "=";
			
			ResultsWithinLastN lastN = new ResultsWithinLastN();
			
			String possibleValues = lastN.getValuesForFieldBasedOnWithinLast(fieldName, gameCode, serialNum,withinLast);
			
			if (possibleValues.length() == 0) {
				blanks++;
				/*ResultHistoryEntity rhe = new ResultHistoryEntity();
				String allEvenOrOdd = rhe.allOddOrEvenValuesInLastNDraws(fieldName, inGameCode, 4);
				
				if (allEvenOrOdd != null) {
					if (allEvenOrOdd.equals("EVEN")) {
						out += "ODD";
					} else {
						out += "EVEN";
					}
				}*/
				
				return out;
			}
			
			List<String> list = new ArrayList<String>(Arrays.asList(possibleValues.split(",")));
			
			ResultHistoryEntity rhe = new ResultHistoryEntity();
			//String realValue = rhe.getValueForField(fieldName, gameCode, (serialNum >0)?serialNum+1:0);
			
			int lastNValueForField = lastN.getLastNValueFor(fieldName, gameCode, serialNum, withinLast);
			
			int predValueForLastN = lastN.predictLastNValueFor(fieldName, gameCode, serialNum, withinLast);
			//int predValueForLastN = lastN.predictLastNValueBasedOnLast2For(fieldName, gameCode, serialNum, withinLast);
			
			if (predValueForLastN >= 0) {
				
				if (predValueForLastN > 0) {
					out += "NOT";
				}
				
			} else {
				if (lastNValueForField == 0) {
					out += "NOT";
				} else {
					int maxLastNValueForField = lastN.getMaxLastNValueFor(fieldName, gameCode, serialNum, withinLast);
					
					if (lastNValueForField < maxLastNValueForField/2) {
						out += "NOT";
					} 
				}
			}
			
		out +=  list.toString() ;
		return out.replace(" ", "");
		
	}
}
