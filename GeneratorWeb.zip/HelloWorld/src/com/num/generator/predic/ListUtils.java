package com.num.generator.predic;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeMap;
import java.util.concurrent.ThreadLocalRandom;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import com.num.generator.Numbers;
import com.num.generator.dataaccess.ResultHistoryEntity;

public class ListUtils {

	private boolean testMode = true;
	private static int inputListSize = 0;
	public static final List<Integer> primes = new ArrayList<Integer>(
			Arrays.asList(2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43,
					47, 53, 59, 61, 67, 71, 73, 79, 83, 89, 97, 101, 103, 107,
					109, 113, 127, 131, 137, 139, 149, 151, 157, 163, 167, 173,
					179, 181, 191, 193, 197, 199, 211, 223, 227, 229, 233, 239,
					241, 251, 257, 263, 269, 271, 277, 281, 283, 293, 307, 311,
					313, 317, 331, 337, 347, 349, 353, 359, 367, 373, 379, 383,
					389, 397, 401, 409, 419, 421, 431, 433, 439, 443, 449, 457,
					461, 463, 467, 479, 487, 491, 499, 503, 509, 521, 523, 541,
					547, 557, 563, 569, 571, 577, 587, 593, 599, 601, 607, 613,
					617, 619, 631, 641, 643, 647, 653, 659, 661, 673, 677, 683,
					691, 701, 709, 719, 727, 733, 739, 743, 751, 757, 761, 769,
					773, 787, 797, 809, 811, 821, 823, 827, 829, 839, 853, 857,
					859, 863, 877, 881, 883, 887, 907, 911, 919, 929, 937, 941,
					947, 953, 967, 971, 977, 983, 991, 997));
	
	private static class RecursiveToStringStyle extends ToStringStyle {

	    /**
		 * 
		 */
		private static final long serialVersionUID = 1L;

		private static final int    INFINITE_DEPTH  = -1;

	    /**
	     * Setting {@link #maxDepth} to 0 will have the same effect as using original {@link #ToStringStyle}: it will
	     * print all 1st level values without traversing into them. Setting to 1 will traverse up to 2nd level and so
	     * on.
	     */
	    private int                 maxDepth;

	    private int                 depth;

	    public RecursiveToStringStyle() {
	        this(INFINITE_DEPTH);
	    }

	    public RecursiveToStringStyle(int maxDepth) {
	        setUseShortClassName(true);
	        setUseIdentityHashCode(false);

	        this.maxDepth = maxDepth;
	    }

	    @Override
	    protected void appendDetail(StringBuffer buffer, String fieldName, Object value) {
	        if (value.getClass().getName().startsWith("java.lang.")
	                    || (maxDepth != INFINITE_DEPTH && depth >= maxDepth)) {
	            buffer.append(value);
	        }
	        else {
	            depth++;
	            buffer.append(ReflectionToStringBuilder.toString(value, this));
	            depth--;
	        }
	    }

	    // another helpful method
	    @Override
	    protected void appendDetail(StringBuffer buffer, String fieldName, Collection<?> coll) {
	         depth++;
	         buffer.append(ReflectionToStringBuilder.toString(coll.toArray(), this, true, true));
	         depth--;
	    }
	}

	public static void main(String[] args) {
		ListUtils dbu = new ListUtils();
		int value = 18;
		String gameCode = "2";
		String attribute = "firstFiveSum";
		
		 analyzeRelations(gameCode);
		//analyzeBucketRemainderWaves(attribute, gameCode, 10, false);
		
		
	}
	
	private static void analyzeBucketRemainderWaves(String attribute, String gameCode, int stepsize, boolean cumulative) {
		
		ResultHistoryEntity rhe = new ResultHistoryEntity();
		rhe.setGameCode(gameCode);
		
		int lastserial = Integer.parseInt(rhe.getValueForField("serialNumber", gameCode, 0));
		
		for (int i=0; i<30; i++) {
			Hashtable<String, Integer> data = rhe.evenOddBucketRemainderInSelectedResults(attribute, gameCode, (lastserial - (i+1)*stepsize + 1), (lastserial - i*stepsize));
			String max = "";
			String min = "";
			
			for(String key: data.keySet()) {
				if (max.length() == 0) {
					max = key + ":" + data.get(key);
				} else {
					int lastmax = Integer.parseInt(max.split(":")[1]);
					if (data.get(key) > lastmax)
						max = key + ":" + data.get(key);
				}
				
				if (min.length() == 0) {
					min = key + ":" + data.get(key);
				} else {
					int lastmin = Integer.parseInt(max.split(":")[1]);
					if (data.get(key) < lastmin)
						min = key + ":" + data.get(key);
				}
			}
			System.out.println(min + " " + max);
		}

	}
	
	private static void analyzeRelations(String gameCode) {
		ResultHistoryEntity rhe = new ResultHistoryEntity();
		rhe.setGameCode(gameCode);

		int totalrec = 500;
		LinkedHashMap<Integer,ArrayList<Integer>>  valdata = rhe.getLastNForAttributes(Arrays.asList("dateOfDraw", "firstValue", "secondValue", "thirdValue", "fourthValue", "fifthValue"), totalrec, 0);
		
		for (Integer thiskey: valdata.keySet()) { /// Just print last few relations
			List<String> relations = getRelations(Integer.parseInt(Integer.toString(valdata.get(thiskey).get(0)).substring(6, 8)), valdata.get(thiskey).subList(1, valdata.get(thiskey).size()));
			if (Integer.toString(valdata.get(thiskey).get(0)).endsWith("11"))
				System.out.println(valdata.get(thiskey).get(0) + " " + relations);
		}
		
		
		for (int idate=1; idate<32; idate++) {
			
			int smalldate = 0;
			int zerorelations = 0;
			int onerelations = 0;
			int tworelations = 0;
			int threeplusrelations = 0;
			int threeplusdistance = 0;
			int distanceCounter = 0;
			
			for (ArrayList<Integer> thiscomb: valdata.values()) {
				//System.out.print(Integer.toString(thiscomb.get(0)).substring(6, 8) + "\t" + thiscomb.subList(1, thiscomb.size()) + "\t");
				/*if (Integer.parseInt(Integer.toString(thiscomb.get(0)).substring(6, 8)) > 3)
					System.out.println(relations);
				else
					System.out.println();*/
				
				
				int numrelations = 0;
				
				
				if (Integer.parseInt(Integer.toString(thiscomb.get(0)).substring(6, 8)) == idate) {
					List<String> relations = getRelations(Integer.parseInt(Integer.toString(thiscomb.get(0)).substring(6, 8)), thiscomb.subList(1, thiscomb.size()));
					for (String relation: relations) {
						if (relation.length() > 0)
							numrelations ++;
					}
					//System.out.println(idate + " " + relations);
					distanceCounter++;
					if (numrelations == 0)
						zerorelations ++;
					
					if (numrelations == 1)
						onerelations++;
					
					if (numrelations == 2)
						tworelations++;
					
					if (numrelations > 2) {
						if (threeplusdistance == 0)
							threeplusdistance = distanceCounter;
						threeplusrelations++;
					}
				} else {
					smalldate ++;
				}
			}
			
			/*System.out.println(smalldate*100/totalrec + " " + 
								zerorelations*100/totalrec + " " + 
								onerelations*100/totalrec + " " + 
								tworelations*100/totalrec + " " + 
								threeplusrelations*100/totalrec);*/
			
			if (threeplusrelations*100/(totalrec-smalldate) > 20)
			System.out.println(idate + " " + ((totalrec-smalldate) ) + " " + threeplusdistance + "\t\t " +
					zerorelations*100/(totalrec-smalldate) + " " + 
					onerelations*100/(totalrec-smalldate) + " " + 
					tworelations*100/(totalrec-smalldate) + " " + 
					threeplusrelations*100/(totalrec-smalldate));
		}
	}
	
	public static String prettyPrintList(List<?> list, int trimfieldheaderlength, int trimfieldvaluelength) {
		
		String out = "";
		Class listtype = list.get(0).getClass();
		List<Field> fld = getAllModelFields(listtype);
		for(java.lang.reflect.Field x : fld)
		{
			if((x.getModifiers() & java.lang.reflect.Modifier.FINAL) != java.lang.reflect.Modifier.FINAL)
			{
				if (trimfieldheaderlength > 0 && x.getName().length() > trimfieldheaderlength)
					out += x.getName().substring(0,trimfieldheaderlength) + "\t";
				else
					out += x.getName() + "\t";
			}
			
		}
		out += "\n";
		
		for (Object obj: list) {
			Class objtype = obj.getClass();
			List<Field> flds = getAllModelFields(objtype);
			for (Field field : flds) {
				if((field.getModifiers() & java.lang.reflect.Modifier.FINAL) != java.lang.reflect.Modifier.FINAL)
				{
			        try {
			            field.setAccessible(true);
			           String val =  (field.get(obj)!= null)?field.get(obj).toString():"";
			           if (trimfieldvaluelength > 0 && (val).length() > trimfieldvaluelength)
			        	   out += val.substring(0,trimfieldvaluelength) + "\t";
			           else
			        	   out += val + "\t";
		
			        } catch ( IllegalAccessException ex ) {
		//	                System.err.println(ex);
			        }
				}
		       
		    }
			out += "\n";
		}
		
		
		return out;
	}
	
	
	
	public static <T> List<List<T>> cartesianProduct(List<List<T>> lists) {
	    List<List<T>> resultLists = new ArrayList<List<T>>();
	    if (lists.size() == 0) {
	        resultLists.add(new ArrayList<T>());
	        return resultLists;
	    } else {
	        List<T> firstList = lists.get(0);
	        List<List<T>> remainingLists = cartesianProduct(lists.subList(1, lists.size()));
	        for (T condition : firstList) {
	            for (List<T> remainingList : remainingLists) {
	                ArrayList<T> resultList = new ArrayList<T>();
	                resultList.add(condition);
	                resultList.addAll(remainingList);
	                resultLists.add(resultList);
	            }
	        }
	    }
	    return resultLists;
	}
	
	private static List<Field> getAllModelFields(Class aClass) {
	    List<Field> fields = new ArrayList<>();
	    do {
	        Collections.addAll(fields, aClass.getDeclaredFields());
	        aClass = aClass.getSuperclass();
	    } while (aClass != null);
	    return fields;
	}

	public static List<Integer> testWhetherHotBasedOnList(
			ArrayList<Integer> data) {
		// TODO Auto-generated method stub

		/*
		 * List<Integer> movavg3list = getMovingAverages(data, 3);
		 * 
		 * System.out.println("3 MA" + movavg3list);
		 * 
		 * List<Integer> movavg5list = getMovingAverages(data, 5);
		 * 
		 * System.out.println("5 MA" + movavg5list);
		 * 
		 * List<Integer> movavg8list = getMovingAverages(data, 8);
		 * 
		 * System.out.println("8 MA" + movavg8list);
		 * 
		 * HashMap<Integer, List<Integer>> hotornotinput = new HashMap<Integer,
		 * List<Integer>>();
		 * 
		 * hotornotinput.put(3, movavg3list); hotornotinput.put(5, movavg5list);
		 */
		// hotornotinput.put(8, movavg8list);
		List<Integer> out = hotOrNotHistoryBasedOnMAs(prepareHotOrNotInputForList(data));
		int len = 0;

		if (out.size() > 0) {
			int firstVal = out.get(0);
			for (int val : out) {
				if (val == firstVal)
					len++;
				else
					break;
			}
		}

		// System.out.println("ListUtils:testWhetherHotBasedOnList: Hot or Not output: "
		// + out + " for " + len + " times.");

		return out;

	}

	public static List<Integer> getHotOrNotHistoryBasedOnDistanceList(
			ArrayList<Integer> data) {
		List<Integer> out = hotOrNotHistoryBasedOnMAs(prepareHotOrNotInputForList(data));

		return out;
	}

	public static int computeTurningPointBasedOnMAs(ArrayList<Integer> data) {
		int turn = 0;

		int hotornot = hotOrNotBasedOnMAs(prepareHotOrNotInputForList(data));

		// System.out.println("Hot or Not output: " + hotornot);

		if (hotornot == -1) { // this is COLD
			turn = data.get(0);

			/*
			 * if (turn < 10) return turn * (-1);
			 */
			while (turn >= 1) {
				data.add(0, turn);
				hotornot = hotOrNotBasedOnMAs(prepareHotOrNotInputForList(data));
				data.remove(0);

				if (hotornot == 1)
					return turn * (-1);

				turn -= 5;
			}

			return -1000;

		}

		if (hotornot == 1) {// this is hot
			/*
			 * turn = data.get(0);
			 * 
			 * if (turn > 200) return turn;
			 */
			turn = 1;

			while (turn < 200) {
				data.add(0, turn);
				hotornot = hotOrNotBasedOnMAs(prepareHotOrNotInputForList(data));
				data.remove(0);

				if (hotornot == -1)
					return turn;

				turn += 5;
			}

			// turning point not found
			return 1000;
		}

		return turn;
	}

	private static HashMap<Integer, List<Integer>> prepareHotOrNotInputForList(
			ArrayList<Integer> data) {
		List<Integer> movavg3list = getMovingAverages(data, 3);

		// System.out.println("3 MA" + movavg3list);

		List<Integer> movavg5list = getMovingAverages(data, 5);

		List<Integer> movavg8list = getMovingAverages(data, 8);
		
		List<Integer> movavg13list = getMovingAverages(data, 13);


		// System.out.println("8 MA" + movavg8list);

		HashMap<Integer, List<Integer>> hotornotinput = new HashMap<Integer, List<Integer>>();

		hotornotinput.put(3, movavg3list);
		// hotornotinput.put(5, movavg5list);
		hotornotinput.put(8, movavg8list);
		//hotornotinput.put(13, movavg8list);

		return hotornotinput;
	}

	public static int hotOrNotBasedOnMAs(HashMap<Integer, List<Integer>> matrix) {// Map
																					// of
																					// distance
																					// MAs
																					// keyed
																					// by
																					// length
																					// 3
																					// :[10,12,8,45,21...]
																					// 5
																					// :[6,25,29,32...]

		int out = -100;
		// List<String> horizontalVals = new ArrayList<String>();
		List<String> verticalVals = new ArrayList<String>();

		Integer[] keyarr = new Integer[matrix.size()];

		matrix.keySet().toArray(keyarr);
		List<Integer> b = Arrays.asList(keyarr);

		int maxMAPeriod = Collections.max(b);
		int minMAPeriod = Collections.min(b);

		Collections.sort(b);

		int counter = 0;
		for (int key : b) {
			// horizontalVals.addAll(matrix.get(key))

			if (matrix.get(key).size() <= 0) {
				System.out
						.println("ListUtils.hotOrNotBasedOnMAs: Not sufficient records to compute MA trends" + matrix.get(key));
				return out;
			}

			for (int x = 0; x < matrix.get(key).size(); x++) {
				if (verticalVals.size() < x + 1) {
					verticalVals.add(x,
							Integer.toString(matrix.get(key).get(x)));
				} else {
					verticalVals.set(
							x,
							verticalVals.get(x) + ","
									+ Integer.toString(matrix.get(key).get(x)));
				}
			}

			counter++;
		}

		if (isSequence(verticalVals.get(0), matrix.size()) > 0)
			out = -1;
		else if (isSequence(verticalVals.get(0), matrix.size()) < 0)
			out = 1;
		else if (isSequence(verticalVals.get(0), matrix.size()) == 0)
			out = 0;

		return out;
	}

	public static ArrayList<Integer> hotOrNotHistoryBasedOnMAs(
			HashMap<Integer, List<Integer>> matrix) {// Map
		// of
		// distance
		// MAs
		// keyed
		// by
		// length
		// 3 :[10,12,8,45,21...]
		// 5 :[6,25,29,32...]

		ArrayList<Integer> out = new ArrayList<Integer>();
		// List<String> horizontalVals = new ArrayList<String>();
		List<String> verticalVals = new ArrayList<String>();

		Integer[] keyarr = new Integer[matrix.size()];

		matrix.keySet().toArray(keyarr);
		List<Integer> b = Arrays.asList(keyarr);

		int maxMAPeriod = Collections.max(b);
		int minMAPeriod = Collections.min(b);

		Collections.sort(b);

		int verticalValEffectiveLength = 0;
		for (int key : b) {
			// horizontalVals.addAll(matrix.get(key))
			if (verticalValEffectiveLength == 0)
				verticalValEffectiveLength = matrix.get(key).size();
			else {
				if (matrix.get(key).size() < verticalValEffectiveLength)
					verticalValEffectiveLength = matrix.get(key).size();
			}

			if (matrix.get(key).size() <= 0) {
				System.out
						.println("ListUtils.hotOrNotBasedOnMAs: Not sufficient records to compute MA trends" + matrix.get(key));
				return out;
			}

			for (int x = 0; x < matrix.get(key).size(); x++) {
				if (verticalVals.size() < x + 1) {
					verticalVals.add(x,
							Integer.toString(matrix.get(key).get(x)));
				} else {
					verticalVals.set(
							x,
							verticalVals.get(x) + ","
									+ Integer.toString(matrix.get(key).get(x)));
				}
			}

		}

		verticalVals = verticalVals.subList(0, verticalValEffectiveLength);

		for (String thisval : verticalVals) {
			if (isSequence(thisval, matrix.size()) > 0)
				out.add(-1);
			else if (isSequence(thisval, matrix.size()) < 0)
				out.add(1);
			else if (isSequence(thisval, matrix.size()) == 0)
				out.add(0);
		}

		return out;
	}

	public static List<Integer> getMovingAverages(List<Integer> data, int i) {
		List<Integer> out = new ArrayList<Integer>();
		int counter = 0;
		for (int val : data) {
			if (counter < data.size() - i) {
				int sumofvals = 0;

				for (int c = counter; c < counter + i; c++) {
					sumofvals += data.get(c);
				}

				out.add(sumofvals / i);

			}
			counter++;
		}
		return out;
	}

	public static String testValueAgainstPredictionForList(int value,
			ArrayList<Integer> data) {
		String out = "NO";
		int score = 0;
		int algoCount = 2;

		ArrayList<Integer> predictionBasedOnSeq = null;
		ArrayList<Integer> predictionBasedOnEvenOdd = null;

		if (data.size() > 10) {
			predictionBasedOnSeq = predictSequenceForList(data);
			predictionBasedOnEvenOdd = predictEvenOddForList(data);
		}

		if (predictionBasedOnSeq != null) {
			if (predictionBasedOnSeq.get(0) > 0
					&& value >= predictionBasedOnSeq.get(0))
				score += 100 / algoCount;

			if (predictionBasedOnSeq.get(0) < 0
					&& value < predictionBasedOnSeq.get(0))
				score += 100 / algoCount;
		}

		if (predictionBasedOnEvenOdd != null) {
			if (predictionBasedOnEvenOdd.get(0) > 0 && value % 2 == 0)
				score += 100 / algoCount;

			if (predictionBasedOnEvenOdd.get(0) < 0 && value % 2 == 1)
				score += 100 / algoCount;
		}

		if (score > 0)
			out = "MAYBE";

		if (score > 90)
			out = "YES";

		// System.out.println(out + " " + score);
		return out;
	}

	public static ArrayList<Integer> predictEvenOddForList(
			ArrayList<Integer> values) {

		inputListSize = values.size();
		ArrayList<Integer> inarg = new ArrayList<Integer>();
		ArrayList<String> failures = new ArrayList<String>();
		ArrayList<String> successes = new ArrayList<String>();
		int lastserial = 0;
		int passed = 0;
		int samplesize = values.size();
		int printsize = 10;

		int latestsuccessserial = 0;// (successes.size() >
									// 0)?Integer.parseInt(successes.get(0).substring(0,
									// successes.get(0).indexOf("-"))):0;
		int latestfailureserial = 0;// (failures.size() >
									// 0)?Integer.parseInt(failures.get(0).substring(0,
									// failures.get(0).indexOf("-"))):0;

		int seqlargerthantwo = 0;

		try {

			for (int i = 0; i < samplesize - 8; i++) {
				Hashtable<Integer, ArrayList<Integer>> seqmap = null;
				String value = Integer.toString(values.get(i));

				ArrayList<Integer> sublist = new ArrayList(values.subList(
						i + 1, values.size()));
				int seqlen = getCurrentEvenOddLengthForList(sublist);

				String scurrval = Integer.toString(values.get(i));
				;
				String sprevval = Integer.toString(values.get(i + 1));
				;
				int currentValueForAttrib = Integer
						.parseInt((scurrval == null) ? "0" : scurrval);
				int prevValueForAttrib = Integer
						.parseInt((sprevval == null) ? "0" : sprevval);

				if (Math.abs(seqlen) > 2) {
					seqlargerthantwo++;
					// System.out.print(i);
					seqmap = findAllEvenOddsInList(sublist, Math.abs(seqlen));
					// System.out.println();

					int useSkip = 0;
					if (seqlen > 0) {
						if (seqmap.get(Math.abs(seqlen) + 1) != null)
							useSkip = seqmap.get(Math.abs(seqlen) + 1).get(2);
					} else {
						if (seqmap.get(Math.abs(seqlen) + 1) != null)
							useSkip = seqmap.get(Math.abs(seqlen) + 1).get(3);
					}

					// If higher sequence is overdue, target move in the same
					// direction otherwise reverse
					boolean contSameDirection = false;

					if (seqmap.get(Math.abs(seqlen) + 1) != null
							&& useSkip > seqmap.get(Math.abs(seqlen) + 1)
									.get(4))
						contSameDirection = true;

					// if (seqlen > 0) { // EVEN values

					if (contSameDirection) {
						if (currentValueForAttrib % 2 == prevValueForAttrib % 2) {
							passed++;
							if (successes.size() < printsize)
								successes.add((lastserial - i) + "-"
										+ prevValueForAttrib);
							if (latestsuccessserial == 0)
								latestsuccessserial = seqlargerthantwo;

						} else {
							if (failures.size() < printsize)
								failures.add((lastserial - i) + "-"
										+ prevValueForAttrib);

							if (latestfailureserial == 0)
								latestfailureserial = seqlargerthantwo;
						}
					} else {
						if (currentValueForAttrib % 2 != prevValueForAttrib % 2) {
							passed++;
							if (successes.size() < printsize)
								successes.add((lastserial - i) + "-"
										+ prevValueForAttrib);

							if (latestsuccessserial == 0)
								latestsuccessserial = seqlargerthantwo;
						} else {
							if (failures.size() < printsize)
								failures.add((lastserial - i) + "-"
										+ prevValueForAttrib);

							if (latestfailureserial == 0)
								latestfailureserial = seqlargerthantwo;
						}
					}

					// }

				}

				if (i == 0) {
					// System.out.println("Exclusions : " + + list.size() +"[" +
					// excl + "] next value: " + value + " --- " + ((list.size()
					// > 0 &&
					// !list.contains(Integer.parseInt(value)))?" passed ":" failed "));
				}

			}

			int currseqlen = getCurrentEvenOddLengthForList(values);
			Hashtable<Integer, ArrayList<Integer>> currseqmap = findAllEvenOddsInList(
					values, Math.abs(currseqlen));
			// System.out.println(currseqmap);

			int useSkip = 0;
			if (currseqlen > 0) {
				if (currseqmap.get(Math.abs(currseqlen) + 1) != null)
					useSkip = currseqmap.get(Math.abs(currseqlen) + 1).get(2);
			} else {
				if (currseqmap.get(Math.abs(currseqlen) + 1) != null)
					useSkip = currseqmap.get(Math.abs(currseqlen) + 1).get(3);
			}

			// If higher sequence is overdue, target move in the same direction
			// otherwise reverse
			boolean contSameDirection = false;

			if (currseqmap.get(Math.abs(currseqlen) + 1) != null) {
				if (useSkip > currseqmap.get(Math.abs(currseqlen) + 1).get(4))
					contSameDirection = true;
			}

			int lastVal = values.get(0);

			if (currseqlen > 0) {
				if (!contSameDirection)
					lastVal = 0 - lastVal;
			} else {
				if (contSameDirection)
					lastVal = 0 - lastVal;
			}

			int percent = 0;

			if (seqlargerthantwo == 0)
				seqlargerthantwo = 1;

			if (Math.abs(currseqlen) > 2) {

				if (latestfailureserial > 1
						&& (latestfailureserial - 1)
								* (100 - (passed * 100 / seqlargerthantwo)) > 100) {
					// ince.setPercent(Integer.toString((100-(passed*100/seqlargerthantwo))));
					// ince.setTotalScore(Integer.toString((latestfailureserial-1)
					// * (100-(passed*100/seqlargerthantwo))));

					percent = (latestfailureserial - 1)
							* (100 - (passed * 100 / seqlargerthantwo));

					lastVal = 0 - lastVal;
					contSameDirection = !contSameDirection;
				}

				if (latestsuccessserial > 1
						&& (latestsuccessserial - 1)
								* (passed * 100 / seqlargerthantwo) > 100) {
					percent = (latestsuccessserial - 1)
							* (passed * 100 / seqlargerthantwo);
					// ince.setPercent(Integer.toString((passed*100/seqlargerthantwo)));
					// ince.setTotalScore(Integer.toString((latestsuccessserial-1)
					// * (passed*100/seqlargerthantwo)));
				}
			}

			if (contSameDirection) {
				// ince.setIsInclusionInd("true");

			} else {
				// ince.setIsInclusionInd("false");
			}

			if (lastVal > 0)
				inarg.add(1 * Math.abs(currseqlen));
			else
				inarg.add(-1 * Math.abs(currseqlen));

			// ince.setData(inarg);
			inarg.add(passed * 100 / seqlargerthantwo);
			inarg.add(percent);

			// System.out.println("EvenOdd Length " + " " + inarg);
		} catch (Exception e) {
			System.out
					.println("ListUtils.predictEvenOddForList: Exception while processing ");
		}

		return inarg;
	}

	public static ArrayList<Integer> predictSequenceForList(
			ArrayList<Integer> values) {

		inputListSize = values.size();
		ArrayList<Integer> inarg = new ArrayList();
		ArrayList<String> failures = new ArrayList<String>();
		ArrayList<String> successes = new ArrayList<String>();
		int lastserial = 0;
		int passed = 0;
		int samplesize = values.size();
		int printsize = 10;

		int latestsuccessserial = 0;// (successes.size() >
									// 0)?Integer.parseInt(successes.get(0).substring(0,
									// successes.get(0).indexOf("-"))):0;
		int latestfailureserial = 0;// (failures.size() >
									// 0)?Integer.parseInt(failures.get(0).substring(0,
									// failures.get(0).indexOf("-"))):0;

		int seqlargerthantwo = 0;

		try {

			for (int i = 0; i < samplesize - 9; i++) {
				Hashtable<Integer, ArrayList<Integer>> seqmap = null;
				String value = Integer.toString(values.get(i));

				ArrayList<Integer> sublist = new ArrayList(values.subList(
						i + 1, values.size()));

				int seqlen = getCurrentSequenceLengthForList(sublist);

				String scurrval = Integer.toString(values.get(i));
				;
				String sprevval = Integer.toString(values.get(i + 1));
				;
				int currentValueForAttrib = Integer
						.parseInt((scurrval == null) ? "0" : scurrval);
				int prevValueForAttrib = Integer
						.parseInt((sprevval == null) ? "0" : sprevval);

				if (Math.abs(seqlen) > 2) {
					seqlargerthantwo++;
					// System.out.print(i);
					seqmap = findAllSequencesInList(sublist, Math.abs(seqlen));
					// System.out.println();

					int useSkip = 0;
					if (seqlen > 0) {
						if (seqmap.get(Math.abs(seqlen) + 1) != null)
							useSkip = seqmap.get(Math.abs(seqlen) + 1).get(2);
					} else {
						if (seqmap.get(Math.abs(seqlen) + 1) != null)
							useSkip = seqmap.get(Math.abs(seqlen) + 1).get(3);
					}

					// If higher sequence is overdue, target move in the same
					// direction otherwise reverse
					boolean contSameDirection = false;

					if (seqmap.get(Math.abs(seqlen) + 1) != null
							&& useSkip > seqmap.get(Math.abs(seqlen) + 1)
									.get(4))
						contSameDirection = true;

					if (seqlen > 0) { // increasing values

						if (contSameDirection) {
							if (currentValueForAttrib > prevValueForAttrib) {
								passed++;
								if (successes.size() < printsize)
									successes.add((lastserial - i) + "-"
											+ prevValueForAttrib);
								if (latestsuccessserial == 0)
									latestsuccessserial = seqlargerthantwo;

							} else {
								if (failures.size() < printsize)
									failures.add((lastserial - i) + "-"
											+ prevValueForAttrib);

								if (latestfailureserial == 0)
									latestfailureserial = seqlargerthantwo;
							}
						} else {
							if (currentValueForAttrib < prevValueForAttrib) {
								passed++;
								if (successes.size() < printsize)
									successes.add((lastserial - i) + "-"
											+ prevValueForAttrib);

								if (latestsuccessserial == 0)
									latestsuccessserial = seqlargerthantwo;
							} else {
								if (failures.size() < printsize)
									failures.add((lastserial - i) + "-"
											+ prevValueForAttrib);

								if (latestfailureserial == 0)
									latestfailureserial = seqlargerthantwo;
							}
						}

					} else {

						if (contSameDirection) {
							if (currentValueForAttrib < prevValueForAttrib) {
								passed++;
								if (successes.size() < printsize)
									successes.add((lastserial - i) + "-"
											+ prevValueForAttrib);

								if (latestsuccessserial == 0)
									latestsuccessserial = seqlargerthantwo;
							} else {
								if (failures.size() < printsize)
									failures.add((lastserial - i) + "-"
											+ prevValueForAttrib);

								if (latestfailureserial == 0)
									latestfailureserial = seqlargerthantwo;
							}
						} else {
							if (currentValueForAttrib > prevValueForAttrib) {
								passed++;
								if (successes.size() < printsize)
									successes.add((lastserial - i) + "-"
											+ prevValueForAttrib);

								if (latestsuccessserial == 0)
									latestsuccessserial = seqlargerthantwo;
							} else {
								if (failures.size() < printsize)
									failures.add((lastserial - i) + "-"
											+ prevValueForAttrib);

								if (latestfailureserial == 0)
									latestfailureserial = seqlargerthantwo;
							}
						}

					}

				}

				if (i == 0) {
					// System.out.println("Exclusions : " + + list.size() +"[" +
					// excl + "] next value: " + value + " --- " + ((list.size()
					// > 0 &&
					// !list.contains(Integer.parseInt(value)))?" passed ":" failed "));
				}

			}

			int currseqlen = getCurrentSequenceLengthForList(values);
			Hashtable<Integer, ArrayList<Integer>> currseqmap = findAllSequencesInList(
					values, Math.abs(currseqlen));
			// System.out.println(currseqmap);

			int useSkip = 0;
			if (currseqlen > 0) {
				if (currseqmap.get(Math.abs(currseqlen) + 1) != null)
					useSkip = currseqmap.get(Math.abs(currseqlen) + 1).get(2);
			} else {
				if (currseqmap.get(Math.abs(currseqlen) + 1) != null)
					useSkip = currseqmap.get(Math.abs(currseqlen) + 1).get(3);
			}

			// If higher sequence is overdue, target move in the same direction
			// otherwise reverse
			boolean contSameDirection = false;

			if (currseqmap.get(Math.abs(currseqlen) + 1) != null) {
				if (useSkip > currseqmap.get(Math.abs(currseqlen) + 1).get(4))
					contSameDirection = true;
			}

			int lastVal = values.get(0);

			if (currseqlen > 0) {
				if (!contSameDirection)
					lastVal = 0 - lastVal;
			} else {
				if (contSameDirection)
					lastVal = 0 - lastVal;
			}

			int percent = 0;

			if (seqlargerthantwo == 0)
				seqlargerthantwo = 1;

			if (Math.abs(currseqlen) > 2) {

				if (latestfailureserial > 1
						&& (latestfailureserial - 1)
								* (100 - (passed * 100 / seqlargerthantwo)) > 100) {
					/*
					 * ince.setPercent(Integer.toString((100-(passed*100/
					 * seqlargerthantwo))));
					 * ince.setTotalScore(Integer.toString(
					 * (latestfailureserial-1) *
					 * (100-(passed*100/seqlargerthantwo))));
					 */

					percent = (latestfailureserial - 1)
							* (100 - (passed * 100 / seqlargerthantwo));
					lastVal = 0 - lastVal;
					contSameDirection = !contSameDirection;
				}

				if (latestsuccessserial > 1
						&& (latestsuccessserial - 1)
								* (passed * 100 / seqlargerthantwo) > 100) {
					percent = (latestsuccessserial - 1)
							* (passed * 100 / seqlargerthantwo);
					/*
					 * ince.setPercent(Integer.toString((passed*100/seqlargerthantwo
					 * )));
					 * ince.setTotalScore(Integer.toString((latestsuccessserial
					 * -1) * (passed*100/seqlargerthantwo)));
					 */
				}
			}

			if (contSameDirection) {
				// ince.setIsInclusionInd("true");

			} else {
				// ince.setIsInclusionInd("false");
			}

			inarg.add(lastVal);
			// ince.setData(inarg);

			inarg.add(passed * 100 / seqlargerthantwo);
			inarg.add(percent);

			// System.out.println("Sequence length " + inarg);
		} catch (Exception e) {
			System.out
					.println("DBUTils.predictSequenceForList: Exception while processing ");
			e.printStackTrace();
		}

		return inarg;

	}

	private static int getCurrentEvenOddLengthForList(ArrayList<Integer> vals) {

		int totalProcessed = 0;

		int startSequencelength = 2;
		int currentMaxLen = 0;
		// System.out.print("Processing seq length ");
		for (int i = startSequencelength; i < 9; i++) {
			// System.out.print("  " + i);

			int isSeq = isAllEvenOrOdd(
					listToCommaSepString(vals.subList(0, i)), i);
			if (isSeq != 0) { // sequence of length i found

				if (isSeq == 1) {
					currentMaxLen = i;
				}

				if (isSeq == 2) {
					currentMaxLen = 0 - i;
				}

			} else {
				break;
			}

		}

		// System.out.println();
		// System.out.println("Current seq length for gameCode " + gameCode +
		// " attribute " + attribute + " ---- " + currentMaxLen);

		return currentMaxLen;
	}

	private static int getCurrentSequenceLengthForList(ArrayList<Integer> vals) {

		int totalProcessed = 0;

		int startSequencelength = 2;
		int currentMaxLen = 0;
		// System.out.print("Processing seq length ");
		for (int i = startSequencelength; i < 9; i++) {
			// System.out.print("  " + i);

			int isSeq = isSequence(listToCommaSepString(vals.subList(0, i)), i);
			if (isSeq != 0) { // sequence of length i found

				if (isSeq == 1) {
					currentMaxLen = isSeq * i;
				}

				if (isSeq == -1) {
					currentMaxLen = isSeq * i;
				}

			} else {
				break;
			}

		}

		// System.out.println();
		// System.out.println("Current seq length for gameCode " + gameCode +
		// " attribute " + attribute + " ---- " + currentMaxLen);

		return currentMaxLen;
	}

	private static Hashtable<Integer, ArrayList<Integer>> findAllEvenOddsInList(
			ArrayList<Integer> list, int seqLength) { // prints even and odd
														// sequence counts for
														// attribute
		// Sequence Length - Odd - Even - Odd Skip - Even Skip - Ratio
		int latestSerial = list.size();

		// System.out.println("Even Odd Sequence data for gameCode " + gameCode
		// + " attribute " + attribute );
		LinkedHashMap<Integer, ArrayList<Integer>> serialData = new LinkedHashMap<Integer, ArrayList<Integer>>();
		Hashtable<Integer, ArrayList<Integer>> sequenceHash = new Hashtable<Integer, ArrayList<Integer>>();

		int maxSerial = inputListSize;

		int startSequencelength = 2;
		int endSequenceLength = 8;

		if (seqLength > 0) {
			startSequencelength = seqLength;
			// endSequenceLength = seqLength+1;
		}

		int depth = list.size() - 1;

		// System.out.print("Processing seq length ");
		for (int j = 0; j < depth - endSequenceLength; j++) {
			// System.out.println("Processing index " + j);
			String maxVals = listToCommaSepString(list.subList(j, j
					+ endSequenceLength));
			// String maxVals = rhe.getLastNForSequenceFromCache(attribute,
			// endSequenceLength, j);
			// System.out.print("  " + i);
			for (int i = startSequencelength; i < endSequenceLength; i++) {

				// System.out.print("  " + i + " " + j);
				int isSeq = isAllEvenOrOdd(maxVals, i);
				if (isSeq != 0) { // sequence of evens of odds found

					if (isSeq == 1) {
						if (serialData.get(j) != null) {
							serialData.get(j).add(i);
						} else {
							ArrayList<Integer> al = new ArrayList<Integer>();
							al.add(i);
							serialData.put(j, al);
						}
					}

					if (isSeq == 2) {
						if (serialData.get(j) != null) {
							serialData.get(j).add(0 - i);
						} else {
							ArrayList<Integer> al = new ArrayList<Integer>();
							al.add(0 - i);
							serialData.put(j, al);
						}
					}

					// j +=i-1;
					// continue;
				}
			}

		}
		// System.out.println();

		// Clear all sequences which are counted twice
		ArrayList<Integer> removedata = new ArrayList<Integer>();

		for (Entry<Integer, ArrayList<Integer>> ent : serialData.entrySet()) {
			// System.out.println(ent.getKey() + "/" + ent.getValue());
			if (ent.getValue().size() > 0) {
				for (int r = 0; r < ent.getValue().size() - 1; r++) {
					removedata.add(ent.getKey() + r + 1);
				}
			}
		}

		serialData.keySet().removeAll(removedata);

		for (int j = 0; j < depth - endSequenceLength; j++) {
			if (serialData.get(j) != null) {
				int longestSeq = serialData.get(j).get(
						serialData.get(j).size() - 1);

				if (sequenceHash.get(Math.abs(longestSeq)) != null) {
					if (longestSeq < 0) {
						sequenceHash.get(Math.abs(longestSeq))
								.set(0,
										sequenceHash.get(Math.abs(longestSeq))
												.get(0) + 1);

						if (sequenceHash.get(Math.abs(longestSeq)).get(2) == 0)
							sequenceHash.get(Math.abs(longestSeq)).set(2,
									latestSerial - j);
					}

					if (longestSeq > 0) {
						sequenceHash.get(Math.abs(longestSeq))
								.set(1,
										sequenceHash.get(Math.abs(longestSeq))
												.get(1) + 1);

						if (sequenceHash.get(Math.abs(longestSeq)).get(3) == 0)
							sequenceHash.get(Math.abs(longestSeq)).set(3,
									latestSerial - j);
					}

				} else {
					ArrayList<Integer> al = new ArrayList<Integer>();

					if (longestSeq > 0) {
						al.add(0, 1);
						al.add(1, 0);
						al.add(2, maxSerial - j);
						al.add(3, 0);
						al.add(4, 0);
					}

					if (longestSeq < 0) {
						al.add(0, 0);
						al.add(1, 1);
						al.add(2, 0);
						al.add(3, maxSerial - j);
						al.add(4, 0);
					}

					sequenceHash.put(Math.abs(longestSeq), al);
				}
			}
		}

		Collection<ArrayList<Integer>> enu = sequenceHash.values();

		Iterator it = enu.iterator();

		while (it.hasNext()) {
			ArrayList<Integer> thislist = (ArrayList<Integer>) it.next();

			thislist.set(4, depth / (thislist.get(0) + thislist.get(1)));
		}

		// System.out.print(sequenceHash);

		return sequenceHash;

	}

	private static Hashtable<Integer, ArrayList<Integer>> findAllSequencesInList(
			ArrayList<Integer> list, int seqLength) { // prints
														// ascending
														// and
														// descending
														// sequence
														// counts
														// for
														// attribute
		// Sequence Length - Total Ascending - Total Descending - ASc Skip -
		// Desc Skip - Ratio
		int latestSerial = list.size();

		LinkedHashMap<Integer, ArrayList<Integer>> serialData = new LinkedHashMap<Integer, ArrayList<Integer>>();
		Hashtable<Integer, ArrayList<Integer>> sequenceHash = new Hashtable<Integer, ArrayList<Integer>>();

		int maxSerial = inputListSize;

		int startSequencelength = 3;
		int endSequenceLength = 8;

		if (seqLength > 0) {
			startSequencelength = seqLength;
			// endSequenceLength = seqLength+1;
		}

		int depth = list.size() - 1;

		// System.out.print("Processing seq length ");
		for (int j = 0; j < depth - endSequenceLength; j++) {
			String maxVals = listToCommaSepString(list.subList(j, j
					+ endSequenceLength));
			// if (j==latestSerial)
			// System.out.println(" doing " + depth + " iterations");
			for (int i = startSequencelength; i < endSequenceLength; i++) {

				// System.out.print("  " + i + " " + j);
				int isSeq = isSequence(maxVals, i);
				if (isSeq != 0) { // sequence of length i found

					if (isSeq == 1) {
						if (serialData.get(j) != null) {
							serialData.get(j).add(i);
						} else {
							ArrayList<Integer> al = new ArrayList<Integer>();
							al.add(i);
							serialData.put(j, al);
						}
					}

					if (isSeq == -1) {
						if (serialData.get(j) != null) {
							serialData.get(j).add(0 - i);
						} else {
							ArrayList<Integer> al = new ArrayList<Integer>();
							al.add(0 - i);
							serialData.put(j, al);
						}
					}

				}
			}

		}
		// System.out.println();

		// Clear all sequences which are counted twice
		ArrayList<Integer> removedata = new ArrayList<Integer>();

		for (Entry<Integer, ArrayList<Integer>> ent : serialData.entrySet()) {
			// System.out.println(ent.getKey() + "/" + ent.getValue());
			if (ent.getValue().size() > 0) {
				for (int r = 0; r < ent.getValue().size() - 1; r++) {
					removedata.add(ent.getKey() + r + 1);
				}
			}
		}

		serialData.keySet().removeAll(removedata);

		for (int j = latestSerial; j > latestSerial - depth; j--) {
			if (serialData.get(j) != null) {
				int longestSeq = serialData.get(j).get(
						serialData.get(j).size() - 1);

				if (sequenceHash.get(Math.abs(longestSeq)) != null) {
					if (longestSeq > 0) {
						sequenceHash.get(Math.abs(longestSeq))
								.set(0,
										sequenceHash.get(Math.abs(longestSeq))
												.get(0) + 1);

						if (sequenceHash.get(Math.abs(longestSeq)).get(2) == 0)
							sequenceHash.get(Math.abs(longestSeq)).set(2,
									latestSerial - j);
					}

					if (longestSeq < 0) {
						sequenceHash.get(Math.abs(longestSeq))
								.set(1,
										sequenceHash.get(Math.abs(longestSeq))
												.get(1) + 1);

						if (sequenceHash.get(Math.abs(longestSeq)).get(3) == 0)
							sequenceHash.get(Math.abs(longestSeq)).set(3,
									latestSerial - j);
					}

				} else {
					ArrayList<Integer> al = new ArrayList<Integer>();

					if (longestSeq > 0) {
						al.add(0, 1);
						al.add(1, 0);
						al.add(2, latestSerial - j);
						al.add(3, 0);
						al.add(4, 0);
					}

					if (longestSeq < 0) {
						al.add(0, 0);
						al.add(1, 1);
						al.add(2, 0);
						al.add(3, latestSerial - j);
						al.add(4, 0);
					}

					sequenceHash.put(Math.abs(longestSeq), al);
				}
			}
		}

		Collection<ArrayList<Integer>> enu = sequenceHash.values();

		Iterator it = enu.iterator();

		while (it.hasNext()) {
			ArrayList<Integer> thislist = (ArrayList<Integer>) it.next();

			thislist.set(4, depth / (thislist.get(0) + thislist.get(1)));
		}

		// System.out.println(" Total records processed " + totalProcessed);
		/*
		 * if (seqLength > 0) System.out.print(seqLength + " "
		 * +sequenceHash.get(seqLength)); else
		 */
		// System.out.print(sequenceHash);

		return sequenceHash;

	}

	private static int isSequence(String vals, int length) {
		int out = 0;

		String[] values = vals.split(",");
		int prevVal = 0;

		if (length > values.length)
			length = values.length;

		for (int k = 0; k < length; k++) {
			if (prevVal == 0) {
				prevVal = Integer.parseInt(values[k].trim());
			} else {
				if (Integer.parseInt(values[k].trim()) == prevVal) {
					out = out + 0;
					prevVal = Integer.parseInt(values[k].trim());
					return 0;
				} else {
					if (Integer.parseInt(values[k].trim()) > prevVal) {
						out = out + 1;
						prevVal = Integer.parseInt(values[k].trim());
					} else {
						out = out - 1;
						prevVal = Integer.parseInt(values[k].trim());
					}
				}

			}
		}

		if (out == length - 1)
			return -1;

		if (out == 0 - length + 1)
			return 1;
		out = 0;

		return out;
	}
	
	private static int isIdentical(String vals, int length) {
		int out = 0;

		String[] values = vals.split(",");
		String prevVal = null;

		if (length > values.length)
			length = values.length;

		for (int k = 0; k < length; k++) {
			if (prevVal == null) {
				prevVal = values[k].trim();
			} else {
				if (!values[k].trim().equals(prevVal)) {
					out = out + 0;
					prevVal = values[k].trim();
					return 0;
				} else {
						out = out + 1;
						prevVal = values[k].trim();
					
				}

			}
		}

		if (out == length - 1)
			return 1;
		out = 0;

		return out;
	}

	private static String listOfValsToString(List<Integer> vals, int size) {

		String out = "";

		if (vals.size() < size)
			return out;

		for (int val : vals) {
			out += val + ",";
		}

		return out.substring(0, out.length() - 1);
	}

	private static int isAllEvenOrOdd(String vals, int length) {
		int out = 0;

		String[] values = vals.split(",");

		if (length > values.length)
			length = values.length;

		for (int k = 0; k < length; k++) {
			if (Integer.parseInt(values[k].trim()) % 2 == 0)
				out = out + 1;
			else
				out = out - 1;

		}

		if (out == length)
			return 1;

		if (out == 0 - length)
			return 2;
		out = 0;

		return out;
	}

	private static int isAllPrime(String vals, int length) {
		int out = 0;

		String[] values = vals.split(",");

		if (length > values.length)
			length = values.length;

		for (int k = 0; k < length; k++) {
			if (primes.contains(Integer.parseInt(values[k].trim())))
				out = out + 1;

		}

		if (out == length)
			return 1;

		out = 0;

		return out;
	}

	private static String listToCommaSepString(List list) {
		String out = "";

		for (Object thisval : list) {
			out += thisval + ",";
		}

		return out.substring(0, out.length() - 1);
	}

	public static List<Integer> commaSepStringToList(String str) {
		ArrayList<Integer> out = new ArrayList<Integer>();

		String[] vals = str.split(",");
		for (int i = 0; i < vals.length; i++) {
			int thisval = Integer.parseInt(vals[i]);
			out.add(thisval);
		}

		return out;
	}

	private static LinkedHashMap<Integer, Integer> getEvenSequenceLocationAndLength(
			List<Integer> vals) {// Given a list like 10,12,14,27,23,11,12,8,7,5
		// we get {6=2, 0=3}
		LinkedHashMap<Integer, Integer> out = new LinkedHashMap<Integer, Integer>();
		int counter = 0;
		int skip = 0;
		int endSequenceLength = (vals.size() > 40) ? 20 : vals.size() / 2;

		if (endSequenceLength < 3)
			return out;

		for (int thisval : vals) {

			if (counter < skip) {
				counter++;
				continue;
			}

			if (thisval % 2 == 0) {
				String maxVals = listToCommaSepString(vals.subList(counter,
						vals.size()));

				for (int i = endSequenceLength; i >= 2; i--) {

					if (isAllEvenOrOdd(maxVals, i) == 1) {
						int size = (i < vals.size() - counter) ? i : vals
								.size() - counter;
						out.put(counter, size);
						skip = counter + size;
						break;
					}
				}
			}

			counter++;

		}

		return out;
	}
	
	
	private static HashMap<Integer, HashMap<String,Integer>> getEvenOddPatternsAndSize(
			List<Integer> vals) {// Given a list like 10,12,14,27,23,11,12,8,7,5
		// we get {6=2, 0=3}
		
		String fullPattern = "";
		
		for (int thisval : vals) {
			if (thisval % 2 == 0) {
				fullPattern += "E";
			} else {
				fullPattern += "O";
			}
		}
		
		HashMap<Integer, HashMap<String,Integer>> out = new HashMap<Integer, HashMap<String,Integer>>();
		
		for (int pattSize=3; pattSize < 5; pattSize++) {
			if (out.get(pattSize) == null)  {
				out.put(pattSize, new HashMap<String,Integer>());
			}
			
			for (int i=0; i<fullPattern.length()-pattSize; i++) {
				String thispatt = fullPattern.substring(i,i+pattSize);
				out.get(pattSize).put(thispatt, StringUtils.countMatches(fullPattern, thispatt));
			}
			
		}
		
		return out;
	}
	
	private static HashMap<Integer, HashMap<String,Integer>> getAscDescPatternsAndSize(
			List<Integer> vals) {
		
		String fullPattern = "";
		
		int c=0;
		for (int thisval : vals) {
			if (c < vals.size()-1) {
				if (thisval >= vals.get(c+1) ) {
					fullPattern += "A";
				} else {
					fullPattern += "D";
				}
			}
			c++;
		}
		
		HashMap<Integer, HashMap<String,Integer>> out = new HashMap<Integer, HashMap<String,Integer>>();
		
		for (int pattSize=3; pattSize < 5; pattSize++) {
			if (out.get(pattSize) == null)  {
				out.put(pattSize, new HashMap<String,Integer>());
			}
			
			for (int i=0; i<fullPattern.length()-pattSize; i++) {
				String thispatt = fullPattern.substring(i,i+pattSize);
				out.get(pattSize).put(thispatt, StringUtils.countMatches(fullPattern, thispatt));
			}
			
		}
		
		return out;
	}

	private static LinkedHashMap<Integer, Integer> getOddSequenceLocationAndLength(
			List<Integer> vals) {// Given a list like 10,12,14,27,23,11,12,8,7,5
		// we get {8=2, 3=3}
		LinkedHashMap<Integer, Integer> out = new LinkedHashMap<Integer, Integer>();
		int counter = 0;
		int skip = 0;
		int endSequenceLength = (vals.size() > 40) ? 20 : vals.size() / 2;

		if (endSequenceLength < 3)
			return out;

		for (int thisval : vals) {

			if (counter < skip) {
				counter++;
				continue;
			}

			if (thisval % 2 == 1) {
				String maxVals = listToCommaSepString(vals.subList(counter,
						vals.size()));

				for (int i = endSequenceLength; i >= 2; i--) {

					if (isAllEvenOrOdd(maxVals, i) == 2) {
						int size = (i < vals.size() - counter) ? i : vals
								.size() - counter;
						out.put(counter, size);
						skip = counter + size;
						break;
					}
				}
			}

			counter++;

		}

		return out;
	}
	
	private static LinkedHashMap<Integer, Integer> getAscSequenceLocationAndLength(
			List<Integer> vals) {// Given a list like 10,12,14,27,23,11,12,8,7,5
		// we get {5=2, 0=4}
		LinkedHashMap<Integer, Integer> out = new LinkedHashMap<Integer, Integer>();
		int counter = 0;
		int skip = 0;
		int endSequenceLength = (vals.size() > 40) ? 10 : vals.size() / 2;

		if (endSequenceLength < 3)
			return out;

		for (int thisval : vals) {

			if (counter < skip) {
				counter++;
				continue;
			}

			//if (thisval % 2 == 0) {
				String maxVals = listToCommaSepString(vals.subList(counter,
						vals.size()));

				for (int i = endSequenceLength; i >= 3; i--) {

					if (isSequence(maxVals, i) == 1) {
						int size = (i < vals.size() - counter) ? i : vals
								.size() - counter;
						out.put(counter, size);
						skip = counter + size;
						break;
					}
				}
			//}

			counter++;

		}

		return out;
	}

	private static LinkedHashMap<Integer, Integer> getDescSequenceLocationAndLength(
			List<Integer> vals) {// Given a list like 10,12,14,27,23,11,12,8,7,5
		// we get {8=2, 3=3}
		LinkedHashMap<Integer, Integer> out = new LinkedHashMap<Integer, Integer>();
		int counter = 0;
		int skip = 0;
		int endSequenceLength = (vals.size() > 40) ? 10 : vals.size() / 2;

		if (endSequenceLength < 3)
			return out;

		for (int thisval : vals) {

			if (counter < skip) {
				counter++;
				continue;
			}

			//if (thisval % 2 == 1) {
				String maxVals = listToCommaSepString(vals.subList(counter,
						vals.size()));

				for (int i = endSequenceLength; i >= 3; i--) {

					if (isSequence(maxVals, i) == -1) {
						int size = (i < vals.size() - counter) ? i : vals
								.size() - counter;
						out.put(counter, size);
						skip = counter + size;
						break;
					}
				}
		//	}

			counter++;

		}

		return out;
	}

	private static LinkedHashMap<Integer, Integer> getPrimesSequenceLocationAndLength(
			List<Integer> vals) {// Given a list like 10,12,14,27,23,11,12,8,7,5
									// we get {8=2, 4=2}
		LinkedHashMap<Integer, Integer> out = new LinkedHashMap<Integer, Integer>();
		int counter = 0;
		int skip = 0;
		int endSequenceLength = (vals.size() > 40) ? 20 : vals.size() / 2;

		if (endSequenceLength < 3)
			return out;

		for (int thisval : vals) {

			if (counter < skip) {
				counter++;
				continue;
			}

			if (primes.contains(thisval)) {
				String maxVals = listToCommaSepString(vals.subList(counter,
						vals.size()));

				for (int i = endSequenceLength; i >= 2; i--) {

					if (isAllPrime(maxVals, i) == 1) {
						int size = (i < vals.size() - counter) ? i : vals
								.size() - counter;
						out.put(counter, size);
						skip = counter + size;
						break;
					}
				}
			}

			counter++;

		}

		return out;
	}
	
	
	private static LinkedHashMap<Integer, Integer> getValueSequenceLocationAndLength(
			List<String> vals, String value) {// Given a list like [F, T, T, T, T, F, T, T, F]
												// and value 'T'
											// we get {1=4, 6=2}
		LinkedHashMap<Integer, Integer> out = new LinkedHashMap<Integer, Integer>();
		int counter = 0;
		int skip = 0;
		int endSequenceLength = (vals.size() > 40) ? 10 : vals.size() / 2;

		if (endSequenceLength < 3)
			return out;

		for (String thisval : vals) {

			if (counter < skip) {
				counter++;
				continue;
			}

			if (thisval.equals(value)) {
				String maxVals = listToCommaSepString(vals.subList(counter,
						vals.size()));

				for (int i = endSequenceLength; i >= 3; i--) {

					if (isIdentical(maxVals, i) == 1) {
						int size = (i < vals.size() - counter) ? i : vals
								.size() - counter;
						out.put(counter, size);
						skip = counter + size;
						break;
					}
				}
			}

			counter++;

		}

		return out;
	}

	private static List<Integer> getDistancesBetweenSequences(
			LinkedHashMap<Integer, Integer> seqData) {

		ArrayList<Integer> out = new ArrayList<Integer>();
		int prevKey = -1;

		for (Map.Entry<Integer, Integer> entry : seqData.entrySet()) {
			int key = entry.getKey();
			if (prevKey >= 0) {
				out.add(key - prevKey);
			}
			prevKey = key;
		}

		return out;

	}

	public static int getSumOfValuesInHashMap(
			LinkedHashMap<Integer, Integer> seqData) {

		int out = 0;

		for (Map.Entry<Integer, Integer> entry : seqData.entrySet()) {
			out += entry.getValue();
		}

		return out;

	}
	
	public static int getSumOfValuesInHashMap(
			HashMap<String, Integer> seqData) {

		int out = 0;

		for (Map.Entry<String, Integer> entry : seqData.entrySet()) {
			out += entry.getValue();
		}

		return out;

	}

	private static int getMaxValueInHashMap(
			LinkedHashMap<Integer, Integer> seqData) {

		int out = 0;

		for (Map.Entry<Integer, Integer> entry : seqData.entrySet()) {
			if (entry.getValue() > out)
				out = entry.getValue();
		}

		return out;

	}
	
	private static LinkedHashMap<Integer, Integer> getValueDistributionInHashMap(
			LinkedHashMap<Integer, Integer> seqData) {

		LinkedHashMap<Integer, Integer> out = new LinkedHashMap<Integer, Integer>();

		for (Map.Entry<Integer, Integer> entry : seqData.entrySet()) {
			if (out.get(entry.getValue()) != null)
				out.put(entry.getValue(), out.get(entry.getValue())+1) ;
			else
				out.put(entry.getValue(), 1) ;
		}

		return out;

	}
	
	private static LinkedHashMap<Integer, Integer> getSubMapFromHashMap(
			LinkedHashMap<Integer, Integer> seqData, int size) {

		LinkedHashMap<Integer, Integer> out = new LinkedHashMap<Integer, Integer>();

		int counter = 0;
		for (Map.Entry<Integer, Integer> entry : seqData.entrySet()) {
			if (counter < size) {
				out.put(entry.getKey(), entry.getValue()) ;
				counter ++;
			} else {
				break;
			}
		}

		return out;

	}
	
	public static LinkedHashMap<Integer, Integer> getValueDistributionInList(
			List<Integer> seqData) {

		LinkedHashMap<Integer, Integer> out = new LinkedHashMap<Integer, Integer>();

		for (int entry : seqData) {
			if (out.get(entry) != null)
				out.put(entry, out.get(entry)+1) ;
			else
				out.put(entry, 1) ;
		}

		return out;

	}
	
	public static TreeMap<String, Integer> getValueDistributionInStringList(
			List<String> seqData) {

		TreeMap<String, Integer> out = new TreeMap<String, Integer>();

		for (String entry : seqData) {
			if (out.get(entry) != null)
				out.put(entry, out.get(entry)+1) ;
			else
				out.put(entry, 1) ;
		}

		return out;

	}

	public static String predictEvenOddCombinationBasedOnTwoDimension(
			List<Integer> list1, List<Integer> list2) {
		// NONE / DIFF / EVEN / ODD / NOTEVEN / NOTODD
		String out = "NONE";

		if (list1.size() != list2.size())
			return out;

		return out;
	}

	public static String predictEvenOddBasedOnOneDimension(List<Integer> list1) {
		// EVEN / ODD
		String out1 = "NONE";
		String out2 = "NONE";
		String out = "NONE";
		
		int minimum =  Collections.min(list1);
		int maximum = Collections.max(list1);

		// Predict same first
		if (list1.get(0) % 2 == 0) {
			out1 = "EVEN";
			out2 = "EVEN";
		} else {
			out1 = "ODD";
			out2 = "ODD";
		}

		LinkedHashMap<Integer, Integer> evens = getEvenSequenceLocationAndLength(list1);

		LinkedHashMap<Integer, Integer> odds = getOddSequenceLocationAndLength(list1);

		if (evens.get(0) != null) {
			// System.out.println("Even seq at the beginning");

			if (evens.get(0) == getMaxValueInHashMap(evens))
				out1 = "ODD";
		}

		if (odds.get(0) != null) {
			// System.out.println("Odd seq at the beginning");
			if (odds.get(0) == getMaxValueInHashMap(odds))
				out1 = "EVEN";
		}

		LinkedHashMap<Integer, Integer> primes = getPrimesSequenceLocationAndLength(list1);

		LinkedHashMap<Integer, Integer> nosequences = new LinkedHashMap<Integer, Integer>();

		for (int i = 0; i < 100; i++) {
			nosequences.put(i, i);
		}

		// remove evens and odd from nosequences

		for (Map.Entry<Integer, Integer> entry : evens.entrySet()) {
			int key = entry.getKey();
			int val = entry.getValue();
			for (int k = key; k < key + val; k++) {
				nosequences.remove(k);
			}
		}

		for (Map.Entry<Integer, Integer> entry : odds.entrySet()) {
			int key = entry.getKey();
			int val = entry.getValue();
			for (int k = key; k < key + val; k++) {
				nosequences.remove(k);
			}
		}

		ArrayList<Integer> noseqdistdata = (ArrayList<Integer>) getDistancesBetweenSequences(nosequences);
		noseqdistdata.removeAll(Arrays.asList(0));

		int skipNoSeq = nosequences.get(nosequences.keySet().iterator().next());

		int ratioNoSeqToData = list1.size() / nosequences.size();

		if (ratioNoSeqToData < skipNoSeq) {// NoSequence is overdue, so reverse
											// the last value
			if (out2.equals("ODD"))
				out2 = "EVEN";

			if (out2.equals("EVEN"))
				out2 = "ODD";
		}
		
		
		if (out1.equals(out2)) // both methods of prediction converge
			out = out1;
		/*else
			out = out2;

		int rand = getRandomNum(minimum, maximum);

		if (rand % 2 == 0) {
			if (out.equals("ODD")) return "NONE";
		} else {
			if (out.equals("EVEN")) return "NONE";
		}*/
			
		return out;
	}
	
	
	
	public static String predictAscDescBasedOnOneDimension(List<Integer> list1) {
		// EVEN / ODD
		String out1 = "NONE";
		String out2 = "NONE";
		String out = "NONE";
		
		int minimum =  Collections.min(list1);
		int maximum = Collections.max(list1);

		// Predict same first
		if (list1.get(0) % 2 == 0) {
			out1 = "ASC";
			out2 = "ASC";
		} else {
			out1 = "DESC";
			out2 = "DESC";
		}

		LinkedHashMap<Integer, Integer> ascs = getAscSequenceLocationAndLength(list1);

		LinkedHashMap<Integer, Integer> descs = getDescSequenceLocationAndLength(list1);

		if (ascs.get(0) != null) {
			// System.out.println("Even seq at the beginning");

			if (ascs.get(0) == getMaxValueInHashMap(ascs))
				out1 = "DESC";
		}

		if (descs.get(0) != null) {
			// System.out.println("Odd seq at the beginning");
			if (descs.get(0) == getMaxValueInHashMap(descs))
				out1 = "ASC";
		}

		LinkedHashMap<Integer, Integer> primes = getPrimesSequenceLocationAndLength(list1);

		LinkedHashMap<Integer, Integer> nosequences = new LinkedHashMap<Integer, Integer>();

		for (int i = 0; i < 100; i++) {
			nosequences.put(i, i);
		}

		// remove evens and odd from nosequences

		for (Map.Entry<Integer, Integer> entry : ascs.entrySet()) {
			int key = entry.getKey();
			int val = entry.getValue();
			for (int k = key; k < key + val; k++) {
				nosequences.remove(k);
			}
		}

		for (Map.Entry<Integer, Integer> entry : descs.entrySet()) {
			int key = entry.getKey();
			int val = entry.getValue();
			for (int k = key; k < key + val; k++) {
				nosequences.remove(k);
			}
		}

		ArrayList<Integer> noseqdistdata = (ArrayList<Integer>) getDistancesBetweenSequences(nosequences);
		noseqdistdata.removeAll(Arrays.asList(0));

		int skipNoSeq = nosequences.get(nosequences.keySet().iterator().next());

		int ratioNoSeqToData = list1.size() / nosequences.size();

		if (ratioNoSeqToData < skipNoSeq) {// NoSequence is overdue, so reverse
											// the last value
			if (out2.equals("DESC"))
				out2 = "ASC";

			if (out2.equals("ASC"))
				out2 = "DESC";
		}
		
		
		if (out1.equals(out2)) // both methods of prediction converge
			out = out1;
		/*else
			out = out2;

		int rand = getRandomNum(minimum, maximum);

		if (rand % 2 == 0) {
			if (out.equals("ODD")) return "NONE";
		} else {
			if (out.equals("EVEN")) return "NONE";
		}*/
			
		return out;
	}
	
	
	public static String predictStateBasedOnOneDimension(List<String> list1) {
		// EVEN / ODD
		String out1 = "NONE";
		String out2 = "NONE";
		String out = "NONE";
		
		Set<String> uniqueVals = new HashSet<String>(list1);
		
		if (uniqueVals.size() < 2)
			return out;
		
		if (uniqueVals.size() > 3) {
			System.out.println("ListUtils:predictStateBasedOnOneDimension: Too many states. Can not predict " + uniqueVals );
		}
			
		String[] states = new String [uniqueVals.size()];
		Iterator it = uniqueVals.iterator();
		int prevfrequency = 0;
		int s=0;
		
		for (String val: uniqueVals) {
			states[s] =  val;
			
			if (prevfrequency > 0) {
				if (Collections.frequency(list1, val) > prevfrequency) {
					String temp = states[s-1];
					states[s-1] = val;
					states[s] = temp;
				}
			}
			prevfrequency = Collections.frequency(list1, val);
			s++;
		}
		//int minimum =  Collections.min(list1);
		//int maximum = Collections.max(list1);

		// Predict same first
		if (uniqueVals.size() > 2) {
			if (!list1.get(0).equals(states[2])) {
				out1 = list1.get(0);
				out2 = list1.get(0);
			}
		} else {
			out1 = list1.get(0);
			out2 = list1.get(0);
		}

		LinkedHashMap<Integer, Integer> state1s = getValueSequenceLocationAndLength(list1,states[0]);	

		LinkedHashMap<Integer, Integer> state2s = getValueSequenceLocationAndLength(list1,states[1]);

		if (state1s.get(0) != null) {
			// System.out.println("Even seq at the beginning");

			if (state1s.get(0) == getMaxValueInHashMap(state1s))
				out1 = states[1];
		}

		if (state2s.get(0) != null) {
			// System.out.println("Odd seq at the beginning");
			if (state2s.get(0) == getMaxValueInHashMap(state2s))
				out1 = states[0];
		}

		//LinkedHashMap<Integer, Integer> primes = getPrimesSequenceLocationAndLength(list1);

		LinkedHashMap<Integer, Integer> nosequences = new LinkedHashMap<Integer, Integer>();

		for (int i = 0; i < 100; i++) {
			nosequences.put(i, i);
		}

		for (Map.Entry<Integer, Integer> entry : state1s.entrySet()) {
			int key = entry.getKey();
			int val = entry.getValue();
			for (int k = key; k < key + val; k++) {
				nosequences.remove(k);
			}
		}

		for (Map.Entry<Integer, Integer> entry : state2s.entrySet()) {
			int key = entry.getKey();
			int val = entry.getValue();
			for (int k = key; k < key + val; k++) {
				nosequences.remove(k);
			}
		}

		ArrayList<Integer> noseqdistdata = (ArrayList<Integer>) getDistancesBetweenSequences(nosequences);
		noseqdistdata.removeAll(Arrays.asList(0));

		int skipNoSeq = nosequences.get(nosequences.keySet().iterator().next());

		int ratioNoSeqToData = list1.size() / nosequences.size();

		if (ratioNoSeqToData < skipNoSeq) {// NoSequence is overdue, so reverse
											// the last value
			if (out2.equals(states[0]))
				out2 = states[1];

			if (out2.equals(states[1]))
				out2 = states[0];
		}
		
		
		if (out1.equals(out2)) // both methods of prediction converge
			out = out1;
		/*else
			out = out2;

		int rand = getRandomNum(minimum, maximum);

		if (rand % 2 == 0) {
			if (out.equals("ODD")) return "NONE";
		} else {
			if (out.equals("EVEN")) return "NONE";
		}*/
			
		return out;
	}

	
	public static String predictStateBasedOnPatterns(List<Integer> list1, String analysisType) { //analysisType "EO" - for Even Odd
																									// "AD" - for Asc Desc
		String out1 = "NONE";
		String out2 = "NONE";
		String out = "NONE";
		
		String fullPattern = "";
		
		if (!(analysisType.equalsIgnoreCase("EO") || analysisType.equalsIgnoreCase("AD")) ) {
			System.out.println("Invalid analysisType : only 'EO' and 'AD' supported");
			return out;
		}
		
			
		if (analysisType.equalsIgnoreCase("EO")) {
			for (int thisval : list1) {
				if (thisval % 2 == 0) {
					fullPattern += "E";
				} else {
					fullPattern += "O";
				}
			}
		}
		
		if (analysisType.equalsIgnoreCase("AD")) {
			int c=0;
			for (int thisval : list1) {
				if (c < list1.size()-1) {
					if (thisval >= list1.get(c+1) ) {
						fullPattern += "A";
					} else {
						fullPattern += "D";
					}
				}
				c++;
			}
		}
		
		String[] states = analysisType.split("(?!^)");
		
		HashMap<Integer, HashMap<String, Integer>> patternhash = null;
		
		if (analysisType.equalsIgnoreCase("EO")) {
			patternhash = getEvenOddPatternsAndSize(list1);
		}
		
		if (analysisType.equalsIgnoreCase("AD")) {
			patternhash = getAscDescPatternsAndSize(list1);
		}
		
		String[] duepatterns = new String[patternhash.size()];
		int duepattcounter = 0;
		for (int pattsize : patternhash.keySet()) {
			duepatterns[duepattcounter] = fullPattern.substring(0, pattsize-1);
			duepattcounter++;
		} 
		
		String evendata = "";
		String odddata = "";
		Hashtable<Integer,List<Integer>> distancedata = new Hashtable<Integer,List<Integer>>();
		Hashtable<Integer,List<Integer>> countdata = new Hashtable<Integer,List<Integer>>();
		
		String predictions = "";
		
		for (int i=0; i<duepatterns.length; i++) {
			int totalcount = getSumOfValuesInHashMap(patternhash.get(duepatterns[i].length()+1));
			evendata += states[0] + duepatterns[i] + ":Distance: " + fullPattern.indexOf(states[0] + duepatterns[i]) + ":Count: " + patternhash.get(duepatterns[i].length()+1).get(states[0] + duepatterns[i]) + " of " + totalcount + "\r\n";
			odddata += states[1] + duepatterns[i] + ":Distance: " + fullPattern.indexOf(states[1] + duepatterns[i]) + ":Count: " + patternhash.get(duepatterns[i].length()+1).get(states[1] + duepatterns[i]) + " of " + totalcount + "\r\n";
			
			ArrayList<Integer> distances = new ArrayList<Integer>();
			ArrayList<Integer> counts = new ArrayList<Integer>();
			//for (int j=0; j<fullPattern.length()-duepatterns[i].length()-1; j++) {
			for (int j=0; j<25; j++) {
				String tempduepattern = fullPattern.substring(j, j+ duepatterns[i].length()+1);
				distances.add(fullPattern.substring(j+1).indexOf(tempduepattern));
				
				HashMap<Integer, HashMap<String, Integer>> temppatternhash = null;
				if (analysisType.equalsIgnoreCase("EO")) {
					temppatternhash = getEvenOddPatternsAndSize(list1.subList(j+1, list1.size()));
				}
				
				if (analysisType.equalsIgnoreCase("AD")) {
					temppatternhash = getAscDescPatternsAndSize(list1.subList(j+1, list1.size()));
				}
				
				if (temppatternhash.get(duepatterns[i].length()+1).get(tempduepattern) != null)
					counts.add(temppatternhash.get(duepatterns[i].length()+1).get(tempduepattern));
			}
			
			distancedata.put(i,testWhetherHotBasedOnList(distances));
			countdata.put(i,testWhetherHotBasedOnList(counts));
			
			List<Integer> heatmapdistances = testWhetherHotBasedOnList(distances);
			List<Integer> heatmapcounts = testWhetherHotBasedOnList(counts);
			
			int distanceheatstatus = heatmapdistances.get(0) + 
										heatmapdistances.get(1) + 
										heatmapdistances.get(2) + 
										heatmapdistances.get(3);
			int countheatstatus = heatmapcounts.get(0) + 
										heatmapcounts.get(1) + 
										heatmapcounts.get(2) + 
										heatmapcounts.get(3);
			
			int threshold = 4;
			
			if (heatmapdistances.get(0) > 0 && distanceheatstatus < threshold) { // HOT -- go for small distance
				if (fullPattern.indexOf(states[0] + duepatterns[i]) < fullPattern.indexOf(states[1] + duepatterns[i])) {
					predictions+=states[0];
				} 
				
				if (fullPattern.indexOf(states[0] + duepatterns[i]) > fullPattern.indexOf(states[1] + duepatterns[i])) {
					predictions+=states[1];
				}
			}
			
			if (heatmapdistances.get(0) < 0 && distanceheatstatus > 0-threshold) { // COLD - go for large distance
				if (fullPattern.indexOf(states[0] + duepatterns[i]) > fullPattern.indexOf(states[1] + duepatterns[i])) {
					predictions+=states[0];
				} 
				
				if (fullPattern.indexOf(states[0] + duepatterns[i]) < fullPattern.indexOf(states[1] + duepatterns[i])) {
					predictions+=states[1];
				}
			}
			
			if (heatmapcounts.get(0) < 0 && countheatstatus > 0-threshold) { // COLD - go for large counts
				if (patternhash.get(duepatterns[i].length()+1).get(states[0] + duepatterns[i]) != null && 
						patternhash.get(duepatterns[i].length()+1).get(states[1] + duepatterns[i]) != null) { 
					if (patternhash.get(duepatterns[i].length()+1).get(states[0] + duepatterns[i]) >
								patternhash.get(duepatterns[i].length()+1).get(states[1] + duepatterns[i])) {
						predictions+=states[0];
					}
					
					if (patternhash.get(duepatterns[i].length()+1).get(states[0] + duepatterns[i]) <
								patternhash.get(duepatterns[i].length()+1).get(states[1] + duepatterns[i])) {
							predictions+=states[1];
					}
				}
			}
			
			if (heatmapcounts.get(0) > 0 && countheatstatus < threshold) { // HOT -- go for small count
				
				if (patternhash.get(duepatterns[i].length()+1).get(states[0] + duepatterns[i]) != null && 
								patternhash.get(duepatterns[i].length()+1).get(states[1] + duepatterns[i]) != null) { 
					if (patternhash.get(duepatterns[i].length()+1).get(states[0] + duepatterns[i]) >
								patternhash.get(duepatterns[i].length()+1).get(states[1] + duepatterns[i])) {
						predictions+=states[1];
					}
					
					if (patternhash.get(duepatterns[i].length()+1).get(states[0] + duepatterns[i]) <
								patternhash.get(duepatterns[i].length()+1).get(states[1] + duepatterns[i])) {
							predictions+=states[0];
					}
				}
			}
		}
			
		/*System.out.println(evendata);
		System.out.println("Distances:");
		for (Integer k: distancedata.keySet())
			System.out.println(distancedata.get(k));
		System.out.println("Count:");
		for (Integer k: countdata.keySet())
			System.out.println(countdata.get(k));
		System.out.println(odddata);
		System.out.println(predictions);*/
		
		if (predictions.length() > 0) {
			if (StringUtils.countMatches(predictions, states[0]) > StringUtils.countMatches(predictions, states[1])) {
				if (analysisType.equalsIgnoreCase("EO"))
					out = "EVEN";
				else
					out = "ASC";
			}
			
			if (StringUtils.countMatches(predictions, states[0]) < StringUtils.countMatches(predictions, states[1])) {
				if (analysisType.equalsIgnoreCase("EO"))
					out = "ODD";
				else
					out = "DESC";
			}
		}
		
		if (analysisType.equalsIgnoreCase("AD")) {
			if (list1.get(0) > (Collections.max(list1)*0.8 + Collections.min(list1)*0.2)) {
				/*if (out.equals("DESC"))
					return "DESC";
				else 
					return "NONE";*/
				return "DESC";
			}
			
			double lowerbound = (Collections.min(list1)*0.8) + (Collections.max(list1)*0.2);
			if (list1.get(0) < lowerbound) {
				/*if (out.equals("ASC"))
					return "ASC";
				else
					return "NONE";*/
				return "ASC";
			}
		}
		
		
		return out;
	}

	

	private static int getRandomNum(int min, int max) {
		return ThreadLocalRandom.current().nextInt(min, max + 1);
	}
	
	private static ArrayList<String> testEvenOddPrediction(String attribute, String gameCode, List<Integer> altListOfVals) {

		ResultHistoryEntity rhe = new ResultHistoryEntity();
		rhe.setGameCode(gameCode);
		ArrayList<String> failures = new ArrayList<String>();
		ArrayList<String> successes = new ArrayList<String>();
		int lastserial = 0;
		int passed = 0;
		int samplesize = 200;
		int printsize = 10;
		int nopredic = 0;
		ArrayList<String> out = new ArrayList<>();
		int latestsuccessserial = 0;// (successes.size() >
									// 0)?Integer.parseInt(successes.get(0).substring(0,
									// successes.get(0).indexOf("-"))):0;
		int latestfailureserial = 0;// (failures.size() >
									// 0)?Integer.parseInt(failures.get(0).substring(0,
									// failures.get(0).indexOf("-"))):0;
		
		int samepredicsuccess = 0;
		int diffpredicsuccess = 0;
		int samepredicfail = 0;
		int diffpredicfail = 0;


		int seqlargerthantwo = 0;

		if (altListOfVals != null && altListOfVals.size() > 0)
			samplesize = altListOfVals.size() - 1;
		
		try {
			if (altListOfVals == null && lastserial == 0)
				lastserial = Integer.parseInt(rhe.getValueForField(
						"serialNumber", gameCode, 0));

			for (int i = 0; i < samplesize; i++) {
				
				String value = "";				
				String maxVals = "";
				
				if (altListOfVals == null || altListOfVals.size() == 0) {
					value = rhe.getValueForFieldFromCache(attribute, gameCode, (lastserial - i));
				} else {
					value = Integer.toString(altListOfVals.get(i));
				}
				
				if (altListOfVals == null || altListOfVals.size() == 0) {
					maxVals = rhe.getLastNForSequenceFromCache(attribute, samplesize, (lastserial - i - 1));
				} else {
					maxVals = listToCommaSepString(altListOfVals.subList(i+1, altListOfVals.size()));
				}
				
				String prediction = predictStateBasedOnPatterns(new ArrayList<Integer>(	commaSepStringToList(maxVals)), "EO");
				String prediction2 = predictEvenOddBasedOnOneDimension(new ArrayList<Integer>(	commaSepStringToList(maxVals)));

				
				if (prediction.equals("NONE")) {
					nopredic++;
					out.add("");
				}

				if (prediction.equals("EVEN")) {
					if (Integer.parseInt(value) % 2 == 0) {
						passed++;
						out.add("T");
					} else
						out.add("F");
				}

				if (prediction.equals("ODD")) {
					if (Integer.parseInt(value) % 2 == 1) {
						passed++;
						out.add("T");
					} else
						out.add("F");
				}
				
				if (i < 10)
					System.out.println(value + "\t" + prediction + "\t" + prediction2 + "\t" + out.get(out.size()-1)+ "\t"
							+ maxVals.substring(0, 50));
				
				if (!prediction.equals("NONE") && !prediction2.equals("NONE") ) {
					if (prediction.equals(prediction2) && out.get(out.size()-1).equalsIgnoreCase("T"))
						samepredicsuccess ++;
					
					if (prediction.equals(prediction2) && out.get(out.size()-1).equalsIgnoreCase("F"))
						samepredicfail ++;
					
					if (!prediction.equals(prediction2) && out.get(out.size()-1).equalsIgnoreCase("T"))
						diffpredicsuccess ++;
					
					if (!prediction.equals(prediction2) && out.get(out.size()-1).equalsIgnoreCase("F"))
						diffpredicfail ++;
				}


			}

			System.out.println("Tests: " + samplesize + " Nopredictions: " + (nopredic*100/samplesize) + " pc Passed: "
					+ (passed*100/(samplesize-nopredic)) + " pc");
			
			System.out.println("Successes when two pred were same " + (samepredicsuccess*100/(samplesize-nopredic)));
			
			System.out.println("Successes when two pred were diff " + (diffpredicsuccess*100/(samplesize-nopredic)));
			
			System.out.println("Fails when two pred were same " + (samepredicfail*100/(samplesize-nopredic)));
			
			System.out.println("Fails when two pred were diff " + (diffpredicfail*100/(samplesize-nopredic)));
			
			
			// Now test WITH state prediction
			System.out.println("\tTESTING WITH STATE PREDICTION ..");
			
			samplesize = out.size()-1;
			passed = 0;
			nopredic = 0;
			
			for (int i = 0; i < samplesize; i++) {
				
				String value = "";				
				
				value = out.get(i);
				
				String prediction = predictStateBasedOnOneDimension(out.subList(i+1, out.size()));

				
				if (prediction.equals("NONE")) {
					nopredic++;
				}

				
					if (prediction.equals(value)) {
						passed++;
					}
				

			}

			System.out.println("\tTests: " + samplesize + " Nopredictions: " + (nopredic*100/samplesize) + " pc Passed: "
					+ (passed*100/(samplesize-nopredic)) + " pc");
			
			

		} catch (Exception e) {
			System.out.println("ListUtils:testEvenOddPrediction - Exception"
					+ e.getMessage());
		}
		
		return out;
	}
	
	private static ArrayList<String> testAscDescPrediction(String attribute, String gameCode, List<Integer> altListOfVals) {

		ResultHistoryEntity rhe = new ResultHistoryEntity();
		rhe.setGameCode(gameCode);
		ArrayList<String> failures = new ArrayList<String>();
		ArrayList<String> successes = new ArrayList<String>();
		int lastserial = 0;
		int passed = 0;
		int samplesize = 200;
		int printsize = 10;
		int nopredic = 0;

		ArrayList<String> out = new ArrayList<>();
		int latestsuccessserial = 0;// (successes.size() >
									// 0)?Integer.parseInt(successes.get(0).substring(0,
									// successes.get(0).indexOf("-"))):0;
		int latestfailureserial = 0;// (failures.size() >
									// 0)?Integer.parseInt(failures.get(0).substring(0,
									// failures.get(0).indexOf("-"))):0;
		
		int samepredicsuccess = 0;
		int diffpredicsuccess = 0;
		int samepredicfail = 0;
		int diffpredicfail = 0;

		if (altListOfVals != null && altListOfVals.size() > 0)
			samplesize = altListOfVals.size() - 1;
		
		try {
			if (altListOfVals == null && lastserial == 0)
				lastserial = Integer.parseInt(rhe.getValueForField(
						"serialNumber", gameCode, 0));
			String prevValue = "";
			for (int i = 0; i < samplesize; i++) {
				String value = "";
				
				String maxVals = "";
				
				if (altListOfVals == null || altListOfVals.size() == 0) {
					value = rhe.getValueForFieldFromCache(attribute, gameCode, (lastserial - i));
				} else {
					value = Integer.toString(altListOfVals.get(i));
				}
				
				if (altListOfVals == null || altListOfVals.size() == 0) {
					prevValue = rhe.getValueForFieldFromCache(attribute, gameCode, (lastserial - i-1));
				} else {
					prevValue = Integer.toString(altListOfVals.get(i+1));
				}
				
				if (altListOfVals == null || altListOfVals.size() == 0) {
					maxVals = rhe.getLastNForSequenceFromCache(attribute, samplesize, (lastserial - i - 1));
				} else {
					maxVals = listToCommaSepString(altListOfVals.subList(i+1, altListOfVals.size()));
				}
				

				String prediction = predictStateBasedOnPatterns(new ArrayList<Integer>(commaSepStringToList(maxVals)),"AD");
				String prediction2 = predictAscDescBasedOnOneDimension(new ArrayList<Integer>(commaSepStringToList(maxVals)));
				
				
				if (prediction.equals("NONE")) {
					nopredic++;
					out.add("");
				}

				if (prediction.equals("ASC")) {
					if (Integer.parseInt(value) > Integer.parseInt(prevValue)) {
						passed++;
						out.add("T");
					} else
						out.add("F");
				}

				if (prediction.equals("DESC")) {
					if (Integer.parseInt(value) < Integer.parseInt(prevValue)) {
						passed++;
						out.add("T");
					} else
						out.add("F");
				}
				
				if (i < 10)
					System.out.println(value + "\t" + prediction + "\t" + prediction2 + "\t" + out.get(out.size()-1)+ "\t"
							+ maxVals.substring(0, 50));
				
				if (!prediction.equals("NONE") && !prediction2.equals("NONE") ) {
					if (prediction.equals(prediction2) && out.get(out.size()-1).equalsIgnoreCase("T"))
						samepredicsuccess ++;
					
					if (prediction.equals(prediction2) && out.get(out.size()-1).equalsIgnoreCase("F"))
						samepredicfail ++;
					
					if (!prediction.equals(prediction2) && out.get(out.size()-1).equalsIgnoreCase("T"))
						diffpredicsuccess ++;
					
					if (!prediction.equals(prediction2) && out.get(out.size()-1).equalsIgnoreCase("F"))
						diffpredicfail ++;
				}


			}

			System.out.println("Tests: " + samplesize + " Nopredictions: " + (nopredic*100/samplesize) + " pc Passed: "
					+ (passed*100/(samplesize-nopredic)) + " pc") ;
			System.out.println("Successes when two pred were same " + (samepredicsuccess*100/(samplesize-nopredic)));
			
			System.out.println("Successes when two pred were diff " + (diffpredicsuccess*100/(samplesize-nopredic)));
			
			System.out.println("Fails when two pred were same " + (samepredicfail*100/(samplesize-nopredic)));
			
			System.out.println("Fails when two pred were diff " + (diffpredicfail*100/(samplesize-nopredic)));
			
			// Now test WITH state prediction
				System.out.println("\tTESTING WITH STATE PREDICTION ..");
				
				samplesize = out.size()-1;
				passed = 0;
				nopredic = 0;
				
				for (int i = 0; i < samplesize; i++) {
					
					String value = "";				
					
					value = out.get(i);
					
					String prediction = predictStateBasedOnOneDimension(out.subList(i+1, out.size()));

					
					if (prediction.equals("NONE")) {
						nopredic++;
					}

					
						if (prediction.equals(value)) {
							passed++;
						}
					

				}

				System.out.println("\tTests: " + samplesize + " Nopredictions: " + (nopredic*100/samplesize) + " pc Passed: "
						+ (passed*100/(samplesize-nopredic)) + " pc");
				
				

		} catch (Exception e) {
			System.out.println("ListUtils:testAscDescPrediction - Exception"
					+ e.getMessage());
		}
		
		System.out.println("Size of out list " + out.size());
		return out;
	}
	
	
	private static ArrayList<String> testStatePrediction(List<String> list) {

		int passed = 0;
		int samplesize = 200;
		int printsize = 10;
		int nopredic = 0;

		ArrayList<String> out = new ArrayList<>();
		int latestsuccessserial = 0;// (successes.size() >
									// 0)?Integer.parseInt(successes.get(0).substring(0,
									// successes.get(0).indexOf("-"))):0;
		int latestfailureserial = 0;// (failures.size() >
									// 0)?Integer.parseInt(failures.get(0).substring(0,
									// failures.get(0).indexOf("-"))):0;

		int seqlargerthantwo = 0;

		try {
			
			for (int i = 0; i < samplesize; i++) {
				String value = list.get(i);
				
				String prediction = predictStateBasedOnOneDimension(list.subList(i+1, list.size()));
				
				if (prediction.equals("NONE")) {
					nopredic++;
					out.add("");
				}

				if (prediction.equals("T")) {
					if (value.equals("T")) {
						passed++;
						out.add("T");
					} else
						out.add("F");
				}

				if (prediction.equals("F")) {
					if (value.equals("F")) {
						passed++;
						out.add("T");
					} else
						out.add("F");
				}
				
				if (i < 10)
					System.out.println(value + "\t" + prediction + "\t" 
							+ list.subList(i+1, i+25));


			}

			System.out.println("Tests: " + samplesize + " Nopredictions: " + (nopredic*100/samplesize) + " pc Passed: "
					+ (passed*100/(samplesize-nopredic)) + " pc");

		} catch (Exception e) {
			System.out.println("ListUtils:testStatePrediction - Exception"
					+ e.getMessage());
		}
		
		System.out.println("Size of out list " + out.size());
		return out;
	}

	public static LinkedHashMap<Integer, ArrayList<Integer>> convertDistDataIntoValueDistanceFreqMap(
			LinkedHashMap<Integer, ArrayList<Integer>> distData,
			int numberOfPossibleVals) {
		LinkedHashMap<Integer, ArrayList<Integer>> out = new LinkedHashMap<Integer, ArrayList<Integer>>();
		
		int counter=0;
		for (int keyserial: distData.keySet()) {
			ArrayList<Integer> valdata = distData.get(keyserial);
			
			if (out.size() < numberOfPossibleVals) {
				int value = valdata.get(0);
				int freq = valdata.get(2) + 1;
				int currentdistance = counter +1;
				if (out.get(value) == null) {
					ArrayList<Integer> distFreq = new ArrayList<Integer>();
					distFreq.add(currentdistance);
					distFreq.add(freq);
					out.put(value, distFreq);
				}
			} else {
				break;
			}
			counter++;
		}
		return out;
	}
	
	
	public static List<String> getRelations(int firstNum, List<Integer> combination) 
		//Investigate whether the numbers in combination are related to the firstNum
		// 'R' - sameRedux, 'D' - same digitDiff, 'M' - Multiple
	{	
		int firstNumRedux = Integer.parseInt(Numbers.getRedux(Integer.toString(firstNum)));			
		int firstNumDigitDiff = Math.abs((firstNum / 10) - (firstNum % 10));
		List<String> out = new ArrayList<String>();
		
		for (int num: combination) {
			String thisOut = "";
			
			if (Math.abs((num / 10) - (num % 10)) == firstNumDigitDiff)
				thisOut = "D";
			
			if (Integer.parseInt(Numbers.getRedux(Integer.toString(num))) == firstNumRedux)
				thisOut = "R";
			
			if (((num > firstNum)?(num%firstNum):(firstNum%num)) == 0)
				thisOut = "M";
			
			out.add(thisOut);
		}
		
		return out;
	}
}
