package com.num.generator.predic;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;

import org.apache.commons.lang3.StringUtils;

import com.num.generator.dataaccess.InclusionExclusionEntity;
import com.num.generator.dataaccess.ResultHistoryEntity;

public class PredictEvenOddBasedOnPatterns extends PredictionStrategy {
	
	private boolean dump = false;
	private String fullPattern="";
	private HashMap<Integer, HashMap<String,Integer>> evenOddPatterns;
	
	private static int serialOffset = 0 ;   // we use this counter to recalculate distance data
	private static int initialSerialOffset = 0; /// this is the offset we start with
	private String latestValue;
	ResultHistoryEntity rhe = new ResultHistoryEntity();

	public static void main(String[] args) {
		String attribute = "firstFiveSumBucket";
		int gameCode = 1;
		
		serialOffset = initialSerialOffset;
		
		PredictEvenOddBasedOnPatterns strat = new PredictEvenOddBasedOnPatterns();
		strat.setTestSampleSize(200);
		
		System.out.println(strat.predictForGameCodeAndAttribute(gameCode, attribute,0));
		//strat.testStrategy(gameCode, attribute);
		
		//strat.saveResult(gameCode, attribute);
		strat.getLastThreePerformanceAndUpdatePrediction(gameCode, attribute);
	}

	@Override
	public String predictForGameCodeAndAttribute(int ingameCode,
			String attribute, int serialNumber) {
		
		String gameCode = Integer.toString(ingameCode);
		
		rhe.setGameCode(gameCode);
		
		if ( serialNumber == 0)
			serialNumber = Integer.parseInt(rhe.getValueForField("serialNumber", gameCode, 0));


		String attributevals = rhe.getLastNForSequence(attribute, 600, serialNumber-serialOffset);

		List<Integer> data = ListUtils.commaSepStringToList(attributevals);
		
		latestValue = Integer.toString(data.get(0));
		
		return predictForData(data);
	}

	@Override
	public String predictForData(List<Integer> list1) {
		String out1 = "NONE";
		String out2 = "NONE";
		String out = "NONE";
		
		String fullPattern = "";
		
		for (int thisval : list1) {
			if (thisval % 2 == 0) {
				fullPattern += "E";
			} else {
				fullPattern += "O";
			}
		}
	
		String analysisType = "EO";
		
		String[] states = analysisType.split("(?!^)");
		
		HashMap<Integer, HashMap<String, Integer>> patternhash = null;	
		
		patternhash = getEvenOddPatternsAndSize(list1);		
		
		if (dump)
			System.out.println(patternhash);
		
		String[] duepatterns = new String[patternhash.size()];
		int duepattcounter = 0;
		for (int pattsize : patternhash.keySet()) {
			duepatterns[duepattcounter] = fullPattern.substring(0, pattsize-1);
			duepattcounter++;
		} 
		
		String evendata = "";
		String odddata = "";
		Hashtable<Integer,List<Integer>> distancedata = new Hashtable<Integer,List<Integer>>();
		Hashtable<Integer,List<Integer>> countdata = new Hashtable<Integer,List<Integer>>();
		
		String predictions = "";
		
		for (int i=0; i<duepatterns.length; i++) {
			int totalcount = ListUtils.getSumOfValuesInHashMap(patternhash.get(duepatterns[i].length()+1));
			evendata += states[0] + duepatterns[i] + ":Distance: " + fullPattern.indexOf(states[0] + duepatterns[i]) + ":Count: " + patternhash.get(duepatterns[i].length()+1).get(states[0] + duepatterns[i]) + " of " + totalcount + "\r\n";
			odddata += states[1] + duepatterns[i] + ":Distance: " + fullPattern.indexOf(states[1] + duepatterns[i]) + ":Count: " + patternhash.get(duepatterns[i].length()+1).get(states[1] + duepatterns[i]) + " of " + totalcount + "\r\n";
			
			ArrayList<Integer> distances = new ArrayList<Integer>();
			ArrayList<Integer> counts = new ArrayList<Integer>();
			//for (int j=0; j<fullPattern.length()-duepatterns[i].length()-1; j++) {
			for (int j=0; j<25; j++) {
				String tempduepattern = fullPattern.substring(j, j+ duepatterns[i].length()+1);
				distances.add(fullPattern.substring(j+1).indexOf(tempduepattern));
				
				HashMap<Integer, HashMap<String, Integer>> temppatternhash = null;
				
				if (analysisType.equalsIgnoreCase("EO")) {
					temppatternhash = getEvenOddPatternsAndSize(list1.subList(j+1, list1.size()));
				}
				
				if (temppatternhash.get(duepatterns[i].length()+1).get(tempduepattern) != null)
					counts.add(temppatternhash.get(duepatterns[i].length()+1).get(tempduepattern));
			}
			
			distancedata.put(i,ListUtils.testWhetherHotBasedOnList(distances));
			countdata.put(i,ListUtils.testWhetherHotBasedOnList(counts));
			
			List<Integer> heatmapdistances = ListUtils.testWhetherHotBasedOnList(distances);
			List<Integer> heatmapcounts = ListUtils.testWhetherHotBasedOnList(counts);
			
			int distanceheatstatus = heatmapdistances.get(0) + 
										heatmapdistances.get(1) + 
										heatmapdistances.get(2) + 
										heatmapdistances.get(3);
			int countheatstatus = heatmapcounts.get(0) + 
										heatmapcounts.get(1) + 
										heatmapcounts.get(2) + 
										heatmapcounts.get(3);
			
			int threshold = 4;
			
			if (heatmapdistances.get(0) > 0 && distanceheatstatus < threshold) { // HOT -- go for small distance
				if (fullPattern.indexOf(states[0] + duepatterns[i]) < fullPattern.indexOf(states[1] + duepatterns[i])) {
					predictions+=states[0];
				} 
				
				if (fullPattern.indexOf(states[0] + duepatterns[i]) > fullPattern.indexOf(states[1] + duepatterns[i])) {
					predictions+=states[1];
				}
			}
			
			if (heatmapdistances.get(0) < 0 && distanceheatstatus > 0-threshold) { // COLD - go for large distance
				if (fullPattern.indexOf(states[0] + duepatterns[i]) > fullPattern.indexOf(states[1] + duepatterns[i])) {
					predictions+=states[0];
				} 
				
				if (fullPattern.indexOf(states[0] + duepatterns[i]) < fullPattern.indexOf(states[1] + duepatterns[i])) {
					predictions+=states[1];
				}
			}
			
			if (heatmapcounts.get(0) < 0 && countheatstatus > 0-threshold) { // COLD - go for large counts
				if (patternhash.get(duepatterns[i].length()+1).get(states[0] + duepatterns[i]) != null && 
						patternhash.get(duepatterns[i].length()+1).get(states[1] + duepatterns[i]) != null) { 
					if (patternhash.get(duepatterns[i].length()+1).get(states[0] + duepatterns[i]) >
								patternhash.get(duepatterns[i].length()+1).get(states[1] + duepatterns[i])) {
						predictions+=states[0];
					}
					
					if (patternhash.get(duepatterns[i].length()+1).get(states[0] + duepatterns[i]) <
								patternhash.get(duepatterns[i].length()+1).get(states[1] + duepatterns[i])) {
							predictions+=states[1];
					}
				}
			}
			
			if (heatmapcounts.get(0) > 0 && countheatstatus < threshold) { // HOT -- go for small count
				
				if (patternhash.get(duepatterns[i].length()+1).get(states[0] + duepatterns[i]) != null && 
								patternhash.get(duepatterns[i].length()+1).get(states[1] + duepatterns[i]) != null) { 
					if (patternhash.get(duepatterns[i].length()+1).get(states[0] + duepatterns[i]) >
								patternhash.get(duepatterns[i].length()+1).get(states[1] + duepatterns[i])) {
						predictions+=states[1];
					}
					
					if (patternhash.get(duepatterns[i].length()+1).get(states[0] + duepatterns[i]) <
								patternhash.get(duepatterns[i].length()+1).get(states[1] + duepatterns[i])) {
							predictions+=states[0];
					}
				}
			}
		}
			
		/*System.out.println(evendata);
		System.out.println("Distances:");
		for (Integer k: distancedata.keySet())
			System.out.println(distancedata.get(k));
		System.out.println("Count:");
		for (Integer k: countdata.keySet())
			System.out.println(countdata.get(k));
		System.out.println(odddata);
		System.out.println(predictions);*/
		
		if (predictions.length() > 0) {
			if (StringUtils.countMatches(predictions, states[0]) > StringUtils.countMatches(predictions, states[1])) {
				
					out = "EVEN";
			}
			
			if (StringUtils.countMatches(predictions, states[0]) < StringUtils.countMatches(predictions, states[1])) {
				
					out = "ODD";
			}
		}
		
	
		if (list1.get(0) > (Collections.max(list1)*0.8 + Collections.min(list1)*0.2)) {
			/*if (out.equals("DESC"))
				return "DESC";
			else 
				return "NONE";*/
			return "ODD";
		}
		
		double lowerbound = (Collections.min(list1)*0.8) + (Collections.max(list1)*0.2);
		if (list1.get(0) < lowerbound) {
			/*if (out.equals("ASC"))
				return "ASC";
			else
				return "NONE";*/
			return "EVEN";
		}
		
		
		
		return out;
	}

	@Override
	public void testStrategy(int ingameCode, String attribute) {
		
		String gameCode = Integer.toString(ingameCode);
		ResultHistoryEntity rhe = new ResultHistoryEntity();
		rhe.setGameCode(gameCode);
		ArrayList<String> failures = new ArrayList<String>();
		ArrayList<String> successes = new ArrayList<String>();
		int lastserial = 0;
		int passed = 0;
		int samplesize = getTestSampleSize();
		int printsize = 10;
		int nopredic = 0;
		
		int pred1 = 0;
		int pred2 = 0;

		ArrayList<String> out = new ArrayList<>();
		int latestsuccessserial = 0;// (successes.size() >
									// 0)?Integer.parseInt(successes.get(0).substring(0,
									// successes.get(0).indexOf("-"))):0;
		int latestfailureserial = 0;// (failures.size() >
									// 0)?Integer.parseInt(failures.get(0).substring(0,
									// failures.get(0).indexOf("-"))):0;
		
		int samepredicsuccess = 0;
		int diffpredicsuccess = 0;
		int samepredicfail = 0;
		int diffpredicfail = 0;
		
		if (fullPattern == null || fullPattern.length() == 0) {
			
			String allVals = rhe.getLastNForSequenceFromCache(attribute, samplesize*3, 0);
			
			for (int thisval : ListUtils.commaSepStringToList(allVals)) {
				if (thisval % 2 == 0) {
					fullPattern += "E";
				} else {
					fullPattern += "O";
				}
			}
		}

		
		try {
			if ( lastserial == 0)
				lastserial = Integer.parseInt(rhe.getValueForField(
						"serialNumber", gameCode, 0));
			String prevValue = "";
			for (int i = initialSerialOffset; i < samplesize + initialSerialOffset; i++) {
				
				serialOffset++;
				/*if (i == 9) {
					dump = true;
				} else dump=false;*/
				
				String value = "";
				
				String maxVals = "";
				
				value = rhe.getValueForFieldFromCache(attribute, gameCode, (lastserial - i));
				
				maxVals = rhe.getLastNForSequenceFromCache(attribute, samplesize*3, (lastserial - i - 1));
				
				String prediction = predictForData(ListUtils.commaSepStringToList(maxVals));
				//String prediction2 = ListUtils.predictAscDescBasedOnOneDimension(ListUtils.commaSepStringToList(maxVals));
				
				
				if (prediction.equals("NONE")) {
					nopredic++;
					out.add("");
				}

				if (prediction.equals("EVEN")) {
					pred1++;
					if (Integer.parseInt(value) % 2 == 0) {
						passed++;
						out.add("T");
					} else
						out.add("F");
				}

				if (prediction.equals("ODD")) {
					pred2++;
					if (Integer.parseInt(value) % 2 != 0) {
						passed++;
						out.add("T");
					} else
						out.add("F");
				}
				
				if (i < initialSerialOffset+10) {
					//System.out.println(value + "\t" + prediction + "\t" + prediction2 + "\t" + out.get(out.size()-1)+ "\t"	+ maxVals.substring(0, 50));
					System.out.println(value + "\t" + prediction + "\t" + out.get(out.size()-1)+ "\t"
							+ maxVals.substring(0, 50));
				}
				
				/*if (!prediction.equals("NONE") && !prediction2.equals("NONE") ) {
					if (prediction.equals(prediction2) && out.get(out.size()-1).equalsIgnoreCase("T"))
						samepredicsuccess ++;
					
					if (prediction.equals(prediction2) && out.get(out.size()-1).equalsIgnoreCase("F"))
						samepredicfail ++;
					
					if (!prediction.equals(prediction2) && out.get(out.size()-1).equalsIgnoreCase("T"))
						diffpredicsuccess ++;
					
					if (!prediction.equals(prediction2) && out.get(out.size()-1).equalsIgnoreCase("F"))
						diffpredicfail ++;
				}*/


			}

			System.out.println("Tests: " + samplesize + " Nopredictions: " + (nopredic*100/samplesize) + " pc Passed: "
					+ (passed*100/(samplesize-nopredic)) + " pc") ;
		/*	System.out.println("Successes when two pred were same " + (samepredicsuccess*100/(samplesize-nopredic)));
			
			System.out.println("Successes when two pred were diff " + (diffpredicsuccess*100/(samplesize-nopredic)));
			
			System.out.println("Fails when two pred were same " + (samepredicfail*100/(samplesize-nopredic)));
			
			System.out.println("Fails when two pred were diff " + (diffpredicfail*100/(samplesize-nopredic)));
			*/
			setPredictionPerformanceHistory(out);
			setPredictionAccuracyPercent(passed*100/(samplesize-nopredic));
			
			if (pred1 == 0 || pred2 == 0)
				setPredictionDivergence(0);
			else 
				setPredictionDivergence((pred1>=pred2)?pred1/pred2:pred2/pred1);
			
			
			// Now test WITH state prediction
			/*	System.out.println("\tTESTING WITH STATE PREDICTION ..");
				
				samplesize = out.size()-1;
				passed = 0;
				nopredic = 0;
				
				for (int i = 0; i < samplesize; i++) {
					
					String value = "";				
					
					value = out.get(i);
					
					String prediction = ListUtils.predictStateBasedOnOneDimension(out.subList(i+1, out.size()));

					
					if (prediction.equals("NONE")) {
						nopredic++;
					}

					
						if (prediction.equals(value)) {
							passed++;
						}
					

				}

				System.out.println("\tTests: " + samplesize + " Nopredictions: " + (nopredic*100/samplesize) + " pc Passed: "
						+ (passed*100/(samplesize-nopredic)) + " pc");
				
				*/

		} catch (Exception e) {
			System.out.println("ListUtils:testAscDescPrediction - Exception"
					+ e.getMessage());
		}
		
		System.out.println("Out list " + out.size() + " : " + out);
		
	}

	
	private HashMap<Integer, HashMap<String,Integer>> getEvenOddPatternsAndSize(
			List<Integer> vals) {
		
		if (fullPattern == null || fullPattern.length() == 0) {
			int c=0;
			for (int thisval : vals) {
				if (thisval % 2 == 0) {
					fullPattern += "E";
				} else {
					fullPattern += "O";
				}
			}
		}
		int localserialoffset = fullPattern.length() - vals.size();
		
		HashMap<Integer, HashMap<String,Integer>> out = new HashMap<Integer, HashMap<String,Integer>>();
		
		if (evenOddPatterns == null) {
			for (int pattSize=3; pattSize < 5; pattSize++) {
				if (out.get(pattSize) == null)  {
					out.put(pattSize, new HashMap<String,Integer>());
				}
				
				for (int i=0; i<fullPattern.length()-pattSize; i++) {
					String thispatt = fullPattern.substring(i,i+pattSize);
					out.get(pattSize).put(thispatt, StringUtils.countMatches(fullPattern, thispatt));
				}
				
			}
			evenOddPatterns = out;
		} else {
			//out = (HashMap<Integer, HashMap<String, Integer>>) ascDescPatterns.clone();
			
			for (Integer mainkey: evenOddPatterns.keySet()) {
				out.put(mainkey, new HashMap<String,Integer>(evenOddPatterns.get(mainkey)));
				
			}
			
			if (localserialoffset > 0) {
				for (int pattSize=3; pattSize < 5; pattSize++) {
					if (out.get(pattSize) == null)  {
						out.put(pattSize, new HashMap<String,Integer>());
					}
					
					for (int i=0; i<localserialoffset; i++) {
						String thispatt = fullPattern.substring(i, fullPattern.length()-1).substring(i,i+pattSize);
						out.get(pattSize).put(thispatt, out.get(pattSize).get(thispatt)-1);
					}
					
				}
			}
		}
		 
		//fullPattern= null;
		//ascDescPatterns = null;
		return out;
	}

	@Override
	public void saveResult(int gameCode, String attribute) {
		
		serialOffset = initialSerialOffset;
		InclusionExclusionEntity ince = new InclusionExclusionEntity();
		rhe.setGameCode(Integer.toString(gameCode));
		ince.setAlgorithmType(InclusionExclusionEntity.ALGORITHM_TYPE_EVEN_ODD_PATTERNS);
		ince.setAttribute(attribute);
		ince.setGameCode(Integer.toString(gameCode));
		ince.setInputDrawDate(rhe.getLastNForAttribute("dateOfDraw", 1, 0));
		ince.setIsInclusionInd("false");
		
		
		//if (latestValue == null ) {
		String currentPred = predictForGameCodeAndAttribute(gameCode, attribute, 0);
		
		System.out.println("Current even-odd pred for " + attribute + ": " + currentPred);
		if (currentPred.equalsIgnoreCase("EVEN")) {
			// if the latest value is 0, that creates problems..
			// Switching values in case of 0 . e.g. For BUCKET even odd, if last bucket was 0
			if ( latestValue.equals("0")) 
				latestValue = "1";
			
			ince.getData().add(Integer.parseInt(latestValue));
		}
		
		if (currentPred.equalsIgnoreCase("ODD")) {
			// For BUCKET even odd, if the latest value is 0, that creates problems..
			// Switching values in case of 0
			if ( latestValue.equals("0")) 
				latestValue = "1";
			
			ince.getData().add(0-Integer.parseInt(latestValue));
		}
		
		//}
		fullPattern = "";
		evenOddPatterns = null;
		testStrategy(gameCode, attribute);
		ince.setPercent(Integer.toString(getPredictionAccuracyPercent()));
		
		if (getPredictionPerformanceHistory() != null) {
			int counter = 0;
			int success = -1;
			int failure = -1;
			int emptyresult = 0;
			for (String thisoutcome: getPredictionPerformanceHistory()) {				
				if (success >= 0 && failure >= 0) break;
				
				if (thisoutcome.equals(""))
					emptyresult++;
				
				if (thisoutcome.equalsIgnoreCase("T") && success < 0)
					success = counter-emptyresult;
				if (thisoutcome.equalsIgnoreCase("F") && failure < 0)
					failure = counter-emptyresult;
				
				counter++;
			}
			
			if (failure < success) {
				ince.setTotalScore(Integer.toString(success*getPredictionAccuracyPercent()));
				ince.setIsInclusionInd("true");
			}
			
			if (failure > success) {
				ince.setTotalScore(Integer.toString(0-(failure*(100-getPredictionAccuracyPercent()))));
				ince.setIsInclusionInd("false");
			}
		}
		
		if (getPredictionDivergence() != 0) {
			ince.addInclusionExclusionResult();
			System.out.println("Prediction divergence " + getPredictionDivergence());
		} else
			System.out.println("One side predictions..");
		
		//System.out.println(ince);
		latestValue = null;
		
		return;
	}

	@Override
	public void getLastThreePerformanceAndUpdatePrediction(int gameCode,
			String attribute) {
		InclusionExclusionEntity ince = new InclusionExclusionEntity();
		rhe.setGameCode(Integer.toString(gameCode));
		
		String latestVal = rhe.getLastNForAttribute(attribute, 1, 0);
		
		if (latestVal == null || latestVal.length()==0)
			return;
		// Get last 3 draw dates
		
		String[] previousdates = new String[3];
		
		for (int i=0; i<previousdates.length; i++) {
			previousdates[i] = rhe.getNthPreviousValueForAttribute("dateOfDraw", i+1, 0);
			
			ince.setAttribute(attribute);
			ince.setAlgorithmType(InclusionExclusionEntity.ALGORITHM_TYPE_EVEN_ODD_PATTERNS);
			ince.setGameCode(Integer.toString(gameCode));
			ince.setInputDrawDate(previousdates[i]);
			
			ArrayList<InclusionExclusionEntity> incexcrows = (ArrayList<InclusionExclusionEntity>) ince.findRows();
			
			if (incexcrows != null && incexcrows.size() == 1  ) {
				String outcome = (Integer.parseInt(latestVal)% 2 == 0)?"EVEN":"ODD";
				
				String prediction = (incexcrows.get(0).getData().get(0) > 0)?"EVEN":"ODD";
				
				if (incexcrows.get(0).getIsInclusionInd().equals("1")) {							
					if (outcome.equals(prediction)) {
						if (i == 0)	incexcrows.get(0).setFirstPerformance("true");
						if (i == 1)	incexcrows.get(0).setSecondPerformance("true");
						if (i == 2)	incexcrows.get(0).setThirdPerformance("true");
					} else {
						if (i == 0)	incexcrows.get(0).setFirstPerformance("false");
						if (i == 1)	incexcrows.get(0).setSecondPerformance("false");
						if (i == 2)	incexcrows.get(0).setThirdPerformance("false");
					}
				} else {
					if (outcome.equals(prediction)) {
						if (i == 0)	incexcrows.get(0).setFirstPerformance("false");
						if (i == 1)	incexcrows.get(0).setSecondPerformance("false");
						if (i == 2)	incexcrows.get(0).setThirdPerformance("false");
					} else {						
						if (i == 0)	incexcrows.get(0).setFirstPerformance("true");
						if (i == 1)	incexcrows.get(0).setSecondPerformance("true");
						if (i == 2)	incexcrows.get(0).setThirdPerformance("true");
					}
				}
				//System.out.println(incexcrows.get(0));
				incexcrows.get(0).update();
			}
			
			
		}
		
	}
}
