package com.num.generator.predic;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.Set;

import com.google.common.collect.ImmutableSet;
import com.google.common.collect.Sets;
import com.google.common.collect.Sets.SetView;
import com.num.generator.Numbers;
import com.num.generator.dataaccess.CurrentStateEntity;
import com.num.generator.dataaccess.GameTypesEntity;
import com.num.generator.dataaccess.ResultHistoryEntity;
import com.num.generator.dataaccess.ResultsWithinLastN;

public class ProcessIndivDBPredicFile {
	private static String inGameCode = "1"; // Mandatory
	
	private static String nextDate = "0107"; // Mandatory
	private static ArrayList attributes =/*new ArrayList(); */ new ArrayList(Arrays.asList("FirstValue",
																		"SecondValue",
																		"ThirdValue",
																		"FourthValue",
																		"FifthValue",
																		"FirstSkip",
																		"SecondSkip",
																		"ThirdSkip",
																		"FourthSkip",
																		"FifthSkip",
																		"FirstFiveSumRedux",
																		"FirstRedux",
																		"FourthRedux",
																		"SecondRedux",
																		"ThirdRedux",
																		"FifthRedux",
																		"MegaRedux",
																		"FirstBucket",
																		"SecondBucket",
																		"FifthBucket",
																		"ThirdBucket",
																		"MegaValue",																		
																		"MegaSkip")); 
	
	private static ArrayList savedattributes = null;
	
	private static String inPrgCode = null;
	
	static Properties DBpredicProp = new Properties();
	
	static int maxValue = 0; // size of current choices list
	
	
	private static String fileName = null;
	
	
	private static boolean suppressVerboseOut = false;
	
	private static ArrayList<ArrayList<Integer>> possibleBucketMap = new ArrayList<ArrayList<Integer>>();
	private static CurrentStateEntity cse = new CurrentStateEntity();
	private static ResultHistoryEntity rhe = new ResultHistoryEntity();
	private static GameTypesEntity gte = null;
	
	public static String getInGameCode() {
		return inGameCode;
	}

	public static void setInGameCode(String inGameCode) {
		ProcessIndivDBPredicFile.inGameCode = inGameCode;
	}

	public static String getNextDate() {
		return nextDate;
	}

	public static void setNextDate(String nextDate) {
		ProcessIndivDBPredicFile.nextDate = nextDate;
	}

	
	public static void main(String[] arg) {
		long start = System.currentTimeMillis();
		
		Numbers.removeLineFromFile("C:\\eclipse\\workspace\\first\\Pred\\possibleLists" + getNextDate(), "*");
		Numbers.removeLineFromFile("C:\\eclipse\\workspace\\first\\Pred\\possibleMegaLists" + getNextDate(), "*");
		if (getInPrgCode() == null) {
			gte = new GameTypesEntity();
			gte.setGameCode(inGameCode);
			
			Iterator itg = ( gte.findRows()).iterator();
			
			if (itg.hasNext()) {
				gte = (GameTypesEntity)itg.next();
				setInPrgCode(gte.getProgramCode());
			}
		}
		
		if (fileName == null)
			fileName = "C:\\eclipse\\workspace\\first\\Pred\\IndivPredFor" + nextDate + "-" + getInPrgCode().toUpperCase();;
		
		FileInputStream fis;

		try {
			fis = new FileInputStream(new File(fileName));
			// "C:\\eclipse\\workspace\\first\\Pred\\PredFor" + nextDate + "-"+
			// getInPrgCode().toUpperCase()
			DBpredicProp.load(fis);
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		preprocessBucketMap();
		for (int i=0; i<possibleBucketMap.size(); i++) {
		//for (int i=0; i<3; i++) {
			String thisAttrib = "";
			
			if (i == 0) thisAttrib = "FIRST";
			if (i == 1) thisAttrib = "SECOND";
			if (i == 2) thisAttrib = "THIRD";
			if (i == 3) thisAttrib = "FOURTH";
			if (i == 4) thisAttrib = "FIFTH";
			if (i == 5) thisAttrib = "MEGA";
			
			Properties tempDBpredicProp = new Properties();
			Properties tempNOTDBpredicProp = new Properties();
					
			Iterator attIt = null;
			if (attributes.size() > 0)
				attIt = attributes.iterator();
			
			while (attIt.hasNext()) {

				String attName = ((String) attIt.next()).toUpperCase();
				String value = (DBpredicProp.getProperty(attName) == null)?"":DBpredicProp.getProperty(attName);
				if (attName.startsWith(thisAttrib) && !attName.contains("SUM") && value.length() > 0) {
				
					value = value.replace("NOT", ""); 
					
					
						tempDBpredicProp.setProperty(attName, value); 
					
					
					value = "NOT" + value;
					
					
					tempNOTDBpredicProp.setProperty("NOT " + attName, value); 
					
				}
			}
			
			savedattributes = attributes;
			//String[] tmpentryarr = tempDBpredicProp.toArray(new String[0]);
			//String[] tmpnotentryarr = tempNOTDBpredicProp.toArray(new String[0]);
			
			Set<Object> tmpNOTentries = tempNOTDBpredicProp.keySet();
			Set<Object> tmpentries = tempDBpredicProp.keySet();
			//Set<List<Object>> allpossibleChoices = Sets.cartesianProduct(tmpNOTentries,tmpentries);
			//Set<List<List<Object>>> furtherCart = Sets.cartesianProduct(allpossibleChoices, allpossibleChoices);
			
			if (tmpentries.size() == 0) continue;
			
			SetView<Object> union = Sets.union(tmpNOTentries, tmpentries);
			
			String[] entryUnionArray = union.toArray(new String[0]);
			//Set<String> availableEntries = ImmutableSet.of(tmpentryarr);
			Set<String> uniqueAttribs = new HashSet<String>();
			Set<String> uniqueAttribsForSizeMatch = new HashSet<String>();
						
			// Generate cartesian product of elements and NOT elements
			int choices = tmpentries.size();
			int[] comb = new int[choices];
			String[] comblocal = new String[choices];
			
			for (int j = 0; j < choices; j++) {
	
				comb[j] = j;
				comblocal[j] = entryUnionArray[comb[j]]; 
				uniqueAttribs.add(comblocal[j].replace("NOT ", ""));
				uniqueAttribsForSizeMatch.add(comblocal[j].replace("NOT ", "").replace(thisAttrib, ""));
			}
			
			//System.out.println((i+1));
			if (i < 5)
				Numbers.addLineToFile("C:\\eclipse\\workspace\\first\\Pred\\possibleLists" + getNextDate(), Integer.toString(i+1), false);
			else
				Numbers.addLineToFile("C:\\eclipse\\workspace\\first\\Pred\\possibleMegaLists" + getNextDate(), Integer.toString(i+1), false);
			
			if (uniqueAttribsForSizeMatch.size() == choices) {
				
				processThisUniqueListOfAttribs(uniqueAttribs,comblocal, i);
			}
	
			maxValue = entryUnionArray.length;
			while (next_comb(comb, choices, maxValue)) {
				uniqueAttribs = new HashSet<String>();
				uniqueAttribsForSizeMatch = new HashSet<String>();
				
				
				for (int j = 0;j < choices; j++) {
					
					//comb[i] = i;
					comblocal[j] = entryUnionArray[comb[j]];
					
					uniqueAttribs.add(comblocal[j].replace("NOT ", ""));
					uniqueAttribsForSizeMatch.add(comblocal[j].replace("NOT ", "").replace(thisAttrib, ""));
				}
				
				if (uniqueAttribsForSizeMatch.size() == choices) {
					
					processThisUniqueListOfAttribs(uniqueAttribs,comblocal, i);
				}
				attributes  = savedattributes;
				
			}
			
		}
		
		System.out.println("ProcessIndivDBPredicFile.main: " + "C:\\eclipse\\workspace\\first\\Pred\\possibleLists" + getNextDate() + " created.");
		System.out.println("ProcessIndivDBPredicFile.main: " + "C:\\eclipse\\workspace\\first\\Pred\\possibleMegaLists" + getNextDate() + " created.");
	}
	
	private static void processThisUniqueListOfAttribs(Set<String> uniqueAttribs, String[] comblocal, int i) {

 		boolean untouched = true;
		//System.out.println(Arrays.toString(comblocal));
		for(int u=0; u<comblocal.length; u++) {
			if (comblocal[u].startsWith("NOT") && !DBpredicProp.getProperty(comblocal[u].replace("NOT ", "")).contains("NOT")) {
				String oldvalue = DBpredicProp.getProperty(comblocal[u].replace("NOT ", ""));
				
				
					DBpredicProp.setProperty(comblocal[u].replace("NOT ", ""),"NOT" + oldvalue);
					untouched =  false;
				
				
			}
			
			if (!comblocal[u].startsWith("NOT") && DBpredicProp.getProperty(comblocal[u]).contains("NOT")) {
				String oldvalue = DBpredicProp.getProperty(comblocal[u]);
				
					DBpredicProp.setProperty(comblocal[u], oldvalue.replace("NOT",""));
					untouched =  false;
				
			}
		}
		
		preprocessBucketMap();
		
		
		attributes = new ArrayList( Arrays.asList(uniqueAttribs.toArray(new String[0])));
		processDBPredictions();
		
		String outline = (i+1)  + " " + ((untouched)?"*":"") + " " + possibleBucketMap.get(i);
		//System.out.println(outline) ;
		
		if (i < 5)
			Numbers.addLineToFile("C:\\eclipse\\workspace\\first\\Pred\\possibleLists" + getNextDate(), outline, false);
		else
			Numbers.addLineToFile("C:\\eclipse\\workspace\\first\\Pred\\possibleMegaLists" + getNextDate(), outline, false);
		
		
		try {
			FileInputStream fis = new FileInputStream(new File(fileName));
			// "C:\\eclipse\\workspace\\first\\Pred\\PredFor" + nextDate + "-"+
			// getInPrgCode().toUpperCase()
			DBpredicProp.load(fis);
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
		
	}

	static boolean next_comb(int comb[], int k, int n) {

		int i = k - 1;

		comb[i]++;

		while (i > 0 && (comb[i] >= n - k + 1 + i)) {
			i--;
			comb[i]++;
		}
		
		if (comb[0] > n - k) /* Combination (n-k, n-k+1, ..., n) reached */
			return false; /* No more combinations can be generated */

		/* comb now looks like (..., x, n, n, n, ..., n). 

		 Turn it into (..., x, x + 1, x + 2, ...) */

		for (i = i + 1; i < k && i > 0; i++)
			comb[i] = comb[i - 1] + 1;

		return true;

	}
	

	private static String processDBPredictions() {
		String out = null;
		
	
		
		// PROCESS EXCLUDES FIRST
		String param = DBpredicProp.getProperty("EXCLUDES");
		if (param !=null) {
			int startInd = param.indexOf("[") + 1;
			if (startInd > 0) {
				String val = param.substring(startInd, param.indexOf("]") );

				String[] valA = val.split("\\,");
				List lis = (List) Arrays.asList(valA);
				
				for (int k=0; k<possibleBucketMap.size(); k++) {			
					if (k < 5)
						removeValues(possibleBucketMap.get(k),lis);
					else
						removeValues(possibleBucketMap.get(k),lis);
				}
			}
		}
		
		
		Iterator attIt = null;
		
		if (attributes.size() > 0)
			attIt = attributes.iterator();
		else {
			ResultsWithinLastN lastN = new ResultsWithinLastN();
			List l = lastN.getColumnNames();
			
			attIt = l.iterator();
		}
		
		while (attIt.hasNext()) {

			String attName = ((String) attIt.next()).toUpperCase();
			param = DBpredicProp.getProperty(attName);

			if (param != null && param.length() > 0) {
				out += "\r\n" + attName + " " + param + " -> ";
				int startInd = param.indexOf("[") + 1;
				if (startInd > 0) {
					String val = param.substring(startInd, param.indexOf("]") );

					String[] valA = val.split("\\,");
					List lis = (List) Arrays.asList(valA);

					if (startInd > 1) {// Prediction was a NOT
						out += "NOT ";
					}
					
					if (attName.endsWith("VALUE")) {
						out += lis;
						if (attName.startsWith("FIRST")) processValueList(0,param,(startInd > 1)?false:true);
						if (attName.startsWith("SECOND")) processValueList(1,param,(startInd > 1)?false:true);
						if (attName.startsWith("THIRD")) processValueList(2,param,(startInd > 1)?false:true);
						if (attName.startsWith("FOURTH")) processValueList(3,param,(startInd > 1)?false:true);
						if (attName.startsWith("FIFTH")) processValueList(4,param,(startInd > 1)?false:true);
						
						if (attName.startsWith("MEGA")) processValueList(5,param,(startInd > 1)?false:true);
					}
					
					if (attName.endsWith("SKIP")) {
						
						 if (attName.startsWith("MEGA")) {
							 if (valA.length > 1) {
								for (int i=0; i< valA.length; i++) {
									out += cse.getValuesForSkip(inGameCode, "ME", Integer.parseInt(valA[i])) + "-";
								}
							 }
						 } else {
							 if (!valA.equals("null") && valA.length > 1) {
								 for (int i=0; i< valA.length; i++) {
									out += cse.getValuesForSkip(inGameCode, "FF", Integer.parseInt(valA[i])) + "-";
								}
							 }
						 }
						
						if (attName.startsWith("FIRST")) processSkipList(attName, 0,param,(startInd > 1)?false:true);
						if (attName.startsWith("SECOND")) processSkipList(attName,1,param,(startInd > 1)?false:true);
						if (attName.startsWith("THIRD")) processSkipList(attName,2,param,(startInd > 1)?false:true);
						if (attName.startsWith("FOURTH")) processSkipList(attName,3,param,(startInd > 1)?false:true);
						if (attName.startsWith("FIFTH")) processSkipList(attName,4,param,(startInd > 1)?false:true);
						
						if (attName.startsWith("MEGA")) processSkipList(attName,5,param,(startInd > 1)?false:true);
					}
					
					if (attName.endsWith("REDUX")) {
												
						if (attName.startsWith("FIRST")) processReduxList(0,param,(startInd > 1)?false:true);
						if (attName.startsWith("SECOND")) processReduxList(1,param,(startInd > 1)?false:true);
						if (attName.startsWith("THIRD")) processReduxList(2,param,(startInd > 1)?false:true);
						if (attName.startsWith("FOURTH")) processReduxList(3,param,(startInd > 1)?false:true);
						if (attName.startsWith("FIFTH")) processReduxList(4,param,(startInd > 1)?false:true);
						
						if (attName.startsWith("MEGA")) processReduxList(5,param,(startInd > 1)?false:true);
					}
					
					
					if (attName.endsWith("BUCKET") ) {						
						
						if (attName.startsWith("FIRST") && !attName.endsWith("SUMBUCKET")) processBucketList(0,param,(startInd > 1)?false:true);
						if (attName.startsWith("SECOND")) processBucketList(1,param,(startInd > 1)?false:true);
						if (attName.startsWith("THIRD")) processBucketList(2,param,(startInd > 1)?false:true);
						if (attName.startsWith("FOURTH")) processBucketList(3,param,(startInd > 1)?false:true);
						if (attName.startsWith("FIFTH")) processBucketList(4,param,(startInd > 1)?false:true);
						
						if (attName.startsWith("MEGA")) processBucketList(5,param,(startInd > 1)?false:true);
					}
					
					if (attName.endsWith("FOLLOWER")
							//&& !attName.startsWith("MEGA")
							) {
						
						if (attName.startsWith("FIRST")) processFollowerList(attName,0,param,(startInd > 1)?false:true);
						if (attName.startsWith("SECOND")) processFollowerList(attName,1,param,(startInd > 1)?false:true);
						if (attName.startsWith("THIRD")) processFollowerList(attName,2,param,(startInd > 1)?false:true);
						if (attName.startsWith("FOURTH")) processFollowerList(attName,3,param,(startInd > 1)?false:true);
						if (attName.startsWith("FIFTH")) processFollowerList(attName,4,param,(startInd > 1)?false:true);
						
						if (attName.startsWith("MEGA")) processFollowerList(attName,5,param,(startInd > 1)?false:true);
					}
					

				}
			}
		}
		return out;
	}
	

	private static void preprocessBucketMap() {
		possibleBucketMap = new ArrayList<ArrayList<Integer>>();
		possibleBucketMap.add(new ArrayList(Arrays.asList(1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39)));
		possibleBucketMap.add(new ArrayList(Arrays.asList(1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50)));
		possibleBucketMap.add(new ArrayList(Arrays.asList(1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64,65,66,67,68,69)));
		possibleBucketMap.add(new ArrayList(Arrays.asList(10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64,65,66,67,68,69,70,71,72,73,74,75)));
		possibleBucketMap.add(new ArrayList(Arrays.asList(20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64,65,66,67,68,69,70,71,72,73,74,75)));
		
		possibleBucketMap.add(new ArrayList(Arrays.asList(1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46)));
		
		ArrayList<String> ffNotList = new ArrayList<String>();
		ArrayList<String> meNotList = new ArrayList<String>();
		
		
		
		for (int x=1; x<75;x++) {
			if (x > Integer.parseInt(gte.getMaximumValue()))
				ffNotList.add(Integer.toString(x));
			
			if (x > Integer.parseInt(gte.getMaxMegaValue()))
				meNotList.add(Integer.toString(x));
		}
		
		for (int k=0; k<possibleBucketMap.size(); k++) {			
			if (k < 5)
				removeValues(possibleBucketMap.get(k),ffNotList);
			else
				removeValues(possibleBucketMap.get(k),meNotList);
		}
		
		
	}
	
	private static void processFollowerList(String attName, int index, String param, boolean b) {
		int startInd = param.indexOf("[") + 1;
		String val = param.substring(startInd, param.indexOf("]") );

		String[] valA = val.split("\\,"); 
		
		
		String vals = "";
		if (startInd > 1) { // is a NOT list
			
			vals += rhe.getFollowers(attName, Integer.parseInt(inGameCode), 0);
			
			String[] avals = vals.split("\\,");
			List lis = (List) Arrays.asList(avals);
			if (valA[0].equals("Y"))
				removeValues(possibleBucketMap.get(index),lis);
			else
				selectValues(possibleBucketMap.get(index),lis);				
			
		} else {
			vals += rhe.getFollowers(attName, Integer.parseInt(inGameCode), 0);
			String[] avals = vals.split("\\,");
			List lis = (List) Arrays.asList(avals);
			
			if (valA[0].equals("Y"))
				selectValues(possibleBucketMap.get(index),lis);
			else
				removeValues(possibleBucketMap.get(index),lis);

			
		}
		
 	}

	private static void processBucketList(int index, String param, boolean b) {
		int startInd = param.indexOf("[") + 1;
		String val = param.substring(startInd, param.indexOf("]") );

		String[] valA = val.split("\\,"); 
		List lis = (List) Arrays.asList(valA);
		ArrayList arrayList = possibleBucketMap.get(index);
				
		if (startInd >= 1) {   
			ArrayList<Integer> removeList = new ArrayList<Integer>();
			if (arrayList != null && arrayList.size() > 0) {
				ListIterator it = arrayList.listIterator(arrayList.size());
				
				while (it.hasPrevious()) {
					Integer value = (Integer) it.previous();
					
					if (startInd > 1) {  // NOT list
						if (lis.contains(Integer.toString(value/10))) removeList.add(value);
					} else {
						if (!lis.contains(Integer.toString(value/10))) removeList.add(value);
					}
				}
				
				for(Integer removeEntry : removeList) {
			         arrayList.remove(removeEntry);
			      }
			}
		} else {
			//selectValues(possibleBucketMap.get(index),lis);
		}
		
	}

	private static void processReduxList(int index, String param, boolean isInclude) {
		int startInd = param.indexOf("[") + 1;
		String val = param.substring(startInd, param.indexOf("]") );

		String[] valA = val.split("\\,"); 
		List lis = (List) Arrays.asList(valA);
		ArrayList arrayList = possibleBucketMap.get(index);
		
		if (param.indexOf("ODD") > 0 || param.indexOf("EVEN") > 0) {
			
			ArrayList<Integer> removeList = new ArrayList<Integer>();
			if (arrayList != null && arrayList.size() > 0) {
				ListIterator it = arrayList.listIterator(arrayList.size());
				
				while (it.hasPrevious()) {
					Integer value = (Integer) it.previous();
					
					if (param.indexOf("ODD") > 0) {
						if (Integer.parseInt(Numbers.getRedux(Integer.toString(value))) % 2 == 0)	removeList.add(value);
					}
					
					if (param.indexOf("EVEN") > 0) {
						if (Integer.parseInt(Numbers.getRedux(Integer.toString(value))) % 2 > 0)	removeList.add(value);
					}
				}
				
				for(Integer removeEntry : removeList) {
			         arrayList.remove(removeEntry);
			      }
			}
		}
		
		
		if (startInd >= 1) {   
			ArrayList<Integer> removeList = new ArrayList<Integer>();
			if (arrayList != null && arrayList.size() > 0) {
				ListIterator it = arrayList.listIterator(arrayList.size());
				
				while (it.hasPrevious()) {
					Integer value = (Integer) it.previous();
					
					if (startInd > 1) {  // NOT list
						if (lis.contains(Numbers.getRedux(Integer.toString(value)))) removeList.add(value);
					} else {
						if (!lis.contains(Numbers.getRedux(Integer.toString(value)))) removeList.add(value);
					}
				}
				
				for(Integer removeEntry : removeList) {
			         arrayList.remove(removeEntry);
			      }
			}
		} else {
			//selectValues(possibleBucketMap.get(index),lis);
		}
		
	}

	private static void processValueList(int index, String param,	boolean isInclude) {
		int startInd = param.indexOf("[") + 1;
		String val = param.substring(startInd, param.indexOf("]") );

		String[] valA = val.split("\\,"); 
		List lis = (List) Arrays.asList(valA);
		
		if (param.indexOf("ODD") > 0) {
			removeEvens(possibleBucketMap.get(index));
		}
		
		if (param.indexOf("EVEN") > 0) {
			removeOdds(possibleBucketMap.get(index));
		}
		
		if (startInd > 1) { // is a NOT list
			removeValues(possibleBucketMap.get(index),lis);
		} else {
			selectValues(possibleBucketMap.get(index),lis);
		}
		
		
	}
	
	private static void selectValues(ArrayList<Integer> arrayList, List lis) {
		ArrayList<Integer> removeList = new ArrayList<Integer>();
		if (arrayList != null && arrayList.size() > 0) {
			ListIterator it = arrayList.listIterator(arrayList.size());
			
			while (it.hasPrevious()) {
				Integer val = (Integer) it.previous();
				
				if (!lis.contains(Integer.toString(val)))
					removeList.add(val);
			}
			
			for(Integer removeEntry : removeList) {
		         arrayList.remove(removeEntry);
		      }
		}
		
	}

	private static void removeValues(ArrayList<Integer> arrayList, List lis) {
		ArrayList<Integer> removeList = new ArrayList<Integer>();
		if (arrayList != null && arrayList.size() > 0) {
			ListIterator it = arrayList.listIterator(arrayList.size());
			
			while (it.hasPrevious()) {
				Integer val = (Integer) it.previous();
				
				if (lis.contains(Integer.toString(val)))
					removeList.add(val);
			}
			
			for(Integer removeEntry : removeList) {
		         arrayList.remove(removeEntry);
		      }
		}
		
	}

	private static void processSkipList(String attName, int index, String param,	boolean isInclude) {
		int startInd = param.indexOf("[") + 1;
		String val = param.substring(startInd, param.indexOf("]") );
		

		String[] valA = val.split("\\,"); 
		
		if (param.indexOf("ODD") > 0) {
			String vals = cse.getValuesForOddSkip(inGameCode, "FF");
			String[] avals = vals.split("\\,");
			List lis = (List) Arrays.asList(avals);
			selectValues(possibleBucketMap.get(index),lis);
		}
		
		if (param.indexOf("EVEN") > 0) {
			String vals = cse.getValuesForEvenSkip(inGameCode, "FF");
			String[] avals = vals.split("\\,");
			List lis = (List) Arrays.asList(avals);
			selectValues(possibleBucketMap.get(index),lis);
		}
		String vals = "";
		if (startInd > 1) { // is a NOT list
			
			if (attName.startsWith("MEGA")) {
				for (int i=0; i< valA.length; i++) {
					String value = cse.getValuesForSkip(inGameCode, "ME", Integer.parseInt(valA[i]));
					vals += ((value.length() > 0)?value:"") + ",";
				}
			} else {
				for (int i=0; i< valA.length; i++) {
					String value = cse.getValuesForSkip(inGameCode, "FF", Integer.parseInt(valA[i]));
					vals += ((value.length() > 0)?value:"") + ",";
				}
			}
			
			String[] avals = vals.split("\\,");
			List lis = (List) Arrays.asList(avals);
			removeValues(possibleBucketMap.get(index),lis);
			
		} else {
			if (attName.startsWith("MEGA")) {
				for (int i=0; i< valA.length; i++) {
					String value = cse.getValuesForSkip(inGameCode, "ME", Integer.parseInt(valA[i]));
					vals += ((value.length() > 0)?value:"") + ",";
				}
			} else {
				for (int i=0; i< valA.length; i++) {
					String value = cse.getValuesForSkip(inGameCode, "FF", Integer.parseInt(valA[i]));
					vals += ((value.length() > 0)?value:"") + ",";
				}
			}
			String[] avals = vals.split("\\,");
			List lis = (List) Arrays.asList(avals);
			selectValues(possibleBucketMap.get(index),lis);

			
		}
		
	}

	private static ArrayList<Integer> removeEvens(ArrayList<Integer> arrayList) {

		ArrayList<Integer> removeList = new ArrayList<Integer>();
		if (arrayList != null && arrayList.size() > 0) {
			ListIterator it = arrayList.listIterator(arrayList.size());
			
			while (it.hasPrevious()) {
				Integer val = (Integer) it.previous();
				
				if (val % 2 == 0)
					removeList.add(val);
			}
			
			for(Integer removeEntry : removeList) {
		         arrayList.remove(removeEntry);
		      }
		}
		
		return arrayList;
	}
	
	private static ArrayList<Integer> removeOdds(ArrayList<Integer> arrayList) {

		ArrayList<Integer> removeList = new ArrayList<Integer>();
		if (arrayList != null && arrayList.size() > 0) {
			ListIterator it = arrayList.listIterator(arrayList.size());
			
			while (it.hasPrevious()) {
				Integer val = (Integer) it.previous();
				
				if (val % 2 != 0)
					removeList.add(val);
			}
			
			for(Integer removeEntry : removeList) {
		         arrayList.remove(removeEntry);
		      }
		}
		
		return arrayList;
	}


	public static String getInPrgCode() {
		return inPrgCode;
	}

	public static void setInPrgCode(String inPrgCode) {
		ProcessIndivDBPredicFile.inPrgCode = inPrgCode;
	}

} 
