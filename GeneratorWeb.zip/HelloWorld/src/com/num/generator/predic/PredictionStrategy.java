package com.num.generator.predic;

import java.util.ArrayList;
import java.util.List;

public abstract class PredictionStrategy {
	
	private String strategyName;
	private String strategyDesc;
	private String strategyCode;
	
	private int testSampleSize = 200;
	private int predictionAccuracyPercent;
	private float predictionDivergence;
	
	private ArrayList<String> predictionPerformanceHistory = new ArrayList<String>();
	
	abstract public String predictForGameCodeAndAttribute(int gameCode, String attribute, int serialNumber);
	abstract public String predictForData(List<Integer> data);
	
	abstract public void testStrategy(int gameCode, String attribute);
	
	abstract public void saveResult(int gameCode, String attribute);
	
	abstract public void getLastThreePerformanceAndUpdatePrediction(int gameCode, String attribute);
	
	
	public String getStrategyName() {
		return strategyName;
	}
	public void setStrategyName(String strategyName) {
		this.strategyName = strategyName;
	}
	public String getStrategyDesc() {
		return strategyDesc;
	}
	public void setStrategyDesc(String strategyDesc) {
		this.strategyDesc = strategyDesc;
	}
	public String getStrategyCode() {
		return strategyCode;
	}
	public void setStrategyCode(String strategyCode) {
		this.strategyCode = strategyCode;
	}
	public int getPredictionAccuracyPercent() {
		return predictionAccuracyPercent;
	}
	public void setPredictionAccuracyPercent(int predictionAccuracyPercent) {
		this.predictionAccuracyPercent = predictionAccuracyPercent;
	}
	public ArrayList<String> getPredictionPerformanceHistory() {
		return predictionPerformanceHistory;
	}
	public void setPredictionPerformanceHistory(ArrayList<String> predictionPerformance) {
		this.predictionPerformanceHistory = predictionPerformance;
	}
	public int getTestSampleSize() {
		return testSampleSize;
	}
	public void setTestSampleSize(int testSampleSize) {
		this.testSampleSize = testSampleSize;
	}
	
	public float getPredictionDivergence() {
		return predictionDivergence;
	}
	public void setPredictionDivergence(float predictionDivergence) {
		this.predictionDivergence = predictionDivergence;
	}
	

}
