package com.num.generator.predic;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.TreeMap;

import com.num.generator.dataaccess.ResultHistoryEntity;
import com.num.generator.dataaccess.ResultsWithinLastN;


public class LastnBackTest { 

	private static int blanks = 0;
	private static boolean suppressVerboseOut = true;
	
	private static String inGameCode = "1"; // Mandatory
	public static String getInGameCode() {
		return inGameCode;
	}

	public static void setInGameCode(String inGameCode) {
		LastnBackTest.inGameCode = inGameCode;
	}

	private static int numberOfSerials = 15;  // Mandatory
	private static int maxfuture = 5;   // Mandatory
	private static int onlyThisFuture = 0; // Mandatory
	
	private static boolean doesExist = true;  // Mandatory
	
	private static Hashtable summaryResults = new Hashtable();
	private static HashMap attributeBlanksMap = new HashMap();
	private static int evaluationCount = 0;  // This is how many times an attribute was evaluated
	private static int lastSerial = 0; 
	private static int maxSerial;
	
	static HashMap resultFreq = new HashMap();
	static int NOTCountInThisDraw = 0;
	static int NOTCountInThisDrawThatMatch = 0;
	static HashMap recentSerialBehaviour = new HashMap();
	private static HashSet predTypeSet = new HashSet();
	private static HashMap completePredTypeSet = new HashMap();
	private static HashMap completePredictionMap = new HashMap();
	private static ResultHistoryEntity rhe = new ResultHistoryEntity();
	private static ResultsWithinLastN lastN = new ResultsWithinLastN();
	
	public static void main(String[] arg) {
		long start = System.currentTimeMillis();
		
		
				
						/*for (int i=1; i<=2; i++) {
							System.out.print("Game " + i + " serial ");
							lastN.setGameCode(Integer.toString(i));
							ArrayList l = lastN.getMissingSerialsForGame(Integer.toString(i));
							
							Iterator it = l.iterator();
							
							while (it.hasNext()) {
								Integer thisSerial = (Integer)it.next();
								System.out.print( thisSerial + " withinLast ");
								for (int j=3; j< 25; j++) {
									lastN.executeLastNProcsForSerial(i, j, thisSerial.intValue());
									System.out.print( j + " ");
								}
								System.out.println("");
							}
						}*/
						
		int future = 0;
		for (int i=0; i< numberOfSerials; i++) {
			
			for (int j=1;j<=maxfuture;j++) {
				
				future = j;
				
				if (onlyThisFuture > 0 && onlyThisFuture != future) {
					continue;
				}
				
				maxSerial =  Integer.parseInt(rhe.getValueForField("serialNumber",inGameCode,0));
				
				lastSerial = maxSerial - numberOfSerials + i;
				
				if (future + lastSerial > maxSerial){
					continue;
				}
				
				
				NOTCountInThisDraw = 0;
				NOTCountInThisDrawThatMatch = 0;
				
				blanks = 0;
				//allTypeSet = new HashSet();
				
				completePredTypeSet.put("firs", new HashSet());
				completePredTypeSet.put("seco", new HashSet());
				completePredTypeSet.put("thir", new HashSet());
				completePredTypeSet.put("four", new HashSet());
				completePredTypeSet.put("fift", new HashSet());
				completePredTypeSet.put("mega", new HashSet());
				predTypeSet = new HashSet();
				evaluationCount++;
				//lastN = new ResultsWithinLastN();
				
				int withinLast = 0;
				System.out.println( "Game " + inGameCode + " SerialNum : " + lastSerial + ((doesExist)?" Matches in ":" Violations in : ")  + " draw " + future);
				
	//			ResultHistoryEntity rhe = new ResultHistoryEntity();
				
				List l = lastN.getColumnNames();
				
				Iterator it = l.iterator();
				
				int countJumpMatch = 0;
				int stdevMatch = 0;
				
				while (it.hasNext()) {
					String fieldName = (String) it.next();
					
					//allTypeSet.add(fieldName.substring(fieldName.length()-4));
					
					withinLast = getWithinLastForField(fieldName, lastSerial);
					
					if (doesExist(fieldName, inGameCode, lastSerial, withinLast,future) == doesExist) {
						
						countJumpMatch++;
						String possibleValues = lastN.getValuesForFieldBasedOnWithinLast(fieldName, inGameCode, lastSerial,withinLast);
						
						if (possibleValues.length() > 0) {
							
							//predTypeSet.add(fieldName.substring(fieldName.length()-4));
							if (completePredTypeSet.get(fieldName.substring(0,4)) != null) {
								if (!fieldName.contains("Sum"))
								((HashSet)completePredTypeSet.get(fieldName.substring(0,4))).add(fieldName.substring(fieldName.length()-4));
							}
												
							if (!suppressVerboseOut) System.out.print(fieldName);
							if (!suppressVerboseOut) System.out.print(" : [" + possibleValues + "]" );
							if (!suppressVerboseOut) System.out.println(rhe.getValueForField(fieldName, inGameCode, (lastSerial >0)?lastSerial+future:0));
						} else {
							if ( !fieldName.endsWith("Prime") && !fieldName.endsWith("Follower") && !fieldName.endsWith("Bucket")) {
								String allEvenOrOdd = rhe.allOddOrEvenValuesInLastNDraws(fieldName, inGameCode, 4);
								
								if (allEvenOrOdd != null) {
									if (allEvenOrOdd.equals("EVEN")) {
										if (!suppressVerboseOut) System.out.print("ODD");
									} else {
										if (!suppressVerboseOut) System.out.print("EVEN");
									}
								}
							}
						}
						
						if (resultFreq.get(fieldName) != null) {
							ArrayList lis = (ArrayList)resultFreq.get(fieldName);
							lis.add(lastSerial+"-" + future);
						} else {
							ArrayList lis = new ArrayList();
							lis.add(lastSerial+"-" + future);
							resultFreq.put(fieldName, lis);
						}
						
						completePredictionMap.put(fieldName+"-" + lastSerial, getDBPredicLine(fieldName, inGameCode, lastSerial, withinLast));
						
					}							
				} 
				
				if (!suppressVerboseOut) System.out.println("");
				if (countJumpMatch > 0)
					if (!suppressVerboseOut) System.out.println("Blanks " + blanks + " Percent " + blanks*100/l.size());
				
				int percents = ((doesExist)?countJumpMatch:countJumpMatch-blanks)*100/(l.size()-blanks);
				int NOTpercents = NOTCountInThisDraw*100/(l.size());
				int NOTpercentsWithMatch = NOTCountInThisDrawThatMatch*100/NOTCountInThisDraw;
				if (countJumpMatch > 0)
					if (!suppressVerboseOut) System.out.println(" -- Percent " + ((doesExist)?" Matches ":" Violations : ") + percents);
				
				if (countJumpMatch > 0)
					if (!suppressVerboseOut) System.out.println(((doesExist)?"Matches ":"Violations : ") + ((doesExist)?countJumpMatch:countJumpMatch-blanks) + ((doesExist)?" Violations ":" Matches : ") + (l.size()-blanks - countJumpMatch));
				
				//System.out.println(((doesExist)?"Matches ":"Violations : ") + predTypeSet + " Out of " + allTypeSet);
				System.out.println(((doesExist)?"Predicted ":"Failed to predict : ") + completePredTypeSet);
				
				if (!suppressVerboseOut) System.out.println("");
				if (!suppressVerboseOut) System.out.println("");
				if (summaryResults.get(lastSerial) == null) {
					Hashtable innerT = new Hashtable();
					innerT.put(future,percents + "-" + NOTpercents + "-" + NOTpercentsWithMatch);
					summaryResults.put(lastSerial , innerT);
				} else {
					((Hashtable)summaryResults.get(lastSerial)).put(future,percents + "-" + NOTpercents + "-" + NOTpercentsWithMatch);
				}
			//	System.out.println("Serial number " + lastSerial + " Exclude count out of " + l.size() + " " + (Integer)includeExcludeFreq.get("NOT"));
			}
			lastSerial++;
		}
		
		System.out.println(printSummaryTable(summaryResults));
		
		ArrayList<Map.Entry<String, ArrayList<String>>> list = new ArrayList<Map.Entry<String, ArrayList<String>>>();
	    list.addAll(resultFreq.entrySet());
	    
	    Collections.sort(list, new Comparator<Map.Entry<String,ArrayList<String>>>(){
	        public int compare(Map.Entry<String, ArrayList<String>> o1,
	                           Map.Entry<String, ArrayList<String>> o2) {

	            Integer size1 = (Integer) o1.getValue().size();
	            Integer size2 = (Integer) o2.getValue().size();
	            return size2.compareTo(size1);
	        }
	    });
	    
	    Iterator it = list.iterator();
	    while(it.hasNext()) {
	    	Entry e = (Entry) it.next();
	    	String[] arr = new String[((ArrayList)e.getValue()).size()];
	    	((ArrayList)e.getValue()).toArray(arr);
	    	
	    	String [] outArr = new String[]{"","","","","","","",""};
	    	int j =1;
	    	
	    	if (arr.length > 8) {
		    	for (int i=arr.length-1; i > arr.length-9; i--) {
		    		outArr[outArr.length-j] = arr[i];
		    		j++;
		    	}
	    	} else {
	    		for (int i=0; i < arr.length; i++) {
		    		outArr[i] = arr[i];
		    		
		    	}
	    	}
	    	
	    	String totalMatchBlank = "";
	    	int percen = 0;
	    	if (attributeBlanksMap.get(e.getKey()) == null) {
	    		totalMatchBlank = evaluationCount + "-" + ((ArrayList)e.getValue()).size() + "-0" ;
	    		percen = (((ArrayList)e.getValue()).size()*100)/(evaluationCount);
	    	} else {
	    		totalMatchBlank = evaluationCount + "-" + ((ArrayList)e.getValue()).size() + "-" + attributeBlanksMap.get(e.getKey());
	    		percen = (((ArrayList)e.getValue()).size()*100)/(evaluationCount-(Integer)attributeBlanksMap.get(e.getKey()));
	    	}
	    	
	    	/// AMONG LAST 7 matches for this attribute which of the last 4 serials has most matches
	    	if (percen >=80) {
	    		// FOR High percentage match fields, use the last serial
	    		String f = (String)e.getKey();
	    		System.out.println("OUT " + (e.getKey()+"-"+maxSerial) + " - " + getDBPredicLine(f, inGameCode, maxSerial, getWithinLastForField(f, maxSerial)));
	    	}
	    	if (percen < 80 && percen >  50) {
	    		int overRepresentedSerial = 0;
	    		int tempCount = 0;
	    		int prevTempCount = 0;
	    		for (int p= maxSerial-4; p<=maxSerial; p++) {
	    			prevTempCount = tempCount;
	    			tempCount = 0;
	    			for (int k= 0; k< outArr.length; k++) {
	    				if (outArr[k].startsWith(Integer.toString(p))) {
	    					tempCount++;
	    				}
	    			}
	    			
	    			if (tempCount >= prevTempCount)
	    				overRepresentedSerial = p;
	    				
	    		}
	    		
	    		if (overRepresentedSerial > 0) {
	    			
	    			if (recentSerialBehaviour.get(overRepresentedSerial) == null) {
	    				ArrayList atts = new ArrayList();
		    			atts.add(e.getKey());
		    			recentSerialBehaviour.put(overRepresentedSerial, atts);
	    			} else {
	    				((ArrayList)recentSerialBehaviour.get(overRepresentedSerial)).add(e.getKey());
	    			}
	    			
	    			System.out.println("OUT " + (e.getKey()+"-"+overRepresentedSerial) + " - " + completePredictionMap.get(e.getKey()+"-"+overRepresentedSerial));
	    		}
	    	}
	    	//System.out.println(e.getKey() + " -- " + totalMatchBlank + " " + percen + "%" + " - "+ Arrays.asList(outArr));
	    	
	    	
	    }
	    System.out.println(recentSerialBehaviour);
		System.out.println("");
		System.out.println("Time taken to process Backtest for gameCode " + inGameCode + " : " + (System.currentTimeMillis()-start)/1000 + " sec");
		
	}
	
	private static String getDBPredicLine(String fieldName, String gameCode, int serialNum, int withinLast) {
		String paramLine = CreateDBPredicFile.createDBPredicLine(fieldName, inGameCode, serialNum, withinLast);
		
		if ( !fieldName.endsWith("Prime") && !fieldName.endsWith("Follower") && !fieldName.endsWith("Bucket")) {
			ResultHistoryEntity rhe = new ResultHistoryEntity();
			String allEvenOrOdd = rhe.allOddOrEvenValuesInLastNDraws(fieldName, inGameCode, 4);
			
			if (allEvenOrOdd != null) {
				if (allEvenOrOdd.equals("EVEN")) {
					paramLine += "ODD";
				} else {
					paramLine += "EVEN";
				}
			}
		}
		return paramLine;
	}
	
	private static String printSummaryTable(Hashtable summaryResults2) {
		List<Integer> tmp = Collections.list(summaryResults2.keys());
	    Collections.sort(tmp);
	    Iterator<Integer> it = tmp.iterator();
	    String header = "\t";
	    String out = "";
	    int counter = 0;

	    while(it.hasNext()){
	    	Integer element =it.next();
	    	out += element + " |\t ";
	    	Hashtable inner = (Hashtable)summaryResults2.get(element);
	    	
	    	List<Integer> itmp = Collections.list(inner.keys());
		    Collections.sort(itmp);
		    Iterator<Integer> iit = itmp.iterator();

		    while(iit.hasNext()){
		    	Integer ielement =iit.next();
		    	if (counter == 0) header += ielement + "\t";
		    	
		    	String val = (String)inner.get(ielement);
		    	
		    	out += val + "\t";
		        //here you can get ordered things: 'your_hashtable'.get(element);
		    }
		    if (counter == 0) header += "\r\n";
		    out += "\r\n";
		    counter++;
	    }
		return header + out;
	}

	private static boolean doesExist(String fieldName, String gameCode, int serialNum, int withinLast, int future) {
		
		boolean out = false;
	//	ResultsWithinLastN lastN = new ResultsWithinLastN();
		int lastNValueForField = lastN.getLastNValueFor(fieldName, gameCode, serialNum, withinLast);
		
		int predValueForLastN = lastN.predictLastNValueFor(fieldName, gameCode, serialNum, withinLast);
		//int predValueForLastN = lastN.predictLastNValueBasedOnLast2For(fieldName, gameCode, serialNum, withinLast);
		
		int maxLastNValueForField = lastN.getMaxLastNValueFor(fieldName, gameCode, serialNum, withinLast);
		
		if (predValueForLastN > 0) NOTCountInThisDraw++;
		
		if (serialNum > 0) {
						
			String possibleValues = lastN.getValuesForFieldBasedOnWithinLast(fieldName, gameCode, serialNum,withinLast);
			
			if (possibleValues.length() == 0) {
				
				if (attributeBlanksMap.get(fieldName) == null) {
					attributeBlanksMap.put(fieldName , 0);
				} else {
					int newCount = ((Integer)attributeBlanksMap.get(fieldName))+1;
					attributeBlanksMap.put(fieldName, newCount);
				}
				
				blanks++;
				return out;
			}
			
			List<String> list = new ArrayList<String>(Arrays.asList(possibleValues.split(",")));
			
			String realValue = rhe.getValueForField(fieldName, gameCode, (serialNum >0)?serialNum+future:0);
			
			if (realValue.length() > 0) {
				if (predValueForLastN >= 0) {
					
					if (predValueForLastN == 0) {
						if (list.contains(realValue)) {
							out = true;
						}
					} else {
						if (!list.contains(realValue)) {
							//if (!suppressVerboseOut) System.out.print(" : NOT ");
							out = true;
							NOTCountInThisDrawThatMatch++;
						}
					}
					
				} else {
					if (lastNValueForField == 0) {
						if (!list.contains(realValue)) {
							//if (!suppressVerboseOut) System.out.print(" : NOT ");
							out = true;
							
						}
					} else {
						
						if (lastNValueForField < maxLastNValueForField/2) {
							if (!list.contains(realValue)) {
								//if (!suppressVerboseOut) System.out.print(" : NOT ");
								out = true;
								
							}
						} else {
							if (list.contains(realValue))
								out = true;
						}
					}
				}
			} else {
				if (!suppressVerboseOut) System.out.println(" No real value found for " + fieldName + " serial " + ((serialNum >0)?serialNum+future:0) + " gameCode " + gameCode);
			}
		}
		
		if (out == doesExist) {
			if (!suppressVerboseOut) {
				if (predValueForLastN > 0) {
					System.out.print(" : NOT ");
						
				} else if (predValueForLastN < 0){
				
					if (lastNValueForField == 0) {
						System.out.print(" : NOT ");
						
					} else {
						if (lastNValueForField < maxLastNValueForField/2) {
							System.out.print(" : NOT ");
							
						}
					}
				}
			}
		}
			
		return out;
		
	}

	public static int getWithinLastForField(String fieldName, int useSerial) {
		int withinLast = 0;
		if ( fieldName.endsWith("Prime") || fieldName.endsWith("Follower")) {
			withinLast = 3;
		} else {
			
			if (fieldName.endsWith("Value")) {
				//withinLast = lastN.getWithinLastValuesForFieldBasedOnCountJump(fieldName, inGameCode, useSerial);
				withinLast = lastN.getWithinLastValuesForFieldBasedOnMaxFieldValue(fieldName, inGameCode, useSerial);
			} else {
				if (fieldName.endsWith("Skip") || fieldName.endsWith("Bucket"))
					withinLast = lastN.getWithinLastValuesForFieldBasedOnMaxFieldValue(fieldName, inGameCode, useSerial);
				else
					withinLast = lastN.getWithinLastValuesForFieldBasedOnMinFieldValue(fieldName, inGameCode, useSerial);
			//withinLast = lastN.getWithinLastValuesForFieldBasedOnSTDEV(fieldName, inGameCode, lastSerial);
			}
		}
		
		return withinLast;
	}
}
 