package com.num.generator.predic;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.lang3.StringUtils;

import net.sourceforge.htmlunit.corejs.javascript.tools.debugger.treetable.JTreeTable.ListToTreeSelectionModelWrapper;

import com.num.generator.Numbers;
import com.num.generator.dataaccess.CurrentStateEntity;
import com.num.generator.dataaccess.GameTypesEntity;
import com.num.generator.dataaccess.InclusionExclusionEntity;
import com.num.generator.dataaccess.ResultHistoryEntity;

// We want to analyze various outcomes depending on one or more combinations of
// predictions coming true.
public class PredictionScenarioAnalysis {
	
	private static String[] possibleIndivOutcome = {"T", "F"};
	private static String gameCode = "2";
	private static String attribute = "firstFiveSumBucket";
	private static int numberofpredictions = 4;
	
	public static void main(String [] args) {
		
		if (attribute.endsWith("FiveSum")) {
			System.out.println("Can not run this for firstFiveSum, try firstFiveSumBucket");
			return;
		}
		List<Integer> allValues = new ArrayList<Integer>();
		
		populateAllValues(allValues);		
		
		List<InclusionExclusionEntity> predictions = getCurrentPredictions(0);
		System.out.println(ListUtils.prettyPrintList(predictions, 15, 15));
		
		// Get the previous histories of actual prediction performance
		getHistoryOfPredicPerformance(20);
		
		
		// Now evaluate current predictions
		List<List<String>> possiblecollectiveOutcomes = new ArrayList<List<String>>();
		List<List<Integer>> valueslist = new ArrayList<List<Integer>>();		
		
		int includedprediccount = 0;
		for (InclusionExclusionEntity onepred: predictions) {
			
			if (includedprediccount == numberofpredictions)
				break;
			
			List<Integer> outcome = getPredictedValues(onepred);
			
			System.out.println("---" + onepred.getAttribute()+ "|" + onepred.getGameCode() + "|" + onepred.getAlgorithmType()+"|" + onepred.getInputDrawDate()+"|" + onepred.getTotalScore() + " " + outcome);
			
			if ( outcome != null && outcome.size() > 0) {
				possiblecollectiveOutcomes.add(Arrays.asList(possibleIndivOutcome));
				valueslist.add(outcome);
			}
			includedprediccount++;
		}
		
		System.out.println();
		if (possiblecollectiveOutcomes.size() > 1) {			
			
			// Get all possible states for all the predication
			// TTF, TFF, TTT etc
			List<List<String>> allPossibleOutcomes = ListUtils.cartesianProduct(possiblecollectiveOutcomes);

			for (List<String> thisoutcome: allPossibleOutcomes) {
				
				int counter = 0;
				List<Integer> listsofar = new ArrayList<Integer>();
				for (List<Integer> thislist:  valueslist) {
					if (counter == 0) {
						if (thisoutcome.get(counter).equals("T"))
							listsofar = ((List) ((ArrayList) thislist).clone());
						else {
							List<Integer> notValues = ((List<Integer>) ((ArrayList) allValues).clone());
							notValues.removeAll(thislist);
							listsofar = notValues;
						}
					} else {
						if (thisoutcome.get(counter).equals("T"))
							listsofar.retainAll(thislist);
						else {
							List<Integer> notValues = ((List<Integer>) ((ArrayList) allValues).clone());
							notValues.removeAll(thislist);
							listsofar.retainAll(notValues);
						}
							
					}
					counter++;
				}
				
				if (listsofar.size() > 0) {
					int truecount = 0;
					
					for (String oneoutcome: thisoutcome) {
						if (oneoutcome.equalsIgnoreCase("T"))
							truecount++;
					}
					
					System.out.println((truecount*100/thisoutcome.size()) + " | " + joinValuesInList(thisoutcome) + " | " + listsofar);
					//System.out.println(listsofar);
				}
			}
		} else {
			System.out.println("Not enough results to create combinations...");
		}
		
		
			
		
	}
	
	private static void getHistoryOfPredicPerformance(int evaluateLastNPerformances) {
		if (evaluateLastNPerformances == 0)
			evaluateLastNPerformances = 20;
		
		ResultHistoryEntity rhe =  new ResultHistoryEntity();
		rhe.setGameCode(gameCode);
		
		String lastdates = rhe.getLastNForAttribute("dateOfDraw", evaluateLastNPerformances, 0);
		String [] datesarr = lastdates.split(","); 
		
		for (int i=1; i<datesarr.length; i++) {
			String predperformance = "";
			
			int avgtotalscore = 0;
			
			rhe.setDateOfDraw(datesarr[i-1]);
			Collection<ResultHistoryEntity> nextres = rhe.findRows();
			if (nextres.size() == 1) {
				List<InclusionExclusionEntity> prevpreds = getPredictionsAsonDate(numberofpredictions,datesarr[i]);				
				
				for (InclusionExclusionEntity oneprevpred: prevpreds) {
					String attributeval = rhe.getLastNForAttribute(oneprevpred.getAttribute(), 1, Integer.parseInt(nextres.iterator().next().getSerialNumber()));
					
					String performance = getPredictionPerformanceForSubAttribute(oneprevpred, Integer.parseInt(attributeval));
					
					predperformance += performance;
				
					avgtotalscore += Math.abs(Integer.parseInt(oneprevpred.getTotalScore()));
				}
				
			}
			if (predperformance.length() > 0)
				System.out.println(datesarr[i] + " | " + predperformance + " | " + (StringUtils.countMatches(predperformance, "T")*100/predperformance.length())+ " | " + avgtotalscore/4);
			else
				System.out.println("No predictions..");
			
		}
		
	}
	
	public static String joinValuesInList(List<String> l) {
		String out = "";
		
		for (String val: l) {
			out += val;
		}
		
		return out;
	}

	public static void populateAllValues(List<Integer> allValues) {
		GameTypesEntity gte =  new GameTypesEntity();
		gte.setGameCode(gameCode);
		int max = 0;
		
		Collection res = gte.findRows();
		
		Iterator it = res.iterator();
		while (it.hasNext()) {
			GameTypesEntity oneent = (GameTypesEntity) it.next();
			
			if (attribute.equalsIgnoreCase("mega"))
				max = Integer.parseInt(oneent.getMaxMegaValue());
			else {
				if (attribute.contains("Sum")) {
					if (attribute.contains("Bucket")) {
						max = 28;
					} else {
						max = 280;
					}
				} else
					max = Integer.parseInt(oneent.getMaximumValue());
			}
		}
		
		if (max > 0) {
			for (int i=1; i<= max; i++) {
				allValues.add(i);
			}
		}
		
		
	}

	public static List<Integer> getPredictedValues(
			InclusionExclusionEntity onepred) {
		
			CurrentStateEntity cs = new CurrentStateEntity();
			cs.setGameCode(onepred.getGameCode());
			//System.out.println("---" + onepred.getAttribute()+ "|" + onepred.getGameCode() + "|" + onepred.getAlgorithmType()+"|" + onepred.getInputDrawDate()+"|" + onepred.getTotalScore());
			return cs.getIndivAttributeValuesBasedOnPrediction(onepred);
		
	}
	
	public static String getPredictionPerformanceForSubAttribute(InclusionExclusionEntity onepred, Integer outcome) { // This is whether the prediction came true or not
																															// This can not come from CurrentState..
		String out = "";	
		if (onepred.getAlgorithmType().equals(InclusionExclusionEntity.ALGORITHM_TYPE_ASC_DESC_PATTERNS)) {			
			
			if (onepred.getData().get(0) > 0) {
				if (outcome > onepred.getData().get(0))
					out = "T";
				else
					out = "F";
			}
			
			if (onepred.getData().get(0) < 0) {
				if (outcome < (0 - onepred.getData().get(0)) )
					out = "T";
				else
					out = "F";
			}
		}
		
		if (onepred.getAlgorithmType().equals(InclusionExclusionEntity.ALGORITHM_TYPE_PRIME_NONPRIME_PATTERNS)) {
			
			if (onepred.getData().get(0) == 0) {
				if (Numbers.primesTill75.contains(outcome))
					out = "F";
				else
					out = "T";
			}
			if (onepred.getData().get(0) == 1) {
				if (Numbers.primesTill75.contains(outcome))
					out = "T";
				else
					out = "F";
			}
			
		}
		
		if (onepred.getAlgorithmType().equals(InclusionExclusionEntity.ALGORITHM_TYPE_EVEN_ODD_PATTERNS)) {
			
			if (onepred.getData().get(0) > 0) {
				if (outcome % 2 == 0)
					out = "T";
				else
					out = "F";
			}
			
			if (onepred.getData().get(0) < 0) {
				if (outcome % 2 == 0)
					out = "F";
				else
					out = "T";
			}
		}
		
		if (onepred.getAlgorithmType().equals(InclusionExclusionEntity.ALGORITHM_TYPE_DIST_FREQ_SAME_DIFF)) {
			
			if (onepred.getData().contains(outcome)) 
				out = "T";
			else
				out = "F";			
			
		}
		
		// We have the outcome based on 'true' isInclusion, now reverse it if needed
		
		if (onepred.getIsInclusionInd().equalsIgnoreCase("False"))
			out = (out == "T")?"F":"T";
		
		//System.out.println(out + "---" + onepred.getAttribute()+ "|" + onepred.getGameCode() + "|" + onepred.getAlgorithmType()+"|" + "|" + onepred.getIsInclusionInd()+"|" + onepred.getInputDrawDate()+"|" + onepred.getTotalScore());
		
		return out;
		
	}

	public static List<InclusionExclusionEntity> getCurrentPredictions(
			int numberofpredictions) {
		InclusionExclusionEntity ent = new InclusionExclusionEntity();
		ent.setGameCode(gameCode);
		ent.setAttribute(attribute);
		
		List<InclusionExclusionEntity> results = ent.getLatestPredictionsForAttribute(numberofpredictions);
		String firstdrawdate = null;
		List<InclusionExclusionEntity> clearfromres = new ArrayList<InclusionExclusionEntity>();
		
		for (InclusionExclusionEntity thisent: results) {
			if (attribute.equalsIgnoreCase("first")) { /// we need to filter out results for firstfivesum
					if (thisent.getAttribute().contains("FiveSum"))
						clearfromres.add(thisent);
			}
			
			if (firstdrawdate == null)
				firstdrawdate = thisent.getInputDrawDate();
			else {
				if (!thisent.getInputDrawDate().equals(firstdrawdate))
					clearfromres.add(thisent);
			}
		}
		
		if (clearfromres.size() > 0)
			results.removeAll(clearfromres);
		
		return results;
	}
	
	public static List<InclusionExclusionEntity> getPredictionsAsonDate(int numberofpredictions, String sdate) {
		InclusionExclusionEntity ent = new InclusionExclusionEntity();
		ent.setGameCode(gameCode);
		ent.setAttribute(attribute);
		
		List<InclusionExclusionEntity> results = ent.getPredictionsForAttributeAsOnDate(0, sdate);
		
		if (results.size() > numberofpredictions) {
			return results.subList(0, numberofpredictions);
		}
		
		
		return results;
	}

	public static String getGameCode() {
		return gameCode;
	}

	public static void setGameCode(String gameCode) {
		PredictionScenarioAnalysis.gameCode = gameCode;
	}

	public static String getAttribute() {
		return attribute;
	}

	public static void setAttribute(String attribute) {
		PredictionScenarioAnalysis.attribute = attribute;
	}
	
	

}
