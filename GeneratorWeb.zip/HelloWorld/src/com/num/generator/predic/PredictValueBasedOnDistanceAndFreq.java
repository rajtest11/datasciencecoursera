package com.num.generator.predic;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.LinkedHashMap;
import java.util.List;

import org.apache.commons.lang3.StringUtils;

import com.num.generator.dataaccess.InclusionExclusionEntity;
import com.num.generator.dataaccess.ResultHistoryEntity;

public class PredictValueBasedOnDistanceAndFreq extends PredictionStrategy {

	private String strategyName="DistanceFreqCombinationEvenOrOdd";
	private String strategyDesc="Tries to predict whether distance and freq for this"
								+ "	attribute likely to be same or different";
	private String strategyCode = "DIST_FREQ_SAME_DIFF_EVEN_ODD";
	
	private LinkedHashMap<Integer,ArrayList<Integer>> distData = null;
	private LinkedHashMap<Integer,ArrayList<Integer>> valueDistanceFreqMap = null;
	private ArrayList<Integer> distanceHistList = new ArrayList<Integer>();
	private ArrayList<Integer> freqHistList = new ArrayList<Integer>();
	private String fullPattern = "";
	private HashMap<Integer, HashMap<String,Integer>> sameDifferentPatterns = null;
	
	private ArrayList<Integer> distFreqSameEvenOddValues = null;
	private ArrayList<Integer> distFreqDiffEvenOddValues = null;
	
	private ArrayList<Integer> allSameEvenOddValues = null;
	private ArrayList<Integer> allDiffEvenOddValues = null;
	
	private int distFreqValSameCount = 0;
	
	private static int serialOffset = 0 ;   // we use this counter to recalculate distance data
	private static int initialSerialOffset = 0; /// this is the offset we start with
	
	private int numberOfPossibleVals = 0;
	private ResultHistoryEntity rhe = new ResultHistoryEntity();
	
	public static void main(String[] args) {
		String attribute = "thirdBucket";
		int gameCode = 1;
		PredictValueBasedOnDistanceAndFreq strat = new PredictValueBasedOnDistanceAndFreq();
		strat.setTestSampleSize(200);
		
		serialOffset = initialSerialOffset;
		
		System.out.println("Attribute " + attribute + " Game: " + gameCode);
		System.out.println("Current (dist freq) pred for " + attribute + " " + strat.predictForGameCodeAndAttribute(gameCode,attribute,0));
		
		//strat.testStrategy(gameCode,attribute);
		//strat.saveResult(gameCode, attribute);
		strat.getLastThreePerformanceAndUpdatePrediction(gameCode, attribute);
	}

	@Override
	public String predictForGameCodeAndAttribute(int ingameCode,
			String attribute, int serialNumber) {
		String gameCode = Integer.toString(ingameCode);
		rhe.setGameCode(gameCode);
		
		if ( serialNumber == 0)
			serialNumber = Integer.parseInt(rhe.getValueForField("serialNumber", gameCode, 0));

		String attributevals = rhe.getLastNForSequence(attribute, 200, serialNumber-serialOffset);

		List<Integer> data = ListUtils.commaSepStringToList(attributevals);
		
		ArrayList<String> attriblist = new ArrayList<String>();
		attriblist.add(attribute);
		
		setDistData(rhe.getCurrentDistancesDataForMultipleAttributes(attriblist, 0, serialNumber-initialSerialOffset));
		
		numberOfPossibleVals = rhe.getNumberOfPossibleValuesForAttributeCombinations(attriblist, serialNumber-initialSerialOffset, 0,true);
		
	//	setValueDistanceFreqMap(ListUtils.convertDistDataIntoValueDistanceFreqMap(getDistData(initialSerialOffset), numberOfPossibleVals));
		
		//System.out.println(getValueDistanceFreqMap().size() + " " + getValueDistanceFreqMap());
		
		String out = predictForData(data);
		
		System.out.println("Same dist freq: " + distFreqSameEvenOddValues);
		System.out.println("Diff dist freq: " + distFreqDiffEvenOddValues);
		System.out.println("Same val dist freq: " + allSameEvenOddValues);
		System.out.println("Diff val dist freq: " + allDiffEvenOddValues);
		
		setValueDistanceFreqMap(null);
		
		if (initialSerialOffset > 0)
			setDistData(rhe.getCurrentDistancesDataForMultipleAttributes(attriblist, 0, 0));
		
		return out;
	}

	@Override
	public String predictForData(List<Integer> data) { // Predict based on distData... not the input in the method
		// TODO Auto-generated method stub
		String out = "NONE";
		//System.out.println("Current distance data " + getDistData(serialOffset));
		List<Integer> localdistanceHistList = new ArrayList<Integer>();
		List<Integer> localfreqHistList = new ArrayList<Integer>();
		String localfullPattern = ""; 
		
		LinkedHashMap<Integer, ArrayList<Integer>> localdistdata = getDistData(0);
		
		//System.out.println("serialoffset " + serialOffset + " initialserialoffset " + initialSerialOffset);
				
		if (serialOffset == initialSerialOffset) {
			int counterforfreqvaldistsame = 0;
			
			if (distanceHistList == null || distanceHistList.size() == 0) {
				for (Integer key: localdistdata.keySet()) {
					distanceHistList.add(localdistdata.get(key).get(1));
					freqHistList.add(localdistdata.get(key).get(2));
					
					if (localdistdata.get(key).get(1) % 2 == localdistdata.get(key).get(2) % 2) {
						fullPattern += "S";
						
						if ((key % 2 == localdistdata.get(key).get(1) % 2) && counterforfreqvaldistsame < getTestSampleSize())
							distFreqValSameCount++;
					} else
						fullPattern += "D";
					
					counterforfreqvaldistsame++;
				}
			}
			
			localdistanceHistList = distanceHistList;
			localfreqHistList = freqHistList;
			localfullPattern = fullPattern.substring(0, fullPattern.length()-1);
			
		} else {
			localdistdata = getDistData(serialOffset);
			localdistanceHistList = distanceHistList.subList(serialOffset - initialSerialOffset, distanceHistList.size());
			localfreqHistList = freqHistList.subList(serialOffset- initialSerialOffset, freqHistList.size());
			localfullPattern = fullPattern.substring(serialOffset- initialSerialOffset, fullPattern.length()-1);
		}
		
		//System.out.println("predicting for :" + localdistanceHistList.subList(0,  5));
		setValueDistanceFreqMap(ListUtils.convertDistDataIntoValueDistanceFreqMap(localdistdata, numberOfPossibleVals));
		
		String analysisType = "SD";
		
		String[] states = analysisType.split("(?!^)");
		
		HashMap<Integer, HashMap<String, Integer>> patternhash = null;	
		
		patternhash = getSameDifferentPatternsAndSize(localdistanceHistList, localfreqHistList);		
		
		String[] duepatterns = new String[patternhash.size()];
		int duepattcounter = 0;
		for (int pattsize : patternhash.keySet()) {
			duepatterns[duepattcounter] = localfullPattern.substring(0, pattsize-1);
			duepattcounter++;
		} 
		
		String evendata = "";
		String odddata = "";
		Hashtable<Integer,List<Integer>> distancedata = new Hashtable<Integer,List<Integer>>();
		Hashtable<Integer,List<Integer>> countdata = new Hashtable<Integer,List<Integer>>();
		
		String predictions = "";
		
		for (int i=0; i<duepatterns.length; i++) {
			int totalcount = ListUtils.getSumOfValuesInHashMap(patternhash.get(duepatterns[i].length()+1));
			evendata += states[0] + duepatterns[i] + ":Distance: " + localfullPattern.indexOf(states[0] + duepatterns[i]) + ":Count: " + patternhash.get(duepatterns[i].length()+1).get(states[0] + duepatterns[i]) + " of " + totalcount + "\r\n";
			odddata += states[1] + duepatterns[i] + ":Distance: " + localfullPattern.indexOf(states[1] + duepatterns[i]) + ":Count: " + patternhash.get(duepatterns[i].length()+1).get(states[1] + duepatterns[i]) + " of " + totalcount + "\r\n";
			
			ArrayList<Integer> distances = new ArrayList<Integer>();
			ArrayList<Integer> counts = new ArrayList<Integer>();
			//for (int j=0; j<fullPattern.length()-duepatterns[i].length()-1; j++) {
			for (int j=0; j<25; j++) {
				String tempduepattern = localfullPattern.substring(j, j+ duepatterns[i].length()+1);
				distances.add(localfullPattern.substring(j+1).indexOf(tempduepattern));
				
				HashMap<Integer, HashMap<String, Integer>> temppatternhash = null;
				
				if (analysisType.equalsIgnoreCase("SD")) {
					temppatternhash = getSameDifferentPatternsAndSize(localdistanceHistList.subList(j+1, localdistanceHistList.size()), localfreqHistList.subList(j+1, localfreqHistList.size()));
				}
				
				if (temppatternhash.get(duepatterns[i].length()+1).get(tempduepattern) != null)
					counts.add(temppatternhash.get(duepatterns[i].length()+1).get(tempduepattern));
			}
			
			distancedata.put(i,ListUtils.testWhetherHotBasedOnList(distances));
			countdata.put(i,ListUtils.testWhetherHotBasedOnList(counts));
			
			List<Integer> heatmapdistances = ListUtils.testWhetherHotBasedOnList(distances);
			List<Integer> heatmapcounts = ListUtils.testWhetherHotBasedOnList(counts);
			
			int distanceheatstatus = heatmapdistances.get(0) + 
										heatmapdistances.get(1) + 
										heatmapdistances.get(2) + 
										heatmapdistances.get(3);
			int countheatstatus = heatmapcounts.get(0) + 
										heatmapcounts.get(1) + 
										heatmapcounts.get(2) + 
										heatmapcounts.get(3);
			
			int threshold = 4;
			
			
			//	System.out.println("localfullpattern " + localfullPattern.substring(0, 50) + "heatmapdistances " + heatmapdistances);
			
			if (heatmapdistances.get(0) > 0 && distanceheatstatus < threshold) { // HOT -- go for small distance
				if (localfullPattern.indexOf(states[0] + duepatterns[i]) < localfullPattern.indexOf(states[1] + duepatterns[i])) {
					predictions+=states[0];
				} 
				
				if (localfullPattern.indexOf(states[0] + duepatterns[i]) > localfullPattern.indexOf(states[1] + duepatterns[i])) {
					predictions+=states[1];
				}
			}
			
			if (heatmapdistances.get(0) < 0 && distanceheatstatus > 0-threshold) { // COLD - go for large distance
				if (localfullPattern.indexOf(states[0] + duepatterns[i]) > localfullPattern.indexOf(states[1] + duepatterns[i])) {
					predictions+=states[0];
				} 
				
				if (localfullPattern.indexOf(states[0] + duepatterns[i]) < localfullPattern.indexOf(states[1] + duepatterns[i])) {
					predictions+=states[1];
				}
			}
			
			if (heatmapcounts.get(0) < 0 && countheatstatus > 0-threshold) { // COLD - go for large counts
				if (patternhash.get(duepatterns[i].length()+1).get(states[0] + duepatterns[i]) != null && 
						patternhash.get(duepatterns[i].length()+1).get(states[1] + duepatterns[i]) != null) { 
					if (patternhash.get(duepatterns[i].length()+1).get(states[0] + duepatterns[i]) >
								patternhash.get(duepatterns[i].length()+1).get(states[1] + duepatterns[i])) {
						predictions+=states[0];
					}
					
					if (patternhash.get(duepatterns[i].length()+1).get(states[0] + duepatterns[i]) <
								patternhash.get(duepatterns[i].length()+1).get(states[1] + duepatterns[i])) {
							predictions+=states[1];
					}
				}
			}
			
			if (heatmapcounts.get(0) > 0 && countheatstatus < threshold) { // HOT -- go for small count
				
				if (patternhash.get(duepatterns[i].length()+1).get(states[0] + duepatterns[i]) != null && 
								patternhash.get(duepatterns[i].length()+1).get(states[1] + duepatterns[i]) != null) { 
					if (patternhash.get(duepatterns[i].length()+1).get(states[0] + duepatterns[i]) >
								patternhash.get(duepatterns[i].length()+1).get(states[1] + duepatterns[i])) {
						predictions+=states[1];
					}
					
					if (patternhash.get(duepatterns[i].length()+1).get(states[0] + duepatterns[i]) <
								patternhash.get(duepatterns[i].length()+1).get(states[1] + duepatterns[i])) {
							predictions+=states[0];
					}
				}
			}
		}
			
		/*System.out.println(evendata);
		System.out.println("Distances:");
		for (Integer k: distancedata.keySet())
			System.out.println(distancedata.get(k));
		System.out.println("Count:");
		for (Integer k: countdata.keySet())
			System.out.println(countdata.get(k));
		System.out.println(odddata);
		System.out.println(predictions);*/
		
		if (predictions.length() > 0) {
			if (StringUtils.countMatches(predictions, states[0]) > StringUtils.countMatches(predictions, states[1])) {
				
					out = "SAME";
			}
			
			if (StringUtils.countMatches(predictions, states[0]) < StringUtils.countMatches(predictions, states[1])) {
				
					out = "DIFF";
			}
		}
		/*System.out.println("Dist: " + distanceHistList);
		System.out.println("Freq: " + freqHistList);
		System.out.println("EvenOddSameDiff: " + ListUtils.getValueDistributionInStringList(sameDiff));
		
		System.out.println("Patterns: " + getSameDifferentPatternsAndSize(distanceHistList, freqHistList));
		
		int blocksize = 10;
		System.out.print("\t\t " + 0 +"-" + (blocksize-1));
		System.out.println(" EvenOddSameDiff: " + ListUtils.getValueDistributionInStringList(sameDiff.subList(0, blocksize-1)));
		for (int i=1; i < 10; i++) {
			System.out.print("\t\t " + (i*blocksize-1) +"-" + ((i+1)*blocksize-1));
			System.out.println(" EvenOddSameDiff: " + ListUtils.getValueDistributionInStringList(sameDiff.subList(i*blocksize-1, (i+1)*blocksize-1)));
			
		}*/
		
		distFreqSameEvenOddValues = new ArrayList<Integer>();
		distFreqDiffEvenOddValues = new ArrayList<Integer>();
		
		allSameEvenOddValues = new ArrayList<Integer>();
		allDiffEvenOddValues = new ArrayList<Integer>();
		
	//	System.out.println("current valuedistancemap " + getValueDistanceFreqMap());
		for (int thisVal: getValueDistanceFreqMap().keySet()) {
			if (getValueDistanceFreqMap().get(thisVal).get(0) % 2 == getValueDistanceFreqMap().get(thisVal).get(1) % 2) {
				distFreqSameEvenOddValues.add(thisVal);
				
				if (thisVal % 2 == getValueDistanceFreqMap().get(thisVal).get(0) % 2) {
					allSameEvenOddValues.add(thisVal);
					
				} else
					allDiffEvenOddValues.add(thisVal);
			} else {
				distFreqDiffEvenOddValues.add(thisVal);
				allDiffEvenOddValues.add(thisVal);
			}
			
		}
		
		//System.out.println("Same distance and Freq " + sameEvenOddValues.size() + " " + sameEvenOddValues);
		//System.out.println("Different distance and Freq " + differentEvenOddValues.size() + " " + differentEvenOddValues);
		return out;
	}

	@Override
	public void testStrategy(int ingameCode, String attribute) {
		String gameCode = Integer.toString(ingameCode);
		
		rhe.setGameCode(gameCode);
		ArrayList<String> failures = new ArrayList<String>();
		ArrayList<String> successes = new ArrayList<String>();
		int lastserial = 0;
		int passed = 0;
		int samplesize = getTestSampleSize();
		int printsize = 10;
		int nopredic = 0;
		int pred1=0;
		int pred2=0;

		ArrayList<String> out = new ArrayList<>();
		int latestsuccessserial = 0;// (successes.size() >
									// 0)?Integer.parseInt(successes.get(0).substring(0,
									// successes.get(0).indexOf("-"))):0;
		int latestfailureserial = 0;// (failures.size() >
									// 0)?Integer.parseInt(failures.get(0).substring(0,
									// failures.get(0).indexOf("-"))):0;
		
		int samepredicsuccess = 0;
		int diffpredicsuccess = 0;
		int samepredicfail = 0;
		int diffpredicfail = 0;		
		
		
		try {
			if ( lastserial == 0)
				lastserial = Integer.parseInt(rhe.getValueForField("serialNumber", gameCode, 0));
			String prevValue = "";
			for (int i = 0; i < samplesize; i++) {				
				serialOffset++;
				String value = "";
				
				String maxVals = "";
				
				value = rhe.getValueForFieldFromCache(attribute, gameCode, (lastserial- serialOffset +1 ));
				
				if (value == null || value.length() == 0)
					continue;
				
				prevValue = rhe.getValueForFieldFromCache(attribute, gameCode, (lastserial - serialOffset));
								
				//maxVals = rhe.getLastNForSequenceFromCache(attribute, samplesize, (lastserial - i - 1));
				
				String prediction = predictForData(null);
				//String prediction2 = ListUtils.predictAscDescBasedOnOneDimension(ListUtils.commaSepStringToList(maxVals));
				
				
				if (prediction.equals("NONE")) {
					nopredic++;
					out.add("");
				}

				if (prediction.equals("SAME")) {
					pred1++;
					if (distFreqSameEvenOddValues.contains(Integer.parseInt(value))) {
						passed++;
						out.add("T");
					} else
						out.add("F");
				}

				if (prediction.equals("DIFF")) {
					pred2++;
					if (distFreqDiffEvenOddValues.contains(Integer.parseInt(value))) {
						passed++;
						out.add("T");
					} else
						out.add("F");
				}
				
				getPredictionPerformanceHistory().add(out.get(out.size()-1));
				
				if (i < 10)
					System.out.println(value + "\t" + prediction + "\t" +  out.get(out.size()-1) + "\t" + allSameEvenOddValues);
				/*else {
					if (i % 20 == 0)
						System.out.println("\t");
					System.out.print(i + " ");
					
				}*/
	
				
			}

			System.out.println("Tests: " + samplesize + " Nopredictions: " + (nopredic*100/samplesize) + " pc Passed: "
					+ (passed*100/(samplesize-nopredic)) + " pc | " +
					" Same val freq dist " + (distFreqValSameCount*100/samplesize) + " pc") ;
			
			setPredictionPerformanceHistory(out);
			setPredictionAccuracyPercent(passed*100/(samplesize-nopredic));
			
			if (pred1 == 0 || pred2 == 0)
				setPredictionDivergence(0);
			else 
				setPredictionDivergence((pred1>=pred2)?pred1/pred2:pred2/pred1);
			
			
		
			System.out.println(getPredictionPerformanceHistory());

		} catch (Exception e) {
			System.out.println("PredictValueBasedOnDistanceAndFreq:testStrategy - Exception "
					+ e.getMessage());
			e.printStackTrace();
		}
		
		System.out.println("Size of out list " + out.size());

	}

	public LinkedHashMap<Integer, ArrayList<Integer>> getDistData(int offset) {
		if (offset > 0) {
			//System.out.println("shifted distdata -- offset " + offset);
			return updateDistDataBasedOnOffset();
		}
		return distData;
	}

	private LinkedHashMap<Integer, ArrayList<Integer>> updateDistDataBasedOnOffset() {
		LinkedHashMap<Integer, ArrayList<Integer>> updateddata = (LinkedHashMap<Integer, ArrayList<Integer>>) getDistData(0).clone();
		//System.out.println("Updating distance data for offset " + serialOffset);
		int counter = 0;
		
		for (Integer key: getDistData(0).keySet()) {
			if (counter < serialOffset) {
				if (updateddata.get(key).get(2) == 1)
					numberOfPossibleVals--;
				updateddata.remove(key);
			} else
				break;
			counter++;
		}
		
		return updateddata;
	}

	public void setDistData(LinkedHashMap<Integer, ArrayList<Integer>> distData) {
		//System.out.println("setting distdata " + distData);
		this.distData = distData;
	}
	
	public LinkedHashMap<Integer, ArrayList<Integer>> getValueDistanceFreqMap() {
		return valueDistanceFreqMap;
	}

	public void setValueDistanceFreqMap(
		LinkedHashMap<Integer, ArrayList<Integer>> valueDistanceFreqMap) {
		//System.out.println("setting valuedistancefreqmap " + valueDistanceFreqMap);
		this.valueDistanceFreqMap = valueDistanceFreqMap;
	}
	
	private HashMap<Integer, HashMap<String,Integer>> getSameDifferentPatternsAndSize(
			List<Integer> distances, List<Integer> freqs) {
			
		if (fullPattern == null || fullPattern.length() == 0) {
			int c=0;
			for (int thisval : distances) {
				if (c < distances.size()-1) {
					if (thisval % 2 == freqs.get(c) % 2 ) {
						fullPattern += "S";
					} else {
						fullPattern += "D";
					}
				}
				c++;
			}
		}	
		
		int localserialoffset = fullPattern.length() - distances.size();
		//String localfullPattern = fullPattern.substring(localserialoffset, fullPattern.length()-1); // this is based on the distances passed in
		HashMap<Integer, HashMap<String,Integer>> out = new HashMap<Integer, HashMap<String,Integer>>();
		
		if (sameDifferentPatterns == null) {	
			for (int pattSize=3; pattSize < 5; pattSize++) {
				if (out.get(pattSize) == null)  {
					out.put(pattSize, new HashMap<String,Integer>());
				}
				
				for (int i=0; i<fullPattern.length()-pattSize; i++) {
					String thispatt = fullPattern.substring(i,i+pattSize);
					out.get(pattSize).put(thispatt, StringUtils.countMatches(fullPattern, thispatt));
				}
				
			}
			
			sameDifferentPatterns = out;
		} else {
			//String localfullPattern = fullPattern.substring(serialOffset, fullPattern.length()-1);
			
			for (Integer mainkey: sameDifferentPatterns.keySet()) {
				out.put(mainkey, new HashMap<String,Integer>(sameDifferentPatterns.get(mainkey)));
				
			}
			
			if (localserialoffset > 0) {
				for (int pattSize=3; pattSize < 5; pattSize++) {
					if (out.get(pattSize) == null)  {
						out.put(pattSize, new HashMap<String,Integer>());
					}
					
					for (int i=0; i<localserialoffset; i++) {
						String thispatt = fullPattern.substring(i, fullPattern.length()-1).substring(i,i+pattSize);
						out.get(pattSize).put(thispatt, out.get(pattSize).get(thispatt)-1);
					}
					
				}
			}
		}
		return out;
	}

	@Override
	public void saveResult(int gameCode, String attribute) {
		
		serialOffset = initialSerialOffset;
		InclusionExclusionEntity ince = new InclusionExclusionEntity();
		rhe.setGameCode(Integer.toString(gameCode));
		ince.setAlgorithmType(InclusionExclusionEntity.ALGORITHM_TYPE_DIST_FREQ_SAME_DIFF);
		ince.setAttribute(attribute);
		ince.setGameCode(Integer.toString(gameCode));
		ince.setInputDrawDate(rhe.getLastNForAttribute("dateOfDraw", 1, 0));
		ince.setIsInclusionInd("false");
		
		
		if (distFreqSameEvenOddValues == null || distFreqDiffEvenOddValues == null) {
			String currentPred = predictForGameCodeAndAttribute(gameCode, attribute, 0);
			
			System.out.println("Current same-diff freq-distance pred for " + attribute + ": " + currentPred);
			if (currentPred.equalsIgnoreCase("SAME"))
				ince.getData().addAll(distFreqSameEvenOddValues);
			
			if (currentPred.equalsIgnoreCase("DIFF"))
				ince.getData().addAll(distFreqDiffEvenOddValues);
			
		}
		
		testStrategy(gameCode, attribute);
		ince.setPercent(Integer.toString(getPredictionAccuracyPercent()));
		
		if (getPredictionPerformanceHistory() != null) {
			int counter = 0;
			int success = -1;
			int failure = -1;
			int emptyresult = 0;
			for (String thisoutcome: getPredictionPerformanceHistory()) {				
				if (success >= 0 && failure >= 0) break;
				
				if (thisoutcome.equals(""))
					emptyresult++;
				
				if (thisoutcome.equalsIgnoreCase("T") && success < 0)
					success = counter-emptyresult;
				if (thisoutcome.equalsIgnoreCase("F") && failure < 0)
					failure = counter-emptyresult;
				
				counter++;
			}
			
			if (failure < success) {
				ince.setTotalScore(Integer.toString(success*getPredictionAccuracyPercent()));
				ince.setIsInclusionInd("true");
			}
			
			if (failure > success) {
				ince.setTotalScore(Integer.toString(0-(failure*(100-getPredictionAccuracyPercent()))));
				ince.setIsInclusionInd("false");
			}
		}
		
		//System.out.println(ince);
		if (getPredictionDivergence() != 0) {
			ince.addInclusionExclusionResult();
			System.out.println("Prediction divergence " + getPredictionDivergence());
		} else
			System.out.println("One side predictions..");
		
		distFreqSameEvenOddValues = null;
		distFreqDiffEvenOddValues = null;
		return;
	}

	@Override
	public void getLastThreePerformanceAndUpdatePrediction(int gameCode, String attribute) {
		InclusionExclusionEntity ince = new InclusionExclusionEntity();
		rhe.setGameCode(Integer.toString(gameCode));
		
		String latestVal = rhe.getLastNForAttribute(attribute, 1, 0);
		
		if (latestVal == null || latestVal.length() == 0)
			return;
		// Get last 3 draw dates
		
		String[] previousdates = new String[3];
		
		for (int i=0; i<previousdates.length; i++) {
			previousdates[i] = rhe.getNthPreviousValueForAttribute("dateOfDraw", i+1, 0);
			
			ince.setAttribute(attribute);
			ince.setAlgorithmType(InclusionExclusionEntity.ALGORITHM_TYPE_DIST_FREQ_SAME_DIFF);
			ince.setGameCode(Integer.toString(gameCode));
			ince.setInputDrawDate(previousdates[i]);
			
			ArrayList<InclusionExclusionEntity> incexcrows = (ArrayList<InclusionExclusionEntity>) ince.findRows();
			
			if (incexcrows != null && incexcrows.size() == 1  ) {
				if (incexcrows.get(0).getIsInclusionInd().equals("1")) {							
					if (incexcrows.get(0).getData().contains(Integer.parseInt(latestVal))) {
						if (i == 0)	incexcrows.get(0).setFirstPerformance("true");
						if (i == 1)	incexcrows.get(0).setSecondPerformance("true");
						if (i == 2)	incexcrows.get(0).setThirdPerformance("true");
					} else {
						if (i == 0)	incexcrows.get(0).setFirstPerformance("false");
						if (i == 1)	incexcrows.get(0).setSecondPerformance("false");
						if (i == 2)	incexcrows.get(0).setThirdPerformance("false");
					}
				} else {
					if (incexcrows.get(0).getData().contains(Integer.parseInt(latestVal))) {
						if (i == 0)	incexcrows.get(0).setFirstPerformance("false");
						if (i == 1)	incexcrows.get(0).setSecondPerformance("false");
						if (i == 2)	incexcrows.get(0).setThirdPerformance("false");
					} else {						
						if (i == 0)	incexcrows.get(0).setFirstPerformance("true");
						if (i == 1)	incexcrows.get(0).setSecondPerformance("true");
						if (i == 2)	incexcrows.get(0).setThirdPerformance("true");
					}
				}
				//System.out.println(incexcrows.get(0));
				incexcrows.get(0).update();
			}
			
			
		}
		
		
	}


}
