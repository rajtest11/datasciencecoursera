/*
 * Created on Apr 12, 2012
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.num.generator;

import java.sql.SQLException;
import java.util.*;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Properties;
import java.util.StringTokenizer;
import java.util.Map.Entry;
import java.io.*;
import java.io.ObjectInputStream.GetField;

import org.apache.commons.lang3.ArrayUtils;

import com.num.generator.dataaccess.AggregateRanksEntity;
import com.num.generator.dataaccess.CriteriaEntity;
import com.num.generator.dataaccess.CriteriaResultEntity;
import com.num.generator.dataaccess.CurrentStateEntity;
import com.num.generator.dataaccess.DBUtils;
import com.num.generator.dataaccess.FollowerPatternEntity;
import com.num.generator.dataaccess.GameBucketEntity;
import com.num.generator.dataaccess.GameTypesEntity;
import com.num.generator.dataaccess.MissingDigitsEntity;
import com.num.generator.dataaccess.ObservationsEntity;
import com.num.generator.dataaccess.ResultHistoryEntity;
import com.num.generator.dataaccess.ResultHistoryTestFilterEntity;
import com.num.generator.predic.ListUtils;

public class Generator {
	static Numbers n = null;
	static boolean doPrint = true;
	static Writer output = null;
	// PARAMETERS
	static String type = null;
	static int maxValue = 0;
	static int choices = 0;
	static int startSum = 0, endSum = 0;
	static int last5Range = 0;
	static int numberOfZeroInAllBrackets = 0;
	static int numberMaxInBracket = 0;
	static int[] hotNumbersArray = new int[5];
	static int notAllowedBucket50;
	static int avgStart;
	static int avgEnd;
	static int propdistCount = 0;
	static int in5HistoryCount = 0;
	static int last9CombsAverageCount = 0;
	static int equiDistantFilterCount = 0;
	static int combsAlreadyAppearedCount = 0;
	static int combsBelowAverageNumbersCount = 0;
	static int if4MoreThan35Count = 0;
	static int allEvensAndOddsCount = 0;
	static int numbersWithSameLstDigitCount = 0;
	static int aboveAverageFreqCount = 0;
	static int notInBucketListFileCount = 0;
	static int sumNotAppearedRecentlyCount = 0;
	static int inclusionsCount = 0;
	static int hotNumberCount = 0;
	static int exclusionsCount = 0;
	static int disallowDigit = -1;
	static int freqFilterCount = 0;
	static int followerPatternAnalysisCount = 0;
	static int matchesFreqList = 0;
	static int checkSkipDetails = 0;
	static int uniqueBucketPattern = 0;
	static int unlikelyFreqShadowReduxesCount = 0;
	static Set<Integer> hotBucketsList = new HashSet<Integer>();
	static int dateMonYearInResultsCount = 0;
	static int[] lastFreqs = null;
	static int[] lastSet = null;

	static ArrayList<ArrayList<Integer>> frq = new ArrayList<ArrayList<Integer>>();

	static ArrayList<ArrayList<Integer>> reduxPredictMap = new ArrayList<ArrayList<Integer>>();
	private static int predictThroughReduxCount = 0;
	static ArrayList<ArrayList<Integer>> possibleBucketMap = new ArrayList<ArrayList<Integer>>();
	private static int sumAppearedRecentlyCount = 0;
	private static int sumLessThanStartSumCount = 0;
	private static int sumMoreThanEndSumCount = 0;
	private static int numberOfPrimesNotAsLast3Count;
	private static int DBPredicCount;
	private static int DisallowDigitCount;
	private static int sameReduxCount;
	private static int sameVDiffCount;
	private static int sameFreqReduxCount;
	private static int sameDigitDiffsInHistoryCount;
	private static int threeOrMoreRelationsCount;
	private static ResultHistoryEntity rhe = new ResultHistoryEntity();
	private static GameTypesEntity gte = new GameTypesEntity();
	private static String gameCode = null;
	private static HashMap followers = new HashMap();

	private static int missedDigitsInHistory = 0;
	private static Properties DBpredicProp = new Properties();
	private static ArrayList<Integer> last3PrimeCount = new ArrayList<Integer>();
	private static ArrayList sumPrimesList = new ArrayList(Arrays.asList(67,
			71, 73, 79, 83, 89, 97, 101, 103, 107, 109, 113, 127, 131, 137,
			139, 149, 151, 157, 163, 167, 173, 179, 181, 191, 193, 197, 199,
			211, 223, 227, 229, 233, 239, 241, 251, 257, 263, 269, 271, 277,
			281, 283, 293, 307, 311, 313, 317, 331, 337, 347, 349));
	private static int matches3DiffsCount = 0;
	private static int skipSumOutOfRangeCount = 0;
	private static int unlikelyMaxFactorCount = 0;
	private static int isPossibleCombAccordingToGeneratorVTwoCount = 0;
	private static int sameRanksDirectionCount = 0;
	private static int sameObsDateCount = 0;
	private static int sameObsPercentile = 0;
	private static Hashtable<Integer, Integer> obsPercentiles = null;
	
	private static int currentBucketRank = 0;
	private static int currentMissingDigitRank = 0;
	private static int currentFollowerRank = 0;
	
	private static Hashtable currentFollowerTableForGame = null;
	private static Hashtable<String, Integer> bucketRanks = new Hashtable<String, Integer>();
	private static Hashtable<String, Integer> missingDigitRanks = new Hashtable<String, Integer>();
	private static Hashtable<String, Integer> followerRanks = new Hashtable<String, Integer>();
	
	private static GeneratorVTwo genv2 = null;
	public static CriteriaEntity currentCriteria = new CriteriaEntity();

	private static String predicFileName = "C:\\eclipse\\workspace\\first\\Pred\\PredFor0607-MM"; // "C:\\eclipse\\workspace\\first\\Pred\\PredFor1225-MM";
	private static String forDate = null;
	static ArrayList<String> unlikelyBuckets = new ArrayList<String>();
	static ArrayList<String> unlikelyFreqShadowReduxes = new ArrayList<String>();
	static ArrayList<Integer> unlikelyMaxFactors = new ArrayList<Integer>();
	public static int unlikelyBucketSpan = 0;
	
	public static Hashtable<String, ArrayList<Integer>> obsData = null;
	
	private static boolean isTest = false;
	
	private static int numberPassedTest = 0;

	public static String getForDate() {
		return forDate;
	}

	public static void setForDate(String forDate) {
		Generator.forDate = forDate;
	}

	Generator() {
		try {
			Properties prop = new Properties();
			File propFile = new File(
					"C:\\Users\\johris\\git\\git\\Generator\\props.properties");
			FileInputStream fis = new FileInputStream(propFile);
			prop.load(fis);
			choices = Integer.parseInt(prop.getProperty("choices"));
			
			if (startSum == 0)
				startSum = Integer.parseInt(prop.getProperty("startSum"));
			
			if (endSum == 0)
				endSum = Integer.parseInt(prop.getProperty("endSum"));
			last5Range = Integer.parseInt(prop.getProperty("last5Range"));
			numberOfZeroInAllBrackets = Integer.parseInt(prop
					.getProperty("numberOfZeroInAllBrackets"));
			numberMaxInBracket = Integer.parseInt(prop
					.getProperty("numberMaxInBracket"));
			notAllowedBucket50 = Integer.parseInt(prop
					.getProperty("notAllowedBucket50"));
			avgStart = Integer.parseInt(prop.getProperty("avgStart"));
			avgEnd = Integer.parseInt(prop.getProperty("avgEnd"));
			
			if (avgStart > avgEnd) {
				System.out.println("Generator--- start average " + avgStart + " is greater than end average " + avgEnd);
				
			}
				
			String disallow = prop.getProperty("disallowDigit");

			if (disallow.length() > 0)
				disallowDigit = Integer.parseInt(prop
						.getProperty("disallowDigit"));
			System.out.println("Generator.java ---- Sum range : " + startSum
					+ " - " + endSum + " | Last 9 Avg range : " + avgStart
					+ " - " + avgEnd);
			String hotNumbers = prop.getProperty("numberMaxInBracket");
			String[] s = hotNumbers.split("\\,");
			for (int i = 0; i < s.length; i++) {
				hotNumbersArray[i] = Integer.parseInt(s[i]);
			}
			String frqNumbers = prop.getProperty("freqBasedList");
			fis.close();
			System.out.println("Generator.java ---- Must appear list : "
					+ frqNumbers);
			
			if (type == null)
				type = prop.getProperty("type");

			if (type.equals("pb"))
				maxValue = 69;
			else
				maxValue = 75;

			Numbers.doNotUpdateInDatabase = true;
			n = new Numbers(type);

			GeneratorVTwo.setForDate(forDate);
			genv2 = new GeneratorVTwo();

			if (frqNumbers.length() > 0) {
				String[] frqNumbersArrays = frqNumbers.split("\\;");
				for (int k = 0; k < frqNumbersArrays.length; k++) {
					ArrayList<Integer> a = new ArrayList<Integer>();
					String[] indivFreqNumbers = frqNumbersArrays[k]
							.split("\\,");
					for (int j = 0; j < indivFreqNumbers.length; j++) {
						a.add(Integer.parseInt(indivFreqNumbers[j].trim()));
					}
					frq.add(a);
				}
			}

			// Initialize followers
			if (gameCode == null) {
				gte = new GameTypesEntity();
				gameCode = gte.findGameCodeByProgramCode(type);
			}

			followers.put(
					"FirstFollower",
					rhe.getFollowers("FirstFollower",
							Integer.parseInt(gameCode), 0));
			followers.put(
					"SecondFollower",
					rhe.getFollowers("SecondFollower",
							Integer.parseInt(gameCode), 0));
			followers.put(
					"ThirdFollower",
					rhe.getFollowers("ThirdFollower",
							Integer.parseInt(gameCode), 0));
			followers.put(
					"FourthFollower",
					rhe.getFollowers("FourthFollower",
							Integer.parseInt(gameCode), 0));
			followers.put(
					"FifthFollower",
					rhe.getFollowers("FifthFollower",
							Integer.parseInt(gameCode), 0));

			// Initialize possibleBucketMap
			possibleBucketMap.add(new ArrayList(Arrays.asList(0, 1, 2, 3, 4)));
			possibleBucketMap.add(new ArrayList(Arrays.asList(0, 1, 2, 3, 4)));
			possibleBucketMap
					.add(new ArrayList(Arrays.asList(1, 2, 3, 4, 5, 6)));
			possibleBucketMap.add(new ArrayList(Arrays.asList(1, 2, 3, 4, 5, 6,
					7)));
			possibleBucketMap
					.add(new ArrayList(Arrays.asList(2, 3, 4, 5, 6, 7)));

			// A good guide to construct this map is to look at the reduxoutput
			// file and
			// remove the last three redux values from each line
			// Can also remove all evens or odds too if last few reduxs are
			// highly concentrated
			// in that group (last 5-6 reduxes were even, remove evens).
			if (reduxPredictMap.size() == 0) {
				ArrayList defaultReduxList = null; // new
													// ArrayList(Arrays.asList(1,2,3,4,5,6,7,8,9));
				reduxPredictMap.add(defaultReduxList); // FirstREDUX
				reduxPredictMap.add(defaultReduxList); // Second REDUX
				reduxPredictMap.add(defaultReduxList); // //Third REDUX
				reduxPredictMap.add(defaultReduxList); // //Fourth REDUX
				reduxPredictMap.add(defaultReduxList); // Fifth REDUX
				reduxPredictMap.add(defaultReduxList); // First five sum REDUX
			}
			

			if (currentBucketRank == 0) {
				GameBucketEntity gbe = new GameBucketEntity();
				currentBucketRank = gbe.getBucketRankForGameAndSerial(gameCode, 0);
				
				bucketRanks = gbe.getBucketRanksForGame(gameCode);
			}
			
			AggregateRanksEntity agre = new AggregateRanksEntity();
			if (currentFollowerRank == 0) {
				FollowerPatternEntity fpe = new FollowerPatternEntity();
				currentFollowerRank = fpe.getFollowerPatternRankForGameAndSerial(gameCode, 0);
				
				followerRanks = agre.getFollowerRanksForGame(gameCode);
			}
			
			if (currentMissingDigitRank == 0) {
				MissingDigitsEntity mde = new MissingDigitsEntity();
				currentMissingDigitRank = mde.getMissingDigitRankForGameAndSerial(gameCode, 0);
				
				missingDigitRanks = agre.getMissingDigitsForGame(gameCode);
			}
			
			if (obsData == null) {
				ObservationsEntity obse = new ObservationsEntity();
				obsData = obse.loadObsData(gameCode);
			}
			
			
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	public static void main(String[] args) {
		new Generator();
		int[] testComb = null;//new int[] { 10,19,30,41,55 };

		if (testComb != null && testComb.length > 0) {
			isTest= true;
			CombTest(testComb, false);
		} else {
			long counter = 1;
			numberPassedTest = 0;
			long sumofdigits = 0;
			int lastnumberPassedTest = 0;

			sumLessThanStartSumCount = 0;
			sumMoreThanEndSumCount = 0;
			propdistCount = 0;
			last9CombsAverageCount = 0;
			equiDistantFilterCount = 0;
			combsAlreadyAppearedCount = 0;
			combsBelowAverageNumbersCount = 0;
			allEvensAndOddsCount = 0;
			aboveAverageFreqCount = 0;
			freqFilterCount = 0;
			notInBucketListFileCount = 0;
			uniqueBucketPattern = 0;
			predictThroughReduxCount = 0;
			followerPatternAnalysisCount = 0;
			DBPredicCount = 0;
			missedDigitsInHistory = 0;
			sameReduxCount = 0;
			sameVDiffCount = 0;
			sameFreqReduxCount = 0;
			sameDigitDiffsInHistoryCount = 0;
			matches3DiffsCount = 0;
			isPossibleCombAccordingToGeneratorVTwoCount = 0;
			skipSumOutOfRangeCount = 0;
			sameRanksDirectionCount = 0;
			threeOrMoreRelationsCount = 0;

			// ProgressBar progressBar = ConsoleProgressBar.on(System.out);
			// progressBar.tickOne();
			// printFreqMapForTestCombs();

			double starttime = System.currentTimeMillis();

			currentCriteria.setFirstFiveSumAvgEnd(Integer.toString(avgEnd));
			currentCriteria.setFirstFiveSumAvgStart(Integer.toString(avgStart));
			currentCriteria.setFirstFiveSumEnd(Integer.toString(endSum));
			currentCriteria.setFirstFiveSumStart(Integer.toString(startSum));
			
			if (DBpredicProp != null) {
				
				String param = DBpredicProp.getProperty("FIRSTFIVESUMBUCKET");
				if (param != null && param.length() > 0) {
					int startInd = param.indexOf("[") + 1;
					if (startInd > 0) {
						String val = param.substring(startInd, param.indexOf("]"));
					
							if (startInd > 1) {// Prediction was a NOT
								currentCriteria.setFirstFiveSumExcludeBucketList(val);
							} else {
								currentCriteria.setFirstFiveSumIncludeBucketList(val);
							}
						
					}
				}
				
				
			}

			try {
				File f = (type.equals("mm")) ? new File(
						"C:\\Users\\johris\\git\\git\\HelloWorld\\meg.properties")
						: new File(
								"C:\\Users\\johris\\git\\git\\HelloWorld\\pwb.properties");
				if (f.exists())
					f.delete();
				output = new OutputStreamWriter(new FileOutputStream(f, true));
				output.write("startSum:" + startSum + " | EndSum:" + endSum
						+ " | last5Range:" + last5Range
						+ " | numberOfEmptyBrackets:"
						+ numberOfZeroInAllBrackets
						+ " | maxNumberInOneBracket:" + numberMaxInBracket
						+ " | ");
				output.write("sumOfFreqDistanceHigh:"
						+ FreqFilter.maxSumOfFreqDistance
						+ " | sumOfFreqDistanceLow:"
						+ FreqFilter.minSumOfFreqDistance
						+ " | MatchTheseNumbersOfFreqInFreqAppearance:"
						+ FreqFilter.matchMap);
				output.write("\r\n");

				int[] comb = new int[choices];

				for (int i = 0; i < choices; i++) {

					comb[i] = i + 1;

				}

				if (intelligentTest(comb)) {
					numberPassedTest++;
					if (doPrint && maxValue <= 20) {
						myprint(counter, comb, choices);
					}
				}

				sumofdigits += sum(comb);

				while (next_comb(comb, choices, maxValue+1)) {
					counter++;
					sumofdigits += sum(comb);

					if (intelligentTest(comb)) {
						numberPassedTest++;
						currentCriteria.setNumberOfPassedCombinations(Integer
								.toString(numberPassedTest));

						if (doPrint && maxValue <= 20)
							myprint(counter, comb, choices);
					}

					// do something
					

					if (counter % 1000000 == 0) {
						double thisTime = System.currentTimeMillis();
						// progressBar.tick(counter/3800000); // this will
						// increase the percentage to 26
						System.out.print("\tRcrd : " + counter/1000000 + "M Time : "
								+ (thisTime - starttime) / 1000
								+ " s. Matched : "
								+ (numberPassedTest - lastnumberPassedTest)
								+ " of " + numberPassedTest);
						starttime = thisTime;
						lastnumberPassedTest = numberPassedTest;

						if (numberPassedTest > 21000) {

							System.out.println("Very High Match count ... terminating further computing");
							String logstr = "Generator.main: " + Calendar.getInstance().getTime().toString() + " Very High Match count... terminating computing after " + counter + " records " +
							"Sum range : " + startSum + " - " + endSum ;
							Numbers.addLineToFile("C:\\Users\\johris\\git\\git\\Generator\\GeneratorRunLog", logstr, false);
							break;
						}
					}

				}

			} catch (FileNotFoundException fx) {
				fx.printStackTrace();
			} catch (IOException ix) {
				ix.printStackTrace();
			} finally {
				try {
					output.close();
				} catch (IOException ix) {
					ix.printStackTrace();
				}
			}

			System.out.println(choices + " out of " + maxValue + " | counter "
					+ counter + " | avgEnd  " + +sumofdigits / counter
					+ " | Pas  " + numberPassedTest + " | Per "
					+ (numberPassedTest * 100 / counter));

			System.out.println();
			System.out.println(" sumLessThanStartSumCount "
					+ sumLessThanStartSumCount * 100 / counter);
			System.out.println(" sumMoreThanEndSumCount "
					+ sumMoreThanEndSumCount * 100 / counter);

			System.out.println("propdistCount " + propdistCount * 100 / counter
					+ " last9CombsAverageCount " + last9CombsAverageCount * 100
					/ counter + " equiDistantFilterCount "
					+ equiDistantFilterCount * 100 / counter
					+ " combsAlreadyAppearedCount " + combsAlreadyAppearedCount
					* 100 / counter + " combsWithLotsOf50s "
					+ combsBelowAverageNumbersCount * 100 / counter
			// " in5HistoryCount " + in5HistoryCount*100/counter +
					// + " morethan35 " + if4MoreThan35Count*100/counter
					);
			System.out.println(" allEvensAndOddsCount " + allEvensAndOddsCount
					* 100 / counter + " aboveAverageFreqCount "
					+ aboveAverageFreqCount 
					+ " freqFilterCount " + freqFilterCount * 100 / counter
			// " numbersWithSameLstDigitCount " +
			// numbersWithSameLstDigitCount*100/counter +
			// " inclusionsCount " + inclusionsCount +
			// " exclusionsCount " + exclusionsCount +
			// " hotNumberCount " + hotNumberCount*100/counter +
			// + " matchesFreqList " + matchesFreqList*100/counter
					

			+ " notInBucketListFileCount "
					+ notInBucketListFileCount * 100 / counter
			+ " uniqueBucketPattern " + uniqueBucketPattern
					* 100 / counter
			+ " predictThroughRedux "
					+ predictThroughReduxCount * 100 / counter
			+ " followerPatternAnalysisCount "
					+ followerPatternAnalysisCount * 100 / counter
			+ " DBPredicCount " + DBPredicCount * 100
					/ counter
			+ " missedDigitsInHistoryCount "
					+ missedDigitsInHistory * 100 / counter
			+ " sameReduxCount " + sameReduxCount * 100
					/ counter
			+ " sameVDiffCount " + sameVDiffCount * 100
					/ counter
			+ " sameFreqReduxCount " + sameFreqReduxCount * 100
					/ counter
			+ " sameDigitDiffsCount " + sameDigitDiffsInHistoryCount * 100
					/ counter
			+ " matches3DiffsCount " + matches3DiffsCount
					* 100 / counter
			+ " skipSumOutOfRangeCount " + skipSumOutOfRangeCount
					* 100 / counter
			+ " sameObsDateCount " + sameObsDateCount
					* 100 / counter
			+ " sameObsPercentile " + sameObsPercentile
					* 100 / counter
			+ " unlikelyMaxFactorCount " + unlikelyMaxFactorCount * 100 / counter
			+ " unlikelyFreqShadowReduxesCount " + unlikelyFreqShadowReduxesCount * 100 / counter
			
			
			+ " sameRanksDirectionCount " + sameRanksDirectionCount
			+ " threeOrMoreRelationsCount " + threeOrMoreRelationsCount
			+ " isPossibleCombAccordingToGeneratorVTwoCount "
					+ isPossibleCombAccordingToGeneratorVTwoCount * 100
					/ counter);

			// System.out.println( " checkSkipDetails " +
			// checkSkipDetails*100/counter);
			// System.out.println( " sumNotAppearedRecently " +
			// sumNotAppearedRecentlyCount*100/counter);
			// System.out.println( " sumAppearedRecently " +
			// sumAppearedRecentlyCount*100/counter);
			// System.out.println( " numberOfPrimesNotAsLast3 " +
			// numberOfPrimesNotAsLast3Count*100/counter);

			System.out.println("Time taken "
					+ (System.currentTimeMillis() - starttime) + " ms");

			printFreqMapForTestCombs();
		}

		// progressBar.complete(); // this will finish it
	}

	private static int[] increment(int[] comb) {
		for (int i = 0; i < comb.length; i++)
			comb[i] += 1;
		return comb;
	}

	static boolean next_comb(int comb[], int k, int n) {

		int i = k - 1;
		
		/*if (comb[4] == 59)
			System.out.println("HI");
*/
		comb[i]++;

		while (i > 0 && (comb[i] >= n - k + 1 + i)) {
			i--;
			comb[i]++;
		}

		if (comb[0] > n - k)
			return false;

		for (i = i + 1; i < k && i > 0; i++)
			comb[i] = comb[i - 1] + 1;

		return true;

	}

	static void myprint(long counter, int[] comb, int k) {

		System.out.print(counter + " {");

		for (int i = 0; i < k; i++)
			System.out.print((comb[i] + 1) + ",");

		System.out.println("}");

	}

	static int sum(int[] comb) {
		int sum = 0;
		for (int i = 0; i < comb.length; i++)
			sum += comb[i];

		return sum;
	}

	static boolean intelligentTest(int[] comb) {
		// Numbers n = new Numbers();
		boolean out = false;
		int[] comblocal = new int[comb.length];
		for (int i = 0; i < comb.length; i++)
			comblocal[i] = comb[i] ;
		// increment(comblocal);
		// Filtering out sums between a range
		int numsum = sum(comblocal);
		// Sorting the local copy of comb to make sure that numbers are in order
		// before filters
		ArrayList<Integer> a = new ArrayList<Integer>();
		for (int i = 0; i < comblocal.length; i++) {
			a.add(i, comblocal[i]);
		}
		Collections.sort(a);
		for (int k = 0; k < a.size(); k++)
			comblocal[k] = a.get(k);

		/* if (comb[0] ==1 && comb[1] == 12 && comb[2] == 48 && comb[3] == 57 && comb[4] == 59)
			 System.out.println( numberPassedTest + " -- " + comb[0] + " " + comb[1] + " " + comb[2]+ " " + comb[3] + " " + comb[4]);
		*/ 
		if (((numsum >= startSum) ? true
				: (++sumLessThanStartSumCount > 0 ? false : true))
				&& ((numsum <= endSum) ? true
						: (++sumMoreThanEndSumCount > 0 ? false : true))
				&& (DBPredicAnalysis(comblocal) ? true
						: (++DBPredicCount > 0 ? false : true))
//				&& (ranksNotInSameDirection(comblocal) ? true
//						: (++sameRanksDirectionCount > 0 ? false : true))
				&& (GeneratorVTwo.isPossibleComb(comblocal) ? true
						: (++isPossibleCombAccordingToGeneratorVTwoCount > 0 ? false : true))
				&& (missedDigitsInHistory(comblocal) ? true
						: (++missedDigitsInHistory > 0 ? false : true))
				&& (sameReduxInHistory(comblocal) ? true
						: (++sameReduxCount > 0 ? false : true))
				&& (sameVDiffsInHistory(comblocal) ? true
						: (++sameVDiffCount > 0 ? false : true))
				&& (sameFreqReduxInHistory(comblocal) ? true
						: (++sameFreqReduxCount > 0 ? false : true))
				&& (sameDigitDiffsInHistory(comblocal) ? true
						: (++sameDigitDiffsInHistoryCount > 0 ? false : true))
				&& (threeOrMoreRelations(comblocal) ? true
						: (++threeOrMoreRelationsCount > 0 ? false : true))
				&& (frqBasedFilter(comblocal) ? true
						: (++freqFilterCount > 0 ? false : true))
				&& (n.exclusions(comblocal) ? true
						: (++exclusionsCount > 0 ? false : true))
				&& (properDistribution(comblocal, numberOfZeroInAllBrackets,
						numberMaxInBracket) ? true
						: (++propdistCount > 0 ? false : true))
				&& (predictThroughRedux(comblocal) ? true
						: (++predictThroughReduxCount > 0 ? false : true))
				&& (n.last9CombsAverage(comblocal, avgStart, avgEnd) ? true
						: (++last9CombsAverageCount > 0 ? false : true))
				&& (equiDistantFilter(comblocal) ? true
						: (++equiDistantFilterCount > 0 ? false : true))
				&& (n.combsAlreadyAppeared(comblocal) ? true
						: (++combsAlreadyAppearedCount > 0 ? false : true))
				&& (removeCombsHavingBelowAverageNumbers(comblocal,
						notAllowedBucket50) ? true
						: (++combsBelowAverageNumbersCount > 0 ? false : true))
				&& (removeAllEvensAndOdds(comblocal) ? true
						: (++allEvensAndOddsCount > 0 ? false : true))
				&& (n.aboveAverageFreq(comblocal) ? true
						: (++aboveAverageFreqCount > 0 ? false : true))
				// && (n.inclusions(comblocal) ? true: (++inclusionsCount > 0?
				// false:true ))
				// && (hotNumbers(comblocal) ? true: (++hotNumberCount > 0?
				// false:true ))
				// && (notInBucketListFile(comblocal)? true:
				// (++notInBucketListFileCount> 0?false:true ))
				// && (n.checkSkipDetails(comblocal)? true: (++checkSkipDetails>
				// 0?false:true ))
				// && (n.uniqueBucketPatterns(comblocal)? true:
				// (++uniqueBucketPattern> 0?false:true ))
//				&& (isALikelyBucketPattern(comblocal) ? true
//						: (++notInBucketListFileCount > 0 ? false : true))
				&& (skipSumWithinRange(comblocal) ? true
						: (++skipSumOutOfRangeCount > 0 ? false : true))
//				&& (followerPatternAnalysis(comblocal) ? true
//						: (++followerPatternAnalysisCount > 0 ? false : true))
				&& (sameObsDate(comblocal) ? true
						: (++sameObsDateCount > 0 ? false : true))
				&& (sameObsPercentile(comblocal) ? true
						: (++sameObsPercentile > 0 ? false : true))
				&& (unlikelyFreqShadowReduxes(comblocal) ? true
						: (++unlikelyFreqShadowReduxesCount > 0 ? false : true))		
				&& (isLikelyMaxFactor(comblocal) ? true
						: (++unlikelyMaxFactorCount > 0 ? false : true))
		

		) {
			out = true;

		}

		if (out) {
			
			
			// PRINT FIRST 50 COMBS
			
			/*if (numberPassedTest < 50 ) {
				System.out.println( numberPassedTest + " -- " + comb[0] + " " + comb[1] + " " + comb[2]+ " " + comb[3] + " " + comb[4]);
			}*/

			String st = a.get(0) + "," + a.get(1) + "," + a.get(2) + ","
					+ a.get(3) + "," + a.get(4);
			try {
				output.write(st.toString());
				output.write(";");
				output.flush();
			} catch (IOException ix) {
				ix.printStackTrace();
			}
		}
		return out;

	} 

	private static boolean threeOrMoreRelations(int[] comblocal) {// Number of relations to date are usually 2 or less
																//18 37 25 8   is the typical percentage for 0, 1, 2 and 3+ relations
		boolean out = true;
		int datepart = 0;
		if (forDate == null) {
			int inputLines = 0;
			if (gameCode.equals("1"))
				inputLines = Numbers.getLinesCountFromFile("C:\\Users\\johris\\git\\git\\HelloWorld\\mm.txt");
			else
				inputLines = Numbers.getLinesCountFromFile("C:\\Users\\johris\\git\\git\\HelloWorld\\pb.txt");
			
			datepart = Integer.parseInt(DBUtils.getNextDateForGameAndSerial(gameCode,inputLines-1).substring(6, 8));
		} else {
			datepart = Integer.parseInt(forDate.substring(2,4));
		}
		//int datepart = Integer.parseInt(predicFileName.substring(41,43));
		List<Integer> comblist = Arrays.asList(ArrayUtils.toObject(comblocal));
		if (predicFileName != null && predicFileName.length() > 0) {
			List<String> relations = ListUtils.getRelations(datepart, comblist);
			/*if (Integer.parseInt(Integer.toString(thiscomb.get(0)).substring(6, 8)) > 3)
				System.out.println(relations);
			else
				System.out.println();*/
			
			int numrelations = 0;
			for (String relation: relations) {
				if (relation.length() > 0)
					numrelations ++;
			}
			
			if (datepart > 4 && datepart != 10 && datepart != 20 && datepart != 21) {
				
				if (numrelations > 2)
					out =  false;
			} else {
				if (numrelations == 0)
					out =  false;
			}
		}
		
		return out;
	}

	private static boolean unlikelyFreqShadowReduxes(int[] comblocal) {
		boolean out = true;
		int[] reduxs = new int[comblocal.length];
		
		if (gameCode == null) {
			gte = new GameTypesEntity();
			gameCode = gte.findGameCodeByProgramCode(type);
		}

		rhe.setGameCode(gameCode);
		
		if (lastFreqs == null || lastFreqs.length == 0) {
			lastFreqs = new int[comblocal.length];
			
			lastFreqs[0] = Integer.parseInt( rhe.getLastNForAttribute("firstFreq", 1, 0));
			lastFreqs[1] = Integer.parseInt( rhe.getLastNForAttribute("secondFreq", 1, 0));
			lastFreqs[2] = Integer.parseInt( rhe.getLastNForAttribute("thirdFreq", 1, 0));
			lastFreqs[3] = Integer.parseInt( rhe.getLastNForAttribute("fourthFreq", 1, 0));
			lastFreqs[4] = Integer.parseInt( rhe.getLastNForAttribute("fifthFreq", 1, 0));
		}
		
		
	
		for (int i = 0; i < comblocal.length; i++) {
			if (n.freq.get(comblocal[i]) != null) {
				
				String thisFreq = (String) n.freq.get(comblocal[i]);
				int[] a = new int[comblocal.length];
				a[0] = Math.abs(Integer.parseInt(thisFreq) - lastFreqs[0]);
				a[1] = Math.abs(Integer.parseInt(thisFreq) - lastFreqs[1]);
				a[2] = Math.abs(Integer.parseInt(thisFreq) - lastFreqs[2]);
				a[3] = Math.abs(Integer.parseInt(thisFreq) - lastFreqs[3]);
				a[4] = Math.abs(Integer.parseInt(thisFreq) - lastFreqs[4]);
				
				List la = Arrays.asList(ArrayUtils.toObject(a));
				int minshadow = Collections.min(la);
				
				reduxs[i] = Integer.parseInt(Numbers.getRedux(Integer.toString(minshadow)));
			}
		}

		
		if (rhe.unlikelyFreqShadowRedux(reduxs, gameCode, 0))
			out = false;

		return out;
	}

	private static boolean sameObsPercentile(int[] comblocal) {
		boolean out = true;
		int firstcount = 0;
		int secondcount = 0;
		int thirdcount = 0;
		int fourthcount = 0;
		
		if (obsPercentiles == null) {
			ObservationsEntity obs = new ObservationsEntity();
			obsPercentiles = obs.getObsPercentiles(gameCode);
		}
		
		for (int i=0; i< comblocal.length; i++) {
			if (obsPercentiles.get(comblocal[i]) == 1)
				firstcount++;
			
			if (obsPercentiles.get(comblocal[i]) == 2)
				secondcount++;
			
			if (obsPercentiles.get(comblocal[i]) == 3)
				thirdcount++;
			
			if (obsPercentiles.get(comblocal[i]) == 4)
				fourthcount++;
			
		}
		
		if (firstcount >= 4 || secondcount >= 4 || thirdcount >= 4 || fourthcount >= 4)
			out = false;
		
		
		return out;
	}

	public static boolean sameObsDate(int[] comblocal) {
		boolean out = false;
		ArrayList<String> keyscontainingvalues = new ArrayList<String>();
		ArrayList<String> tempremovekeys = new ArrayList<String>();
		
		if (obsData != null && obsData.size() > 0) {
			
			Enumeration<String> enumKey = obsData.keys();
			while(enumKey.hasMoreElements()) {
			    String key = enumKey.nextElement();
			    ArrayList<Integer> val = obsData.get(key);

			    if (val.contains(comblocal[0])) {
			    	keyscontainingvalues.add(key);
			    }
			}
			
			for (int i=1; i<comblocal.length; i++) {
				if (keyscontainingvalues.size() == 0) {
					return true;
				} else {
					Iterator<String> it = keyscontainingvalues.iterator();
					while (it.hasNext()) {
						String thisdate = it.next();
						if (!obsData.get(thisdate).contains(comblocal[i]))
							tempremovekeys.add(thisdate);
					}
					
					keyscontainingvalues.removeAll(tempremovekeys);
					tempremovekeys = new ArrayList<String>();
				}
			}
			
			if (keyscontainingvalues.size() == 0)
				return true;
			else {
				//System.out.println(keyscontainingvalues);
				return false;
			}
		}
		
		return out;
	}

	private static boolean ranksNotInSameDirection(int[] comblocal) { // We do not want bucketRank, missingDigitRank and followerRank all
																	 // increasing or decreasing for a combination
		boolean out = true;
		
		FollowerPatternEntity fte = new FollowerPatternEntity();
		if (currentFollowerTableForGame ==null) {

			if (gameCode == null) {
				gte = new GameTypesEntity();
				gameCode = gte.findGameCodeByProgramCode(type);
			}
	
			currentFollowerTableForGame = fte.getCurrentFollowerTableForGame(gameCode);
			// System.out.println(h);h
		}
		String thisFollowerPattern = "";

		for (int i = 0; i < comblocal.length; i++) {
			if (((ArrayList) currentFollowerTableForGame.get(Integer.toString(i + 1))).size() > 0) {
				if (((ArrayList) currentFollowerTableForGame.get(Integer.toString(i + 1)))
						.contains(Integer.toString(comblocal[i])))
					thisFollowerPattern += "Y";
				else
					thisFollowerPattern += "N";
			} else {
				thisFollowerPattern += "N";
			}
		}
		
		String thisMissingDigits = getMissingDigitsForComb(comblocal);
		String thisBucketPattern = getBucketPatternForComb(comblocal); 
		//System.out.println("Current bucket, MD and follower ranks " + currentBucketRank + " " + currentMissingDigitRank + " " + currentFollowerRank);
		
		
		if (followerRanks.get(thisFollowerPattern) > currentFollowerRank &&
			((missingDigitRanks.get(thisMissingDigits) == null)?1000:missingDigitRanks.get(thisMissingDigits)) > currentMissingDigitRank &&
			((bucketRanks.get(thisBucketPattern)== null)?1000:bucketRanks.get(thisBucketPattern)) > currentBucketRank) {
			//System.out.println("Comb " + comblocal.toString() + " discarded : high ranks");
			return false;
		}
		
		if (followerRanks.get(thisFollowerPattern) < currentFollowerRank &&
				((missingDigitRanks.get(thisMissingDigits) == null)?1000:missingDigitRanks.get(thisMissingDigits)) < currentMissingDigitRank &&
				((bucketRanks.get(thisBucketPattern)== null)?1000:bucketRanks.get(thisBucketPattern)) < currentBucketRank) {
			//System.out.println("Comb " + comblocal.toString() + " discarded : low ranks");
				return false;
		}
		
		
		return out;
	}

	private static boolean isLikelyMaxFactor(int[] comblocal) {
		boolean out = false;
		/*
		return true;
		*/
		
		if (unlikelyMaxFactors.size() == 0) {
			String excl = rhe.getExclusionsForField("maxFactor", gameCode,  0, 75, 50);
			String[] excfactors = excl.split(",");
			
			for (int i=0; i< excfactors.length; i++) {
				unlikelyMaxFactors.add(Integer.parseInt(excfactors[i]));
			}
			
			System.out.println("Generator.java:isLikelyMaxFactor --- Exclude maxFactor size " + unlikelyMaxFactors.size() + " " + unlikelyMaxFactors);
		}
		
		String mfandcount = Factors.getMaxFactorAndCountForComb(comblocal);
		
		if (mfandcount.length() == 0) return true;
		
		String [] mfac = mfandcount.split(" ");
		
		if (!unlikelyMaxFactors.contains(Integer.parseInt(mfac[0]))) out = true;
		
		return out;
	}

	private static boolean skipSumWithinRange(int[] comblocal) {
		boolean out = false;
		/*
		return true;
		*/
		int sum = 0;
		for (int j = 0; j < comblocal.length; j++) {
			if (n.skipHashCurrent.get(comblocal[j]) != null)
				sum += n.skipHashCurrent.get(comblocal[j]);
		}
		
		if (sum > 10 && sum < 90) out = true;
		
		return out;
	}

	private static int computeSkipSum(int[] comblocal) {
		
		int sum = 0;
		for (int j = 0; j < comblocal.length; j++) {
			if (n.skipHashCurrent.get(comblocal[j]) != null)
				sum += n.skipHashCurrent.get(comblocal[j]);
		}
		
		
		return sum;
	}
	
	private static boolean matches3Differences(int[] comblocal) {
		// TODO Auto-generated method stub
		boolean out = false;
		if (gameCode == null) {
			gte = new GameTypesEntity();
			gameCode = gte.findGameCodeByProgramCode(type);
		}

		if (rhe.matches3Diffs(0, Integer.parseInt(gameCode), comblocal))
			out = true;
		return out;
	}
	
	private static boolean matches3Gaps(int[] comblocal) {
		// TODO Auto-generated method stub
		boolean out = false;
		if (gameCode == null) {
			gte = new GameTypesEntity();
			gameCode = gte.findGameCodeByProgramCode(type);
		}

		if (rhe.matches3Gaps(0, Integer.parseInt(gameCode), comblocal))
			out = true;
		return out;
	}


	private static boolean sameReduxInHistory(int[] comblocal) {
		boolean out = true;
		int[] reduxs = new int[comblocal.length];

		for (int i = 0; i < comblocal.length; i++) {
			reduxs[i] = Integer.parseInt(Numbers.getRedux(Integer
					.toString(comblocal[i])));
		}

		if (gameCode == null) {
			gte = new GameTypesEntity();
			gameCode = gte.findGameCodeByProgramCode(type);
		}

		if (rhe.sameReduxInHistory(reduxs, gameCode, 0))
			out = false;

		return out;
	}
	
	private static boolean sameVDiffsInHistory(int[] comblocal) {
		boolean out = true;
		int[] diffs = new int[comblocal.length];
		
		if (gameCode == null) {
			gte = new GameTypesEntity();
			gameCode = gte.findGameCodeByProgramCode(type);
			
		}
				
		if (lastSet == null || lastSet.length == 0) {
			lastSet = new int[comblocal.length];
			rhe.setGameCode(gameCode);
			lastSet[0] = Integer.parseInt( rhe.getLastNForAttribute("firstValue", 1, 0));
			lastSet[1] = Integer.parseInt( rhe.getLastNForAttribute("secondValue", 1, 0));
			lastSet[2] = Integer.parseInt( rhe.getLastNForAttribute("thirdValue", 1, 0));
			lastSet[3] = Integer.parseInt( rhe.getLastNForAttribute("fourthValue", 1, 0));
			lastSet[4] = Integer.parseInt( rhe.getLastNForAttribute("fifthValue", 1, 0));
		}
		

		for (int i = 0; i < comblocal.length; i++) {
			diffs[i] = Math.abs(comblocal[i] - lastSet[i]);
		}

		

		if (rhe.sameVDiffInHistory(diffs, gameCode, 0))
			out = false;

		return out;
	}
	
	
	
	private static boolean sameFreqReduxInHistory(int[] comblocal) {
		boolean out = true;
		int[] reduxs = new int[comblocal.length];
	
		for (int i = 0; i < comblocal.length; i++) {
			if (n.freq.get(comblocal[i]) != null) {
				reduxs[i] = Integer.parseInt(Numbers.getRedux((String) n.freq
								.get(comblocal[i])));
			}
		}

		if (gameCode == null) {
			gte = new GameTypesEntity();
			gameCode = gte.findGameCodeByProgramCode(type);
		}

		if (rhe.sameFreqReduxInHistory(reduxs, gameCode, 0))
			out = false;

		return out;
	}
	
	
	
	
	
	private static boolean sameDigitDiffsInHistory(int[] comblocal) {
		boolean out = true;
		int[] reduxs = new int[comblocal.length];

		for (int i = 0; i < comblocal.length; i++) {
			reduxs[i] = Math.abs((comblocal[i] / 10) - (comblocal[i] % 10));
		}

		if (gameCode == null) {
			gte = new GameTypesEntity();
			gameCode = gte.findGameCodeByProgramCode(type);
		}

		if (rhe.sameDigitDiffInHistory(reduxs, gameCode, 0))
			out = false;

		return out;
	}

	private static boolean missedDigitsInHistory(int[] comblocal) {
		boolean out = true;
		String missingDigits = getMissingDigitsForComb(comblocal);
			
		if (missingDigits.length() == 0)
			return false;

		if (Numbers.missingDigits.containsKey(missingDigits)) {
			Integer val = Numbers.missingDigits.get(missingDigits);

			if (val == 1)
				return false;
		}

		return out;
	}
	
	private static String getMissingDigitsForComb(int[] comblocal) {
		String missingDigits = "";
		ArrayList complete = new ArrayList(Arrays.asList(new String[] { "1", "2", "3", "4", "5", "6", "7", "8", "9","0" }));
		ArrayList<String> removeList = new ArrayList<String>();

		int[] thisLine = new int[6];
		for (int i = 0; i < comblocal.length; i++) {
			String num = Integer.toString(comblocal[i]);

			if (complete.contains(Integer.toString(Integer.parseInt(num) / 10)))
				removeList.add(Integer.toString(Integer.parseInt(num) / 10));

			if (complete.contains(Integer.toString(Integer.parseInt(num) % 10)))
				removeList.add(Integer.toString(Integer.parseInt(num) % 10));

		}

		for (String removeEntry : removeList) {
			complete.remove(removeEntry);
		}

		Iterator it = complete.iterator();
		while (it.hasNext()) {
			missingDigits += ((String) it.next());
		}
		
		return missingDigits;
	}

	private static boolean DisallowDigit(int[] comblocal) {
		boolean out = true;

		for (int i = 0; i < comblocal.length; i++) {
			if (comblocal[i] / 10 == disallowDigit)
				return false;

			if (comblocal[i] % 10 == disallowDigit)
				return false;
		}

		return out;
	}

	private static boolean DBPredicAnalysis(int[] comblocal) {
		boolean out = true;
		int violations = 0;
		int allowedViolations = 0;

		if (DBpredicProp.isEmpty()) {

			setDBpredicProp(null);

			System.out.println("Generator.java ---- Procesing prediction file "
					+ predicFileName + " Allowed violations "
					+ allowedViolations);

			if (DBpredicProp.getProperty("EMPTYPREDICPROP") != null)
				return true;

		} else {
			if (DBpredicProp.getProperty("EMPTYPREDICPROP") != null)
				return true;
		}

		String param = DBpredicProp.getProperty("FIRSTSKIP");
		if (param != null && param.length() > 0) {
			int startInd = param.indexOf("[") + 1;
			if (startInd > 0) {
				String val = param.substring(startInd, param.indexOf("]"));

				String[] valA = val.split("\\,");
				List lis = (List) Arrays.asList(valA);

				Integer skip = n.getSkipHashCurrent().get(comblocal[0]);

				if (lis.contains(Integer.toString(skip))) {
					if (startInd > 1) {// Prediction was a NOT
						// return false;
						violations++;
					}
				} else {
					if (startInd <= 1) {
						violations++;
					}
				}
			}
		}

		param = DBpredicProp.getProperty("SECONDSKIP");
		if (param != null && param.length() > 0) {
			int startInd = param.indexOf("[") + 1;
			if (startInd > 0) {
				String val = param.substring(startInd, param.indexOf("]"));

				String[] valA = val.split("\\,");
				List lis = (List) Arrays.asList(valA);

				Integer skip = n.getSkipHashCurrent().get(comblocal[1]);

				if (skip != null) {
					if (lis.contains(Integer.toString(skip))) {
						if (startInd > 1) {// Prediction was a NOT
							violations++;
						}
					} else {
						if (startInd <= 1) {
							violations++;
						}
					}
				} else {
					if (startInd <= 1) {
						violations++;
					}
				}
			}
		}

		param = DBpredicProp.getProperty("THIRDSKIP");
		if (param != null && param.length() > 0) {
			int startInd = param.indexOf("[") + 1;
			if (startInd > 0) {
				String val = param.substring(startInd, param.indexOf("]"));

				String[] valA = val.split("\\,");
				List lis = (List) Arrays.asList(valA);

				Integer skip = n.getSkipHashCurrent().get(comblocal[2]);

				if (skip != null) {
					if (lis.contains(Integer.toString(skip))) {
						if (startInd > 1) {// Prediction was a NOT
							violations++;
						}
					} else {
						if (startInd <= 1) {
							violations++;
						}
					}
				} else {
					if (startInd <= 1) {
						violations++;
					}
				}
			}
		}

		param = DBpredicProp.getProperty("FOURTHSKIP");
		if (param != null && param.length() > 0) {
			int startInd = param.indexOf("[") + 1;
			if (startInd > 0) {
				String val = param.substring(startInd, param.indexOf("]"));

				String[] valA = val.split("\\,");
				List lis = (List) Arrays.asList(valA);

				Integer skip = n.getSkipHashCurrent().get(comblocal[3]);

				if (skip != null) {
					if (lis.contains(Integer.toString(skip))) {
						if (startInd > 1) {// Prediction was a NOT
							violations++;
						}
					} else {
						if (startInd <= 1) {
							violations++;
						}
					}
				} else { // SKIP is null
					if (startInd <= 1) {
						violations++;
					}
				}
			}
		}

		param = DBpredicProp.getProperty("FIFTHSKIP");
		if (param != null && param.length() > 0) {
			int startInd = param.indexOf("[") + 1;
			if (startInd > 0) {
				String val = param.substring(startInd, param.indexOf("]"));

				String[] valA = val.split("\\,");
				List lis = (List) Arrays.asList(valA);

				Integer skip = n.getSkipHashCurrent().get(comblocal[4]);

				if (skip != null) {
					if (lis.contains(Integer.toString(skip))) {
						if (startInd > 1) {// Prediction was a NOT
							violations++;
						}
					} else {
						if (startInd <= 1) {
							violations++;
						}
					}
				} else {
					if (startInd <= 1) {
						violations++;
					}
				}
			}
		}

		if (violations > allowedViolations)
			return false;

		param = DBpredicProp.getProperty("FIRSTVALUE");
		if (param != null && param.length() > 0) {
			int startInd = param.indexOf("[") + 1;
			if (startInd > 0) {
				String val = param.substring(startInd, param.indexOf("]"));

				String[] valA = val.split("\\,");
				List lis = (List) Arrays.asList(valA);

				if (lis.contains(Integer.toString(comblocal[0]))) {
					if (startInd > 1) {// Prediction was a NOT
						violations++;
					}
				} else {
					if (startInd <= 1) {
						violations++;
					}
				}
			}
		}

		param = DBpredicProp.getProperty("SECONDVALUE");
		if (param != null && param.length() > 0) {
			int startInd = param.indexOf("[") + 1;
			if (startInd > 0) {
				String val = param.substring(startInd, param.indexOf("]"));

				String[] valA = val.split("\\,");
				List lis = (List) Arrays.asList(valA);

				if (lis.contains(Integer.toString(comblocal[1]))) {
					if (startInd > 1) {// Prediction was a NOT
						violations++;
					}
				} else {
					if (startInd <= 1) {
						violations++;
					}
				}
			}
		}

		param = DBpredicProp.getProperty("THIRDVALUE");
		if (param != null && param.length() > 0) {
			int startInd = param.indexOf("[") + 1;
			if (startInd > 0) {
				String val = param.substring(startInd, param.indexOf("]"));

				String[] valA = val.split("\\,");
				List lis = (List) Arrays.asList(valA);

				if (lis.contains(Integer.toString(comblocal[2]))) {
					if (startInd > 1) {// Prediction was a NOT
						violations++;
					}
				} else {
					if (startInd <= 1) {
						violations++;
					}
				}
			}
		}

		param = DBpredicProp.getProperty("FOURTHVALUE");
		if (param != null && param.length() > 0) {
			int startInd = param.indexOf("[") + 1;
			if (startInd > 0) {
				String val = param.substring(startInd, param.indexOf("]"));

				String[] valA = val.split("\\,");
				List lis = (List) Arrays.asList(valA);

				if (lis.contains(Integer.toString(comblocal[3]))) {
					if (startInd > 1) {// Prediction was a NOT
						violations++;
					}
				} else {
					if (startInd <= 1) {
						violations++;
					}
				}
			}
		}

		param = DBpredicProp.getProperty("FIFTHVALUE");
		if (param != null && param.length() > 0) {
			int startInd = param.indexOf("[") + 1;
			if (startInd > 0) {
				String val = param.substring(startInd, param.indexOf("]"));

				String[] valA = val.split("\\,");
				List lis = (List) Arrays.asList(valA);

				if (lis.contains(Integer.toString(comblocal[4]))) {
					if (startInd > 1) {// Prediction was a NOT
						violations++;
					}
				} else {
					if (startInd <= 1) {
						violations++;
					}
				}
			}
		}

		if (violations > allowedViolations)
			return false;

		param = DBpredicProp.getProperty("FIRSTBUCKET");
		if (param != null && param.length() > 0) {
			int startInd = param.indexOf("[") + 1;
			if (startInd > 0) {
				String val = param.substring(startInd, param.indexOf("]"));

				String[] valA = val.split("\\,");
				List lis = (List) Arrays.asList(valA);

				if (lis.contains(Integer.toString(comblocal[0] / 10))) {
					if (startInd > 1) {// Prediction was a NOT
						violations++;
					}
				} else {
					if (startInd <= 1) {
						violations++;
					}
				}
			}
		}

		param = DBpredicProp.getProperty("SECONDBUCKET");
		if (param != null && param.length() > 0) {
			int startInd = param.indexOf("[") + 1;
			if (startInd > 0) {
				String val = param.substring(startInd, param.indexOf("]"));

				String[] valA = val.split("\\,");
				List lis = (List) Arrays.asList(valA);

				if (lis.contains(Integer.toString(comblocal[1] / 10))) {
					if (startInd > 1) {// Prediction was a NOT
						violations++;
					}
				} else {
					if (startInd <= 1) {
						violations++;
					}
				}
			}
		}

		param = DBpredicProp.getProperty("THIRDBUCKET");
		if (param != null && param.length() > 0) {
			int startInd = param.indexOf("[") + 1;
			if (startInd > 0) {
				String val = param.substring(startInd, param.indexOf("]"));

				String[] valA = val.split("\\,");
				List lis = (List) Arrays.asList(valA);

				if (lis.contains(Integer.toString(comblocal[2] / 10))) {
					if (startInd > 1) {// Prediction was a NOT
						violations++;
					}
				} else {
					if (startInd <= 1) {
						violations++;
					}
				}
			}
		}

		param = DBpredicProp.getProperty("FOURTHBUCKET");
		if (param != null && param.length() > 0) {
			int startInd = param.indexOf("[") + 1;
			if (startInd > 0) {
				String val = param.substring(startInd, param.indexOf("]"));

				String[] valA = val.split("\\,");
				List lis = (List) Arrays.asList(valA);

				if (lis.contains(Integer.toString(comblocal[3] / 10))) {
					if (startInd > 1) {// Prediction was a NOT
						violations++;
					}
				} else {
					if (startInd <= 1) {
						violations++;
					}
				}
			}
		}

		param = DBpredicProp.getProperty("FIFTHBUCKET");
		if (param != null && param.length() > 0) {
			int startInd = param.indexOf("[") + 1;
			if (startInd > 0) {
				String val = param.substring(startInd, param.indexOf("]"));

				String[] valA = val.split("\\,");
				List lis = (List) Arrays.asList(valA);

				if (lis.contains(Integer.toString(comblocal[4] / 10))) {
					if (startInd > 1) {// Prediction was a NOT
						violations++;
					}
				} else {
					if (startInd <= 1) {
						violations++;
					}
				}
			}
		}

		if (violations > allowedViolations)
			return false;

		param = DBpredicProp.getProperty("FIRSTREDUX");
		if (param != null && param.length() > 0) {
			int startInd = param.indexOf("[") + 1;
			if (startInd > 0) {
				String val = param.substring(startInd, param.indexOf("]"));

				String[] valA = val.split("\\,");
				List lis = (List) Arrays.asList(valA);

				if (lis.contains(n.getRedux(Integer.toString(comblocal[0])))) {
					if (startInd > 1) {// Prediction was a NOT
						violations++;
					}
				} else {
					if (startInd <= 1) {
						violations++;
					}
				}
			}
		}

		param = DBpredicProp.getProperty("SECONDREDUX");
		if (param != null && param.length() > 0) {
			int startInd = param.indexOf("[") + 1;
			if (startInd > 0) {
				String val = param.substring(startInd, param.indexOf("]"));

				String[] valA = val.split("\\,");
				List lis = (List) Arrays.asList(valA);

				if (lis.contains(n.getRedux(Integer.toString(comblocal[1])))) {
					if (startInd > 1) {// Prediction was a NOT
						violations++;
					}
				} else {
					if (startInd <= 1) {
						violations++;
					}
				}
			}
		}

		param = DBpredicProp.getProperty("THIRDREDUX");
		if (param != null && param.length() > 0) {
			int startInd = param.indexOf("[") + 1;
			if (startInd > 0) {
				String val = param.substring(startInd, param.indexOf("]"));

				String[] valA = val.split("\\,");
				List lis = (List) Arrays.asList(valA);

				if (lis.contains(n.getRedux(Integer.toString(comblocal[2])))) {
					if (startInd > 1) {// Prediction was a NOT
						violations++;
					}
				} else {
					if (startInd <= 1) {
						violations++;
					}
				}
			}
		}

		param = DBpredicProp.getProperty("FOURTHREDUX");
		if (param != null && param.length() > 0) {
			int startInd = param.indexOf("[") + 1;

			if (startInd > 0) {
				String val = param.substring(startInd, param.indexOf("]") - 1);
				String[] valA = val.split("\\,");
				List lis = (List) Arrays.asList(valA);

				if (lis.contains(n.getRedux(Integer.toString(comblocal[3])))) {
					if (startInd > 1) {// Prediction was a NOT
						violations++;
					}
				} else {
					if (startInd <= 1) {
						violations++;
					}
				}
			}
		}

		param = DBpredicProp.getProperty("FIFTHREDUX");
		if (param != null && param.length() > 0) {
			int startInd = param.indexOf("[") + 1;
			if (startInd > 0) {
				String val = param.substring(startInd, param.indexOf("]"));
				String[] valA = val.split("\\,");
				List lis = (List) Arrays.asList(valA);

				if (lis.contains(n.getRedux(Integer.toString(comblocal[4])))) {
					if (startInd > 1) {// Prediction was a NOT
						violations++;
					}
				} else {
					if (startInd <= 1) {
						violations++;
					}
				}
			}
		}

		if (violations > allowedViolations)
			return false;

		param = DBpredicProp.getProperty("FIRSTFIVESUMREDUX");
		if (param != null && param.length() > 0) {
			int startInd = param.indexOf("[") + 1;
			if (startInd > 0) {
				String val = param.substring(startInd, param.indexOf("]"));

				String[] valA = val.split("\\,");
				List lis = (List) Arrays.asList(valA);

				if (lis.contains(n.getRedux(Integer.toString(comblocal[0]
						+ comblocal[1] + comblocal[2] + comblocal[3]
						+ comblocal[4])))) {
					if (startInd > 1) {// Prediction was a NOT
						violations++;
					}
				} else {
					if (startInd <= 1) {
						violations++;
					}
				}
			}
		}

		if (violations > allowedViolations)
			return false;

		param = DBpredicProp.getProperty("FIRSTFIVESUMBUCKET");
		if (param != null && param.length() > 0) {
			int startInd = param.indexOf("[") + 1;
			if (startInd > 0) {
				String val = param.substring(startInd, param.indexOf("]"));

				String[] valA = val.split("\\,");
				List lis = (List) Arrays.asList(valA);

				if (lis.contains(Integer.toString((comblocal[0] + comblocal[1]
						+ comblocal[2] + comblocal[3] + comblocal[4]) / 10))) {
					if (startInd > 1) {// Prediction was a NOT
						violations++;
					}
				} else {
					if (startInd <= 1) {
						violations++;
					}
				}
			}
		}

		if (violations > allowedViolations)
			return false;

		param = DBpredicProp.getProperty("FIRSTFIVESUM");
		if (param != null && param.length() > 0) {
			int startInd = param.indexOf("[") + 1;
			if (startInd > 0) {
				String val = param.substring(startInd, param.indexOf("]"));
				val = val.replace(" ", "");

				String[] valA = val.split("\\,");
				List lis = (List) Arrays.asList(valA);

				if (lis.contains(Integer.toString(comblocal[0] + comblocal[1]
													+ comblocal[2] + comblocal[3] + comblocal[4] 
												 )
								 )
					) {
					if (startInd > 1) {// Prediction was a NOT
						violations++;
						//System.out.println("Comb discarded due to sum exclusion...");
					}
				} else {
					if (startInd <= 1) {
						violations++;
						//System.out.println("Comb discarded due to sum inclusion...");
					}
				}
			}

			if (param.indexOf("ODD") >= 0 || param.indexOf("EVEN") >= 0) {
				if (param.indexOf("ODD") >= 0) {
					if ((comblocal[0] + comblocal[1] + comblocal[2]
							+ comblocal[3] + comblocal[4]) % 2 == 0)
						violations++;
				}

				if (param.indexOf("EVEN") >= 0) {
					if ((comblocal[0] + comblocal[1] + comblocal[2]
							+ comblocal[3] + comblocal[4]) % 2 > 0)
						violations++;
				}
			}
		}

		if (violations > allowedViolations)
			return false;

		param = DBpredicProp.getProperty("NUMPRIMES");
		if (param != null && param.length() > 0) {
			int startInd = param.indexOf("[") + 1;
			if (startInd > 0) {
				String val = param.substring(startInd, param.indexOf("]"));

				String[] valA = val.split("\\,");
				List lis = (List) Arrays.asList(valA);

				//Iterator it = lis.iterator();

				//while (it.hasNext()) {
					//int count = Integer.parseInt((String) it.next());
					int primes = numberOfPrimesInComb(comblocal);
					
					if (lis.contains(Integer.toString(primes))) {
						if (startInd > 1) {// Prediction was a NOT
							violations++;
						}
					} else {
						if (startInd <= 1) {
							violations++;
						} 
					}
				//}
			}
		}

		if (violations > allowedViolations)
			return false;

		param = DBpredicProp.getProperty("FIRSTFOLLOWER");
		if (param != null && param.length() > 0) {

			int startInd = param.indexOf("[") + 1;
			if (startInd > 0) {
				String val = param.substring(startInd, param.indexOf("]"));

				String[] valA = val.split("\\,");
				// List lis = (List) Arrays.asList(valA);

				String vals = (String) followers.get("FirstFollower");

				String[] avals = vals.split("\\,");
				List lis = (List) Arrays.asList(avals);

				if (lis.contains(Integer.toString(comblocal[0]))) {

					if (valA[0].equals("N")) {
						if (startInd <= 1) {
							violations++;
						}
					} else {
						if (startInd > 1) { // Prediction was a NOT and Value
											// was Y
							violations++;
						}
					}

				} else {
					if (valA[0].equals("Y")) {
						if (startInd <= 1) {
							violations++;
						}
					} else {
						if (startInd > 1) { // Prediction was a NOT and Value
											// was N
							violations++;
						}
					}
				}
			}
		}

		if (violations > allowedViolations)
			return false;

		param = DBpredicProp.getProperty("SECONDFOLLOWER");
		if (param != null && param.length() > 0) {

			int startInd = param.indexOf("[") + 1;
			if (startInd > 0) {
				String val = param.substring(startInd, param.indexOf("]"));

				String[] valA = val.split("\\,");
				// List lis = (List) Arrays.asList(valA);

				String vals = (String) followers.get("SecondFollower");

				String[] avals = vals.split("\\,");
				List lis = (List) Arrays.asList(avals);

				if (lis.contains(Integer.toString(comblocal[1]))) {

					if (valA[0].equals("N")) {
						if (startInd <= 1) {
							violations++;
						}
					} else {
						if (startInd > 1) { // Prediction was a NOT and Value
											// was Y
							violations++;
						}
					}

				} else {
					if (valA[0].equals("Y")) {
						if (startInd <= 1) {
							violations++;
						}
					} else {
						if (startInd > 1) { // Prediction was a NOT and Value
											// was N
							violations++;
						}
					}
				}
			}
		}

		if (violations > allowedViolations)
			return false;

		param = DBpredicProp.getProperty("THIRDFOLLOWER");
		if (param != null && param.length() > 0) {

			int startInd = param.indexOf("[") + 1;
			if (startInd > 0) {
				String val = param.substring(startInd, param.indexOf("]"));

				String[] valA = val.split("\\,");
				// List lis = (List) Arrays.asList(valA);

				String vals = (String) followers.get("ThirdFollower");

				String[] avals = vals.split("\\,");
				List lis = (List) Arrays.asList(avals);

				if (lis.contains(Integer.toString(comblocal[2]))) {

					if (valA[0].equals("N")) {
						if (startInd <= 1) {
							violations++;
						}
					} else {
						if (startInd > 1) { // Prediction was a NOT and Value
											// was Y
							violations++;
						}
					}

				} else {
					if (valA[0].equals("Y")) {
						if (startInd <= 1) {
							violations++;
						}
					} else {
						if (startInd > 1) { // Prediction was a NOT and Value
											// was N
							violations++;
						}
					}
				}
			}
		}

		if (violations > allowedViolations)
			return false;

		param = DBpredicProp.getProperty("FOURTHFOLLOWER");
		if (param != null && param.length() > 0) {

			int startInd = param.indexOf("[") + 1;
			if (startInd > 0) {
				String val = param.substring(startInd, param.indexOf("]"));

				String[] valA = val.split("\\,");
				// List lis = (List) Arrays.asList(valA);

				String vals = (String) followers.get("FourthFollower");

				String[] avals = vals.split("\\,");
				List lis = (List) Arrays.asList(avals);

				if (lis.contains(Integer.toString(comblocal[3]))) {

					if (valA[0].equals("N")) {
						if (startInd <= 1) {
							violations++;
						}
					} else {
						if (startInd > 1) { // Prediction was a NOT and Value
											// was Y
							violations++;
						}
					}

				} else {
					if (valA[0].equals("Y")) {
						if (startInd <= 1) {
							violations++;
						}
					} else {
						if (startInd > 1) { // Prediction was a NOT and Value
											// was N
							violations++;
						}
					}
				}
			}
		}
		if (violations > allowedViolations)
			return false;

		param = DBpredicProp.getProperty("FIFTHFOLLOWER");
		if (param != null && param.length() > 0) {

			int startInd = param.indexOf("[") + 1;
			if (startInd > 0) {
				String val = param.substring(startInd, param.indexOf("]"));

				String[] valA = val.split("\\,");
				// List lis = (List) Arrays.asList(valA);

				String vals = (String) followers.get("FifthFollower");

				String[] avals = vals.split("\\,");
				List lis = (List) Arrays.asList(avals);

				if (lis.contains(Integer.toString(comblocal[4]))) {

					if (valA[0].equals("N")) {
						if (startInd <= 1) {
							violations++;
						}
					} else {
						if (startInd > 1) { // Prediction was a NOT and Value
											// was Y
							violations++;
						}
					}

				} else {
					if (valA[0].equals("Y")) {
						if (startInd <= 1) {
							violations++;
						}
					} else {
						if (startInd > 1) { // Prediction was a NOT and Value
											// was N
							violations++;
						}
					}
				}
			}
		}

		if (violations > allowedViolations)
			return false;

		param = DBpredicProp.getProperty("FIRSTFIVESUMPRIME");
		if (param != null && param.length() > 0) {
			int startInd = param.indexOf("[") + 1;
			if (startInd > 0) {
				String val = param.substring(startInd, param.indexOf("]"));

				String[] valA = val.split("\\,");
				List lis = (List) Arrays.asList(valA);

				if (sumPrimesList.contains(comblocal[0] + comblocal[1]
						+ comblocal[2] + comblocal[3] + comblocal[4])) {

					if (valA[0].equals("0")) {
						if (startInd <= 1) {
							violations++;
						}
					} else {
						if (startInd > 1) { // Prediction was a NOT and Value
											// was Y
							violations++;
						}
					}

				} else {
					if (valA[0].equals("1")) {
						if (startInd <= 1) {
							violations++;
						}
					} else {
						if (startInd > 1) { // Prediction was a NOT and Value
											// was N
							violations++;
						}
					}
				}

			}
		}

		if (violations > allowedViolations)
			return false;

		param = DBpredicProp.getProperty("MATCH3DIFFS");
		if (param != null && param.length() > 0) {
			if (param.startsWith("Y")) {
				if (!matches3Differences(comblocal))
					violations++;
			} else {
				if (matches3Differences(comblocal))
					violations++;
			}

		}

		if (violations > allowedViolations)
			return false;
		
		param = DBpredicProp.getProperty("MATCH3GAPS");
		if (param != null && param.length() > 0) {
			if (param.startsWith("Y")) {
				if (!matches3Gaps(comblocal))
					violations++;
			} else {
				if (matches3Gaps(comblocal))
					violations++;
			}

		}

		if (violations > allowedViolations)
			return false;
		
		param = DBpredicProp.getProperty("DIFF1");
		if (param != null && param.length() > 0) {
			int startInd = param.indexOf("[") + 1;
			if (startInd > 0) {
				String val = param.substring(startInd, param.indexOf("]"));
				String[] valA = val.split("\\,");
				List lis = (List) Arrays.asList(valA);

				if (lis.contains(Integer.toString(comblocal[1]-comblocal[0]))) {
					if (startInd > 1) {// Prediction was a NOT
						violations++;
					}
				} else {
					if (startInd <= 1) {
						violations++;
					}
				}
			}
			
			if (param.indexOf("ODD") >= 0 || param.indexOf("EVEN") >= 0) {
				if (param.indexOf("ODD") >= 0) {
					if ((comblocal[1]-comblocal[0])% 2 == 0)
						violations++;
				}

				if (param.indexOf("EVEN") >= 0) {
					if ((comblocal[1]-comblocal[0]) % 2 > 0)
						violations++;
				}
			}
		}

		if (violations > allowedViolations)
			return false;

		param = DBpredicProp.getProperty("DIFF2");
		if (param != null && param.length() > 0) {
			int startInd = param.indexOf("[") + 1;
			if (startInd > 0) {
				String val = param.substring(startInd, param.indexOf("]"));
				String[] valA = val.split("\\,");
				List lis = (List) Arrays.asList(valA);

				if (lis.contains(Integer.toString(comblocal[2]-comblocal[0]))) {
					if (startInd > 1) {// Prediction was a NOT
						violations++;
					}
				} else {
					if (startInd <= 1) {
						violations++;
					}
				}
			}
			
			if (param.indexOf("ODD") >= 0 || param.indexOf("EVEN") >= 0) {
				if (param.indexOf("ODD") >= 0) {
					if ((comblocal[2]-comblocal[0])% 2 == 0)
						violations++;
				}

				if (param.indexOf("EVEN") >= 0) {
					if ((comblocal[2]-comblocal[0]) % 2 > 0)
						violations++;
				}
			}
		}

		if (violations > allowedViolations)
			return false;

		param = DBpredicProp.getProperty("DIFF3");
		if (param != null && param.length() > 0) {
			int startInd = param.indexOf("[") + 1;
			if (startInd > 0) {
				String val = param.substring(startInd, param.indexOf("]"));
				String[] valA = val.split("\\,");
				List lis = (List) Arrays.asList(valA);

				if (lis.contains(Integer.toString(comblocal[3]-comblocal[0]))) {
					if (startInd > 1) {// Prediction was a NOT
						violations++;
					}
				} else {
					if (startInd <= 1) {
						violations++;
					}
				}
			}
			
			if (param.indexOf("ODD") >= 0 || param.indexOf("EVEN") >= 0) {
				if (param.indexOf("ODD") >= 0) {
					if ((comblocal[3]-comblocal[0])% 2 == 0)
						violations++;
				}

				if (param.indexOf("EVEN") >= 0) {
					if ((comblocal[3]-comblocal[0]) % 2 > 0)
						violations++;
				}
			}
		}

		if (violations > allowedViolations)
			return false;

		param = DBpredicProp.getProperty("DIFF4");
		if (param != null && param.length() > 0) {
			int startInd = param.indexOf("[") + 1;
			if (startInd > 0) {
				String val = param.substring(startInd, param.indexOf("]"));
				String[] valA = val.split("\\,");
				List lis = (List) Arrays.asList(valA);

				if (lis.contains(Integer.toString(comblocal[4]-comblocal[0]))) {
					if (startInd > 1) {// Prediction was a NOT
						violations++;
					}
				} else {
					if (startInd <= 1) {
						violations++;
					}
				}
			}
			
			if (param.indexOf("ODD") >= 0 || param.indexOf("EVEN") >= 0) {
				if (param.indexOf("ODD") >= 0) {
					if ((comblocal[4]-comblocal[0])% 2 == 0)
						violations++;
				}

				if (param.indexOf("EVEN") >= 0) {
					if ((comblocal[4]-comblocal[0]) % 2 > 0)
						violations++;
				}
			}
		}

		if (violations > allowedViolations)
			return false;


		param = DBpredicProp.getProperty("OBSINCLUDECOUNT");
		if (param != null && param.length() > 0) {
			int obsIncludeCount = Integer.parseInt(param);
			param = DBpredicProp.getProperty("OBSLIST");
			int count = 0;
			if (param != null && param.length() > 0) {
				String val = "";
				int startInd = param.indexOf("[") + 1;
				if (startInd > 0) {
					val = param.substring(startInd, param.indexOf("]"));
					String[] valA = val.split("\\,");
					List lis = (List) Arrays.asList(valA);

					for (int i = 0; i < comblocal.length; i++) {
						if (lis.contains(Integer.toString(comblocal[i])))
							count++;
					}
				}
				
				if (val.length() > 0) {
					if (count != obsIncludeCount)
						violations++;
				}

			}

			
		}

		param = DBpredicProp.getProperty("SKIPSUM");
		if (param != null && param.length() > 0) {
			int startInd = param.indexOf("[") + 1;
			if (startInd > 0) {
				String val = param.substring(startInd, param.indexOf("]"));
				val = val.replace(" ", "");

				String[] valA = val.split("\\,");
				List lis = (List) Arrays.asList(valA);

				if (lis.contains(Integer.toString(computeSkipSum(comblocal) )
								 )
					) {
					if (startInd > 1) {// Prediction was a NOT
						violations++;
						//System.out.println("Comb discarded due to sum exclusion...");
					}
				} else {
					if (startInd <= 1) {
						violations++;
						//System.out.println("Comb discarded due to sum inclusion...");
					}
				}
			}

			if (param.indexOf("ODD") >= 0 || param.indexOf("EVEN") >= 0) {
				if (param.indexOf("ODD") >= 0) {
					if (computeSkipSum(comblocal) % 2 == 0)
						violations++;
				}

				if (param.indexOf("EVEN") >= 0) {
					if (computeSkipSum(comblocal) % 2 > 0)
						violations++;
				}
			}
		}

		if (violations > allowedViolations)
			return false;

		return out;
	}

	private static boolean followerPatternAnalysis(int[] comblocal) { // We do
																		// not
																		// want
																		// the
																		// comb
																		// to be
																		// one
																		// of
																		// the
																		// last
																		// few
																		// follower
																		// patterns
																		// Follower
																		// pattern
																		// is
																		// whether
																		// the
																		// number
																		// appearing
																		// has
																		// followed
																		// the
																		// previous
																		// number
																		// in
																		// history.
		boolean out = true;
		FollowerPatternEntity fte = new FollowerPatternEntity();
		if (currentFollowerTableForGame ==null) {

			if (gameCode == null) {
				gte = new GameTypesEntity();
				gameCode = gte.findGameCodeByProgramCode(type);
			}
	
			currentFollowerTableForGame = fte.getCurrentFollowerTableForGame(gameCode);
			// System.out.println(h);
		}
		
		if (fte.getLast10Patterns() == null) {
			fte.populateLast10Patterns(gameCode,0);
			System.out.println("Generator.java:followerPatternAnalysis --- Exclude follower pattern size " + fte.getLast10Patterns().size() + " " + fte.getLast10Patterns().toString());
		}
		
		String thisPattern = "";

		for (int i = 0; i < comblocal.length; i++) {
			if (((ArrayList) currentFollowerTableForGame.get(Integer.toString(i + 1))).size() > 0) {
				if (((ArrayList) currentFollowerTableForGame.get(Integer.toString(i + 1)))
						.contains(Integer.toString(comblocal[i])))
					thisPattern += "Y";
				else
					thisPattern += "N";
			} else {
				thisPattern += "X";
			}
		}

		//Iterator it = fte.getLast10Patterns().iterator();

		/*while (it.hasNext()) {
			String pattern = (String) it.next();

			if (pattern.startsWith(thisPattern))
				return false;
		}*/
		
		if (fte.getLast10Patterns().contains(thisPattern)) return false;

		return out;
	}

	private static boolean numberOfPrimesNotAsLast3(int[] comblocal) {
		// TODO Automate this
		// Numbers.last10MultAndPrimes
		int countOfPrimes = 0;

		for (int i = 0; i < comblocal.length; i++) {
			if (Numbers.primesTill75.contains(comblocal[i]))
				countOfPrimes++;
		}

		if (countOfPrimes != 1 && countOfPrimes != 3)
			return false;

		return true;
	}

	private static boolean numberOfPrimesMatch(int[] comblocal, int count) {
		// TODO Automate this
		// Numbers.last10MultAndPrimes
		int countOfPrimes = 0;

		for (int i = 0; i < comblocal.length; i++) {
			if (Numbers.primesTill75.contains(comblocal[i]))
				countOfPrimes++;
		}

		if (countOfPrimes != count)
			return false;

		return true;
	}
	
	private static int numberOfPrimesInComb(int[] comblocal) {
		// TODO Automate this
		// Numbers.last10MultAndPrimes
		int countOfPrimes = 0;

		for (int i = 0; i < comblocal.length; i++) {
			if (Numbers.primesTill75.contains(comblocal[i]))
				countOfPrimes++;
		}

		
		return countOfPrimes;
	}

	private static boolean predictThroughRedux(int[] comblocal) {

		int followsReduxMap = 0; // We do not want to follow reduxMap very
									// rigidly, we allow max 2 exceptions
		int sum = 0;

		for (int i = 0; i < comblocal.length; i++) {
			if (!possibleBucketMap.get(i).contains(comblocal[i] / 10))
				return false;

			if (reduxPredictMap.get(i) != null) {
				if (reduxPredictMap.get(i).contains(
						Integer.parseInt(Numbers.getRedux(Integer
								.toString(comblocal[i])))))
					followsReduxMap++;
			} else {
				followsReduxMap++;
			}

			sum += comblocal[i];
		}

		if (followsReduxMap < 5)
			return false;

		if (reduxPredictMap.get(5) != null) {
			if (!reduxPredictMap.get(5).contains(
					Integer.parseInt(Numbers.getRedux(Integer.toString(sum)))))
				return false;
		}

		return true;
	}

	private static boolean sumNotAppearedRecently(int[] comblocal) {
		boolean b = true;
		// If sum is not repeated for about 6 draws, do the inverse too
		int sum = comblocal[0] + comblocal[1] + comblocal[2] + comblocal[3]
				+ comblocal[4];

		// if (sum % 2 == 0) return false;
		// if
		// (Numbers.findStringInFile("C:\\Users\\johris\\git\\git\\Generator\\numAppearanceMap"+type,
		// Integer.toString(sum)) == -1)
		if (Numbers.lastFewSums.size() > 0 && Numbers.lastFewSums.contains(sum))
			b = false;
		else
			b = true;

		return b;
	}

	private static boolean sumAppearedRecently(int[] comblocal) {
		boolean b = true;
		// If sum is not repeated for about 6 draws, do the inverse too
		int sum = comblocal[0] + comblocal[1] + comblocal[2] + comblocal[3]
				+ comblocal[4];

		// TODO remove the check for even odd sums
		// if (sum % 2 == 0) return false;
		// if
		// (Numbers.findStringInFile("C:\\Users\\johris\\git\\git\\Generator\\numAppearanceMap"+type,
		// Integer.toString(sum)) == -1)
		if (Numbers.lastFewSums.size() > 0 && Numbers.lastFewSums.contains(sum))
			b = true;
		else
			b = false;

		return b;
	}

	private static boolean isALikelyBucketPattern(int[] comblocal) {
		boolean b = false;
		String bucketPatternString = getBucketPatternForComb(comblocal);
		
		if (unlikelyBuckets.size() == 0) {
			GameBucketEntity gb = new GameBucketEntity();
			unlikelyBuckets = gb.getUnlikelyBucketsList(gameCode,
					unlikelyBucketSpan);
			
			System.out.println("Generator.java:isALikelyBucketPattern----Exclude bucket pattern list size " + unlikelyBuckets.size() + " " + unlikelyBuckets.toString());

		}

		if (!unlikelyBuckets.contains(bucketPatternString))
			b = true;

		return b;

	}
	
	private static String getBucketPatternForComb(int[] comblocal) {
		String bucketPatternString = "";
		for (int i = 0; i < comblocal.length; i++) {

			if (10 > comblocal[i] && comblocal[i] >= 0)
				bucketPatternString += "0";
			if (20 > comblocal[i] && comblocal[i] >= 10)
				bucketPatternString += "1";
			if (30 > comblocal[i] && comblocal[i] >= 20)
				bucketPatternString += "2";
			if (40 > comblocal[i] && comblocal[i] >= 30)
				bucketPatternString += "3";
			if (50 > comblocal[i] && comblocal[i] >= 40)
				bucketPatternString += "4";
			if (60 > comblocal[i] && comblocal[i] >= 50)
				bucketPatternString += "5";
			if (70 > comblocal[i] && comblocal[i] >= 60)
				bucketPatternString += "6";
			if (80 > comblocal[i] && comblocal[i] >= 70)
				bucketPatternString += "7";
		}
		
		return bucketPatternString;
	}

	private static boolean notInBucketListFile(int[] comblocal) {
		boolean b = false;
		String outString;
		int[] bucketCount = new int[8];

		// Also check if hotBuckets are represented

		if (hotBucketsList.size() == 0) {
			Set nums = Numbers.bucketFreqlast10.keySet();
			Iterator it = nums.iterator();

			Integer bucket = (Integer) it.next();
			int tempfreq = Numbers.bucketFreqlast10.get(bucket);
			hotBucketsList.add(bucket);

			while (it.hasNext()) {
				bucket = (Integer) it.next();
				int freq = Numbers.bucketFreqlast10.get(bucket);

				if (freq < tempfreq) {
					hotBucketsList.clear();
					tempfreq = freq;
					hotBucketsList.add(bucket);
				}

			}
			System.out
					.println("Generator.java.notInBucketListFile ---- Hot Buckets "
							+ hotBucketsList
							+ " --- Bucket freqs in last 10 "
							+ Numbers.bucketFreqlast10);
		}

		for (int i = 0; i < comblocal.length; i++) {

			if (10 > comblocal[i] && comblocal[i] >= 0)
				bucketCount[0] += 1;
			if (20 > comblocal[i] && comblocal[i] >= 10)
				bucketCount[1] += 1;
			if (30 > comblocal[i] && comblocal[i] >= 20)
				bucketCount[2] += 1;
			if (40 > comblocal[i] && comblocal[i] >= 30)
				bucketCount[3] += 1;
			if (50 > comblocal[i] && comblocal[i] >= 40)
				bucketCount[4] += 1;
			if (60 > comblocal[i] && comblocal[i] >= 50)
				bucketCount[5] += 1;
			if (60 > comblocal[i] && comblocal[i] >= 60)
				bucketCount[6] += 1;
			if (60 > comblocal[i] && comblocal[i] >= 70)
				bucketCount[7] += 1;
		}

		outString = " " + bucketCount[0] + " " + bucketCount[1] + " "
				+ bucketCount[2] + " " + bucketCount[3] + " " + bucketCount[4]
				+ " " + bucketCount[5] + " " + bucketCount[6] + " "
				+ bucketCount[7] + " ";

		if (Numbers.findStringInFile(
				"C:\\Users\\johris\\git\\git\\Generator\\bucketsList" + type,
				outString) == -1)
			b = true;

		/*
		 * if (hotBucketsList.size() > 0) {
		 * 
		 * Iterator it = hotBucketsList.iterator(); while (it.hasNext()) { int
		 * bucket = (Integer) it.next(); if (bucketCount[bucket] == 0) return
		 * false; } }
		 */

		return b;
	}

	static boolean properDistribution(int[] comb, int z, int c) { // z min
																	// number of
																	// brakcets
																	// which are
																	// blank
																	// each
																	// bracket
																	// can have
																	// max c
																	// numbmers
		boolean out = false;

		int count110 = 0;
		int count1020 = 0;
		int count2030 = 0;
		int count3040 = 0;
		int count4050 = 0;
		int count5060 = 0;

		for (int i = 0; i < comb.length; i++) {
			if (comb[i] > 0 && comb[i] < 10)
				count110++;
			if (comb[i] >= 10 && comb[i] < 20)
				count1020++;
			if (comb[i] >= 20 && comb[i] < 30)
				count2030++;
			if (comb[i] >= 30 && comb[i] < 40)
				count3040++;
			if (comb[i] >= 40 && comb[i] < 50)
				count4050++;
			if (comb[i] >= 50 && comb[i] < 60)
				count5060++;
		}

		int numofzeroes = 0;

		if (count110 == 0)
			numofzeroes++;
		if (count1020 == 0)
			numofzeroes++;
		if (count2030 == 0)
			numofzeroes++;
		if (count3040 == 0)
			numofzeroes++;
		if (count4050 == 0)
			numofzeroes++;
		if (count5060 == 0)
			numofzeroes++;

		if (numofzeroes >= z && count110 <= c && count1020 <= c
				&& count2030 <= c && count3040 <= c && count4050 <= c
				&& count5060 <= c)
			out = true;

		return out;
	}

	static boolean equiDistantFilter(int[] comb) { // Not more than 3 numbers
													// should be equidistant
													// 5 10 15 is OK 5 10 15 20
													// is not
		boolean b = true;
		int distance1 = 0;
		int distance2 = 0;
		int distance3 = 0;
		int distance4 = 0;

		distance1 = comb[1] - comb[0];
		distance2 = comb[2] - comb[1];
		distance3 = comb[3] - comb[2];
		distance4 = comb[4] - comb[3];

		Hashtable<Integer, Integer> hash = new Hashtable<Integer, Integer>();

		hash.put(distance1, 1);

		if (hash.get(distance2) != null) {
			int count = hash.get(distance2);
			hash.put(distance2, count + 1);
		} else {
			hash.put(distance2, 1);
		}

		if (hash.get(distance3) != null) {
			int count = hash.get(distance3);
			hash.put(distance3, count + 1);
		} else {
			hash.put(distance3, 1);
		}

		if (hash.get(distance4) != null) {
			int count = hash.get(distance4);
			hash.put(distance4, count + 1);

		} else {
			hash.put(distance4, 1);
		}

		Enumeration en = hash.keys();
		while (en.hasMoreElements()) {
			int count = hash.get(en.nextElement());

			if (count > 2) {
				b = false;
				break;
			}
		}

		// if (!b) System.out.println(comb[0] + " " + comb[1]+ " " + comb[2] +
		// " " + comb[3]+ " " + comb[4] );
		return b;
	}

	static boolean removeCombsHavingBelowAverageNumbers(int[] comb, int ct) {
		boolean b = true;
		int count = 0;
		
		
		for (int i = 0; i < comb.length; i++) {
			if (comb[i] >= (maxValue / 10)*10) {
				count++;
			}
		}
		if (count >= ct)
			b = false;
		return b;
	}

	static boolean removeIf4MoreThan35(int[] comb) {
		boolean b = true;
		int counter = 0;
		for (int i = 0; i < comb.length; i++) {
			if (comb[i] > 35) {
				counter++;
			}

			if (counter >= 4)
				b = false;
		}

		return b;

	}

	static boolean removeAllEvensAndOdds(int[] comb) {
		boolean b = true;
		int ec = 0;
		int oc = 0;
		for (int i = 0; i < comb.length; i++) {
			if (comb[i] % 2 == 0) {
				ec++;
			} else {
				oc++;
			}

			if (ec > 4 || oc > 4)
				return false;
		}

		// Also do the Even Odd analysis based on Numbers.evenOddLastNineCount
		// -- We count every even num as +1 and odd as -1. We sum last 9
		// occurences.
		// If this sum is > 4, we play for majority of odds, if this is less
		// than -2, we play for majority of Evens
		// And Numbers.lastEvenOdd = null; // If evenOddLastNineCount does not
		// give an answer (between -2 and 4, we switch even and odds.

		/*if (Numbers.lastEvenOdd == null)
			Numbers.numberAppearance(10);
		if (Numbers.evenOddLastNineCount > -7
				&& Numbers.evenOddLastNineCount < 4) {// Not an extreme , stay
														// course
			if (Numbers.lastEvenOdd.equals("E") && oc > 2)
				return false;
			if (Numbers.lastEvenOdd.equals("O") && ec > 2)
				return false;

		} else {

			if (Numbers.evenOddLastNineCount <= -7 && oc > 2)
				return false;// Lots of odds in last 9, go for Evens

			if (Numbers.evenOddLastNineCount >= 4 && ec > 2)
				return false;// Lots of evens in last 9, go for odds
		}*/

		return b;
	}

	static boolean removeNumbersWithSameLstDigit(int[] comb) {
		boolean b = true;
		int count = 0;
		HashMap<Integer, Integer> hm = new HashMap<Integer, Integer>();

		for (int i = 0; i < comb.length; i++) {
			if (hm.containsKey(comb[i] % 10))
				hm.put(comb[i] % 10, (hm.get(comb[i] % 10) + 1));
			else
				hm.put(comb[i] % 10, 1);
		}

		Iterator i = hm.entrySet().iterator();
		while (i.hasNext()) {
			Map.Entry<Integer, Integer> pairs = (Map.Entry) i.next();
			if (pairs.getValue() >= 3) {
				b = false;

			}

		}

		return b;
	}

	static boolean hotNumbers(int[] comb) {
		boolean b = false;
		int count = 0;
		HashSet<Integer> hotNumbers = new HashSet<Integer>();
		for (int j = 0; j < hotNumbersArray.length; j++)
			if (hotNumbersArray[j] != 0)
				hotNumbers.add(hotNumbersArray[j]);

		for (int i = 0; i < comb.length; i++) {
			if (hotNumbers.contains(comb[i]))
				count++;
		}

		if (count == hotNumbers.size())
			b = true;
		return b;
	}

	static boolean frqBasedFilter(int[] comb) { // If freqBasedList is populated
												// in props.properties file, we
												// need one number from
												// each list separated by ;

		boolean b = false;
		int count = 0;

		ArrayList<ArrayList<Integer>> localfrq = (ArrayList<ArrayList<Integer>>) frq
				.clone();
		if (localfrq.size() == 0)
			return true;

		if (localfrq.size() > 5)
			return false;

		for (int i = 0; i < comb.length; i++) {
			for (int j = 0; j < localfrq.size(); j++) {
				ArrayList<Integer> a = localfrq.get(j);
				if (a.contains(comb[i])) {
					count++;
					localfrq.remove(j);
					break;
				}
			}

		}

		if (count < frq.size())
			return false;
		else
			return true;

	}

	static void CombTest(int[] comb, boolean doSave) {
		boolean out = false;
		
		ResultHistoryTestFilterEntity rht = new ResultHistoryTestFilterEntity();

		System.out.println();
		
		String fileName = (type.equals("mm")) ? "C:\\Users\\johris\\git\\git\\HelloWorld\\meg.properties"	: "C:\\Users\\johris\\git\\git\\HelloWorld\\pwb.properties";
		
		Numbers.removeLineFromFile(fileName, "*");
		
		String st = comb[0] + "," + comb[1] + "," + comb[2] + ","
				+ comb[3] + "," + comb[4];
		
		Numbers.addLineToFile(fileName, st, false);
		
		System.out.println("Testing these numbers: " + comb[0] + "," + comb[1]
				+ "," + comb[2] + "," + comb[3] + "," + comb[4]);
		
		/*System.out
		.println(" Complete test "
				+ (intelligentTest(comb)));*/
		System.out
				.println(" More than start Sum "
						+ ((comb[0] + comb[1] + comb[2] + comb[3] + comb[4] > startSum)));
		System.out.println(" Less than end Sum "
				+ ((comb[0] + comb[1] + comb[2] + comb[3] + comb[4] < endSum)));
		
		boolean temp = false;
		temp = properDistribution(comb, numberOfZeroInAllBrackets,	numberMaxInBracket);		
		System.out.println("properDistribution " + temp);
		rht.setProperDistribution((temp)?"1":"0");
		
		temp = Numbers.last9CombsAverage(comb, avgStart, avgEnd);
		System.out.println("last9CombsAverage "	+ temp);
		rht.setLast9CombsAverage((temp)?"1":"0");
		
		temp = equiDistantFilter(comb);
		System.out.println("equiDistantFilter " + temp);
		rht.setEquiDistantFilter((temp)?"1":"0");
		
		temp = n.combsAlreadyAppeared(comb);
		System.out.println("combsAlreadyAppeared "	+ temp);
		rht.setCombsAlreadyAppeared((temp)?"1":"0");
		
		temp =removeCombsHavingBelowAverageNumbers(comb,notAllowedBucket50);
		System.out.println("removeCombsHavingBelowAverageNumbers " + temp);
		rht.setRemoveCombsHavingBelowAverageNumbers((temp)?"1":"0");
		
		// System.out.println("removeIf4MoreThan35 " +
		// removeIf4MoreThan35(comb));
		
		temp = removeAllEvensAndOdds(comb);
		System.out.println("removeAllEvensAndOdds "	+ temp);
		rht.setRemoveAllEvensAndOdds((temp)?"1":"0");
		// System.out.println(hotNumbers(comb));
		// System.out.println("removeNumbersWithSameLstDigit " +
		// removeNumbersWithSameLstDigit(comb));
		
		temp = Numbers.aboveAverageFreq(comb);
		System.out.println("aboveAverageFreq " + temp);
		rht.setAboveAverageFreq((temp)?"1":"0");
		
		// System.out.println("matchesFreqs " + n.matchesFreqs(comb));
		
		temp = frqBasedFilter(comb);
		System.out.println("frqBasedFilter " + temp);
		rht.setFrqBasedFilter((temp)?"1":"0");
		// System.out.println("inclusions " + n.inclusions(comb));
		
		temp = Numbers.exclusions(comb);
		System.out.println("exclusions " + temp);
		rht.setExclusions((temp)?"1":"0");
		// System.out.println("notInBucketListFile " +
		// notInBucketListFile(comb));
		// System.out.println("checkSkipDetails " + n.checkSkipDetails(comb));
		// System.out.println("sumNotAppearedRecently " +
		// sumNotAppearedRecently(comb));
		// System.out.println("sumAppearedRecently " +
		// sumAppearedRecently(comb));
		
		temp = predictThroughRedux(comb);
		System.out.println("predictThroughRedux " + temp);
		rht.setPredictThroughRedux((temp)?"1":"0");
		
		temp = DBPredicAnalysis(comb);
		System.out.println("DBPredicAnalysis " + temp);
		rht.setDBPredicAnalysis((temp)?"1":"0");
		
		temp = followerPatternAnalysis(comb);
		System.out.println(" followerPatternAnalysis " + temp);
		rht.setFollowerPatternAnalysis((temp)?"1":"0");
		
		temp = isALikelyBucketPattern(comb);
		System.out.println(" isALikelyBucketPattern " + temp);
		rht.setIsALikelyBucketPattern((temp)?"1":"0");

		temp = sameReduxInHistory(comb);
		System.out.println(" sameReduxInHistory " + temp);
		rht.setSameReduxInHistory((temp)?"1":"0");
		
		temp = sameVDiffsInHistory(comb);
		System.out.println(" sameVDiffsInHistory " + temp);
		rht.setSameVDiffsInHistory((temp)?"1":"0");
		
		temp = sameFreqReduxInHistory(comb);
		System.out.println(" sameFreqReduxInHistory " + temp);
		rht.setSameFreqReduxInHistory((temp)?"1":"0");
		
		temp = sameDigitDiffsInHistory(comb);
		System.out.println(" sameDigitDiffsInHistory " + temp);
		rht.setSameDigitDiffsInHistory((temp)?"1":"0");
		
		temp = missedDigitsInHistory(comb);
		System.out.println(" missedDigitsInHistory " + temp);
		rht.setMissedDigitsInHistory((temp)?"1":"0");
		
		temp = skipSumWithinRange(comb);
		System.out.println(" skipSumWithinRange " + temp);
		rht.setSkipSumWithinRange((temp)?"1":"0");
		
		temp = isLikelyMaxFactor(comb);
		System.out.println(" isLikelyMaxFactor " + temp);
		rht.setIsLikelyMaxFactor((temp)?"1":"0");
		
		temp = ranksNotInSameDirection(comb);
		System.out.println(" ranksNotInSameDirection " + temp);
		rht.setRanksNotInSameDirection((temp)?"1":"0");
		
		temp = sameObsDate(comb);
		System.out.println(" sameObsDate " + temp);
		rht.setSameObsDate((temp)?"1":"0");
		
		temp = sameObsPercentile(comb);
		System.out.println(" sameObsPercentile " + temp);
		rht.setSameObsPercentile((temp)?"1":"0");
		
		temp = unlikelyFreqShadowReduxes(comb);
		System.out.println(" unlikelyFreqShadowReduxes " + temp);
		rht.setUnlikelyFreqShadowReduxes((temp)?"1":"0");
		
		temp = GeneratorVTwo.isPossibleComb(comb);
		System.out.println(" PossibleCombAccordingToGeneratorVTwoCount " + temp);
		rht.setPossibleCombAccordingToGeneratorVTwoCount((temp)?"1":"0");
		
		temp = threeOrMoreRelations(comb);
		System.out.println(" threeOrMoreRelations " + temp);
		rht.setThreeOrMoreRelations((temp)?"1":"0");
		
		rht.setGameCode(gameCode);
		rhe.setGameCode(gameCode);
		
		int lastSerial = Integer.parseInt(rhe.getLastNForAttribute("serialNumber", 1, 0));
		
		lastSerial ++;
		rht.setSerialNumber(Integer.toString(lastSerial));
		
		if (doSave)
			rht.create();
		
		//System.out.println(rht.toString());
		
		printFreqMapForTestCombs();

	}

	static void printFreqMapForTestCombs() { // Prints freq map -----*---*-- for
												// all combs in meg.properties
		StringBuilder sb = new StringBuilder();

		currentCriteria.setExecuteFlag("true");

		if (currentCriteria.getTargetDrawDate() != null) {
			currentCriteria.setCriteriaID(Integer.toString(currentCriteria
					.createWithAutoIncrement()));

			if (Integer.parseInt(currentCriteria.getCriteriaID()) < 0) {
				currentCriteria.setCriteriaID(null);
				System.out.println("Could not create new criteria... ");
			} else {
				System.out.println("new criteria created "
						+ currentCriteria.getCriteriaID());
			}
		}

		try {
			BufferedReader reader = new BufferedReader(
					(type.equals("mm")) ? new FileReader(
							"C:\\Users\\johris\\git\\git\\HelloWorld\\meg.properties")
							: new FileReader(
									"C:\\Users\\johris\\git\\git\\HelloWorld\\pwb.properties"));

			// Reads until the end-of-file met
			while (reader.ready()) {
				// Read line-by-line directly
				String line = reader.readLine();
				if (!line.startsWith("start")) {
					if (line.length() > 0) {
						CriteriaResultEntity globalcre = new CriteriaResultEntity();
						String[] frqNumbersArrays = line.split("\\;");
						if (frqNumbersArrays.length <= 22000) {
							for (int k = 0; k < frqNumbersArrays.length; k++) {
								CriteriaResultEntity cre = new CriteriaResultEntity();
								String skipVals = "";
								String freqLast5Vals = "";
								ArrayList<Integer> a = new ArrayList<Integer>();
								String[] indivFreqNumbers = frqNumbersArrays[k]
										.split("\\,");
								for (int j = 0; j < indivFreqNumbers.length; j++) {
									int num = 0;
									if (indivFreqNumbers[j] != null) {
										num = Integer
												.parseInt(indivFreqNumbers[j]);

									} else {
										num = 0;
									}
									a.add(num);

									skipVals += " "
											+ n.skipHashCurrent.get(num) + " ";
									freqLast5Vals += " "
											+ n.freqInLast25.get(num) + " ";

									if (j == 0) {

										cre.setFirstValue(Integer.toString(num));
										if (n.skipHashCurrent.get(num) != null)
											cre.setFirstSkip(n.skipHashCurrent
													.get(num).toString());

										if (n.freq.get(num) != null)
											cre.setFirstFreq((String) n.freq
													.get(num));
									}
									if (j == 1) {
										cre.setSecondValue(Integer
												.toString(num));

										if (n.skipHashCurrent.get(num) != null)
											cre.setSecondSkip(n.skipHashCurrent
													.get(num).toString());

										if (n.freq.get(num) != null)
											cre.setSecondFreq((String) n.freq
													.get(num));
									}
									if (j == 2) {
										cre.setThirdValue(Integer.toString(num));

										if (n.skipHashCurrent.get(num) != null)
											cre.setThirdSkip(n.skipHashCurrent
													.get(num).toString());

										if (n.freq.get(num) != null)
											cre.setThirdFreq((String) n.freq
													.get(num));
									}
									if (j == 3) {
										cre.setFourthValue(Integer
												.toString(num));

										if (n.skipHashCurrent.get(num) != null)
											cre.setFourthSkip(n.skipHashCurrent
													.get(num).toString());

										if (n.freq.get(num) != null)
											cre.setFourthFreq((String) n.freq
													.get(num));
									}
									if (j == 4) {
										cre.setFifthValue(Integer.toString(num));

										if (n.skipHashCurrent.get(num) != null)
											cre.setFifthSkip(n.skipHashCurrent
													.get(num).toString());

										if (n.freq.get(num) != null)
											cre.setFifthFreq((String) n.freq
													.get(num));
									}

								}
								
								if ((cre.getFirstFreq() == null)) cre.setFirstFreq("0");
								if ((cre.getSecondFreq() == null)) cre.setSecondFreq("0");
								if ((cre.getThirdFreq() == null)) cre.setThirdFreq("0");
								if ((cre.getFourthFreq() == null)) cre.setFourthFreq("0");
								if ((cre.getFifthFreq() == null)) cre.setFifthFreq("0");
								
								
								if ((cre.getFirstSkip() == null || cre.getFirstSkip().equals("null"))) cre.setFirstSkip("0");
								if ((cre.getSecondSkip() == null || cre.getSecondSkip().equals("null"))) cre.setSecondSkip("0");
								if ((cre.getThirdSkip() == null || cre.getThirdSkip().equals("null"))) cre.setThirdSkip("0");
								if ((cre.getFourthSkip() == null || cre.getFourthSkip().equals("null"))) cre.setFourthSkip("0");
								if ((cre.getFifthSkip() == null || cre.getFifthSkip().equals("null"))) cre.setFifthSkip("0");
								
								cre.setFirstFiveSum( Integer.toString(
										Integer.parseInt(cre.getFirstValue()) +
										Integer.parseInt(cre.getSecondValue())+
										Integer.parseInt(cre.getThirdValue()) +
										Integer.parseInt(cre.getFourthValue())+
										Integer.parseInt(cre.getFifthValue())
											));
								
								cre.setSkipSum(Integer.toString(
										Integer.parseInt(cre.getFirstSkip()) +
										Integer.parseInt(cre.getSecondSkip())+
										Integer.parseInt(cre.getThirdSkip()) +
										Integer.parseInt(cre.getFourthSkip())+
										Integer.parseInt(cre.getFifthSkip())
											));
								
								Integer[] arr = new Integer[a.size()];
								
								a.toArray(arr);

								cre.setStarCount(Integer.toString(GeneratorVTwo
										.getStarCount(arr)));
								
								cre.setNumPrimes("0");
								
								if (Numbers.primesTill75.contains(Integer.parseInt(cre.getFirstValue())))
										cre.setNumPrimes(Integer.toString(Integer.parseInt(cre.getNumPrimes())+1));
								
								if (Numbers.primesTill75.contains(Integer.parseInt(cre.getSecondValue())))
									cre.setNumPrimes(Integer.toString(Integer.parseInt(cre.getNumPrimes())+1));
								if (Numbers.primesTill75.contains(Integer.parseInt(cre.getThirdValue())))
									cre.setNumPrimes(Integer.toString(Integer.parseInt(cre.getNumPrimes())+1));
								if (Numbers.primesTill75.contains(Integer.parseInt(cre.getFourthValue())))
									cre.setNumPrimes(Integer.toString(Integer.parseInt(cre.getNumPrimes())+1));
								if (Numbers.primesTill75.contains(Integer.parseInt(cre.getFifthValue())))
									cre.setNumPrimes(Integer.toString(Integer.parseInt(cre.getNumPrimes())+1));
								
								cre.setSimilarResults(Integer.toString(AnalyzeOutput.getSimilarCombs(arr)));
								
								cre.setMissingDigits(Numbers.getMissingDigits(cre.getFirstValue() + "," + cre.getSecondValue() + "," +
														cre.getThirdValue()	+ "," +	cre.getFourthValue() + "," + cre.getFifthValue() + "+" + ""	));
								
								String maxfactandcount = Factors.getMaxFactorAndCountForComb(new int[]{Integer.parseInt(cre.getFirstValue()) ,
										Integer.parseInt(cre.getSecondValue()),
										Integer.parseInt(cre.getThirdValue()) ,
										Integer.parseInt(cre.getFourthValue()),
										Integer.parseInt(cre.getFifthValue())});
								
								
								if (maxfactandcount.length() > 0) {
									String[] factorSplit = maxfactandcount.split(" ");
																
									cre.setMaxFactor(factorSplit[0]);
									cre.setMaxFactorCount(factorSplit[1]);
								} else {
									cre.setMaxFactor("0");
									cre.setMaxFactorCount("0");
								}

								String thisMissingDigits = getMissingDigitsForComb(ArrayUtils.toPrimitive(arr));
								String thisBucketPattern = getBucketPatternForComb(ArrayUtils.toPrimitive(arr)); 
								//System.out.println("Current bucket, MD and follower ranks " + currentBucketRank + " " + currentMissingDigitRank + " " + currentFollowerRank);
								
								int mdrank = (missingDigitRanks.get(thisMissingDigits) == null)?1000:missingDigitRanks.get(thisMissingDigits);
								int bucketRank = (bucketRanks.get(thisBucketPattern)== null)?1000:bucketRanks.get(thisBucketPattern);
								
								String prinOut = n
										.freqAppearanceMapForATestComb(10, arr)
										+ "|"
										+ skipVals
										+ "|"
										+ freqLast5Vals
										+ "|"
										+ " Matches: " + cre.getSimilarResults()
										+ " Brank: " + bucketRank
										+ " Mdrank: " + mdrank;
								;

								// Do not print combs which return no matches
								// for example - Check Suspended 20140117
								// 8 13 36 38 42 140 153 155 158 155 Range : 64
								// - 168----*--------*------**--*----| 1 16 25
								// 35 17 | 2 2 null null 2 |Matches ---NONE
								// if (!prinOut.endsWith("Matches ---NONE")) {
								// // Stoppnig this check
								// String[] elems = prinOut.split("\\ |	");

								cre.setCriteriaID(currentCriteria
										.getCriteriaID());

								cre.setFrequencyMap(prinOut.substring(
										prinOut.indexOf("|") - maxValue,
										prinOut.indexOf("|")));

								if (currentCriteria.getCriteriaID() != null)
									globalcre.getListOfCriteriaResults().add(cre);
								else {
									if (!isTest)
									 System.out.println(prinOut.substring(8));
								}
								
								if (isTest)
								 System.out.println(prinOut.substring(8));
								// }

							}
							
							if (currentCriteria.getCriteriaID() != null) {
								if (globalcre.create()) 
									System.out.println("Added " +globalcre.getListOfCriteriaResults().size() + " results. ");
							}
							
						} else {
							System.out
									.println("More than 22000 results. Can not print...");
						}
					}

				}

			}
			reader.close();

		} catch (IOException ex) {
			ex.printStackTrace();
		}

	}

	public static Properties getDBpredicProp() {
		return DBpredicProp;
	}

	public static void setDBpredicProp(Properties dBpredicProp) {

		if (dBpredicProp == null) {
			if (DBpredicProp.isEmpty()) {
				try {

					if (predicFileName != null) {
						FileInputStream fis = new FileInputStream(new File(
								predicFileName));
						// "C:\\eclipse\\workspace\\first\\Pred\\PredFor" +
						// nextDate + "-"+
						// getInPrgCode().toUpperCase()
						DBpredicProp.load(fis);
					} else {
						System.out
								.println("Generator.java ---- No prediction file "
										+ predicFileName
										+ " exists. Setting empty predicProperties.");
						DBpredicProp.setProperty("EMPTYPREDICPROP", "EMPTY");
					}

				} catch (FileNotFoundException e) {
					System.out
							.println("Generator.java ---- No prediction file "
									+ predicFileName
									+ " exists. Setting empty predicProperties.");
					DBpredicProp.setProperty("EMPTYPREDICPROP", "EMPTY");

				} catch (IOException e) {
					System.out
							.println("Generator.java ---- Can not read prediction file "
									+ predicFileName
									+ " exists. Setting empty predicProperties.");
					DBpredicProp.setProperty("EMPTYPREDICPROP", "EMPTY");

				}
			}
		} else {
			DBpredicProp = dBpredicProp;
		}

		String FIRSTFIVESUMPRIME = DBpredicProp
				.getProperty("FIRSTFIVESUMPRIME");
		if (FIRSTFIVESUMPRIME != null && FIRSTFIVESUMPRIME.length() > 0) {
			int startInd = FIRSTFIVESUMPRIME.indexOf("[") + 1;
			if (startInd > 0) {
				String val = FIRSTFIVESUMPRIME.substring(startInd,
						FIRSTFIVESUMPRIME.indexOf("]"));

				String[] valA = val.split("\\,");
				List lis = (List) Arrays.asList(valA);

				if (FIRSTFIVESUMPRIME.indexOf("NOT") < 0) {

					if (valA[0].equals("0")) {
						currentCriteria.setFirstFiveSumPrimeInd("false");
					} else {
						currentCriteria.setFirstFiveSumPrimeInd("true");
					}
				} else {
					if (valA[0].equals("0")) {
						currentCriteria.setFirstFiveSumPrimeInd("true");
					} else {
						currentCriteria.setFirstFiveSumPrimeInd("false");
					}
				}
			}
		}

		String FIRSTFIVESUM = DBpredicProp.getProperty("FIRSTFIVESUM");

		if (FIRSTFIVESUM != null && FIRSTFIVESUM.length() > 0) {

			if (FIRSTFIVESUM.indexOf("EVEN") >= 0)
				currentCriteria.setFirstFiveSumEvenInd("Y");

			if (FIRSTFIVESUM.indexOf("ODD") >= 0)
				currentCriteria.setFirstFiveSumOddInd("Y");

			int startInd = FIRSTFIVESUM.indexOf("[") + 1;
			if (startInd > 0) {
				String val = FIRSTFIVESUM.substring(startInd,
						FIRSTFIVESUM.indexOf("]"));

				
			}

		}
		
		String FIRSTFIVESUMBUCKET = DBpredicProp.getProperty("FIRSTFIVESUMBUCKET");

		if (FIRSTFIVESUMBUCKET != null && FIRSTFIVESUMBUCKET.length() > 0) {

			int startInd = FIRSTFIVESUMBUCKET.indexOf("[") + 1;
			if (startInd > 0) {
				String val = FIRSTFIVESUMBUCKET.substring(startInd,
						FIRSTFIVESUMBUCKET.indexOf("]"));

				if (FIRSTFIVESUMBUCKET.indexOf("NOT") >= 0)
					currentCriteria.setFirstFiveSumExcludeBucketList(val);
				else
					currentCriteria.setFirstFiveSumIncludeBucketList(val);
			}

		}

		String MATCH3DIFFS = DBpredicProp.getProperty("MATCH3DIFFS");

		if (MATCH3DIFFS != null && MATCH3DIFFS.length() > 0) {
			if (MATCH3DIFFS.equalsIgnoreCase("Y"))
				currentCriteria.setMatch3DiffInd("true");
			else
				currentCriteria.setMatch3DiffInd("false");
		}
		
		String MATCH3GAPS = DBpredicProp.getProperty("MATCH3GAPS");

		if (MATCH3GAPS != null && MATCH3GAPS.length() > 0) {
			if (MATCH3GAPS.equalsIgnoreCase("Y"))
				currentCriteria.setMatch3GapInd("true");
			else
				currentCriteria.setMatch3GapInd("false");
		}
		
		

		// currentCriteria.setTargetDrawDate(predicFileName.substring(predicFileName.indexOf("PredFor")+7,predicFileName.indexOf("PredFor")+11));
		currentCriteria.setTargetDrawDate(forDate);

		if (gameCode == null) {
			gte = new GameTypesEntity();
			gameCode = gte.findGameCodeByProgramCode(type);

			currentCriteria.setTargetGameCode(gameCode);
		} else {
			currentCriteria.setTargetGameCode(gameCode);
		}

		// currentCriteria.setMiss3Diff(miss3Diff);

		String OBSINCLUDECOUNT = DBpredicProp.getProperty("OBSINCLUDECOUNT");

		if (OBSINCLUDECOUNT != null && OBSINCLUDECOUNT.length() > 0) {
			currentCriteria.setObsIncludeCount(OBSINCLUDECOUNT);

		}
	}

	public static String getGameCode() {
		return gameCode;
	}

	public static void setGameCode(String gameCode) {
		Generator.gameCode = gameCode;
	}

	public static int getNotAllowedBucket50() {
		return notAllowedBucket50;
	}

	public static void setNotAllowedBucket50(int notAllowedBucket50) {
		Generator.notAllowedBucket50 = notAllowedBucket50;
	}

	public static int getAvgStart() {
		return avgStart;
	}

	public static void setAvgStart(int avgStart) {
		Generator.avgStart = avgStart;
	}

	public static int getAvgEnd() {
		return avgEnd;
	}

	public static void setAvgEnd(int avgEnd) {
		Generator.avgEnd = avgEnd;
	}

	public static Numbers getN() {
		return n;
	}

	public static void setN(Numbers n) {
		Generator.n = n;
	}

	public static String getType() {
		return type;
	}

	public static void setType(String type) {
		Generator.type = type;
	}

}
