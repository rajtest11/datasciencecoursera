/*
 * Created on Apr 12, 2012
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.num.generator;

import java.sql.SQLException;
import java.util.*;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Properties;
import java.util.StringTokenizer;
import java.util.Map.Entry;
import java.io.*;
import java.io.ObjectInputStream.GetField;

import com.num.generator.dataaccess.CriteriaEntity;
import com.num.generator.dataaccess.CriteriaResultEntity;
import com.num.generator.dataaccess.FollowerPatternEntity;
import com.num.generator.dataaccess.GameBucketEntity;
import com.num.generator.dataaccess.GameTypesEntity;
import com.num.generator.dataaccess.ResultHistoryEntity;

public class GeneratorSaved {
	static Numbers n = null;
	static boolean doPrint = true;
	static Writer output = null;
	// PARAMETERS
	static String type = "";
	static int maxValue = 0;
	static int choices = 0;
	static int startSum = 0, endSum = 0;
	static int last5Range = 0;
	static int numberOfZeroInAllBrackets = 0;
	static int numberMaxInBracket = 0;
	static int[] hotNumbersArray = new int[5];
	static int notAllowedBucket50;
	static int avgStart;
	static int avgEnd;
	static int propdistCount = 0;
	static int in5HistoryCount = 0;
	static int last9CombsAverageCount = 0;
	static int equiDistantFilterCount = 0;
	static int combsAlreadyAppearedCount = 0;
	static int combsBelowAverageNumbersCount = 0;
	static int if4MoreThan35Count = 0;
	static int allEvensAndOddsCount = 0;
	static int numbersWithSameLstDigitCount = 0;
	static int aboveAverageFreqCount = 0;
	static int notInBucketListFileCount = 0;
	static int sumNotAppearedRecentlyCount = 0;
	static int inclusionsCount = 0;
	static int hotNumberCount = 0;
	static int exclusionsCount = 0;
	static int disallowDigit = -1;
	static int freqFilterCount = 0;
	static int followerPatternAnalysisCount = 0;
	static int matchesFreqList = 0;
	static int checkSkipDetails = 0;
	static int uniqueBucketPattern = 0;
	static Set<Integer> hotBucketsList = new HashSet<Integer>();
	static int dateMonYearInResultsCount = 0;

	static ArrayList<ArrayList<Integer>> frq = new ArrayList<ArrayList<Integer>>();

	static ArrayList<ArrayList<Integer>> reduxPredictMap = new ArrayList<ArrayList<Integer>>();
	private static int predictThroughReduxCount = 0;
	static ArrayList<ArrayList<Integer>> possibleBucketMap = new ArrayList<ArrayList<Integer>>();
	private static int sumAppearedRecentlyCount = 0;
	private static int sumLessThanStartSumCount = 0;
	private static int sumMoreThanEndSumCount = 0;
	private static int numberOfPrimesNotAsLast3Count;
	private static int DBPredicCount;
	private static int DisallowDigitCount;
	private static int sameReduxCount;
	private static ResultHistoryEntity rhe = new ResultHistoryEntity();
	private static GameTypesEntity gte = new GameTypesEntity();
	private static String gameCode = null;
	private static HashMap followers = new HashMap();

	private static int missedDigitsInHistory = 0;
	private static Properties DBpredicProp = new Properties();
	private static ArrayList<Integer> last3PrimeCount = new ArrayList<Integer>();
	private static ArrayList sumPrimesList = new ArrayList(Arrays.asList(67,
			71, 73, 79, 83, 89, 97, 101, 103, 107, 109, 113, 127, 131, 137,
			139, 149, 151, 157, 163, 167, 173, 179, 181, 191, 193, 197, 199,
			211, 223, 227, 229, 233, 239, 241, 251, 257, 263, 269, 271, 277,
			281, 283, 293, 307, 311, 313, 317, 331, 337, 347, 349));
	private static int matches3DiffsCount = 0;
	private static int isPossibleCombAccordingToGeneratorVTwoCount = 0;
	private static GeneratorVTwo genv2 = null;
	public static CriteriaEntity currentCriteria = new CriteriaEntity();

	private static String predicFileName = null; // "C:\\eclipse\\workspace\\first\\Pred\\PredFor0107-MM";
	private static String forDate = null;
	static ArrayList<String> unlikelyBuckets = new ArrayList<String>();
	public static int unlikelyBucketSpan = 0;

	public static String getForDate() {
		return forDate;
	}

	public static void setForDate(String forDate) {
		GeneratorSaved.forDate = forDate;
	}

	GeneratorSaved() {
		try {
			Properties prop = new Properties();
			File propFile = new File(
					"C:\\Users\\johris\\git\\git\\Generator\\props.properties");
			FileInputStream fis = new FileInputStream(propFile);
			prop.load(fis);
			choices = Integer.parseInt(prop.getProperty("choices"));
			startSum = Integer.parseInt(prop.getProperty("startSum"));
			endSum = Integer.parseInt(prop.getProperty("endSum"));
			last5Range = Integer.parseInt(prop.getProperty("last5Range"));
			numberOfZeroInAllBrackets = Integer.parseInt(prop
					.getProperty("numberOfZeroInAllBrackets"));
			numberMaxInBracket = Integer.parseInt(prop
					.getProperty("numberMaxInBracket"));
			notAllowedBucket50 = Integer.parseInt(prop
					.getProperty("notAllowedBucket50"));
			avgStart = Integer.parseInt(prop.getProperty("avgStart"));
			avgEnd = Integer.parseInt(prop.getProperty("avgEnd"));
			String disallow = prop.getProperty("disallowDigit");

			if (disallow.length() > 0)
				disallowDigit = Integer.parseInt(prop
						.getProperty("disallowDigit"));
			System.out.println("Generator.java ---- Sum range : " + startSum
					+ " - " + endSum + " | Last 9 Avg range : " + avgStart
					+ " - " + avgEnd);
			String hotNumbers = prop.getProperty("numberMaxInBracket");
			String[] s = hotNumbers.split("\\,");
			for (int i = 0; i < s.length; i++) {
				hotNumbersArray[i] = Integer.parseInt(s[i]);
			}
			String frqNumbers = prop.getProperty("freqBasedList");
			fis.close();
			System.out.println("Generator.java ---- Must appear list : "
					+ frqNumbers);
			type = prop.getProperty("type");

			if (type.equals("pb"))
				maxValue = 59;
			else
				maxValue = 75;

			Numbers.doNotUpdateInDatabase = true;
			n = new Numbers(type);

			GeneratorVTwo.setForDate(forDate);
			genv2 = new GeneratorVTwo();

			if (frqNumbers.length() > 0) {
				String[] frqNumbersArrays = frqNumbers.split("\\;");
				for (int k = 0; k < frqNumbersArrays.length; k++) {
					ArrayList<Integer> a = new ArrayList<Integer>();
					String[] indivFreqNumbers = frqNumbersArrays[k]
							.split("\\,");
					for (int j = 0; j < indivFreqNumbers.length; j++) {
						a.add(Integer.parseInt(indivFreqNumbers[j].trim()));
					}
					frq.add(a);
				}
			}

			// Initialize followers
			if (gameCode == null) {
				gte = new GameTypesEntity();
				gameCode = gte.findGameCodeByProgramCode(type);
			}

			followers.put(
					"FirstFollower",
					rhe.getFollowers("FirstFollower",
							Integer.parseInt(gameCode), 0));
			followers.put(
					"SecondFollower",
					rhe.getFollowers("SecondFollower",
							Integer.parseInt(gameCode), 0));
			followers.put(
					"ThirdFollower",
					rhe.getFollowers("ThirdFollower",
							Integer.parseInt(gameCode), 0));
			followers.put(
					"FourthFollower",
					rhe.getFollowers("FourthFollower",
							Integer.parseInt(gameCode), 0));
			followers.put(
					"FifthFollower",
					rhe.getFollowers("FifthFollower",
							Integer.parseInt(gameCode), 0));

			// Initialize possibleBucketMap
			possibleBucketMap.add(new ArrayList(Arrays.asList(0, 1, 2, 3, 4)));
			possibleBucketMap.add(new ArrayList(Arrays.asList(0, 1, 2, 3, 4)));
			possibleBucketMap
					.add(new ArrayList(Arrays.asList(1, 2, 3, 4, 5, 6)));
			possibleBucketMap.add(new ArrayList(Arrays.asList(1, 2, 3, 4, 5, 6,
					7)));
			possibleBucketMap
					.add(new ArrayList(Arrays.asList(2, 3, 4, 5, 6, 7)));

			// A good guide to construct this map is to look at the reduxoutput
			// file and
			// remove the last three redux values from each line
			// Can also remove all evens or odds too if last few reduxs are
			// highly concentrated
			// in that group (last 5-6 reduxes were even, remove evens).
			if (reduxPredictMap.size() == 0) {
				ArrayList defaultReduxList = null; // new
													// ArrayList(Arrays.asList(1,2,3,4,5,6,7,8,9));
				reduxPredictMap.add(defaultReduxList); // FirstREDUX
				reduxPredictMap.add(defaultReduxList); // Second REDUX
				reduxPredictMap.add(defaultReduxList); // //Third REDUX
				reduxPredictMap.add(defaultReduxList); // //Fourth REDUX
				reduxPredictMap.add(defaultReduxList); // Fifth REDUX
				reduxPredictMap.add(defaultReduxList); // First five sum REDUX
			}

		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	public static void main(String[] args) {
		new GeneratorSaved();
		int[] testComb = null;// new int[] { 5,12,15,27,38 };

		if (testComb != null && testComb.length > 0) {

			CombTest(testComb);
		} else {
			long counter = 1;
			int numberPassedTest = 0;
			long sumofdigits = 0;
			int lastnumberPassedTest = 0;

			sumLessThanStartSumCount = 0;
			sumMoreThanEndSumCount = 0;
			propdistCount = 0;
			last9CombsAverageCount = 0;
			equiDistantFilterCount = 0;
			combsAlreadyAppearedCount = 0;
			combsBelowAverageNumbersCount = 0;
			allEvensAndOddsCount = 0;
			aboveAverageFreqCount = 0;
			freqFilterCount = 0;
			notInBucketListFileCount = 0;
			uniqueBucketPattern = 0;
			predictThroughReduxCount = 0;
			followerPatternAnalysisCount = 0;
			DBPredicCount = 0;
			missedDigitsInHistory = 0;
			sameReduxCount = 0;
			matches3DiffsCount = 0;
			isPossibleCombAccordingToGeneratorVTwoCount = 0;

			// ProgressBar progressBar = ConsoleProgressBar.on(System.out);
			// progressBar.tickOne();
			// printFreqMapForTestCombs();

			double starttime = System.currentTimeMillis();

			currentCriteria.setFirstFiveSumAvgEnd(Integer.toString(avgEnd));
			currentCriteria.setFirstFiveSumAvgStart(Integer.toString(avgStart));
			currentCriteria.setFirstFiveSumEnd(Integer.toString(endSum));
			currentCriteria.setFirstFiveSumStart(Integer.toString(startSum));
			
			if (DBpredicProp != null) {
				
				String param = DBpredicProp.getProperty("FIRSTFIVESUMBUCKET");
				if (param != null && param.length() > 0) {
					int startInd = param.indexOf("[") + 1;
					if (startInd > 0) {
						String val = param.substring(startInd, param.indexOf("]"));
					
							if (startInd > 1) {// Prediction was a NOT
								currentCriteria.setFirstFiveSumExcludeBucketList(val);
							} else {
								currentCriteria.setFirstFiveSumIncludeBucketList(val);
							}
						
					}
				}
				
				
			}

			try {
				File f = (type.equals("mm")) ? new File(
						"C:\\eclipse\\workspace\\first\\HelloWorld\\meg.properties")
						: new File(
								"C:\\eclipse\\workspace\\first\\HelloWorld\\pwb.properties");
				if (f.exists())
					f.delete();
				output = new OutputStreamWriter(new FileOutputStream(f, true));
				output.write("startSum:" + startSum + " | EndSum:" + endSum
						+ " | last5Range:" + last5Range
						+ " | numberOfEmptyBrackets:"
						+ numberOfZeroInAllBrackets
						+ " | maxNumberInOneBracket:" + numberMaxInBracket
						+ " | ");
				output.write("sumOfFreqDistanceHigh:"
						+ FreqFilter.maxSumOfFreqDistance
						+ " | sumOfFreqDistanceLow:"
						+ FreqFilter.minSumOfFreqDistance
						+ " | MatchTheseNumbersOfFreqInFreqAppearance:"
						+ FreqFilter.matchMap);
				output.write("\r\n");

				int[] comb = new int[choices];

				for (int i = 0; i < choices; i++) {

					comb[i] = i + 1;

				}

				if (intelligentTest(comb)) {
					numberPassedTest++;
					if (doPrint && maxValue <= 20) {
						myprint(counter, comb, choices);
					}
				}

				sumofdigits += sum(comb);

				while (next_comb(comb, choices, maxValue)) {
					counter++;
					sumofdigits += sum(comb);

					if (intelligentTest(comb)) {
						numberPassedTest++;
						currentCriteria.setNumberOfPassedCombinations(Integer
								.toString(numberPassedTest));

						if (doPrint && maxValue <= 20)
							myprint(counter, comb, choices);
					}

					// do something

					if (counter % 1000000 == 0) {
						double thisTime = System.currentTimeMillis();
						// progressBar.tick(counter/3800000); // this will
						// increase the percentage to 26
						System.out.println("Rcrd : " + counter + " Time : "
								+ (thisTime - starttime) / 1000
								+ " s. Matched : "
								+ (numberPassedTest - lastnumberPassedTest)
								+ " of " + numberPassedTest);
						starttime = thisTime;
						lastnumberPassedTest = numberPassedTest;

						if (numberPassedTest > 1000) {

							System.out
									.println("High Match count ... terminating this run");
							break;
						}
					}

				}

			} catch (FileNotFoundException fx) {
				fx.printStackTrace();
			} catch (IOException ix) {
				ix.printStackTrace();
			} finally {
				try {
					output.close();
				} catch (IOException ix) {
					ix.printStackTrace();
				}
			}

			System.out.println(choices + " out of " + maxValue + " | counter "
					+ counter + " | avgEnd  " + +sumofdigits / counter
					+ " | Pas  " + numberPassedTest + " | Per "
					+ (numberPassedTest * 100 / counter));

			System.out.println();
			System.out.println(" sumLessThanStartSumCount "
					+ sumLessThanStartSumCount * 100 / counter);
			System.out.println(" sumMoreThanEndSumCount "
					+ sumMoreThanEndSumCount * 100 / counter);

			System.out.println("propdistCount " + propdistCount * 100 / counter
					+ " last9CombsAverageCount " + last9CombsAverageCount * 100
					/ counter + " equiDistantFilterCount "
					+ equiDistantFilterCount * 100 / counter
					+ " combsAlreadyAppearedCount " + combsAlreadyAppearedCount
					* 100 / counter + " combsWithLotsOf50s "
					+ combsBelowAverageNumbersCount * 100 / counter
			// " in5HistoryCount " + in5HistoryCount*100/counter +
					// + " morethan35 " + if4MoreThan35Count*100/counter
					);
			System.out.println(" allEvensAndOddsCount " + allEvensAndOddsCount
					* 100 / counter + " aboveAverageFreqCount "
					+ aboveAverageFreqCount * 100 / counter
					+ " freqFilterCount " + freqFilterCount * 100 / counter
			// " numbersWithSameLstDigitCount " +
			// numbersWithSameLstDigitCount*100/counter +
			// " inclusionsCount " + inclusionsCount +
			// " exclusionsCount " + exclusionsCount +
			// " hotNumberCount " + hotNumberCount*100/counter +
			// + " matchesFreqList " + matchesFreqList*100/counter
					

			+ " notInBucketListFileCount "
					+ notInBucketListFileCount * 100 / counter
			+ " uniqueBucketPattern " + uniqueBucketPattern
					* 100 / counter
			+ " predictThroughRedux "
					+ predictThroughReduxCount * 100 / counter
			+ " followerPatternAnalysisCount "
					+ followerPatternAnalysisCount * 100 / counter
			+ " DBPredicCount " + DBPredicCount * 100
					/ counter
			+ " missedDigitsInHistoryCount "
					+ missedDigitsInHistory * 100 / counter
			+ " sameReduxCount " + sameReduxCount * 100
					/ counter
			+ " matches3DiffsCount " + matches3DiffsCount
					* 100 / counter
			+ " isPossibleCombAccordingToGeneratorVTwoCount "
					+ isPossibleCombAccordingToGeneratorVTwoCount * 100
					/ counter);

			// System.out.println( " checkSkipDetails " +
			// checkSkipDetails*100/counter);
			// System.out.println( " sumNotAppearedRecently " +
			// sumNotAppearedRecentlyCount*100/counter);
			// System.out.println( " sumAppearedRecently " +
			// sumAppearedRecentlyCount*100/counter);
			// System.out.println( " numberOfPrimesNotAsLast3 " +
			// numberOfPrimesNotAsLast3Count*100/counter);

			System.out.println("Time taken "
					+ (System.currentTimeMillis() - starttime) + " ms");

			printFreqMapForTestCombs();
		}

		// progressBar.complete(); // this will finish it

	}

	private static int[] increment(int[] comb) {
		for (int i = 0; i < comb.length; i++)
			comb[i] += 1;
		return comb;
	}

	static boolean next_comb(int comb[], int k, int n) {

		int i = k - 1;

		comb[i]++;

		while (i > 0 && (comb[i] >= n - k + 1 + i)) {
			i--;
			comb[i]++;
		}

		if (comb[0] > n - k)
			return false;

		for (i = i + 1; i < k && i > 0; i++)
			comb[i] = comb[i - 1] + 1;

		return true;

	}

	static void myprint(long counter, int[] comb, int k) {

		System.out.print(counter + " {");

		for (int i = 0; i < k; i++)
			System.out.print((comb[i] + 1) + ",");

		System.out.println("}");

	}

	static int sum(int[] comb) {
		int sum = 0;
		for (int i = 0; i < comb.length; i++)
			sum += comb[i];

		return sum;
	}

	static boolean intelligentTest(int[] comb) {
		// Numbers n = new Numbers();
		boolean out = false;
		int[] comblocal = new int[comb.length];
		for (int i = 0; i < comb.length; i++)
			comblocal[i] = comb[i] + 1;
		// increment(comblocal);
		// Filtering out sums between a range
		int numsum = sum(comblocal);
		// Sorting the local copy of comb to make sure that numbers are in order
		// before filters
		ArrayList<Integer> a = new ArrayList<Integer>();
		for (int i = 0; i < comblocal.length; i++) {
			a.add(i, comblocal[i]);
		}
		Collections.sort(a);
		for (int k = 0; k < a.size(); k++)
			comblocal[k] = a.get(k);

		// if (comblocal[0] ==25 && comblocal[1] ==34&& comblocal[2] ==45&&
		// comblocal[3] ==46&& comblocal[4] ==49)
		// System.out.println("Hi");
		if (((numsum >= startSum) ? true
				: (++sumLessThanStartSumCount > 0 ? false : true))
				&& ((numsum <= endSum) ? true
						: (++sumMoreThanEndSumCount > 0 ? false : true))
				// && (sumNotAppearedRecently(comblocal)? true:
				// (++sumNotAppearedRecentlyCount> 0?false:true ))
				&& (DBPredicAnalysis(comblocal) ? true
						: (++DBPredicCount > 0 ? false : true))
				&& (GeneratorVTwo.isPossibleComb(comblocal) ? true
						: (++isPossibleCombAccordingToGeneratorVTwoCount > 0 ? false
								: true))
				// && (matches3Differences(comblocal)? true:
				// (++matches3DiffsCount> 0?false:true ))
				// && (DisallowDigit(comblocal)? true: (++DisallowDigitCount>
				// 0?false:true ))
				&& (missedDigitsInHistory(comblocal) ? true
						: (++missedDigitsInHistory > 0 ? false : true))
				&& (sameReduxInHistory(comblocal) ? true
						: (++sameReduxCount > 0 ? false : true))
				// && (sumAppearedRecently(comblocal)? true:
				// (++sumAppearedRecentlyCount> 0?false:true ))
				&& (frqBasedFilter(comblocal) ? true
						: (++freqFilterCount > 0 ? false : true))
				&& (n.exclusions(comblocal) ? true
						: (++exclusionsCount > 0 ? false : true))
				// && (numberOfPrimesNotAsLast3(comblocal)? true:
				// (++numberOfPrimesNotAsLast3Count> 0?false:true ))
				&& (properDistribution(comblocal, numberOfZeroInAllBrackets,
						numberMaxInBracket) ? true
						: (++propdistCount > 0 ? false : true))
				// && (n.in5History(comblocal,last5Range)? true:
				// (++in5HistoryCount > 0? false:true ))
				// && n.calculateBuckets(comblocal)
				&& (predictThroughRedux(comblocal) ? true
						: (++predictThroughReduxCount > 0 ? false : true))
				// && (n.matchesFreqs(comblocal)? true: (++matchesFreqList >
				// 0?false:true))
				&& (n.last9CombsAverage(comblocal, avgStart, avgEnd) ? true
						: (++last9CombsAverageCount > 0 ? false : true))
				&& (equiDistantFilter(comblocal) ? true
						: (++equiDistantFilterCount > 0 ? false : true))
				&& (n.combsAlreadyAppeared(comblocal) ? true
						: (++combsAlreadyAppearedCount > 0 ? false : true))
				&& (removeCombsHavingBelowAverageNumbers(comblocal,
						notAllowedBucket50) ? true
						: (++combsBelowAverageNumbersCount > 0 ? false : true))
				// && (removeIf4MoreThan35(comblocal) ? true:
				// (++if4MoreThan35Count > 0? false:true ))
				&& (removeAllEvensAndOdds(comblocal) ? true
						: (++allEvensAndOddsCount > 0 ? false : true))
				// && (removeNumbersWithSameLstDigit(comblocal) ? true:
				// (++numbersWithSameLstDigitCount > 0? false:true ))
				&& (n.aboveAverageFreq(comblocal) ? true
						: (++aboveAverageFreqCount > 0 ? false : true))
				// && (n.inclusions(comblocal) ? true: (++inclusionsCount > 0?
				// false:true ))
				// && (hotNumbers(comblocal) ? true: (++hotNumberCount > 0?
				// false:true ))
				// && (notInBucketListFile(comblocal)? true:
				// (++notInBucketListFileCount> 0?false:true ))
				// && (n.checkSkipDetails(comblocal)? true: (++checkSkipDetails>
				// 0?false:true ))
				// && (n.uniqueBucketPatterns(comblocal)? true:
				// (++uniqueBucketPattern> 0?false:true ))
				&& (isALikelyBucketPattern(comblocal) ? true
						: (++notInBucketListFileCount > 0 ? false : true))
				&& (followerPatternAnalysis(comblocal) ? true
						: (++followerPatternAnalysisCount > 0 ? false : true))

		) {
			out = true;

		}

		if (out) {
			String st = a.get(0) + "," + a.get(1) + "," + a.get(2) + ","
					+ a.get(3) + "," + a.get(4);
			try {
				output.write(st.toString());
				output.write(";");
				output.flush();
			} catch (IOException ix) {
				ix.printStackTrace();
			}
		}
		return out;

	}

	private static boolean matches3Differences(int[] comblocal) {
		// TODO Auto-generated method stub
		boolean out = false;
		if (gameCode == null) {
			gte = new GameTypesEntity();
			gameCode = gte.findGameCodeByProgramCode(type);
		}

		if (rhe.matches3Diffs(0, Integer.parseInt(gameCode), comblocal))
			out = true;
		return out;
	}

	private static boolean sameReduxInHistory(int[] comblocal) {
		boolean out = true;
		int[] reduxs = new int[comblocal.length];

		for (int i = 0; i < comblocal.length; i++) {
			reduxs[i] = Integer.parseInt(Numbers.getRedux(Integer
					.toString(comblocal[i])));
		}

		if (gameCode == null) {
			gte = new GameTypesEntity();
			gameCode = gte.findGameCodeByProgramCode(type);
		}

		if (rhe.sameReduxInHistory(reduxs, gameCode, 0))
			out = false;

		return out;
	}

	private static boolean missedDigitsInHistory(int[] comblocal) {
		boolean out = true;
		String missingDigits = "";
		ArrayList complete = new ArrayList(Arrays.asList(new String[] { "1", "2", "3", "4", "5", "6", "7", "8", "9","0" }));
		ArrayList<String> removeList = new ArrayList<String>();

		int[] thisLine = new int[6];
		for (int i = 0; i < comblocal.length; i++) {
			String num = Integer.toString(comblocal[i]);

			if (complete.contains(Integer.toString(Integer.parseInt(num) / 10)))
				removeList.add(Integer.toString(Integer.parseInt(num) / 10));

			if (complete.contains(Integer.toString(Integer.parseInt(num) % 10)))
				removeList.add(Integer.toString(Integer.parseInt(num) % 10));

		}

		for (String removeEntry : removeList) {
			complete.remove(removeEntry);
		}

		Iterator it = complete.iterator();
		while (it.hasNext()) {
			missingDigits += ((String) it.next());
		}

		if (Numbers.missingDigits.containsKey(missingDigits)) {
			Integer val = Numbers.missingDigits.get(missingDigits);

			if (val == 1)
				return false;
		}

		return out;
	}

	private static boolean DisallowDigit(int[] comblocal) {
		boolean out = true;

		for (int i = 0; i < comblocal.length; i++) {
			if (comblocal[i] / 10 == disallowDigit)
				return false;

			if (comblocal[i] % 10 == disallowDigit)
				return false;
		}

		return out;
	}

	private static boolean DBPredicAnalysis(int[] comblocal) {
		boolean out = true;
		int violations = 0;
		int allowedViolations = 0;

		if (DBpredicProp.isEmpty()) {

			setDBpredicProp(null);

			System.out.println("Generator.java ---- Procesing prediction file "
					+ predicFileName + " Allowed violations "
					+ allowedViolations);

			if (DBpredicProp.getProperty("EMPTYPREDICPROP") != null)
				return true;

		} else {
			if (DBpredicProp.getProperty("EMPTYPREDICPROP") != null)
				return true;
		}

		String param = DBpredicProp.getProperty("FIRSTSKIP");
		if (param != null && param.length() > 0) {
			int startInd = param.indexOf("[") + 1;
			if (startInd > 0) {
				String val = param.substring(startInd, param.indexOf("]"));

				String[] valA = val.split("\\,");
				List lis = (List) Arrays.asList(valA);

				Integer skip = n.getSkipHashCurrent().get(comblocal[0]);

				if (lis.contains(Integer.toString(skip))) {
					if (startInd > 1) {// Prediction was a NOT
						// return false;
						violations++;
					}
				} else {
					if (startInd <= 1) {
						violations++;
					}
				}
			}
		}

		param = DBpredicProp.getProperty("SECONDSKIP");
		if (param != null && param.length() > 0) {
			int startInd = param.indexOf("[") + 1;
			if (startInd > 0) {
				String val = param.substring(startInd, param.indexOf("]"));

				String[] valA = val.split("\\,");
				List lis = (List) Arrays.asList(valA);

				Integer skip = n.getSkipHashCurrent().get(comblocal[1]);

				if (skip != null) {
					if (lis.contains(Integer.toString(skip))) {
						if (startInd > 1) {// Prediction was a NOT
							violations++;
						}
					} else {
						if (startInd <= 1) {
							violations++;
						}
					}
				} else {
					if (startInd <= 1) {
						violations++;
					}
				}
			}
		}

		param = DBpredicProp.getProperty("THIRDSKIP");
		if (param != null && param.length() > 0) {
			int startInd = param.indexOf("[") + 1;
			if (startInd > 0) {
				String val = param.substring(startInd, param.indexOf("]"));

				String[] valA = val.split("\\,");
				List lis = (List) Arrays.asList(valA);

				Integer skip = n.getSkipHashCurrent().get(comblocal[2]);

				if (skip != null) {
					if (lis.contains(Integer.toString(skip))) {
						if (startInd > 1) {// Prediction was a NOT
							violations++;
						}
					} else {
						if (startInd <= 1) {
							violations++;
						}
					}
				} else {
					if (startInd <= 1) {
						violations++;
					}
				}
			}
		}

		param = DBpredicProp.getProperty("FOURTHSKIP");
		if (param != null && param.length() > 0) {
			int startInd = param.indexOf("[") + 1;
			if (startInd > 0) {
				String val = param.substring(startInd, param.indexOf("]"));

				String[] valA = val.split("\\,");
				List lis = (List) Arrays.asList(valA);

				Integer skip = n.getSkipHashCurrent().get(comblocal[3]);

				if (skip != null) {
					if (lis.contains(Integer.toString(skip))) {
						if (startInd > 1) {// Prediction was a NOT
							violations++;
						}
					} else {
						if (startInd <= 1) {
							violations++;
						}
					}
				} else { // SKIP is null
					if (startInd <= 1) {
						violations++;
					}
				}
			}
		}

		param = DBpredicProp.getProperty("FIFTHSKIP");
		if (param != null && param.length() > 0) {
			int startInd = param.indexOf("[") + 1;
			if (startInd > 0) {
				String val = param.substring(startInd, param.indexOf("]"));

				String[] valA = val.split("\\,");
				List lis = (List) Arrays.asList(valA);

				Integer skip = n.getSkipHashCurrent().get(comblocal[4]);

				if (skip != null) {
					if (lis.contains(Integer.toString(skip))) {
						if (startInd > 1) {// Prediction was a NOT
							violations++;
						}
					} else {
						if (startInd <= 1) {
							violations++;
						}
					}
				} else {
					if (startInd <= 1) {
						violations++;
					}
				}
			}
		}

		if (violations > allowedViolations)
			return false;

		param = DBpredicProp.getProperty("FIRSTVALUE");
		if (param != null && param.length() > 0) {
			int startInd = param.indexOf("[") + 1;
			if (startInd > 0) {
				String val = param.substring(startInd, param.indexOf("]"));

				String[] valA = val.split("\\,");
				List lis = (List) Arrays.asList(valA);

				if (lis.contains(Integer.toString(comblocal[0]))) {
					if (startInd > 1) {// Prediction was a NOT
						violations++;
					}
				} else {
					if (startInd <= 1) {
						violations++;
					}
				}
			}
		}

		param = DBpredicProp.getProperty("SECONDVALUE");
		if (param != null && param.length() > 0) {
			int startInd = param.indexOf("[") + 1;
			if (startInd > 0) {
				String val = param.substring(startInd, param.indexOf("]"));

				String[] valA = val.split("\\,");
				List lis = (List) Arrays.asList(valA);

				if (lis.contains(Integer.toString(comblocal[1]))) {
					if (startInd > 1) {// Prediction was a NOT
						violations++;
					}
				} else {
					if (startInd <= 1) {
						violations++;
					}
				}
			}
		}

		param = DBpredicProp.getProperty("THIRDVALUE");
		if (param != null && param.length() > 0) {
			int startInd = param.indexOf("[") + 1;
			if (startInd > 0) {
				String val = param.substring(startInd, param.indexOf("]"));

				String[] valA = val.split("\\,");
				List lis = (List) Arrays.asList(valA);

				if (lis.contains(Integer.toString(comblocal[2]))) {
					if (startInd > 1) {// Prediction was a NOT
						violations++;
					}
				} else {
					if (startInd <= 1) {
						violations++;
					}
				}
			}
		}

		param = DBpredicProp.getProperty("FOURTHVALUE");
		if (param != null && param.length() > 0) {
			int startInd = param.indexOf("[") + 1;
			if (startInd > 0) {
				String val = param.substring(startInd, param.indexOf("]"));

				String[] valA = val.split("\\,");
				List lis = (List) Arrays.asList(valA);

				if (lis.contains(Integer.toString(comblocal[3]))) {
					if (startInd > 1) {// Prediction was a NOT
						violations++;
					}
				} else {
					if (startInd <= 1) {
						violations++;
					}
				}
			}
		}

		param = DBpredicProp.getProperty("FIFTHVALUE");
		if (param != null && param.length() > 0) {
			int startInd = param.indexOf("[") + 1;
			if (startInd > 0) {
				String val = param.substring(startInd, param.indexOf("]"));

				String[] valA = val.split("\\,");
				List lis = (List) Arrays.asList(valA);

				if (lis.contains(Integer.toString(comblocal[4]))) {
					if (startInd > 1) {// Prediction was a NOT
						violations++;
					}
				} else {
					if (startInd <= 1) {
						violations++;
					}
				}
			}
		}

		if (violations > allowedViolations)
			return false;

		param = DBpredicProp.getProperty("FIRSTBUCKET");
		if (param != null && param.length() > 0) {
			int startInd = param.indexOf("[") + 1;
			if (startInd > 0) {
				String val = param.substring(startInd, param.indexOf("]"));

				String[] valA = val.split("\\,");
				List lis = (List) Arrays.asList(valA);

				if (lis.contains(Integer.toString(comblocal[0] / 10))) {
					if (startInd > 1) {// Prediction was a NOT
						violations++;
					}
				} else {
					if (startInd <= 1) {
						violations++;
					}
				}
			}
		}

		param = DBpredicProp.getProperty("SECONDBUCKET");
		if (param != null && param.length() > 0) {
			int startInd = param.indexOf("[") + 1;
			if (startInd > 0) {
				String val = param.substring(startInd, param.indexOf("]"));

				String[] valA = val.split("\\,");
				List lis = (List) Arrays.asList(valA);

				if (lis.contains(Integer.toString(comblocal[1] / 10))) {
					if (startInd > 1) {// Prediction was a NOT
						violations++;
					}
				} else {
					if (startInd <= 1) {
						violations++;
					}
				}
			}
		}

		param = DBpredicProp.getProperty("THIRDBUCKET");
		if (param != null && param.length() > 0) {
			int startInd = param.indexOf("[") + 1;
			if (startInd > 0) {
				String val = param.substring(startInd, param.indexOf("]"));

				String[] valA = val.split("\\,");
				List lis = (List) Arrays.asList(valA);

				if (lis.contains(Integer.toString(comblocal[2] / 10))) {
					if (startInd > 1) {// Prediction was a NOT
						violations++;
					}
				} else {
					if (startInd <= 1) {
						violations++;
					}
				}
			}
		}

		param = DBpredicProp.getProperty("FOURTHBUCKET");
		if (param != null && param.length() > 0) {
			int startInd = param.indexOf("[") + 1;
			if (startInd > 0) {
				String val = param.substring(startInd, param.indexOf("]"));

				String[] valA = val.split("\\,");
				List lis = (List) Arrays.asList(valA);

				if (lis.contains(Integer.toString(comblocal[3] / 10))) {
					if (startInd > 1) {// Prediction was a NOT
						violations++;
					}
				} else {
					if (startInd <= 1) {
						violations++;
					}
				}
			}
		}

		param = DBpredicProp.getProperty("FIFTHBUCKET");
		if (param != null && param.length() > 0) {
			int startInd = param.indexOf("[") + 1;
			if (startInd > 0) {
				String val = param.substring(startInd, param.indexOf("]"));

				String[] valA = val.split("\\,");
				List lis = (List) Arrays.asList(valA);

				if (lis.contains(Integer.toString(comblocal[4] / 10))) {
					if (startInd > 1) {// Prediction was a NOT
						violations++;
					}
				} else {
					if (startInd <= 1) {
						violations++;
					}
				}
			}
		}

		if (violations > allowedViolations)
			return false;

		param = DBpredicProp.getProperty("FIRSTREDUX");
		if (param != null && param.length() > 0) {
			int startInd = param.indexOf("[") + 1;
			if (startInd > 0) {
				String val = param.substring(startInd, param.indexOf("]"));

				String[] valA = val.split("\\,");
				List lis = (List) Arrays.asList(valA);

				if (lis.contains(n.getRedux(Integer.toString(comblocal[0])))) {
					if (startInd > 1) {// Prediction was a NOT
						violations++;
					}
				} else {
					if (startInd <= 1) {
						violations++;
					}
				}
			}
		}

		param = DBpredicProp.getProperty("SECONDREDUX");
		if (param != null && param.length() > 0) {
			int startInd = param.indexOf("[") + 1;
			if (startInd > 0) {
				String val = param.substring(startInd, param.indexOf("]"));

				String[] valA = val.split("\\,");
				List lis = (List) Arrays.asList(valA);

				if (lis.contains(n.getRedux(Integer.toString(comblocal[1])))) {
					if (startInd > 1) {// Prediction was a NOT
						violations++;
					}
				} else {
					if (startInd <= 1) {
						violations++;
					}
				}
			}
		}

		param = DBpredicProp.getProperty("THIRDREDUX");
		if (param != null && param.length() > 0) {
			int startInd = param.indexOf("[") + 1;
			if (startInd > 0) {
				String val = param.substring(startInd, param.indexOf("]"));

				String[] valA = val.split("\\,");
				List lis = (List) Arrays.asList(valA);

				if (lis.contains(n.getRedux(Integer.toString(comblocal[2])))) {
					if (startInd > 1) {// Prediction was a NOT
						violations++;
					}
				} else {
					if (startInd <= 1) {
						violations++;
					}
				}
			}
		}

		param = DBpredicProp.getProperty("FOURTHREDUX");
		if (param != null && param.length() > 0) {
			int startInd = param.indexOf("[") + 1;

			if (startInd > 0) {
				String val = param.substring(startInd, param.indexOf("]") - 1);
				String[] valA = val.split("\\,");
				List lis = (List) Arrays.asList(valA);

				if (lis.contains(n.getRedux(Integer.toString(comblocal[3])))) {
					if (startInd > 1) {// Prediction was a NOT
						violations++;
					}
				} else {
					if (startInd <= 1) {
						violations++;
					}
				}
			}
		}

		param = DBpredicProp.getProperty("FIFTHREDUX");
		if (param != null && param.length() > 0) {
			int startInd = param.indexOf("[") + 1;
			if (startInd > 0) {
				String val = param.substring(startInd, param.indexOf("]"));
				String[] valA = val.split("\\,");
				List lis = (List) Arrays.asList(valA);

				if (lis.contains(n.getRedux(Integer.toString(comblocal[4])))) {
					if (startInd > 1) {// Prediction was a NOT
						violations++;
					}
				} else {
					if (startInd <= 1) {
						violations++;
					}
				}
			}
		}

		if (violations > allowedViolations)
			return false;

		param = DBpredicProp.getProperty("FIRSTFIVESUMREDUX");
		if (param != null && param.length() > 0) {
			int startInd = param.indexOf("[") + 1;
			if (startInd > 0) {
				String val = param.substring(startInd, param.indexOf("]"));

				String[] valA = val.split("\\,");
				List lis = (List) Arrays.asList(valA);

				if (lis.contains(n.getRedux(Integer.toString(comblocal[0]
						+ comblocal[1] + comblocal[2] + comblocal[3]
						+ comblocal[4])))) {
					if (startInd > 1) {// Prediction was a NOT
						violations++;
					}
				} else {
					if (startInd <= 1) {
						violations++;
					}
				}
			}
		}

		if (violations > allowedViolations)
			return false;

		param = DBpredicProp.getProperty("FIRSTFIVESUMBUCKET");
		if (param != null && param.length() > 0) {
			int startInd = param.indexOf("[") + 1;
			if (startInd > 0) {
				String val = param.substring(startInd, param.indexOf("]"));

				String[] valA = val.split("\\,");
				List lis = (List) Arrays.asList(valA);

				if (lis.contains(Integer.toString((comblocal[0] + comblocal[1]
						+ comblocal[2] + comblocal[3] + comblocal[4]) / 10))) {
					if (startInd > 1) {// Prediction was a NOT
						violations++;
					}
				} else {
					if (startInd <= 1) {
						violations++;
					}
				}
			}
		}

		if (violations > allowedViolations)
			return false;

		param = DBpredicProp.getProperty("FIRSTFIVESUM");
		if (param != null && param.length() > 0) {
			int startInd = param.indexOf("[") + 1;
			if (startInd > 0) {
				String val = param.substring(startInd, param.indexOf("]"));

				String[] valA = val.split("\\,");
				List lis = (List) Arrays.asList(valA);

				if (lis.contains(Integer.toString((comblocal[0] + comblocal[1]
						+ comblocal[2] + comblocal[3] + comblocal[4]) / 10))) {
					if (startInd > 1) {// Prediction was a NOT
						violations++;
					}
				} else {
					if (startInd <= 1) {
						violations++;
					}
				}
			}

			if (param.indexOf("ODD") >= 0 || param.indexOf("EVEN") >= 0) {
				if (param.indexOf("ODD") >= 0) {
					if ((comblocal[0] + comblocal[1] + comblocal[2]
							+ comblocal[3] + comblocal[4]) % 2 == 0)
						violations++;
				}

				if (param.indexOf("EVEN") >= 0) {
					if ((comblocal[0] + comblocal[1] + comblocal[2]
							+ comblocal[3] + comblocal[4]) % 2 > 0)
						violations++;
				}
			}
		}

		if (violations > allowedViolations)
			return false;

		param = DBpredicProp.getProperty("NUMPRIMES");
		if (param != null && param.length() > 0) {
			int startInd = param.indexOf("[") + 1;
			if (startInd > 0) {
				String val = param.substring(startInd, param.indexOf("]"));

				String[] valA = val.split("\\,");
				List lis = (List) Arrays.asList(valA);

				Iterator it = lis.iterator();

				while (it.hasNext()) {
					int count = Integer.parseInt((String) it.next());
					if (numberOfPrimesMatch(comblocal, count)) {
						if (startInd > 1) {// Prediction was a NOT
							violations++;
						}
					} else {
						if (startInd <= 1) {
							violations++;
						}
					}
				}
			}
		}

		if (violations > allowedViolations)
			return false;

		param = DBpredicProp.getProperty("FIRSTFOLLOWER");
		if (param != null && param.length() > 0) {

			int startInd = param.indexOf("[") + 1;
			if (startInd > 0) {
				String val = param.substring(startInd, param.indexOf("]"));

				String[] valA = val.split("\\,");
				// List lis = (List) Arrays.asList(valA);

				String vals = (String) followers.get("FirstFollower");

				String[] avals = vals.split("\\,");
				List lis = (List) Arrays.asList(avals);

				if (lis.contains(Integer.toString(comblocal[0]))) {

					if (valA[0].equals("N")) {
						if (startInd <= 1) {
							violations++;
						}
					} else {
						if (startInd > 1) { // Prediction was a NOT and Value
											// was Y
							violations++;
						}
					}

				} else {
					if (valA[0].equals("Y")) {
						if (startInd <= 1) {
							violations++;
						}
					} else {
						if (startInd > 1) { // Prediction was a NOT and Value
											// was N
							violations++;
						}
					}
				}
			}
		}

		if (violations > allowedViolations)
			return false;

		param = DBpredicProp.getProperty("SECONDFOLLOWER");
		if (param != null && param.length() > 0) {

			int startInd = param.indexOf("[") + 1;
			if (startInd > 0) {
				String val = param.substring(startInd, param.indexOf("]"));

				String[] valA = val.split("\\,");
				// List lis = (List) Arrays.asList(valA);

				String vals = (String) followers.get("SecondFollower");

				String[] avals = vals.split("\\,");
				List lis = (List) Arrays.asList(avals);

				if (lis.contains(Integer.toString(comblocal[1]))) {

					if (valA[0].equals("N")) {
						if (startInd <= 1) {
							violations++;
						}
					} else {
						if (startInd > 1) { // Prediction was a NOT and Value
											// was Y
							violations++;
						}
					}

				} else {
					if (valA[0].equals("Y")) {
						if (startInd <= 1) {
							violations++;
						}
					} else {
						if (startInd > 1) { // Prediction was a NOT and Value
											// was N
							violations++;
						}
					}
				}
			}
		}

		if (violations > allowedViolations)
			return false;

		param = DBpredicProp.getProperty("THIRDFOLLOWER");
		if (param != null && param.length() > 0) {

			int startInd = param.indexOf("[") + 1;
			if (startInd > 0) {
				String val = param.substring(startInd, param.indexOf("]"));

				String[] valA = val.split("\\,");
				// List lis = (List) Arrays.asList(valA);

				String vals = (String) followers.get("ThirdFollower");

				String[] avals = vals.split("\\,");
				List lis = (List) Arrays.asList(avals);

				if (lis.contains(Integer.toString(comblocal[2]))) {

					if (valA[0].equals("N")) {
						if (startInd <= 1) {
							violations++;
						}
					} else {
						if (startInd > 1) { // Prediction was a NOT and Value
											// was Y
							violations++;
						}
					}

				} else {
					if (valA[0].equals("Y")) {
						if (startInd <= 1) {
							violations++;
						}
					} else {
						if (startInd > 1) { // Prediction was a NOT and Value
											// was N
							violations++;
						}
					}
				}
			}
		}

		if (violations > allowedViolations)
			return false;

		param = DBpredicProp.getProperty("FOURTHFOLLOWER");
		if (param != null && param.length() > 0) {

			int startInd = param.indexOf("[") + 1;
			if (startInd > 0) {
				String val = param.substring(startInd, param.indexOf("]"));

				String[] valA = val.split("\\,");
				// List lis = (List) Arrays.asList(valA);

				String vals = (String) followers.get("FourthFollower");

				String[] avals = vals.split("\\,");
				List lis = (List) Arrays.asList(avals);

				if (lis.contains(Integer.toString(comblocal[3]))) {

					if (valA[0].equals("N")) {
						if (startInd <= 1) {
							violations++;
						}
					} else {
						if (startInd > 1) { // Prediction was a NOT and Value
											// was Y
							violations++;
						}
					}

				} else {
					if (valA[0].equals("Y")) {
						if (startInd <= 1) {
							violations++;
						}
					} else {
						if (startInd > 1) { // Prediction was a NOT and Value
											// was N
							violations++;
						}
					}
				}
			}
		}
		if (violations > allowedViolations)
			return false;

		param = DBpredicProp.getProperty("FIFTHFOLLOWER");
		if (param != null && param.length() > 0) {

			int startInd = param.indexOf("[") + 1;
			if (startInd > 0) {
				String val = param.substring(startInd, param.indexOf("]"));

				String[] valA = val.split("\\,");
				// List lis = (List) Arrays.asList(valA);

				String vals = (String) followers.get("FifthFollower");

				String[] avals = vals.split("\\,");
				List lis = (List) Arrays.asList(avals);

				if (lis.contains(Integer.toString(comblocal[4]))) {

					if (valA[0].equals("N")) {
						if (startInd <= 1) {
							violations++;
						}
					} else {
						if (startInd > 1) { // Prediction was a NOT and Value
											// was Y
							violations++;
						}
					}

				} else {
					if (valA[0].equals("Y")) {
						if (startInd <= 1) {
							violations++;
						}
					} else {
						if (startInd > 1) { // Prediction was a NOT and Value
											// was N
							violations++;
						}
					}
				}
			}
		}

		if (violations > allowedViolations)
			return false;

		param = DBpredicProp.getProperty("FIRSTFIVESUMPRIME");
		if (param != null && param.length() > 0) {
			int startInd = param.indexOf("[") + 1;
			if (startInd > 0) {
				String val = param.substring(startInd, param.indexOf("]"));

				String[] valA = val.split("\\,");
				List lis = (List) Arrays.asList(valA);

				if (sumPrimesList.contains(comblocal[0] + comblocal[1]
						+ comblocal[2] + comblocal[3] + comblocal[4])) {

					if (valA[0].equals("0")) {
						if (startInd <= 1) {
							violations++;
						}
					} else {
						if (startInd > 1) { // Prediction was a NOT and Value
											// was Y
							violations++;
						}
					}

				} else {
					if (valA[0].equals("1")) {
						if (startInd <= 1) {
							violations++;
						}
					} else {
						if (startInd > 1) { // Prediction was a NOT and Value
											// was N
							violations++;
						}
					}
				}

			}
		}

		if (violations > allowedViolations)
			return false;

		param = DBpredicProp.getProperty("MATCH3DIFFS");
		if (param != null && param.length() > 0) {
			if (param.equalsIgnoreCase("Y")) {
				if (!matches3Differences(comblocal))
					violations++;
			} else {
				if (matches3Differences(comblocal))
					violations++;
			}

		}

		if (violations > allowedViolations)
			return false;

		param = DBpredicProp.getProperty("OBSINCLUDECOUNT");
		if (param != null && param.length() > 0) {
			int obsIncludeCount = Integer.parseInt(param);
			param = DBpredicProp.getProperty("OBSLIST");
			int count = 0;
			if (param != null && param.length() > 0) {
				int startInd = param.indexOf("[") + 1;
				if (startInd > 0) {
					String val = param.substring(startInd, param.indexOf("]"));
					String[] valA = val.split("\\,");
					List lis = (List) Arrays.asList(valA);

					for (int i = 0; i < comblocal.length; i++) {
						if (lis.contains(Integer.toString(comblocal[i])))
							count++;
					}
				}
			}

			if (!(count == obsIncludeCount))
				violations++;

		}

		if (violations > allowedViolations)
			return false;

		return out;
	}

	private static boolean followerPatternAnalysis(int[] comblocal) { // We do
																		// not
																		// want
																		// the
																		// comb
																		// to be
																		// one
																		// of
																		// the
																		// last
																		// few
																		// follower
																		// patterns
																		// Follower
																		// pattern
																		// is
																		// whether
																		// the
																		// number
																		// appearing
																		// has
																		// followed
																		// the
																		// previous
																		// number
																		// in
																		// history.
		boolean out = true;
		FollowerPatternEntity fte = new FollowerPatternEntity();

		if (gameCode == null) {
			gte = new GameTypesEntity();
			gameCode = gte.findGameCodeByProgramCode(type);
		}

		Hashtable h = fte.getCurrentFollowerTableForGame(gameCode);
		// System.out.println(h);

		if (fte.getLast10Patterns() == null) {
			fte.populateLast10Patterns(gameCode,0);
			System.out.println("Generator.java:followerPatternAnalysis --- Exclude follower pattern size " + fte.getLast10Patterns().size() + " " + fte.getLast10Patterns().toString());
		}

		String thisPattern = "";

		for (int i = 0; i < comblocal.length; i++) {
			if (((ArrayList) h.get(Integer.toString(i + 1))).size() > 0) {
				if (((ArrayList) h.get(Integer.toString(i + 1)))
						.contains(Integer.toString(comblocal[i])))
					thisPattern += "Y";
				else
					thisPattern += "N";
			} else {
				thisPattern += "X";
			}
		}

		Iterator it = fte.getLast10Patterns().iterator();

		while (it.hasNext()) {
			String pattern = (String) it.next();

			if (pattern.startsWith(thisPattern))
				return false;
		}

		return out;
	}

	private static boolean numberOfPrimesNotAsLast3(int[] comblocal) {
		// TODO Automate this
		// Numbers.last10MultAndPrimes
		int countOfPrimes = 0;

		for (int i = 0; i < comblocal.length; i++) {
			if (Numbers.primesTill75.contains(comblocal[i]))
				countOfPrimes++;
		}

		if (countOfPrimes != 1 && countOfPrimes != 3)
			return false;

		return true;
	}

	private static boolean numberOfPrimesMatch(int[] comblocal, int count) {
		// TODO Automate this
		// Numbers.last10MultAndPrimes
		int countOfPrimes = 0;

		for (int i = 0; i < comblocal.length; i++) {
			if (Numbers.primesTill75.contains(comblocal[i]))
				countOfPrimes++;
		}

		if (countOfPrimes != count)
			return false;

		return true;
	}

	private static boolean predictThroughRedux(int[] comblocal) {

		int followsReduxMap = 0; // We do not want to follow reduxMap very
									// rigidly, we allow max 2 exceptions
		int sum = 0;

		for (int i = 0; i < comblocal.length; i++) {
			if (!possibleBucketMap.get(i).contains(comblocal[i] / 10))
				return false;

			if (reduxPredictMap.get(i) != null) {
				if (reduxPredictMap.get(i).contains(
						Integer.parseInt(Numbers.getRedux(Integer
								.toString(comblocal[i])))))
					followsReduxMap++;
			} else {
				followsReduxMap++;
			}

			sum += comblocal[i];
		}

		if (followsReduxMap < 5)
			return false;

		if (reduxPredictMap.get(5) != null) {
			if (!reduxPredictMap.get(5).contains(
					Integer.parseInt(Numbers.getRedux(Integer.toString(sum)))))
				return false;
		}

		return true;
	}

	private static boolean sumNotAppearedRecently(int[] comblocal) {
		boolean b = true;
		// If sum is not repeated for about 6 draws, do the inverse too
		int sum = comblocal[0] + comblocal[1] + comblocal[2] + comblocal[3]
				+ comblocal[4];

		// if (sum % 2 == 0) return false;
		// if
		// (Numbers.findStringInFile("C:\\Users\\johris\\git\\git\\Generator\\numAppearanceMap"+type,
		// Integer.toString(sum)) == -1)
		if (Numbers.lastFewSums.size() > 0 && Numbers.lastFewSums.contains(sum))
			b = false;
		else
			b = true;

		return b;
	}

	private static boolean sumAppearedRecently(int[] comblocal) {
		boolean b = true;
		// If sum is not repeated for about 6 draws, do the inverse too
		int sum = comblocal[0] + comblocal[1] + comblocal[2] + comblocal[3]
				+ comblocal[4];

		// TODO remove the check for even odd sums
		// if (sum % 2 == 0) return false;
		// if
		// (Numbers.findStringInFile("C:\\Users\\johris\\git\\git\\Generator\\numAppearanceMap"+type,
		// Integer.toString(sum)) == -1)
		if (Numbers.lastFewSums.size() > 0 && Numbers.lastFewSums.contains(sum))
			b = true;
		else
			b = false;

		return b;
	}

	private static boolean isALikelyBucketPattern(int[] comblocal) {
		boolean b = false;
		String bucketPatternString = "";
		for (int i = 0; i < comblocal.length; i++) {

			if (10 > comblocal[i] && comblocal[i] >= 0)
				bucketPatternString += "0";
			if (20 > comblocal[i] && comblocal[i] >= 10)
				bucketPatternString += "1";
			if (30 > comblocal[i] && comblocal[i] >= 20)
				bucketPatternString += "2";
			if (40 > comblocal[i] && comblocal[i] >= 30)
				bucketPatternString += "3";
			if (50 > comblocal[i] && comblocal[i] >= 40)
				bucketPatternString += "4";
			if (60 > comblocal[i] && comblocal[i] >= 50)
				bucketPatternString += "5";
			if (70 > comblocal[i] && comblocal[i] >= 60)
				bucketPatternString += "6";
			if (80 > comblocal[i] && comblocal[i] >= 70)
				bucketPatternString += "7";
		}

		if (unlikelyBuckets.size() == 0) {
			GameBucketEntity gb = new GameBucketEntity();
			unlikelyBuckets = gb.getUnlikelyBucketsList(gameCode,
					unlikelyBucketSpan);
			
			System.out.println("Generator.java:isALikelyBucketPattern----Exclude bucket pattern list size " + unlikelyBuckets.size() + " " + unlikelyBuckets.toString());

		}

		if (!unlikelyBuckets.contains(bucketPatternString))
			b = true;

		return b;

	}

	private static boolean notInBucketListFile(int[] comblocal) {
		boolean b = false;
		String outString;
		int[] bucketCount = new int[8];

		// Also check if hotBuckets are represented

		if (hotBucketsList.size() == 0) {
			Set nums = Numbers.bucketFreqlast10.keySet();
			Iterator it = nums.iterator();

			Integer bucket = (Integer) it.next();
			int tempfreq = Numbers.bucketFreqlast10.get(bucket);
			hotBucketsList.add(bucket);

			while (it.hasNext()) {
				bucket = (Integer) it.next();
				int freq = Numbers.bucketFreqlast10.get(bucket);

				if (freq < tempfreq) {
					hotBucketsList.clear();
					tempfreq = freq;
					hotBucketsList.add(bucket);
				}

			}
			System.out
					.println("Generator.java.notInBucketListFile ---- Hot Buckets "
							+ hotBucketsList
							+ " --- Bucket freqs in last 10 "
							+ Numbers.bucketFreqlast10);
		}

		for (int i = 0; i < comblocal.length; i++) {

			if (10 > comblocal[i] && comblocal[i] >= 0)
				bucketCount[0] += 1;
			if (20 > comblocal[i] && comblocal[i] >= 10)
				bucketCount[1] += 1;
			if (30 > comblocal[i] && comblocal[i] >= 20)
				bucketCount[2] += 1;
			if (40 > comblocal[i] && comblocal[i] >= 30)
				bucketCount[3] += 1;
			if (50 > comblocal[i] && comblocal[i] >= 40)
				bucketCount[4] += 1;
			if (60 > comblocal[i] && comblocal[i] >= 50)
				bucketCount[5] += 1;
			if (60 > comblocal[i] && comblocal[i] >= 60)
				bucketCount[6] += 1;
			if (60 > comblocal[i] && comblocal[i] >= 70)
				bucketCount[7] += 1;
		}

		outString = " " + bucketCount[0] + " " + bucketCount[1] + " "
				+ bucketCount[2] + " " + bucketCount[3] + " " + bucketCount[4]
				+ " " + bucketCount[5] + " " + bucketCount[6] + " "
				+ bucketCount[7] + " ";

		if (Numbers.findStringInFile(
				"C:\\Users\\johris\\git\\git\\Generator\\bucketsList" + type,
				outString) == -1)
			b = true;

		/*
		 * if (hotBucketsList.size() > 0) {
		 * 
		 * Iterator it = hotBucketsList.iterator(); while (it.hasNext()) { int
		 * bucket = (Integer) it.next(); if (bucketCount[bucket] == 0) return
		 * false; } }
		 */

		return b;
	}

	static boolean properDistribution(int[] comb, int z, int c) { // z min
																	// number of
																	// brakcets
																	// which are
																	// blank
																	// each
																	// bracket
																	// can have
																	// max c
																	// numbmers
		boolean out = false;

		int count110 = 0;
		int count1020 = 0;
		int count2030 = 0;
		int count3040 = 0;
		int count4050 = 0;
		int count5060 = 0;

		for (int i = 0; i < comb.length; i++) {
			if (comb[i] > 0 && comb[i] < 10)
				count110++;
			if (comb[i] >= 10 && comb[i] < 20)
				count1020++;
			if (comb[i] >= 20 && comb[i] < 30)
				count2030++;
			if (comb[i] >= 30 && comb[i] < 40)
				count3040++;
			if (comb[i] >= 40 && comb[i] < 50)
				count4050++;
			if (comb[i] >= 50 && comb[i] < 60)
				count5060++;
		}

		int numofzeroes = 0;

		if (count110 == 0)
			numofzeroes++;
		if (count1020 == 0)
			numofzeroes++;
		if (count2030 == 0)
			numofzeroes++;
		if (count3040 == 0)
			numofzeroes++;
		if (count4050 == 0)
			numofzeroes++;
		if (count5060 == 0)
			numofzeroes++;

		if (numofzeroes >= z && count110 <= c && count1020 <= c
				&& count2030 <= c && count3040 <= c && count4050 <= c
				&& count5060 <= c)
			out = true;

		return out;
	}

	static boolean equiDistantFilter(int[] comb) { // Not more than 3 numbers
													// should be equidistant
													// 5 10 15 is OK 5 10 15 20
													// is not
		boolean b = true;
		int distance1 = 0;
		int distance2 = 0;
		int distance3 = 0;
		int distance4 = 0;

		distance1 = comb[1] - comb[0];
		distance2 = comb[2] - comb[1];
		distance3 = comb[3] - comb[2];
		distance4 = comb[4] - comb[3];

		Hashtable<Integer, Integer> hash = new Hashtable<Integer, Integer>();

		hash.put(distance1, 1);

		if (hash.get(distance2) != null) {
			int count = hash.get(distance2);
			hash.put(distance2, count + 1);
		} else {
			hash.put(distance2, 1);
		}

		if (hash.get(distance3) != null) {
			int count = hash.get(distance3);
			hash.put(distance3, count + 1);
		} else {
			hash.put(distance3, 1);
		}

		if (hash.get(distance4) != null) {
			int count = hash.get(distance4);
			hash.put(distance4, count + 1);

		} else {
			hash.put(distance4, 1);
		}

		Enumeration en = hash.keys();
		while (en.hasMoreElements()) {
			int count = hash.get(en.nextElement());

			if (count > 2) {
				b = false;
				break;
			}
		}

		// if (!b) System.out.println(comb[0] + " " + comb[1]+ " " + comb[2] +
		// " " + comb[3]+ " " + comb[4] );
		return b;
	}

	static boolean removeCombsHavingBelowAverageNumbers(int[] comb, int ct) {
		boolean b = true;
		int count = 0;
		for (int i = 0; i < comb.length; i++) {
			if (comb[i] >= 50) {
				count++;
			}
		}
		if (count >= ct)
			b = false;
		return b;
	}

	static boolean removeIf4MoreThan35(int[] comb) {
		boolean b = true;
		int counter = 0;
		for (int i = 0; i < comb.length; i++) {
			if (comb[i] > 35) {
				counter++;
			}

			if (counter >= 4)
				b = false;
		}

		return b;

	}

	static boolean removeAllEvensAndOdds(int[] comb) {
		boolean b = true;
		int ec = 0;
		int oc = 0;
		for (int i = 0; i < comb.length; i++) {
			if (comb[i] % 2 == 0) {
				ec++;
			} else {
				oc++;
			}

			if (ec > 4 || oc > 4)
				return false;
		}

		// Also do the Even Odd analysis based on Numbers.evenOddLastNineCount
		// -- We count every even num as +1 and odd as -1. We sum last 9
		// occurences.
		// If this sum is > 4, we play for majority of odds, if this is less
		// than -2, we play for majority of Evens
		// And Numbers.lastEvenOdd = null; // If evenOddLastNineCount does not
		// give an answer (between -2 and 4, we switch even and odds.

		if (Numbers.lastEvenOdd == null)
			Numbers.numberAppearance(10);
		if (Numbers.evenOddLastNineCount > -7
				&& Numbers.evenOddLastNineCount < 4) {// Not an extreme , stay
														// course
			if (Numbers.lastEvenOdd.equals("E") && oc > 2)
				return false;
			if (Numbers.lastEvenOdd.equals("O") && ec > 2)
				return false;

		} else {

			if (Numbers.evenOddLastNineCount <= -7 && oc > 2)
				return false;// Lots of odds in last 9, go for Evens

			if (Numbers.evenOddLastNineCount >= 4 && ec > 2)
				return false;// Lots of evens in last 9, go for odds
		}

		return b;
	}

	static boolean removeNumbersWithSameLstDigit(int[] comb) {
		boolean b = true;
		int count = 0;
		HashMap<Integer, Integer> hm = new HashMap<Integer, Integer>();

		for (int i = 0; i < comb.length; i++) {
			if (hm.containsKey(comb[i] % 10))
				hm.put(comb[i] % 10, (hm.get(comb[i] % 10) + 1));
			else
				hm.put(comb[i] % 10, 1);
		}

		Iterator i = hm.entrySet().iterator();
		while (i.hasNext()) {
			Map.Entry<Integer, Integer> pairs = (Map.Entry) i.next();
			if (pairs.getValue() >= 3) {
				b = false;

			}

		}

		return b;
	}

	static boolean hotNumbers(int[] comb) {
		boolean b = false;
		int count = 0;
		HashSet<Integer> hotNumbers = new HashSet<Integer>();
		for (int j = 0; j < hotNumbersArray.length; j++)
			if (hotNumbersArray[j] != 0)
				hotNumbers.add(hotNumbersArray[j]);

		for (int i = 0; i < comb.length; i++) {
			if (hotNumbers.contains(comb[i]))
				count++;
		}

		if (count == hotNumbers.size())
			b = true;
		return b;
	}

	static boolean frqBasedFilter(int[] comb) { // If freqBasedList is populated
												// in props.properties file, we
												// need one number from
												// each list separated by ;

		boolean b = false;
		int count = 0;

		ArrayList<ArrayList<Integer>> localfrq = (ArrayList<ArrayList<Integer>>) frq
				.clone();
		if (localfrq.size() == 0)
			return true;

		if (localfrq.size() > 5)
			return false;

		for (int i = 0; i < comb.length; i++) {
			for (int j = 0; j < localfrq.size(); j++) {
				ArrayList<Integer> a = localfrq.get(j);
				if (a.contains(comb[i])) {
					count++;
					localfrq.remove(j);
					break;
				}
			}

		}

		if (count < frq.size())
			return false;
		else
			return true;

	}

	static void CombTest(int[] comb) {
		boolean out = false;

		System.out.println();
		System.out.println("Testing these numbers: " + comb[0] + "," + comb[1]
				+ "," + comb[2] + "," + comb[3] + "," + comb[4]);
		System.out
				.println(" More than start Sum "
						+ ((comb[0] + comb[1] + comb[2] + comb[3] + comb[4] > startSum)));
		System.out.println(" Less than end Sum "
				+ ((comb[0] + comb[1] + comb[2] + comb[3] + comb[4] < endSum)));
		System.out.println("properDistribution "
				+ properDistribution(comb, numberOfZeroInAllBrackets,
						numberMaxInBracket));
		System.out.println("last9CombsAverage "
				+ n.last9CombsAverage(comb, avgStart, avgEnd));
		System.out.println("equiDistantFilter " + equiDistantFilter(comb));
		System.out.println("combsAlreadyAppeared "
				+ n.combsAlreadyAppeared(comb));
		System.out
				.println("removeCombsHavingBelowAverageNumbers "
						+ removeCombsHavingBelowAverageNumbers(comb,
								notAllowedBucket50));
		// System.out.println("removeIf4MoreThan35 " +
		// removeIf4MoreThan35(comb));
		System.out.println("removeAllEvensAndOdds "
				+ removeAllEvensAndOdds(comb));
		// System.out.println(hotNumbers(comb));
		// System.out.println("removeNumbersWithSameLstDigit " +
		// removeNumbersWithSameLstDigit(comb));
		System.out.println("aboveAverageFreq " + n.aboveAverageFreq(comb));
		// System.out.println("matchesFreqs " + n.matchesFreqs(comb));
		System.out.println("frqBasedFilter " + frqBasedFilter(comb));
		// System.out.println("inclusions " + n.inclusions(comb));
		System.out.println("exclusions " + n.exclusions(comb));
		// System.out.println("notInBucketListFile " +
		// notInBucketListFile(comb));
		// System.out.println("checkSkipDetails " + n.checkSkipDetails(comb));
		// System.out.println("sumNotAppearedRecently " +
		// sumNotAppearedRecently(comb));
		// System.out.println("sumAppearedRecently " +
		// sumAppearedRecently(comb));
		System.out.println("predictThroughRedux " + predictThroughRedux(comb));
		System.out.println("DBPredicAnalysis " + DBPredicAnalysis(comb));
		System.out.println(" followerPatternAnalysis "
				+ followerPatternAnalysis(comb));
		System.out.println(" isALikelyBucketPattern "
				+ isALikelyBucketPattern(comb));

		System.out.println(" sameReduxInHistory " + sameReduxInHistory(comb));

		System.out.println(" missedDigitsInHistory "
				+ missedDigitsInHistory(comb));

	}

	static void printFreqMapForTestCombs() { // Prints freq map -----*---*-- for
												// all combs in meg.properties
		StringBuilder sb = new StringBuilder();

		currentCriteria.setExecuteFlag("true");

		if (currentCriteria.getTargetDrawDate() != null) {
			currentCriteria.setCriteriaID(Integer.toString(currentCriteria
					.createWithAutoIncrement()));

			if (Integer.parseInt(currentCriteria.getCriteriaID()) < 0) {
				currentCriteria.setCriteriaID(null);
				System.out.println("Could not create new criteria... ");
			} else {
				System.out.println("new criteria created "
						+ currentCriteria.getCriteriaID());
			}
		}

		try {
			BufferedReader reader = new BufferedReader(
					(type.equals("mm")) ? new FileReader(
							"C:\\eclipse\\workspace\\first\\HelloWorld\\meg.properties")
							: new FileReader(
									"C:\\eclipse\\workspace\\first\\HelloWorld\\pwb.properties"));

			// Reads until the end-of-file met
			while (reader.ready()) {
				// Read line-by-line directly
				String line = reader.readLine();
				if (!line.startsWith("start")) {
					if (line.length() > 0) {
						CriteriaResultEntity globalcre = new CriteriaResultEntity();
						String[] frqNumbersArrays = line.split("\\;");
						if (frqNumbersArrays.length < 1000) {
							for (int k = 0; k < frqNumbersArrays.length; k++) {
								CriteriaResultEntity cre = new CriteriaResultEntity();
								String skipVals = "";
								String freqLast5Vals = "";
								ArrayList<Integer> a = new ArrayList<Integer>();
								String[] indivFreqNumbers = frqNumbersArrays[k]
										.split("\\,");
								for (int j = 0; j < indivFreqNumbers.length; j++) {
									int num = 0;
									if (indivFreqNumbers[j] != null) {
										num = Integer
												.parseInt(indivFreqNumbers[j]);

									} else {
										num = 0;
									}
									a.add(num);

									skipVals += " "
											+ n.skipHashCurrent.get(num) + " ";
									freqLast5Vals += " "
											+ n.freqInLast25.get(num) + " ";

									if (j == 0) {

										cre.setFirstValue(Integer.toString(num));
										if (n.skipHashCurrent.get(num) != null)
											cre.setFirstSkip(n.skipHashCurrent
													.get(num).toString());

										if (n.freq.get(num) != null)
											cre.setFirstFreq((String) n.freq
													.get(num));
									}
									if (j == 1) {
										cre.setSecondValue(Integer
												.toString(num));

										if (n.skipHashCurrent.get(num) != null)
											cre.setSecondSkip(n.skipHashCurrent
													.get(num).toString());

										if (n.freq.get(num) != null)
											cre.setSecondFreq((String) n.freq
													.get(num));
									}
									if (j == 2) {
										cre.setThirdValue(Integer.toString(num));

										if (n.skipHashCurrent.get(num) != null)
											cre.setThirdSkip(n.skipHashCurrent
													.get(num).toString());

										if (n.freq.get(num) != null)
											cre.setThirdFreq((String) n.freq
													.get(num));
									}
									if (j == 3) {
										cre.setFourthValue(Integer
												.toString(num));

										if (n.skipHashCurrent.get(num) != null)
											cre.setFourthSkip(n.skipHashCurrent
													.get(num).toString());

										if (n.freq.get(num) != null)
											cre.setFourthFreq((String) n.freq
													.get(num));
									}
									if (j == 4) {
										cre.setFifthValue(Integer.toString(num));

										if (n.skipHashCurrent.get(num) != null)
											cre.setFifthSkip(n.skipHashCurrent
													.get(num).toString());

										if (n.freq.get(num) != null)
											cre.setFifthFreq((String) n.freq
													.get(num));
									}

								}
								cre.setFirstFiveSum( Integer.toString(
										Integer.parseInt(cre.getFirstValue()) +
										Integer.parseInt(cre.getSecondValue())+
										Integer.parseInt(cre.getThirdValue()) +
										Integer.parseInt(cre.getFourthValue())+
										Integer.parseInt(cre.getFifthValue())
											));
								Integer[] arr = new Integer[a.size()];
								a.toArray(arr);

								cre.setStarCount(Integer.toString(GeneratorVTwo
										.getStarCount(arr)));

								String prinOut = n
										.freqAppearanceMapForATestComb(10, arr)
										+ "|"
										+ skipVals
										+ "|"
										+ freqLast5Vals
										+ "|"
										+ AnalyzeOutput.getSimilarCombs(arr);
								;

								// Do not print combs which return no matches
								// for example - Check Suspended 20140117
								// 8 13 36 38 42 140 153 155 158 155 Range : 64
								// - 168----*--------*------**--*----| 1 16 25
								// 35 17 | 2 2 null null 2 |Matches ---NONE
								// if (!prinOut.endsWith("Matches ---NONE")) {
								// // Stoppnig this check
								// String[] elems = prinOut.split("\\ |	");

								cre.setCriteriaID(currentCriteria
										.getCriteriaID());

								cre.setFrequencyMap(prinOut.substring(
										prinOut.indexOf("|") - maxValue,
										prinOut.indexOf("|")));

								if (currentCriteria.getCriteriaID() != null)
									globalcre.getListOfCriteriaResults().add(cre);
								// System.out.println(prinOut.substring(8));
								// }

							}
							
							if (globalcre.create()) 
								System.out.println("Added " +globalcre.getListOfCriteriaResults().size() + " results. ");
							
						} else {
							System.out
									.println("More than 1000 results. Can not print...");
						}
					}

				}

			}
			reader.close();

		} catch (IOException ex) {
			ex.printStackTrace();
		}

	}

	public static Properties getDBpredicProp() {
		return DBpredicProp;
	}

	public static void setDBpredicProp(Properties dBpredicProp) {

		if (dBpredicProp == null) {
			if (DBpredicProp.isEmpty()) {
				try {

					if (predicFileName != null) {
						FileInputStream fis = new FileInputStream(new File(
								predicFileName));
						// "C:\\eclipse\\workspace\\first\\Pred\\PredFor" +
						// nextDate + "-"+
						// getInPrgCode().toUpperCase()
						DBpredicProp.load(fis);
					} else {
						System.out
								.println("Generator.java ---- No prediction file "
										+ predicFileName
										+ " exists. Setting empty predicProperties.");
						DBpredicProp.setProperty("EMPTYPREDICPROP", "EMPTY");
					}

				} catch (FileNotFoundException e) {
					System.out
							.println("Generator.java ---- No prediction file "
									+ predicFileName
									+ " exists. Setting empty predicProperties.");
					DBpredicProp.setProperty("EMPTYPREDICPROP", "EMPTY");

				} catch (IOException e) {
					System.out
							.println("Generator.java ---- Can not read prediction file "
									+ predicFileName
									+ " exists. Setting empty predicProperties.");
					DBpredicProp.setProperty("EMPTYPREDICPROP", "EMPTY");

				}
			}
		} else {
			DBpredicProp = dBpredicProp;
		}

		String FIRSTFIVESUMPRIME = DBpredicProp
				.getProperty("FIRSTFIVESUMPRIME");
		if (FIRSTFIVESUMPRIME != null && FIRSTFIVESUMPRIME.length() > 0) {
			int startInd = FIRSTFIVESUMPRIME.indexOf("[") + 1;
			if (startInd > 0) {
				String val = FIRSTFIVESUMPRIME.substring(startInd,
						FIRSTFIVESUMPRIME.indexOf("]"));

				String[] valA = val.split("\\,");
				List lis = (List) Arrays.asList(valA);

				if (FIRSTFIVESUMPRIME.indexOf("NOT") < 0) {

					if (valA[0].equals("0")) {
						currentCriteria.setFirstFiveSumPrimeInd("false");
					} else {
						currentCriteria.setFirstFiveSumPrimeInd("true");
					}
				} else {
					if (valA[0].equals("0")) {
						currentCriteria.setFirstFiveSumPrimeInd("true");
					} else {
						currentCriteria.setFirstFiveSumPrimeInd("false");
					}
				}
			}
		}

		String FIRSTFIVESUM = DBpredicProp.getProperty("FIRSTFIVESUM");

		if (FIRSTFIVESUM != null && FIRSTFIVESUM.length() > 0) {

			if (FIRSTFIVESUM.indexOf("EVEN") >= 0)
				currentCriteria.setFirstFiveSumEvenInd("Y");

			if (FIRSTFIVESUM.indexOf("ODD") >= 0)
				currentCriteria.setFirstFiveSumOddInd("Y");

			int startInd = FIRSTFIVESUM.indexOf("[") + 1;
			if (startInd > 0) {
				String val = FIRSTFIVESUM.substring(startInd,
						FIRSTFIVESUM.indexOf("]"));

				if (FIRSTFIVESUM.indexOf("NOT") >= 0)
					currentCriteria.setFirstFiveSumExcludeBucketList(val);
				else
					currentCriteria.setFirstFiveSumIncludeBucketList(val);
			}

		}

		String MATCH3DIFFS = DBpredicProp.getProperty("MATCH3DIFFS");

		if (MATCH3DIFFS != null && MATCH3DIFFS.length() > 0) {
			if (MATCH3DIFFS.equalsIgnoreCase("Y"))
				currentCriteria.setMatch3DiffInd("true");
			else
				currentCriteria.setMatch3DiffInd("false");
		}

		// currentCriteria.setTargetDrawDate(predicFileName.substring(predicFileName.indexOf("PredFor")+7,predicFileName.indexOf("PredFor")+11));
		currentCriteria.setTargetDrawDate(forDate);

		if (gameCode == null) {
			gte = new GameTypesEntity();
			gameCode = gte.findGameCodeByProgramCode(type);

			currentCriteria.setTargetGameCode(gameCode);
		} else {
			currentCriteria.setTargetGameCode(gameCode);
		}

		// currentCriteria.setMiss3Diff(miss3Diff);

		String OBSINCLUDECOUNT = DBpredicProp.getProperty("OBSINCLUDECOUNT");

		if (OBSINCLUDECOUNT != null && OBSINCLUDECOUNT.length() > 0) {
			currentCriteria.setObsIncludeCount(OBSINCLUDECOUNT);

		}
	}

}
