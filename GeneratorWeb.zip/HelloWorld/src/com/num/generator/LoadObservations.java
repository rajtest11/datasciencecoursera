package com.num.generator;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Calendar;
import java.util.StringTokenizer;

import com.num.generator.dataaccess.ObservationsEntity;

public class LoadObservations {
	
	public static void main(String[] args) {
		
//		File f = new File("C:\\eclipse\\workspace\\first\\HelloWorld\\obs.csv");
//		
//		BufferedReader in;
//		try {
//			in = new BufferedReader(new FileReader(f));
//		
//			String line;
//			
//			while ((line = in.readLine()) != null) {
//				String[] vals = null;
//				
//				if (line.contains(","))
//					vals = line.split("\\,");
//				else
//					vals = line.split(" ");
//				
//				Calendar cal = Calendar.getInstance();
//				cal.set(Calendar.YEAR, 2000 + Integer.parseInt(vals[0].substring(6)));
//				cal.set(Calendar.MONTH, Integer.parseInt(vals[0].substring(0,2))-1);
//				cal.set(Calendar.DAY_OF_MONTH, Integer.parseInt(vals[0].substring(3,5)));
//
//				int imon = cal.get(Calendar.MONTH) + 1;
//				String smon = ((imon < 10) ? "0" : "") + (Integer.toString(imon));
//				int iday = cal.get(Calendar.DAY_OF_MONTH);
//				String sday = ((iday < 10) ? "0" : "") + (Integer.toString(iday));
//				int iyear = cal.get(Calendar.YEAR);
//				String syear = Integer.toString(iyear);
//						
//				System.out.print("Col ");
//				System.out.print(syear+smon+sday + " ");
//				
//				for (int i=0; i<vals.length; i++) {
//					if (i > 0 && i < 16) {
//						if (vals[i].length() > 0) {
//						
//							ObservationsEntity oe = new ObservationsEntity();
//									
//							oe.setDateOfObs(syear+smon+sday);
//							oe.setSequence(Integer.toString(i-1));
//							oe.setNumber(vals[i]);
//							
//							oe.setDayOfTheWeek(Integer.toString(cal.get(Calendar.DAY_OF_WEEK)));
//								
//							if (!oe.exists()) {
//								System.out.print(i + ":" + vals[i] + " ");
//								oe.create();
//							} else {
//								System.out.print(i + ":" + vals[i] + " exists.");
//							}
//							
//						}
//					}
//					
//				}
//				System.out.println();
//			}
//		} catch (FileNotFoundException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		} catch (IOException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
		
		loadData("20140919", " 12 34      45 ");
	}
	
	public static void loadData (String date, String numbers) {

		int numbersCount = 0;
		
		Calendar cal = Calendar.getInstance();
		cal.set(Calendar.YEAR, Integer.parseInt(date.substring(0,4)));
		cal.set(Calendar.MONTH, Integer.parseInt(date.substring(4,6))-1);
		cal.set(Calendar.DAY_OF_MONTH, Integer.parseInt(date.substring(6,8)));

		int imon = cal.get(Calendar.MONTH) + 1;
		String smon = ((imon < 10) ? "0" : "") + (Integer.toString(imon));
		int iday = cal.get(Calendar.DAY_OF_MONTH);
		String sday = ((iday < 10) ? "0" : "") + (Integer.toString(iday));
		int iyear = cal.get(Calendar.YEAR);
		String syear = Integer.toString(iyear);
				
		System.out.print("Col ");
		System.out.print(syear+smon+sday + " ");
		
		String[] vals = null;
		
		if (numbers.contains(",")) {
			vals = numbers.split("\\,");
		} else {
			vals = numbers.split(" ");
		}
		
		
		for (int i=0; i<vals.length; i++) {
			if (i < 16) {
				if (vals[i].length() > 0) {
				
					ObservationsEntity oe = new ObservationsEntity();
							
					oe.setDateOfObs(syear+smon+sday);
					oe.setSequence(Integer.toString(i+1));
					oe.setNumber(vals[i]);
					
					oe.setDayOfTheWeek(Integer.toString(cal.get(Calendar.DAY_OF_WEEK)));
						
					if (!oe.exists()) {
						System.out.print((numbersCount+1) + ":" + vals[i] + " ");
						oe.create();
					} else {
						System.out.print((numbersCount+1) + ":" + vals[i] + " exists.");
					}
					numbersCount++;
				}
			}
			
		}
		System.out.println();
	
	}

}
