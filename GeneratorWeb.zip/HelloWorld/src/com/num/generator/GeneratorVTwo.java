package com.num.generator;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;


public class GeneratorVTwo {
	
	private static HashMap<String,ArrayList<ArrayList<Integer>>> possibleLists = new HashMap<String,ArrayList<ArrayList<Integer>>>();
	private static HashMap<String,ArrayList<Integer>> starredLists = new HashMap<String,ArrayList<Integer>>();
	private static String forDate = null;


	GeneratorVTwo(){
		if (possibleLists.size() == 0)
			createPossibleLists();
	
	}
	
	public static String getForDate() {
		return forDate;
	}

	public static void setForDate(String forDate) {
		GeneratorVTwo.forDate = forDate;
	}

	public static void main(String[] args) {
		
		if (possibleLists.size() == 0)
			createPossibleLists();
		
	
		
		/*for(ArrayList<Integer> innerLs : possibleLists.get("1")) {
			for(int arrayItem : innerLs)
			 {
			    System.out.println(arrayItem);
			 }

	    }*/
		
		printPossibleCombs();
		int[] test = new int[] {2,65,23,34,56};
		isPossibleComb(test);
		
	}
	
	public static boolean isPossibleComb(int[] test) {

		boolean out = false;
		
		if (getForDate() == null)
			return true;
		
		if (possibleLists.size() == 0)
			createPossibleLists();
		
		int count = 0;
		int starCount = 0;
		
		for (int i=1; i<= test.length; i++) {
			
			/*if (i ==4)
				System.out.print("Hi");*/
			
			if (starredLists.get(Integer.toString(i)) != null) {
				ArrayList<Integer> starList = starredLists.get(Integer.toString(i));
				
				if (starList.contains(Integer.valueOf(test[i-1]))) {
					starCount++;
				}
			}
			
			if (possibleLists.get(Integer.toString(i)) != null) {
				for(ArrayList<Integer> innermLs : possibleLists.get(Integer.toString(i))) {
					//System.out.println(count + " " + innerLs + " " + innerjLs + " " + innerkLs + " " + innerlLs + " " + innermLs);
					
					if (innermLs.contains(Integer.valueOf(test[i-1]))) {
						count++;
						break;
					}
					/*for(int arrayItem : innermLs)
					 {
					    System.out.println(arrayItem);
					 }*/
	
				}
				
				if (count < i) break;
			} else {
				//count++;
			}
			
			
		}
		
		if (count == possibleLists.size() && (starCount > 0 && starCount < 4)) 
			return true;
		
		return out;
		
	}
	
	public static int getStarCount(Integer[] test) {
		int starCount = 0;
		
		for (int i=1; i<= test.length; i++) {
			
			/*if (i ==4)
				System.out.print("Hi");*/
			
			if (starredLists.get(Integer.toString(i)) != null) {
				ArrayList<Integer> starList = starredLists.get(Integer.toString(i));
				
				if (starList.contains(Integer.valueOf(test[i-1]))) {
					starCount++;
				}
			}
		
		}
		
		return starCount;
	}

	private static void printPossibleCombs() {
		//ArrayList<ArrayList<Integer>> list1 = possibleLists.get("FIRST");
		
		int count = 0;
		
		for (int i = 1; i<= possibleLists.size(); i++) {
			System.out.println("-----------" + i + "-------");
			for(ArrayList<Integer> innerLs : possibleLists.get(i)) {
				
				for (int j = i+1; j<= possibleLists.size(); j++) {
					for(ArrayList<Integer> innerjLs : possibleLists.get(j)) {
						
						for (int k = j+1; k<= possibleLists.size(); k++) {
							for(ArrayList<Integer> innerkLs : possibleLists.get(k)) {

								for (int l = k+1; l<= possibleLists.size(); l++) {
									for(ArrayList<Integer> innerlLs : possibleLists.get(l)) {

										for (int m = l+1; m<= possibleLists.size(); m++) {
											for(ArrayList<Integer> innermLs : possibleLists.get(m)) {
												System.out.println(count + " " + innerLs + " " + innerjLs + " " + innerkLs + " " + innerlLs + " " + innermLs);
												count++;
											}
										} 
									}
								} 
							}
						} 
					}
				}
				
				
		    }
			
		}
		
		
		 
	}

	public static void createPossibleLists(){
		
		if (getForDate() != null) {
		
		File m = new File(
				"C:\\eclipse\\workspace\\first\\Pred\\possibleLists" + getForDate());
		try {
			BufferedReader in = new BufferedReader(new FileReader(m));
			String line;
			String listName = null;
			
			while ((line = in.readLine()) != null) {
				if (line.length() > 0) {
					line = line.replaceAll("\\s+","");
					
					if (line.indexOf("[") >= 0) {
						ArrayList<Integer> lis = new ArrayList<Integer>();
						int startInd = line.indexOf("[") + 1;
							if (startInd > 0) {
								String val = line.substring(startInd, line.indexOf("]") );

								String[] valA = val.split("\\,");
								
								for (int k=0; k< valA.length; k++) {
									if (valA[k].length() > 0)
										lis.add(Integer.parseInt(valA[k]));
								}
							}
							
							if (lis.size() > 0) {
								if (possibleLists.get(listName) != null) {
									possibleLists.get(listName).add(lis);
								}
								
								if (line.indexOf("*") >= 0) {
									starredLists.put(listName, lis );
								}
							}
						
					} else {
						listName = line.trim();
						
						possibleLists.put(listName, new ArrayList<ArrayList<Integer>>() );
					}
				}
				
				
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	} 
	} 
}
