package com.num.generator;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;

public class AnalyzeOutput {

	public AnalyzeOutput(String gametype) {
		super();
		gameType = gametype;
		
	}

	private static Properties prop = new Properties();
	private static HashMap<Integer, Integer> freq = new HashMap();
	private static ArrayList<String> results = new ArrayList<String>();
	static String gameType = ""; // mm or pb

	public static void main(String[] args) {

		if (args != null && args.length >0) {
			gameType = args[0];
		}
		
		FileInputStream fis;
		//gameType = ""; // mm or pb or frq
		File f = null;
		try {
			
			if (gameType.length() == 0) {
				fis = new FileInputStream(
						new File(
								"C:\\Users\\johris\\git\\git\\Generator\\props.properties"));
	
				prop.load(fis);
				
				gameType = prop.getProperty("type");
			}
			
			if (gameType.equals("frq")) {
				f = new File(
						"C:\\Users\\johris\\git\\git\\HelloWorld\\frqs.properties");
			}

			if (gameType.equals("mm")) {
				f = new File(
						"C:\\Users\\johris\\git\\git\\HelloWorld\\meg.properties");
			}

			if (gameType.equals("pb")) {
				f = new File(
						"C:\\Users\\johris\\git\\git\\HelloWorld\\pwb.properties");
			}

			BufferedReader in = new BufferedReader(new FileReader(f));
			String line = null;

			while ((line = in.readLine()) != null) {
				if (!(line.startsWith("start") || line.startsWith("Start"))) {
					String[] combs = line.split(";");

					for (int i = 0; i < combs.length; i++) {
						String[] nums = combs[i].split(",");
						
						if (Integer.parseInt(nums[4]) > 64) {
							line.replace(combs[i], "");
						}
							
						for (int j = 0; j < nums.length; j++) {
							if (freq.containsKey(new Integer(nums[j]))) {
								int count = freq.get(new Integer(nums[j]));
								freq.put(new Integer(nums[j]), count + 1);
							} else {
								freq.put(new Integer(nums[j]), 1);
							}
						}
					}
				}
				System.out.println(line);
			}

			System.out.print(sortByValueDes(freq));
			System.out.println(" SIZE " + freq.size());
			
			/*printSimilarCombs(new int[]{14,  19,  26,  29,  35});
			printSimilarCombs(new int[]{12,  19,  29,  33,  36});

			printSimilarCombs(new int[]{7, 14, 19, 28, 46});
			printSimilarCombs(new int[]{7, 14, 19, 25, 41});
			printSimilarCombs(new int[]{4, 19, 26, 29, 33});
			printSimilarCombs(new int[]{1, 21, 26, 33, 38 });
			printSimilarCombs(new int[]{11, 19, 23, 38, 56});
			printSimilarCombs(new int[]{8, 11, 19, 35, 38});
			*/
			
			printSimilarCombs(new int[]{25,27,36,42,44    });
		
			
			

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	
	private static void printSimilarCombs(int[] input) {
		FileInputStream fis;
		//gameType = ""; // mm or pb or frq
		File f = null;
		int matches = 0;
		
		if (gameType.equals("mm")) {
			f = new File("C:\\Users\\johris\\git\\git\\HelloWorld\\mm.txt");
		} else {
			f = new File("C:\\Users\\johris\\git\\git\\HelloWorld\\pb.txt");
		}
		
		
			System.out.print("Matches for : " + input[0] + " " + input[1] + " " + input[2] + " " + input[3] + " " + input[4] + "---" );
			
			if (results.size() == 0) {
				BufferedReader in;
				try {
					in = new BufferedReader(new FileReader(f));
				
				String line = null;
				while ((line = in.readLine()) != null) {
					results.add(line);
					
				}
				} catch (FileNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (NumberFormatException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			

			int lineNum = 0;
			Iterator<String> it = results.iterator();
			while (it.hasNext()) {
				String line = it.next();
				int similar = 0;
				if (!(line.startsWith("start") || line.startsWith("Start"))) {
				
					String[] nums = line.split(",");

					for (int j = 0; j < nums.length; j++) {
						int thisNum = 0;
						if (j < nums.length -1) {
							thisNum = Integer.parseInt(nums[j].trim());
						} else {
							String[] lasttwo = nums[j].split("\\+");
							thisNum = Integer.parseInt(lasttwo[0].trim());
						}
						
						//for (int x=0;x<input.length;x++) {
							if (input[j]>=thisNum && (input[j]-thisNum < 2))
								similar ++;
							if (input[j]<thisNum && (thisNum - input[j] < 2))
								similar ++;
						//	}
					}
					if (similar > 3) {
						//System.out.println( lineNum + " - " + line + " matches : " + similar);
						System.out.print( lineNum + " - " + similar + " | ");
						matches++;
					}
					
				}
				lineNum++;
			}
			if (matches == 0)
				System.out.println("NONE");
			else
				System.out.println("");
		
		
	}
	
	
	public static int getSimilarCombs(Integer[] input) { // 3 or more numbers within +-2 of this comb
		FileInputStream fis;
		//gameType = ""; // mm or pb or frq
		File f = null;
		String out = "";
		int matches = 0;
		
		if (gameType.equals("mm")) {
			f = new File("C:\\Users\\johris\\git\\git\\HelloWorld\\mm.txt");
		} else {
			f = new File("C:\\Users\\johris\\git\\git\\HelloWorld\\pb.txt");
		}
		
		BufferedReader in;
		try {
			in = new BufferedReader(new FileReader(f));
		
		String line = null;
		int lineNum = 0;
			out = "Matches ---" ;
			while ((line = in.readLine()) != null) {
				int similar = 0;
				if (!(line.startsWith("start") || line.startsWith("Start"))) {
				
					String[] nums = line.split(",");

					for (int j = 0; j < nums.length; j++) {
						int thisNum = 0;
						if (j < nums.length -1) {
							thisNum = Integer.parseInt(nums[j].trim());
						} else {
							String[] lasttwo = nums[j].split("\\+");
							thisNum = Integer.parseInt(lasttwo[0].trim());
						}
						
						//for (int x=0;x<input.length;x++) {
							if (input[j]>=thisNum && (input[j]-thisNum < 2))
								similar ++;
							if (input[j]<thisNum && (thisNum - input[j] < 2))
								similar ++;
						//	}
					}
					if (similar > 3) {
						//System.out.println( lineNum + " - " + line + " matches : " + similar);
						out +=  lineNum + " - " + similar + " | ";
						matches++;
					}
					
				}
				lineNum++;
			}
			if (matches == 0)
				out +="NONE";
			else
				out += "";
		
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		//System.out.println(out);
		return matches;
	}

	public static ArrayList<String> getResults() {
		return results;
	}

	public static void setResults(ArrayList<String> results) {
		AnalyzeOutput.results = results;
	}

	public static List sortByValueDes(final Map m) {
		List keys = new ArrayList();
		keys.addAll(m.keySet());
		Collections.sort(keys, new Comparator() {
			public int compare(Object o1, Object o2) {
				Object v1 = m.get(o1);
				Object v2 = m.get(o2);
				if (v1 == null) {
					return (v2 == null) ? 0 : 1;
				} else if (v2 instanceof Comparable) {
					return ((Comparable) v2).compareTo(v1);
				} else {
					return 0;
				}
			}
		});
		return keys;
	}

}
