package com.num.generator.webscraper;

import java.io.IOException;
import java.net.MalformedURLException;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import com.gargoylesoftware.htmlunit.BrowserVersion;
import com.gargoylesoftware.htmlunit.FailingHttpStatusCodeException;
import com.gargoylesoftware.htmlunit.WebClient;
import com.gargoylesoftware.htmlunit.html.HtmlPage;
import com.num.generator.Numbers;
import com.num.generator.SynchInput;
import com.num.generator.dataaccess.DBUtils;

public class GameSiteOpen {

	/**
	 * @param args
	 */
	
	public static boolean fromBatchProgram =  false;
	
	public static void main(String[] args) {
		final WebClient webClient = new WebClient(BrowserVersion.CHROME);
		
		webClient.getOptions().setThrowExceptionOnFailingStatusCode(false);
		webClient.getOptions().setThrowExceptionOnScriptError(false);
		
	    HtmlPage page, pageMM;
	    SynchInput.fromBatchProgram = true;
		try {
			
			page = webClient.getPage("http://www.powerball.com/powerball/pb_numbers.asp");
		//	pageMM = webClient.getPage("http://www.powerball.com/megamillions/mm_numbers.asp");
			
			pageMM = webClient.getPage("http://www.megamillions.com/winning-numbers/last-25-drawings");
		
			// Assert.assertEquals("HtmlUnit - Welcome to HtmlUnit", page.getTitleText());

			//final String pageAsXml = page.asXml();
			// Assert.assertTrue(pageAsXml.contains("<body class=\"composite\">"));
			//System.out.print(pageAsXml);
			
			System.out.println();
			Numbers.addLineToFile("C:\\temp\\MyGameScraper.log", "" , false);
			Calendar cal = Calendar.getInstance();
	    	SimpleDateFormat sdf = new SimpleDateFormat("EEE, MMM d, ''yy HH:mm:ss");
	    	Numbers.addLineToFile("C:\\temp\\MyGameScraper.log", " GAMESITEOPEN STARTING AT: " + sdf.format(cal.getTime()) , false);
			
			final String pageAsText = page.asText();
			final String pageAsTextMM = pageMM.asText();
			//System.out.print(pageAsText);
			//Assert.assertTrue(pageAsText.contains("Support for the HTTP and HTTPS protocols"));
			
			
			String impSection = pageAsText.substring(pageAsText.indexOf("Draw Date"), pageAsText.indexOf("Every attempt"));
			impSection = impSection.replaceAll("	", ",");
			impSection = impSection.replaceAll(", ,","+");
			//impSection = impSection.replaceAll("\n","||");
			
			String[] splits = impSection.split("\r\n");
			//System.out.println(impSection);
			// Collect all new sets in pb.txt
			for (int c=splits.length-1; c>3; c--) {
				if ( Character.isDigit(splits[c].charAt(0)) ) {
					String line = splits[c].substring(splits[c].indexOf(",")+1, splits[c].length()-2);
					System.out.println (line);				
					
					if (Numbers.findStringInFile("C:\\Users\\johris\\git\\git\\HelloWorld\\pb.txt", line) < 0) {
						Numbers.addLineToFile("C:\\Users\\johris\\git\\git\\HelloWorld\\pb.txt", line, true); 
						if (fromBatchProgram)
							Numbers.addLineToFile("C:\\temp\\MyGameScraper.log", "Line " + line + " Added to " +" C:\\Users\\johris\\git\\git\\HelloWorld\\pb.txt" , false);
						
						/*DBUtils dbu = new DBUtils();
						dbu.getCurrentInclusionAndExclusionsForAllAttributes("2");*/
					}
					else {
						if (fromBatchProgram)
							Numbers.addLineToFile("C:\\temp\\MyGameScraper.log", "Line " + line + " Already exists in " +"C:\\Users\\johris\\git\\git\\HelloWorld\\pb.txt" , false);
					}
				}
			}
			
			SynchInput.main(new String[]{"pb"});
			
			String impSectionMM = pageAsTextMM.substring(pageAsTextMM.indexOf("Draw Date"), pageAsTextMM.indexOf("Most states"));
			
			String[] resultsArr = impSectionMM.split("Details\r\n");
			
			String[] top3Results = {"","",""};
			
			for (int x=0; x<3; x++) {
				resultsArr[x+1] = resultsArr[x+1].replaceAll("\t", ",");
				resultsArr[x+1] = resultsArr[x+1].replaceAll(", ,","+");
				
				String[] splitresult = resultsArr[x+1].split(" ,");
				for (int p=1; p<7; p++) {
					top3Results[x] += splitresult[p].trim();
					
					if (p < 5) 
						top3Results[x] += ",";
					else if (p < 6)
						top3Results[x] += "+";
				}
			}
			
			
			
			//impSectionMM = impSectionMM.replaceAll("	", ",");
			//impSectionMM = impSectionMM.replaceAll(", ,","+");
			//impSection = impSection.replaceAll("\n","||");h
			
			//String[] splitsMM = impSectionMM.split("\r\n");
			//System.out.println(impSection);
			// Collect all new sets in mm.txt
			for (int c=top3Results.length-1; c>=0; c--) {
				if ( Character.isDigit(top3Results[c].charAt(0)) ) {
					//String lineMM = top3Results[c].substring(top3Results[c].indexOf(",")+1, top3Results[c].length()-2);
					String lineMM = top3Results[c];
					System.out.println (lineMM);
					
					if (Numbers.findStringInFile("C:\\Users\\johris\\git\\git\\HelloWorld\\mm.txt", lineMM) < 0) {
						Numbers.addLineToFile("C:\\Users\\johris\\git\\git\\HelloWorld\\mm.txt", lineMM, true);
						if (fromBatchProgram)
							Numbers.addLineToFile("C:\\temp\\MyGameScraper.log", "Line " + lineMM + " Added to " +" C:\\Users\\johris\\git\\git\\HelloWorld\\mm.txt" , false);
						
						/*DBUtils dbu = new DBUtils();
						dbu.getCurrentInclusionAndExclusionsForAllAttributes("1");*/
					}
					else {
						if (fromBatchProgram)
							Numbers.addLineToFile("C:\\temp\\MyGameScraper.log", "Line " + lineMM + " Already exists in " +"C:\\Users\\johris\\git\\git\\HelloWorld\\mm.txt" , false);
					}
				}
			}
			
			SynchInput.main(new String[]{"mm"});
			/*final HtmlTable table = page.getHtmlElementById("table1");
			for (final HtmlTableRow row : table.getRows()) {
			    System.out.println("Found row");
			    for (final HtmlTableCell cell : row.getCells()) {
			        System.out.println("   Found cell: " + cell.asText());
			    }
			}*/
			
			//Numbers.addLineToFile("C:\\Game\\ran.txt.txt", line, true);
			
			Numbers.addLineToFile("C:\\temp\\MyGameScraper.log", " GAMESITEOPEN RAN AT: " + sdf.format(cal.getTime()) , false);
			
	    	webClient.closeAllWindows();
	    	System.exit(0);
		} catch (FailingHttpStatusCodeException e) {
			if (fromBatchProgram)
			Numbers.addLineToFile("C:\\temp\\MyGameScraper.log", "EXCEPTION " + e.getMessage() , false);
		} catch (MalformedURLException e) {
			if (fromBatchProgram)
			Numbers.addLineToFile("C:\\temp\\MyGameScraper.log", "EXCEPTION " + e.getMessage() , false);
		} catch (IOException e) {
			if (fromBatchProgram)
			Numbers.addLineToFile("C:\\temp\\MyGameScraper.log", "EXCEPTION " + e.getMessage() , false);
		}
	}

}
