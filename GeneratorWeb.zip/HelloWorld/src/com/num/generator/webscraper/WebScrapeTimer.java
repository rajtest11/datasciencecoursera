package com.num.generator.webscraper;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Timer;
import java.util.TimerTask;

import com.num.generator.Numbers;

public class WebScrapeTimer extends TimerTask {
    @Override
    public void run() {
    	Calendar nowCal = Calendar.getInstance();
    	long start = System.currentTimeMillis();
    	SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy:hh:mm:ss");
    	String out = "\r\nStarted GameSiteOpen at " + format.format(nowCal.getTime());
    	Numbers.addLineToFile("C:\\temp\\MyGameScraper.log","\n", false);
    	Numbers.addLineToFile("C:\\temp\\MyGameScraper.log", out , false);
    	GameSiteOpen.fromBatchProgram = true;
        GameSiteOpen.main(null);
        
        out = "Completed GameSiteOpen after " + (System.currentTimeMillis() - start) + " ms.";
        Numbers.addLineToFile("C:\\temp\\MyGameScraper.log", out , false);
        Numbers.addLineToFile("C:\\temp\\MyGameScraper.log","\r\n", false);
    }

    public void start() {
        Timer timer = new Timer();
        timer.scheduleAtFixedRate(this, 5 *  1000 , 60 * 360 * 1000);
    }

    public static void main(String[] args) {
    	WebScrapeTimer schedular = new WebScrapeTimer();
        schedular.start();
    }
}