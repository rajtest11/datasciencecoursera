package com.rj.lott;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

public class FileReader {

	/**
	 * @param args
	 */
	private static String csvfilelocation="C:\\eclipse\\workspace\\first\\HelloWorld\\Lott.csv";
	
	private static FileInputStream fstream;
	private static DataInputStream in;
	private static BufferedReader br;
	
	private static int WEEKS_PAST = 10;
	private static int DISPLAY_SIZE = 10;  // Used to display things like most frequently observed numbers
	
	private static TreeMap mainhash = new TreeMap();   // Contains date and a corresponding value object which have collection of obs and res For all dates
	private static TreeMap obsMap = new TreeMap();  // Contains obs and its freq
	private static TreeMap resMap = new TreeMap();   // Contains res and its freq
	
	private static TreeMap obsDatesMap = new TreeMap();  // Contains obs and the dates associated
	private static TreeMap resDatesMap = new TreeMap();   // Contains res and the dates associated
	
	
	private static TreeMap obsCoAppMap = new TreeMap();   // Contains obs and a table of co-appearing obs with their freq
	private static TreeMap resCoAppMap = new TreeMap();	  // Contains res and a table of co-appearing res with their freq
	
	
	public static void main(String[] args) {
		String date = null;
		
		if (args.length > 0 ) {
			date = args[0];
		}
		 
		readfileAndbuildhash(date);
		  
		  buildMainMaps(date,WEEKS_PAST);
		  
		  
		  System.out.println(DISPLAY_SIZE + " Numbers least frequently observed..");
			int x = 0;
			for (Iterator i = sortByValueAsc(obsMap).iterator(); i.hasNext(); ) {
				if (x > DISPLAY_SIZE-1) break;
	            String key = (String) i.next();
	            System.out.printf("%s : (%s)\t", key, obsMap.get(key));
	            x++;
	        }
			if (obsMap.size() >DISPLAY_SIZE) System.out.println("...");
			
			x = 0;
			System.out.println(DISPLAY_SIZE + " Numbers most frequently observed..");
			for (Iterator i = sortByValueDes(obsMap).iterator(); i.hasNext(); ) {
				if (x > DISPLAY_SIZE-1) break;
	            String key = (String) i.next();
	            System.out.printf("%s : (%s)\t", key, obsMap.get(key));
	            x++;
	        }
			if (obsMap.size() >DISPLAY_SIZE) System.out.println("...");
			
			System.out.println(DISPLAY_SIZE + " Numbers least frequently seen in result..");
			x = 0;
			for (Iterator i = sortByValueAsc(resMap).iterator(); i.hasNext(); ) {
				if (x > DISPLAY_SIZE-1) break;
	            String key = (String) i.next();
	            System.out.printf("%s : (%s)\t", key, resMap.get(key));
	            x++;
	        }
			if (resMap.size() >DISPLAY_SIZE) System.out.println("...");
			
			x = 0;
			System.out.println(DISPLAY_SIZE + " Numbers most frequently seen in result..");
			for (Iterator i = sortByValueDes(resMap).iterator(); i.hasNext(); ) {
				if (x > DISPLAY_SIZE-1) break;
	            String key = (String) i.next();
	            System.out.printf("%s : (%s)\t", key, resMap.get(key));
	            x++;
	        }
			if (resMap.size() >DISPLAY_SIZE) System.out.println("...");
			
			System.out.println();
			buildCoAppearanceMaps();
			//System.out.println("-------------Result Coappearance Map----------------------");
			//printCoappearanceMap(resCoAppMap);
			
			analyzePastResultsAndObs(date, WEEKS_PAST);
	}

	private static void readfileAndbuildhash(String date) {
		try{
		    fstream = new FileInputStream(csvfilelocation);
		    // Get the object of DataInputStream
		    in = new DataInputStream(fstream);
		    br = new BufferedReader(new InputStreamReader(in));
		    String strLine;
		    //Read File Line By Line
		    while ((strLine = br.readLine()) != null)   {
		      // System.out.println (strLine);
		      buildHash(strLine, date);
		      
		    }
		   
		    //Close the input stream
		    in.close();
		    }catch (Exception e){//Catch exception if any
		      System.err.println("Error: " + e.getMessage());
		    }
	}
	
	private static void buildMainMaps(String enddate, int weekspast) {
		
		String startDate = null;
		Calendar cal = Calendar.getInstance();
		if(enddate == null) {
			int imon = cal.get(Calendar.MONTH)+1;
			String smon = ((imon < 10)?"0":"") + (Integer.toString(imon));
			int iday = cal.get(Calendar.DAY_OF_MONTH);
			String sday = ((iday < 10)?"0":"") + (Integer.toString(iday));
			int iyear = cal.get(Calendar.YEAR);
			String syear = Integer.toString(iyear % 2000);
			enddate = smon + "/" + sday + "/" + syear;
			
			Calendar startcal = (Calendar)cal.clone();
			startcal.add(Calendar.WEEK_OF_YEAR, 0-weekspast);
			
			imon = startcal.get(Calendar.MONTH)+1;
			smon = ((imon < 10)?"0":"") + (Integer.toString(imon));
			iday = startcal.get(Calendar.DAY_OF_MONTH);
			sday = ((iday < 10)?"0":"") + (Integer.toString(iday));
			iyear = startcal.get(Calendar.YEAR);
			syear = Integer.toString(iyear % 2000);
			startDate = smon + "/" + sday + "/" + syear;
		} else {
			Calendar startcal = (Calendar)cal.clone();
			
			startcal.set(Calendar.MONTH, Integer.parseInt(enddate.substring(0,2))-1);
			startcal.set(Calendar.DAY_OF_MONTH, Integer.parseInt(enddate.substring(3,5)));
			startcal.set(Calendar.YEAR, 2000 + Integer.parseInt(enddate.substring(6,8)));
			
			startcal.add(Calendar.WEEK_OF_YEAR, 0-weekspast);
			
			int imon = startcal.get(Calendar.MONTH)+1;
			String smon = ((imon < 10)?"0":"") + (Integer.toString(imon));
			int iday = startcal.get(Calendar.DAY_OF_MONTH);
			String sday = ((iday < 10)?"0":"") + (Integer.toString(iday));
			int iyear = startcal.get(Calendar.YEAR);
			String syear = Integer.toString(iyear % 2000);
			startDate = smon + "/" + sday + "/" + syear;
		}
		
		System.out.println("Date range " + startDate + " : " + enddate + " - Weeks " + weekspast);
		
		Iterator it = mainhash.keySet().iterator();
		
		while (it.hasNext()) {
			String sdate = (String)it.next();
			//System.out.println("Processing date " + sdate);
				
			if (sdate.compareTo(enddate) <= 0 && sdate.compareTo(startDate) >= 0 ) {
				Value v = (Value)mainhash.get(sdate);
				
				if (v.getObservations() != null) {
					Iterator obsIt = v.getObservations().getNumbers().iterator();
					while (obsIt.hasNext()) {
						String num = (String)obsIt.next();
						if (obsMap.get(num) == null) {
							obsMap.put(num, Integer.valueOf(1));
							obsDatesMap.put(num, new ArrayList());
							((ArrayList)obsDatesMap.get(num)).add(sdate);
						}
						else {
							obsMap.put(num, Integer.valueOf(((Integer)obsMap.get(num)).intValue() + 1));
							((ArrayList)obsDatesMap.get(num)).add(sdate);
						}
					}
					
				}
				
				if (v.getResult() != null) {
					Iterator resIt = v.getResult().getNumbers().iterator();
					while (resIt.hasNext()) {
						String num = (String)resIt.next();
						if (resMap.get(num) == null) {
							resMap.put(num, Integer.valueOf(1));
							resDatesMap.put(num, new ArrayList());
							((ArrayList)resDatesMap.get(num)).add(sdate);
						}
						else {
							resMap.put(num, Integer.valueOf(((Integer)resMap.get(num)).intValue() + 1));
							((ArrayList)resDatesMap.get(num)).add(sdate);
						}
					}
					
				}
			}
		}
		
	}
	
	public static void buildCoAppearanceMaps() {
		Iterator it = mainhash.values().iterator();
		
		while (it.hasNext()) {
			Value val = (Value) it.next();
			
			if (val.getObservations() != null) {
				Iterator itobs = val.getObservations().getNumbers().iterator();
				
				while (itobs.hasNext()) {
					String num = (String) itobs.next();
					TreeMap internalMap = new TreeMap();
					
					HashSet set = new HashSet();
					Iterator itobsinternal = val.getObservations().getNumbers().iterator();
					while (itobsinternal.hasNext()) {
						String numinternal = (String) itobsinternal.next();
						if (!num.equals(numinternal))
							set.add(numinternal);
					}
					if (obsCoAppMap.get(num) == null) {
						obsCoAppMap.put(num, addUniqueEntriesAndIncrementDups(internalMap,set));
					} else {
						internalMap = (TreeMap) obsCoAppMap.get(num);
						obsCoAppMap.put(num, addUniqueEntriesAndIncrementDups(internalMap,set));
					}
				}
			}
			
			if (val.getResult() != null) {
				Iterator itres = val.getResult().getNumbers().iterator();
				
				while (itres.hasNext()) {
					String num = (String) itres.next();
					TreeMap internalMap = new TreeMap();
					
					HashSet set = new HashSet();
					Iterator itresinternal = val.getResult().getNumbers().iterator();
					while (itresinternal.hasNext()) {
						String numinternal = (String) itresinternal.next();
						if (!num.equals(numinternal))
							set.add(numinternal);
					}
					if (resCoAppMap.get(num) == null) {
						resCoAppMap.put(num, addUniqueEntriesAndIncrementDups(internalMap,set));
					} else {
						internalMap = (TreeMap) resCoAppMap.get(num);
						resCoAppMap.put(num, addUniqueEntriesAndIncrementDups(internalMap,set));
					}
				}
			}
		}
	}
	
	private static void analyzePastResultsAndObs(String enddate, int weekspast) {
		PB pbobj = new PB();
		MM mmobj = new MM();
		
		pbobj.setNotSeenLastFewButInResult(new ArrayList());
		pbobj.setNotSeenLastFewWeeks(new ArrayList());
		pbobj.setSeenLastFewWeeksAndInResult(new ArrayList());
		pbobj.setNotSeenInResult(new ArrayList());
		
		mmobj.setNotSeenLastFewButInResult(new ArrayList());
		mmobj.setNotSeenLastFewWeeks(new ArrayList());
		mmobj.setSeenLastFewWeeksAndInResult(new ArrayList());
		mmobj.setNotSeenInResult(new ArrayList());
		
		for (int i=1;i<=pbobj.getHighest();i++) {
			pbobj.getNotSeenLastFewButInResult().add(Integer.toString(i));
			pbobj.getNotSeenLastFewWeeks().add(Integer.toString(i));
			pbobj.getNotSeenInResult().add(Integer.toString(i));
			//pbobj.getSeenLastFewWeeksAndInResult().add(Integer.toString(i));
		}
		
		for (int i=1;i<=mmobj.getHighest();i++) {
			mmobj.getNotSeenLastFewButInResult().add(Integer.toString(i));
			mmobj.getNotSeenLastFewWeeks().add(Integer.toString(i));
			mmobj.getNotSeenInResult().add(Integer.toString(i));
			//mmobj.getSeenLastFewWeeksAndInResult().add(Integer.toString(i));
		}
		
		if (mainhash == null || mainhash.size() == 0)
			buildMainMaps(enddate, weekspast);
		
		Iterator obsIt = obsMap.keySet().iterator();

		while (obsIt.hasNext()) {
			String ob = (String)obsIt.next();
			pbobj.getNotSeenLastFewWeeks().remove(ob);
			mmobj.getNotSeenLastFewWeeks().remove(ob);
			
			pbobj.getNotSeenLastFewButInResult().remove(ob);
			mmobj.getNotSeenLastFewButInResult().remove(ob);
			
			pbobj.getSeenLastFewWeeksAndInResult().add(ob);
			mmobj.getSeenLastFewWeeksAndInResult().add(ob);
			
		}
		
		Iterator resDatesIt = resDatesMap.keySet().iterator();
		
		while (resDatesIt.hasNext()) {
			String res = (String)resDatesIt.next();
			ArrayList dates = (ArrayList)resDatesMap.get(res);
			
			Iterator datesIt = dates.iterator();
			while (datesIt.hasNext()) {
				String date = (String) datesIt.next();
				Result resObj = new Result();
				String lotttype = resObj.getLottType(date);
				
				if (lotttype != null &&  lotttype.equals("MM"))
					mmobj.getNotSeenInResult().remove(res);	
				
				if (lotttype != null &&  lotttype.equals("PB"))
					pbobj.getNotSeenInResult().remove(res);	
			}
			
		}
	
		ArrayList obinpbresclone = (ArrayList)pbobj.getNotSeenLastFewButInResult().clone();
		Iterator itobinpbres =obinpbresclone.iterator();
		while (itobinpbres.hasNext()) {
			String num = (String) itobinpbres.next();
			ArrayList datesofres = (resDatesMap.containsKey(num))?(ArrayList) resDatesMap.get(num):null;
			
			if (datesofres == null )
				pbobj.getNotSeenLastFewButInResult().remove(num);
			else {
				Iterator datesit = datesofres.iterator();
				boolean pbtype = false;
				while (datesit.hasNext()) {
					String date = (String) datesit.next();
					if (Result.getLottType(date).equals("PB")) pbtype = true;
				}
				if (!pbtype) pbobj.getNotSeenLastFewButInResult().remove(num);
			}
		}
		
		obinpbresclone = (ArrayList)pbobj.getSeenLastFewWeeksAndInResult().clone();
		itobinpbres =obinpbresclone.iterator();
		while (itobinpbres.hasNext()) {
			String num = (String) itobinpbres.next();
			ArrayList datesofres = (resDatesMap.containsKey(num))?(ArrayList) resDatesMap.get(num):null;
			
			if (datesofres == null )
				pbobj.getSeenLastFewWeeksAndInResult().remove(num);
			else {
				Iterator datesit = datesofres.iterator();
				boolean pbtype = false;
				while (datesit.hasNext()) {
					String date = (String) datesit.next();
					if (Result.getLottType(date).equals("PB")) pbtype = true;
				}
				if (!pbtype) pbobj.getSeenLastFewWeeksAndInResult().remove(num);
			}
		}
		
		ArrayList obinmmresclone = (ArrayList)mmobj.getNotSeenLastFewButInResult().clone();
		Iterator itobinmmres = obinmmresclone.iterator();
		while (itobinmmres.hasNext()) {
			String num = (String) itobinmmres.next();
			ArrayList datesofres = (resDatesMap.containsKey(num))?(ArrayList) resDatesMap.get(num):null;
			
			if (datesofres == null )
				mmobj.getNotSeenLastFewButInResult().remove(num);
			else {
				Iterator datesit = datesofres.iterator();
				boolean mmtype = false;
				while (datesit.hasNext()) {
					String date = (String) datesit.next();
					if (Result.getLottType(date).equals("MM")) mmtype = true;
				}
				if (!mmtype) mmobj.getNotSeenLastFewButInResult().remove(num);
			}
		}
		
		obinmmresclone = (ArrayList)mmobj.getSeenLastFewWeeksAndInResult().clone();
		itobinmmres = obinmmresclone.iterator();
		while (itobinmmres.hasNext()) {
			String num = (String) itobinmmres.next();
			ArrayList datesofres = (resDatesMap.containsKey(num))?(ArrayList) resDatesMap.get(num):null;
			
			if (datesofres == null )
				mmobj.getSeenLastFewWeeksAndInResult().remove(num);
			else {
				Iterator datesit = datesofres.iterator();
				boolean mmtype = false;
				while (datesit.hasNext()) {
					String date = (String) datesit.next();
					if (Result.getLottType(date).equals("MM")) mmtype = true;
				}
				if (!mmtype) mmobj.getSeenLastFewWeeksAndInResult().remove(num);
			}
		}
		
		
		System.out.print("Numbers not observed");
		printList(pbobj.getNotSeenLastFewWeeks(), 100);
		
		System.out.println("----------PB analysis----------");
		System.out.print("Not seen but in res");
		printList(pbobj.getNotSeenLastFewButInResult(), 20);
		System.out.print("Seen and in res	");
		printList(pbobj.getSeenLastFewWeeksAndInResult(), 20);
		System.out.print("Not Seen in res	");
		printList(pbobj.getNotSeenInResult(), 20);
		
		System.out.println("----------MM analysis----------");
		System.out.print("Not seen but in res");
		printList(mmobj.getNotSeenLastFewButInResult(), 20);
		System.out.print("Seen and in res	");
		printList(mmobj.getSeenLastFewWeeksAndInResult(), 20);
		System.out.print("Not Seen in res	");
		printList(mmobj.getNotSeenInResult(), 20);
		
	}
	
	private static Map addUniqueEntriesAndIncrementDups(Map oldMap, Collection entries) {
		Iterator it = entries.iterator();
		
		while (it.hasNext()) {
			String num = (String) it.next();
			if (oldMap.get(num) == null)
				oldMap.put(num, Integer.valueOf(1));
			else
				oldMap.put(num, Integer.valueOf(((Integer)oldMap.get(num)).intValue() + 1));
		}
		
		return oldMap;
	}
	
	 public static List sortByValueAsc(final Map m) {
	        List keys = new ArrayList();
	        keys.addAll(m.keySet());
	        Collections.sort(keys, new Comparator() {
	            public int compare(Object o1, Object o2) {
	                Object v1 = m.get(o1);
	                Object v2 = m.get(o2);
	                if (v1 == null) {
	                    return (v2 == null) ? 0 : 1;
	                }
	                else if (v1 instanceof Comparable) {
	                    return ((Comparable) v1).compareTo(v2);
	                }
	                else {
	                    return 0;
	                }
	            }
	        });
	        return keys;
	    }
	 
	 public static List sortByValueDes(final Map m) {
	        List keys = new ArrayList();
	        keys.addAll(m.keySet());
	        Collections.sort(keys, new Comparator() {
	            public int compare(Object o1, Object o2) {
	                Object v1 = m.get(o1);
	                Object v2 = m.get(o2);
	                if (v1 == null) {
	                    return (v2 == null) ? 0 : 1;
	                }
	                else if (v2 instanceof Comparable) {
	                    return ((Comparable) v2).compareTo(v1);
	                }
	                else {
	                    return 0;
	                }
	            }
	        });
	        return keys;
	    }
	 
	 private static void printCoappearanceMap(TreeMap input) {
		 Iterator it = input.keySet().iterator();
		 
		 while (it.hasNext()) {
			 String corenum = (String)it.next();
			 System.out.println(corenum);
			 printMap((TreeMap)input.get(corenum),4);
		 }
		 
	 }
	
	private static void printMap(TreeMap map, int depth) {
		int x=0;
		for (Iterator i = sortByValueDes(map).iterator(); i.hasNext(); ) {
			if (x > depth) break;
            String key = (String) i.next();
            System.out.printf("\t%s : (%s)", key, map.get(key));
            x++;
        }
		System.out.println("...");
	}
	
	private static void printList(List l, int depth) {
		int x=0;
		for (Iterator i = l.iterator(); i.hasNext(); ) {
			if (x > depth-1) break;
            String key = (String) i.next();
            System.out.printf("\t%s", key);
            x++;
        }
		if (l.size() > depth) System.out.println("...");
		else  System.out.println("");
	}
	 
	private static void buildHash(String input, String date) {
		if (Character.isDigit(input.charAt(0))) { // Line is like 01/17/11,"Mon",17,,38,39,,,,,,,,,,,,,,,,,,,,,,,,8,,38,39,,,,,,,,,,,,
			//System.out.println ("First char of line: " + input.charAt(0));
			String [] elements = input.split(",");
			Result oneres = new Result();
			Observations oneobs = new Observations();
			Value val = new Value();
			
			String sdate = elements[0];
			
			if (sdate.length()> 0 && sdate.compareTo(date) <= 0) {
				if (elements.length > 5 && elements[5].length()>0) {
					
					ArrayList nums = new ArrayList();
					if (elements[4] != null && elements[4].length() > 0)
						nums.add(elements[4]);
					if (elements[5] != null && elements[5].length() > 0)
						nums.add(elements[5]);
					if (elements.length > 6 && elements[6].length() > 0)
						nums.add(elements[6]);
					if (elements.length > 7 && elements[7].length() > 0)
						nums.add(elements[7]);
					if (elements.length > 8 && elements[8].length() > 0)
						nums.add(elements[8]);
					if (elements.length > 9 && elements[9].length() > 0)
						nums.add(elements[9]);
					if (elements.length > 10 && elements[10].length() > 0)
						nums.add(elements[10]);
					if (elements.length > 11 && elements[11].length() > 0)
						nums.add(elements[11]);
					if (elements.length > 12 && elements[12].length() > 0)
						nums.add(elements[12]);
					if (elements.length > 13 && elements[13].length() > 0)
						nums.add(elements[13]);
					if (elements.length > 14 && elements[14].length() > 0)
						nums.add(elements[14]);
					if (elements.length > 15 && elements[15].length() > 0)
						nums.add(elements[15]);
					if (elements.length > 16 && elements[16].length() > 0)
						nums.add(elements[16]);
					if (elements.length > 17 && elements[17].length() > 0)
						nums.add(elements[17]);
					if (elements.length > 18 && elements[18].length() > 0)
						nums.add(elements[18]);
					
					oneobs.setNumbers(nums);
					oneobs.setDate(elements[0]);
					val.setObservations(oneobs);
				}
				
				if (elements.length > 19 && elements[19].length()>0) {
				
					ArrayList nums = new ArrayList();
					if (elements[19].length() > 0)
						nums.add(elements[19]);
					if (elements[20].length() > 0)
						nums.add(elements[20]);
					if (elements[21].length() > 0)
						nums.add(elements[21]);
					if (elements[22].length() > 0)
						nums.add(elements[22]);
					if (elements[23].length() > 0)
						nums.add(elements[23]);
					if (elements[24].length() > 0)
						nums.add(elements[24]);
					
					oneres.setNumbers(nums);
					if (elements[24].length() > 0)
						oneres.setLast(elements[24]);
					oneres.setDate(elements[0]);
					
					val.setResult(oneres);
				}
				
				mainhash.put(elements[0],val);
				//System.out.println("Data for date " + elements[0] + " added.");
			}
			
		}
	}
	
	

}
