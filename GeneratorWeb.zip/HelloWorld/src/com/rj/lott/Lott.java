package com.rj.lott;

public abstract class Lott {

}
