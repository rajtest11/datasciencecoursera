package com.rj.lott;

public class Value {
	private Observations observations;
	public Observations getObservations() {
		return observations;
	}
	public void setObservations(Observations observations) {
		this.observations = observations;
	}
	public Result getResult() {
		return result;
	}
	public void setResult(Result result) {
		this.result = result;
	}
	private Result result;

}
