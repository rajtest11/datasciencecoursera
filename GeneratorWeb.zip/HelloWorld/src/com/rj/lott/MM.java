package com.rj.lott;

import java.util.ArrayList;

public class MM extends Lott {
	private static final int highest=56;
	private static final int highmegaball=46;

	private static ArrayList notSeenLastFewWeeks;
	public static ArrayList getNotSeenLastFewWeeks() {
		return notSeenLastFewWeeks;
	}

	public static void setNotSeenLastFewWeeks(ArrayList notSeenLastFewWeeks) {
		MM.notSeenLastFewWeeks = notSeenLastFewWeeks;
	}

	public static ArrayList getNotSeenLastFewButInResult() {
		return notSeenLastFewButInResult;
	}

	public static void setNotSeenLastFewButInResult(
			ArrayList notSeenLastFewButInResult) {
		MM.notSeenLastFewButInResult = notSeenLastFewButInResult;
	}

	public static ArrayList getSeenLastFewWeeksAndInResult() {
		return seenLastFewWeeksAndInResult;
	}

	public static void setSeenLastFewWeeksAndInResult(
			ArrayList seenLastFewWeeksAndInResult) {
		MM.seenLastFewWeeksAndInResult = seenLastFewWeeksAndInResult;
	}

	private static ArrayList notSeenLastFewButInResult;
	private static ArrayList seenLastFewWeeksAndInResult;
	private static ArrayList notSeenInResult;

	
	public static ArrayList getNotSeenInResult() {
		return notSeenInResult;
	}

	public static void setNotSeenInResult(ArrayList notSeenInResult) {
		MM.notSeenInResult = notSeenInResult;
	}

	public static int getHighest() {
		return highest;
	}
	
	public static int getHighmegaball() {
		return highmegaball;
	}
}
