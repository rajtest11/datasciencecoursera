package com.rj.lott;

import java.util.Collection;
import java.util.List;

public class Observations {

	private String date;
	
	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public List getNumbers() {
		return numbers;
	}

	public void setNumbers(List numbers) {
		this.numbers = numbers;
	}

	private List numbers;
}
