package com.rj.lott;

import java.util.Calendar;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

public class Result {

	private List numbers;
	public List getNumbers() {
		return numbers;
	}
	public void setNumbers(List numbers) {
		this.numbers = numbers;
	}
	public String getLast() {
		return last;
	}
	public void setLast(String last) {
		this.last = last;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public Lott getLottType() {
		
		if (getDate() != null) {
			Calendar cal = Calendar.getInstance();
			cal.set(Calendar.MONTH, Integer.parseInt(getDate().substring(0,2)));
			cal.set(Calendar.DAY_OF_MONTH, Integer.parseInt(getDate().substring(3,5)));
			//cal.set(Calendar.YEAR, Integer.parseInt(getDate().substring(0,2))); // AUTOMATIC
			
			if ((cal.get(Calendar.DAY_OF_WEEK) == Calendar.TUESDAY) || (cal.get(Calendar.DAY_OF_WEEK) == Calendar.FRIDAY)) {
				return new MM();
			}
			
			if ((cal.get(Calendar.DAY_OF_WEEK) == Calendar.WEDNESDAY) || (cal.get(Calendar.DAY_OF_WEEK) == Calendar.SATURDAY)) {
				return new PB();
			}
				
		}
		return null;
	}
	
	public static int compareResults(Result res1, Result res2) {
		int match = 0;
		
		if (res1.getNumbers() == null || res2.getNumbers() == null || res1.getLast()== null || res2.getLast() == null)
			return match;
		
		Iterator it = res1.getNumbers().iterator();
		
		while (it.hasNext()) {
			String num = (String) it.next();
			if (res2.getNumbers().contains(num))
					match++;
		}
		
		if (res1.getLast().equals(res2.getLast()))
			match++;
		
		return match;
	}
	
public static String getLottType(String date) {
		
		if (date != null) {
			Calendar cal = Calendar.getInstance();
			cal.set(Calendar.MONTH, Integer.parseInt(date.substring(0,2))-1);
			cal.set(Calendar.DAY_OF_MONTH, Integer.parseInt(date.substring(3,5)));
			//cal.set(Calendar.YEAR, Integer.parseInt(getDate().substring(0,2))); // AUTOMATIC
			
			if ((cal.get(Calendar.DAY_OF_WEEK) == Calendar.TUESDAY) || (cal.get(Calendar.DAY_OF_WEEK) == Calendar.FRIDAY)) {
				return "MM";
			}
			
			if ((cal.get(Calendar.DAY_OF_WEEK) == Calendar.WEDNESDAY) || (cal.get(Calendar.DAY_OF_WEEK) == Calendar.SATURDAY)) {
				return "PB";
			}
				
		}
		return "";
	}
	public void setLottType(String lottType) {
		this.lottType = lottType;
	}
	private String last;
	private String date;
	private String lottType; // whether MM or PB
}
