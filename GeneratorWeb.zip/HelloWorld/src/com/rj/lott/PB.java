package com.rj.lott;

import java.util.ArrayList;

public class PB extends Lott {
	private static final int highest=69;
	private static final int highpowerball=26;
	
	private static ArrayList notSeenLastFewWeeks;
	
	public static ArrayList getNotSeenLastFewWeeks() {
		return notSeenLastFewWeeks;
	}

	public static void setNotSeenLastFewWeeks(ArrayList notSeenLastFewWeeks) {
		PB.notSeenLastFewWeeks = notSeenLastFewWeeks;
	}

	public static ArrayList getNotSeenLastFewButInResult() {
		return notSeenLastFewButInResult;
	}

	public static void setNotSeenLastFewButInResult(
			ArrayList notSeenLastFewButInResult) {
		PB.notSeenLastFewButInResult = notSeenLastFewButInResult;
	}

	public static ArrayList getSeenLastFewWeeksAndInResult() {
		return seenLastFewWeeksAndInResult;
	}

	public static void setSeenLastFewWeeksAndInResult(
			ArrayList seenLastFewWeeksAndInResult) {
		PB.seenLastFewWeeksAndInResult = seenLastFewWeeksAndInResult;
	}

	private static ArrayList notSeenLastFewButInResult;
	private static ArrayList seenLastFewWeeksAndInResult;
	private static ArrayList notSeenInResult;

	public static ArrayList getNotSeenInResult() {
		return notSeenInResult;
	}

	public static void setNotSeenInResult(ArrayList notSeenInResult) {
		PB.notSeenInResult = notSeenInResult;
	}

	public static int getHighest() {
		return highest;
	}
	
	public static int getHighpowerball() {
		return highpowerball;
	}
	
}
